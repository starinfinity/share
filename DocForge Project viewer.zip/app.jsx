const { useState, useEffect, useRef, useMemo } = React;

/* ---------- Dropdown ---------- */
function Dropdown({ label, value, placeholder, options, onChange, disabled, renderOption, width }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const ref = useRef(null);

  useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  useEffect(() => { if (!open) setQuery(""); }, [open]);

  const filtered = useMemo(() => {
    if (!query) return options;
    return options.filter(o => o.value.toLowerCase().includes(query.toLowerCase()) || (o.label || "").toLowerCase().includes(query.toLowerCase()));
  }, [options, query]);

  return (
    <div ref={ref} style={{ position: "relative", width: width || 280 }}>
      <div style={{ fontSize: 11, fontFamily: "Geist Mono", letterSpacing: 0.5, textTransform: "uppercase", color: "var(--ink-3)", marginBottom: 6 }}>{label}</div>
      <button
        onClick={() => !disabled && setOpen(o => !o)}
        disabled={disabled}
        style={{
          width: "100%",
          background: disabled ? "var(--bg-2)" : "var(--surface)",
          color: disabled ? "var(--ink-3)" : "var(--ink)",
          border: `1px solid ${open ? "var(--accent)" : "var(--line-2)"}`,
          borderRadius: "var(--radius)",
          padding: "12px 14px",
          height: 48,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          textAlign: "left",
          boxShadow: open ? "0 0 0 3px var(--accent-soft)" : "var(--shadow-sm)",
          transition: "border-color 120ms, box-shadow 120ms, background 120ms",
          cursor: disabled ? "not-allowed" : "pointer",
          fontSize: 15,
          fontWeight: 500,
        }}>
        <span style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0, flex: 1 }}>
          {value ? (renderOption ? renderOption(options.find(o => o.value === value), true) : value) : <span style={{ color: "var(--ink-3)", fontWeight: 400 }}>{placeholder}</span>}
        </span>
        <Icon.chevDown style={{ color: "var(--ink-2)", transform: open ? "rotate(180deg)" : "none", transition: "transform 140ms" }} />
      </button>

      {open && (
        <div style={{
          position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0,
          background: "var(--surface)",
          border: "1px solid var(--line-2)",
          borderRadius: "var(--radius)",
          boxShadow: "var(--shadow-lg)",
          zIndex: 50,
          overflow: "hidden",
        }}>
          <div style={{ padding: 8, borderBottom: "1px solid var(--line)", display: "flex", alignItems: "center", gap: 8 }}>
            <Icon.search style={{ color: "var(--ink-3)", marginLeft: 4 }} />
            <input
              autoFocus
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder={`Search ${label.toLowerCase()}…`}
              style={{ flex: 1, border: 0, outline: 0, background: "transparent", fontSize: 13, fontFamily: "inherit", color: "var(--ink)" }}
            />
          </div>
          <div style={{ maxHeight: 320, overflowY: "auto", padding: 4 }}>
            {filtered.length === 0 && (
              <div style={{ padding: "16px 12px", color: "var(--ink-3)", fontSize: 13, textAlign: "center" }}>No matches</div>
            )}
            {filtered.map(o => {
              const selected = o.value === value;
              return (
                <button
                  key={o.value}
                  onClick={() => { onChange(o.value); setOpen(false); }}
                  style={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    padding: "10px 10px",
                    border: 0,
                    background: selected ? "var(--accent-soft)" : "transparent",
                    color: "var(--ink)",
                    borderRadius: 6,
                    textAlign: "left",
                    cursor: "pointer",
                    fontSize: 14,
                  }}
                  onMouseEnter={e => { if (!selected) e.currentTarget.style.background = "var(--bg-2)"; }}
                  onMouseLeave={e => { if (!selected) e.currentTarget.style.background = "transparent"; }}>
                  <span style={{ flex: 1, minWidth: 0 }}>{renderOption ? renderOption(o, false) : o.value}</span>
                  {selected && <Icon.check style={{ color: "var(--accent-ink)" }} />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Avatar ---------- */
function Avatar({ initials, size = 24 }) {
  const palette = ["#b4502b", "#2a4d7a", "#2f6b3c", "#7a4b8a", "#a8651f"];
  const hash = (initials || "").split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const color = palette[hash % palette.length];
  return (
    <span style={{
      width: size, height: size, borderRadius: "50%",
      background: color, color: "#fff",
      display: "inline-flex", alignItems: "center", justifyContent: "center",
      fontSize: size * 0.42, fontWeight: 600, letterSpacing: 0.3, flexShrink: 0,
    }}>{initials}</span>
  );
}

/* ---------- Nav ---------- */
function Nav({ currentUser, onUserChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const user = FS[currentUser];

  return (
    <header style={{
      position: "sticky", top: 0, zIndex: 100,
      background: "rgba(247,245,240,0.85)",
      backdropFilter: "blur(8px)",
      borderBottom: "1px solid var(--line)",
    }}>
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "14px 32px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Icon.logo />
          <span style={{ fontWeight: 700, fontSize: 17, letterSpacing: -0.2 }}>DocForge</span>
          <span className="mono" style={{ marginLeft: 6, padding: "2px 6px", fontSize: 10, color: "var(--ink-3)", border: "1px solid var(--line-2)", borderRadius: 4 }}>v2.4</span>
        </div>

        <nav style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <a href="#" style={navLink}>How it works</a>
          <a href="#" style={{ ...navLink, display: "inline-flex", alignItems: "center", gap: 6 }}>
            <Icon.github /> Github Integration
          </a>

          <div ref={ref} style={{ position: "relative", marginLeft: 8 }}>
            <button onClick={() => setOpen(o => !o)} style={{
              display: "flex", alignItems: "center", gap: 8,
              background: open ? "var(--bg-2)" : "transparent",
              border: "1px solid var(--line-2)",
              borderRadius: 999,
              padding: "5px 10px 5px 5px",
              color: "var(--ink)",
              fontSize: 13, fontWeight: 500,
            }}>
              <Avatar initials={user.avatar} size={26} />
              <span>{currentUser}</span>
              <Icon.chevDown />
            </button>
            {open && (
              <div style={{
                position: "absolute", top: "calc(100% + 6px)", right: 0,
                background: "var(--surface)", border: "1px solid var(--line-2)",
                borderRadius: "var(--radius)", boxShadow: "var(--shadow-lg)",
                minWidth: 240, padding: 6, zIndex: 100,
              }}>
                <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--line)", marginBottom: 6 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{currentUser}</div>
                  <div style={{ fontSize: 12, color: "var(--ink-3)" }}>{user.role}</div>
                </div>
                <div style={{ fontSize: 11, fontFamily: "Geist Mono", textTransform: "uppercase", color: "var(--ink-3)", padding: "6px 10px" }}>Switch user</div>
                {USERS.map(u => (
                  <button key={u} onClick={() => { onUserChange(u); setOpen(false); }} style={menuItem(u === currentUser)}>
                    <Avatar initials={FS[u].avatar} size={20} />
                    <span style={{ flex: 1, textAlign: "left" }}>{u}</span>
                    {u === currentUser && <Icon.check style={{ color: "var(--accent-ink)" }} />}
                  </button>
                ))}
                <div style={{ borderTop: "1px solid var(--line)", marginTop: 6, paddingTop: 6 }}>
                  <button style={menuItem(false)}>Settings</button>
                  <button style={menuItem(false)}>Sign out</button>
                </div>
              </div>
            )}
          </div>
        </nav>
      </div>
    </header>
  );
}
const navLink = {
  padding: "8px 12px", borderRadius: 6,
  color: "var(--ink-2)", textDecoration: "none",
  fontSize: 13.5, fontWeight: 500,
};
const menuItem = (active) => ({
  display: "flex", alignItems: "center", gap: 10,
  width: "100%", padding: "8px 10px",
  border: 0, borderRadius: 6,
  background: active ? "var(--accent-soft)" : "transparent",
  color: "var(--ink)", fontSize: 13, cursor: "pointer",
});

/* ---------- Hero ---------- */
function Hero() {
  return (
    <section style={{ padding: "56px 0 28px", textAlign: "center" }}>
      <div style={{
        display: "inline-flex", alignItems: "center", gap: 8,
        padding: "5px 12px",
        background: "var(--accent-soft)", color: "var(--accent-ink)",
        border: "1px solid #ebccb5",
        borderRadius: 999,
        fontSize: 12, fontWeight: 500, marginBottom: 24,
      }}>
        <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--accent)" }}></span>
        <span className="mono" style={{ letterSpacing: 0.4 }}>projects/</span>
        <span>indexed across {USERS.length} engineers</span>
      </div>
      <h1 style={{
        fontSize: 88, lineHeight: 0.95, letterSpacing: -3.5,
        fontWeight: 700, margin: "0 0 16px",
      }}>
        Doc<span style={{ color: "var(--accent)", fontStyle: "italic", fontWeight: 600 }}>Forge</span>
      </h1>
      <p style={{
        fontSize: 18, color: "var(--ink-2)", maxWidth: 580, margin: "0 auto",
        lineHeight: 1.5, textWrap: "pretty",
      }}>
        A tool for project developers to browse, explore, and document codebases.
        Pick a user, pick a project — DocForge does the rest.
      </p>
    </section>
  );
}

/* ---------- Pickers ---------- */
function Pickers({ user, project, onUser, onProject, onReset }) {
  const userOptions = USERS.map(u => ({
    value: u,
    label: u,
    avatar: FS[u].avatar,
    role: FS[u].role,
  }));

  const projectOptions = user
    ? Object.entries(FS[user].projects).map(([name, p]) => ({
        value: name, label: name, updated: p.updated, files: p.files,
      }))
    : [];

  return (
    <section style={{ display: "flex", alignItems: "flex-end", gap: 16, padding: "0 0 28px" }}>
      <Dropdown
        label="Select User"
        placeholder="Choose a user…"
        value={user}
        options={userOptions}
        onChange={onUser}
        width={300}
        renderOption={(o, compact) => (
          <span style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
            <Avatar initials={o.avatar} size={compact ? 22 : 24} />
            <span style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
              <span style={{ fontWeight: 500, fontSize: compact ? 14 : 13, lineHeight: 1.2 }}>{o.value}</span>
              {!compact && <span style={{ fontSize: 11, color: "var(--ink-3)" }}>{o.role}</span>}
            </span>
          </span>
        )}
      />

      <Dropdown
        label="Select Project"
        placeholder={user ? "Choose a project…" : "Select a user first"}
        value={project}
        disabled={!user}
        options={projectOptions}
        onChange={onProject}
        width={340}
        renderOption={(o, compact) => (
          <span style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0, flex: 1 }}>
            <Icon.folder style={{ color: "var(--accent)" }} />
            <span style={{ display: "flex", flexDirection: compact ? "row" : "column", minWidth: 0, gap: compact ? 8 : 0, flex: 1, alignItems: compact ? "center" : "flex-start" }}>
              <span className="mono" style={{ fontSize: compact ? 13 : 13, fontWeight: 500, lineHeight: 1.2 }}>{o.value}</span>
              {!compact && (
                <span style={{ fontSize: 11, color: "var(--ink-3)", marginTop: 2 }}>
                  {o.files} files · updated {o.updated}
                </span>
              )}
            </span>
          </span>
        )}
      />

      {(user || project) && (
        <button onClick={onReset} style={{
          height: 48, padding: "0 14px",
          background: "transparent", color: "var(--ink-2)",
          border: "1px solid var(--line-2)", borderRadius: "var(--radius)",
          display: "inline-flex", alignItems: "center", gap: 6, fontSize: 13,
        }}>
          <Icon.reset /> Reset
        </button>
      )}

      <div style={{ flex: 1 }}></div>

      {project && (
        <div style={{ display: "flex", alignItems: "center", gap: 8, paddingBottom: 8, color: "var(--ink-3)", fontSize: 12 }} className="mono">
          <span>projects</span>
          <Icon.chevRight />
          <span>{user}</span>
          <Icon.chevRight />
          <span style={{ color: "var(--accent-ink)" }}>{project}</span>
        </div>
      )}
    </section>
  );
}

/* ---------- Empty states ---------- */
function EmptyState({ step }) {
  return (
    <div style={{
      border: "1px dashed var(--line-2)",
      borderRadius: "var(--radius)",
      background: "var(--surface)",
      padding: "64px 32px",
      textAlign: "center",
      color: "var(--ink-3)",
    }}>
      <div style={{
        width: 56, height: 56, borderRadius: 14,
        background: "var(--bg-2)",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        marginBottom: 16,
      }}>
        <Icon.folder style={{ width: 26, height: 26, color: "var(--ink-3)" }} />
      </div>
      <div style={{ fontSize: 15, fontWeight: 500, color: "var(--ink-2)" }}>
        {step === 1 ? "Pick a user to get started" : "Now choose a project"}
      </div>
      <div style={{ fontSize: 13, marginTop: 6 }}>
        {step === 1
          ? "Select a teammate from the dropdown above to see what they're working on."
          : "Their projects will appear in the second dropdown."}
      </div>
    </div>
  );
}

/* ---------- File list ---------- */
function FileList({ user, project }) {
  const data = FS[user].projects[project];
  const items = useMemo(() => {
    return [...data.items].sort((a, b) => {
      if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
  }, [data]);

  const folderCount = items.filter(i => i.type === "folder").length;
  const fileCount = items.filter(i => i.type === "file").length;

  const [hovered, setHovered] = useState(null);

  return (
    <div style={{
      background: "var(--surface)",
      border: "1px solid var(--line)",
      borderRadius: "var(--radius)",
      boxShadow: "var(--shadow-sm)",
      overflow: "hidden",
    }}>
      <div style={{
        padding: "14px 18px",
        borderBottom: "1px solid var(--line)",
        background: "var(--bg-2)",
        display: "flex", alignItems: "center", justifyContent: "space-between",
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Icon.folder style={{ color: "var(--accent)" }} />
          <span className="mono" style={{ fontWeight: 500, fontSize: 14 }}>{project}</span>
          <span style={{ fontSize: 12, color: "var(--ink-3)" }}>
            {folderCount} folders · {fileCount} files · updated {data.updated}
          </span>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <button style={chipBtn}><Icon.external /> Open in editor</button>
          <button style={chipBtn}><Icon.github /> Clone</button>
        </div>
      </div>

      <div style={{
        display: "grid",
        gridTemplateColumns: "auto 1fr auto auto",
        fontSize: 11, fontFamily: "Geist Mono", letterSpacing: 0.5, textTransform: "uppercase", color: "var(--ink-3)",
        padding: "10px 18px",
        borderBottom: "1px solid var(--line)",
      }}>
        <div style={{ width: 18 }}></div>
        <div style={{ paddingLeft: 12 }}>Name</div>
        <div style={{ paddingRight: 28 }}>Contents</div>
        <div style={{ width: 90 }}>Action</div>
      </div>

      <div>
        {items.map((it, i) => {
          const isFolder = it.type === "folder";
          const FileIcon = isFolder ? Icon.folder : pickFileIcon(it.name);
          const isHover = hovered === i;
          return (
            <div
              key={it.name}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
              style={{
                display: "grid",
                gridTemplateColumns: "auto 1fr auto auto",
                alignItems: "center",
                padding: "12px 18px",
                borderBottom: i === items.length - 1 ? 0 : "1px solid var(--line)",
                background: isHover ? "var(--bg-2)" : "transparent",
                transition: "background 80ms",
                cursor: "pointer",
              }}>
              <span style={{ display: "inline-flex", color: isFolder ? "var(--accent)" : "var(--ink-2)" }}>
                <FileIcon />
              </span>
              <div style={{ paddingLeft: 12, display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                <span className="mono" style={{ fontSize: 13.5, fontWeight: isFolder ? 500 : 400, color: "var(--ink)" }}>
                  {it.name}
                </span>
                {isFolder && <span style={{
                  fontSize: 10, padding: "2px 6px",
                  background: "var(--accent-soft)", color: "var(--accent-ink)",
                  borderRadius: 4, fontFamily: "Geist Mono", letterSpacing: 0.3,
                }}>folder</span>}
              </div>
              <div style={{ paddingRight: 28, color: "var(--ink-3)", fontSize: 12 }} className="mono">
                {isFolder ? `${it.count} items` : it.size}
              </div>
              <div style={{ width: 90, textAlign: "right" }}>
                <span style={{
                  display: "inline-flex", alignItems: "center", gap: 4,
                  fontSize: 12, color: isHover ? "var(--accent-ink)" : "var(--ink-3)",
                  transition: "color 80ms",
                }}>
                  {isFolder ? "Open" : "View"} <Icon.chevRight />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
const chipBtn = {
  display: "inline-flex", alignItems: "center", gap: 6,
  padding: "6px 10px",
  background: "var(--surface)", color: "var(--ink-2)",
  border: "1px solid var(--line-2)", borderRadius: 6,
  fontSize: 12, fontWeight: 500,
};

/* ---------- App ---------- */
function App() {
  const [currentUser, setCurrentUser] = useState("alice.chen"); // logged-in user (nav)
  const [user, setUser] = useState(null);   // browsing user
  const [project, setProject] = useState(null);

  const onUser = (u) => { setUser(u); setProject(null); };
  const onReset = () => { setUser(null); setProject(null); };

  let content;
  if (!user) content = <EmptyState step={1} />;
  else if (!project) content = <EmptyState step={2} />;
  else content = <FileList user={user} project={project} />;

  return (
    <div data-screen-label="DocForge Home">
      <Nav currentUser={currentUser} onUserChange={setCurrentUser} />
      <main style={{ maxWidth: 1180, margin: "0 auto", padding: "0 32px 80px" }}>
        <Hero />
        <Pickers user={user} project={project} onUser={onUser} onProject={setProject} onReset={onReset} />
        {content}

        <footer style={{ marginTop: 56, paddingTop: 24, borderTop: "1px solid var(--line)", display: "flex", justifyContent: "space-between", color: "var(--ink-3)", fontSize: 12 }}>
          <span className="mono">DocForge © 2026 — projects/ root mounted at /var/forge/projects</span>
          <span>Docs · Changelog · Status</span>
        </footer>
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
