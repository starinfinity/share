// Mock filesystem: projects/{username}/{project}/{...folders & files}
const FS = {
  "alice.chen": {
    avatar: "AC",
    role: "Frontend engineer",
    projects: {
      "design-system-v3": {
        updated: "2 hours ago",
        files: 142,
        items: [
          { type: "folder", name: "components", count: 38 },
          { type: "folder", name: "tokens", count: 12 },
          { type: "folder", name: "primitives", count: 24 },
          { type: "folder", name: "docs", count: 9 },
          { type: "file", name: "README.md", size: "4.2 KB" },
          { type: "file", name: "package.json", size: "1.8 KB" },
          { type: "file", name: "CHANGELOG.md", size: "12.4 KB" },
          { type: "file", name: "tsconfig.json", size: "612 B" },
        ],
      },
      "marketing-site": {
        updated: "yesterday",
        files: 87,
        items: [
          { type: "folder", name: "pages", count: 14 },
          { type: "folder", name: "content", count: 32 },
          { type: "folder", name: "public", count: 28 },
          { type: "file", name: "next.config.mjs", size: "1.1 KB" },
          { type: "file", name: "README.md", size: "2.0 KB" },
        ],
      },
      "auth-rewrite": {
        updated: "4 days ago",
        files: 63,
        items: [
          { type: "folder", name: "src", count: 41 },
          { type: "folder", name: "tests", count: 18 },
          { type: "folder", name: "migrations", count: 6 },
          { type: "file", name: "Dockerfile", size: "892 B" },
          { type: "file", name: ".env.example", size: "412 B" },
        ],
      },
    },
  },
  "bob.martinez": {
    avatar: "BM",
    role: "Backend engineer",
    projects: {
      "billing-service": {
        updated: "32 min ago",
        files: 218,
        items: [
          { type: "folder", name: "handlers", count: 56 },
          { type: "folder", name: "models", count: 34 },
          { type: "folder", name: "queues", count: 12 },
          { type: "folder", name: "migrations", count: 41 },
          { type: "file", name: "go.mod", size: "2.4 KB" },
          { type: "file", name: "Makefile", size: "1.6 KB" },
          { type: "file", name: "README.md", size: "8.1 KB" },
        ],
      },
      "analytics-pipeline": {
        updated: "today",
        files: 94,
        items: [
          { type: "folder", name: "etl", count: 28 },
          { type: "folder", name: "schemas", count: 14 },
          { type: "folder", name: "dashboards", count: 9 },
          { type: "file", name: "airflow.cfg", size: "3.2 KB" },
          { type: "file", name: "requirements.txt", size: "1.4 KB" },
        ],
      },
    },
  },
  "carlos.nguyen": {
    avatar: "CN",
    role: "Product designer",
    projects: {
      "onboarding-redesign": {
        updated: "1 hour ago",
        files: 41,
        items: [
          { type: "folder", name: "screens", count: 24 },
          { type: "folder", name: "prototypes", count: 8 },
          { type: "folder", name: "exports", count: 6 },
          { type: "file", name: "brief.md", size: "5.6 KB" },
          { type: "file", name: "research-notes.md", size: "11.2 KB" },
          { type: "file", name: "moodboard.pdf", size: "8.4 MB" },
        ],
      },
      "icon-library": {
        updated: "3 days ago",
        files: 312,
        items: [
          { type: "folder", name: "outline", count: 142 },
          { type: "folder", name: "filled", count: 142 },
          { type: "folder", name: "duotone", count: 24 },
          { type: "file", name: "index.svg", size: "284 KB" },
          { type: "file", name: "README.md", size: "1.9 KB" },
        ],
      },
      "brand-refresh-2026": {
        updated: "last week",
        files: 28,
        items: [
          { type: "folder", name: "logos", count: 12 },
          { type: "folder", name: "guidelines", count: 4 },
          { type: "file", name: "rationale.md", size: "9.8 KB" },
          { type: "file", name: "deck.pdf", size: "14.2 MB" },
        ],
      },
    },
  },
  "diana.park": {
    avatar: "DP",
    role: "ML engineer",
    projects: {
      "recsys-v2": {
        updated: "12 min ago",
        files: 76,
        items: [
          { type: "folder", name: "notebooks", count: 18 },
          { type: "folder", name: "training", count: 24 },
          { type: "folder", name: "evaluation", count: 14 },
          { type: "folder", name: "data", count: 8 },
          { type: "file", name: "model.py", size: "18.4 KB" },
          { type: "file", name: "config.yaml", size: "2.1 KB" },
        ],
      },
      "embedding-store": {
        updated: "2 days ago",
        files: 52,
        items: [
          { type: "folder", name: "index", count: 22 },
          { type: "folder", name: "benchmarks", count: 16 },
          { type: "file", name: "README.md", size: "6.4 KB" },
          { type: "file", name: "Cargo.toml", size: "1.2 KB" },
        ],
      },
    },
  },
  "evan.wright": {
    avatar: "EW",
    role: "Platform engineer",
    projects: {
      "infra-terraform": {
        updated: "5 hours ago",
        files: 156,
        items: [
          { type: "folder", name: "modules", count: 64 },
          { type: "folder", name: "environments", count: 38 },
          { type: "folder", name: "policies", count: 22 },
          { type: "file", name: "main.tf", size: "4.2 KB" },
          { type: "file", name: "variables.tf", size: "2.8 KB" },
          { type: "file", name: "README.md", size: "10.4 KB" },
        ],
      },
      "k8s-operator": {
        updated: "yesterday",
        files: 84,
        items: [
          { type: "folder", name: "controllers", count: 28 },
          { type: "folder", name: "api", count: 18 },
          { type: "folder", name: "config", count: 14 },
          { type: "file", name: "go.mod", size: "1.8 KB" },
          { type: "file", name: "Dockerfile", size: "1.2 KB" },
        ],
      },
      "ci-templates": {
        updated: "3 weeks ago",
        files: 34,
        items: [
          { type: "folder", name: "github-actions", count: 16 },
          { type: "folder", name: "gitlab", count: 12 },
          { type: "file", name: "README.md", size: "7.2 KB" },
        ],
      },
    },
  },
};

window.FS = FS;
window.USERS = Object.keys(FS);
