const Icon = {
  folder: (p = {}) => (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" {...p}>
      <path d="M2.5 5.5a1.5 1.5 0 0 1 1.5-1.5h3.4c.4 0 .77.16 1.06.44L9.6 5.5h6.4a1.5 1.5 0 0 1 1.5 1.5v8a1.5 1.5 0 0 1-1.5 1.5H4a1.5 1.5 0 0 1-1.5-1.5v-9.5Z" fill="currentColor" fillOpacity="0.15" stroke="currentColor" strokeWidth="1.2"/>
    </svg>
  ),
  file: (p = {}) => (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" {...p}>
      <path d="M5 3h7l3 3v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" stroke="currentColor" strokeWidth="1.2" fill="currentColor" fillOpacity="0.04"/>
      <path d="M12 3v3h3" stroke="currentColor" strokeWidth="1.2"/>
    </svg>
  ),
  chevDown: (p = {}) => (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" {...p}>
      <path d="M3 4.5 6 7.5 9 4.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  chevRight: (p = {}) => (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" {...p}>
      <path d="M4.5 3 7.5 6 4.5 9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  search: (p = {}) => (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" {...p}>
      <circle cx="6" cy="6" r="4" stroke="currentColor" strokeWidth="1.4"/>
      <path d="m9 9 3 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/>
    </svg>
  ),
  check: (p = {}) => (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" {...p}>
      <path d="m2.5 6 2.5 2.5L9.5 3.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  logo: (p = {}) => (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" {...p}>
      <rect x="2" y="2" width="18" height="18" rx="4" fill="var(--accent)"/>
      <path d="M7 6.5h4.2a4.5 4.5 0 0 1 0 9H7v-9Z" fill="#fff"/>
      <circle cx="14.5" cy="11" r="1.6" fill="var(--accent)"/>
    </svg>
  ),
  github: (p = {}) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" {...p}>
      <path d="M8 0C3.58 0 0 3.58 0 8a8 8 0 0 0 5.47 7.59c.4.07.55-.17.55-.38v-1.34c-2.22.48-2.69-1.07-2.69-1.07-.36-.92-.89-1.17-.89-1.17-.73-.5.05-.49.05-.49.8.06 1.23.83 1.23.83.72 1.23 1.88.87 2.34.67.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.22 2.2.82a7.6 7.6 0 0 1 4 0c1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.28.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.74.54 1.48v2.2c0 .21.15.46.55.38A8 8 0 0 0 16 8c0-4.42-3.58-8-8-8Z"/>
    </svg>
  ),
  external: (p = {}) => (
    <svg width="11" height="11" viewBox="0 0 12 12" fill="none" {...p}>
      <path d="M4 2h6v6M10 2 5 7M8 7v3H2V4h3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  reset: (p = {}) => (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" {...p}>
      <path d="M2 4.5a4 4 0 1 1-.2 3M2 1.5v3h3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  // file-type glyphs
  fileMd: (p = {}) => (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" {...p}>
      <path d="M5 3h7l3 3v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" stroke="#2a4d7a" strokeWidth="1.2" fill="#e8eef7"/>
      <text x="6" y="14" fontSize="5" fontFamily="Geist Mono" fontWeight="600" fill="#2a4d7a">MD</text>
    </svg>
  ),
  fileJson: (p = {}) => (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" {...p}>
      <path d="M5 3h7l3 3v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" stroke="#7a5a16" strokeWidth="1.2" fill="#f7efde"/>
      <text x="6" y="14" fontSize="4.5" fontFamily="Geist Mono" fontWeight="600" fill="#7a5a16">{ }</text>
    </svg>
  ),
  fileYml: (p = {}) => (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" {...p}>
      <path d="M5 3h7l3 3v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" stroke="#2f6b3c" strokeWidth="1.2" fill="#e6f2e7"/>
      <text x="6" y="14" fontSize="5" fontFamily="Geist Mono" fontWeight="600" fill="#2f6b3c">YML</text>
    </svg>
  ),
  fileCode: (p = {}) => (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" {...p}>
      <path d="M5 3h7l3 3v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" stroke="#b4502b" strokeWidth="1.2" fill="#f7e8de"/>
      <path d="M7.5 11 6 12.5 7.5 14M10.5 11l1.5 1.5L10.5 14" stroke="#b4502b" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  fileDoc: (p = {}) => (
    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" {...p}>
      <path d="M5 3h7l3 3v11a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z" stroke="#5a4a40" strokeWidth="1.2" fill="#efece4"/>
      <path d="M7 10h6M7 12.5h6M7 8h4" stroke="#5a4a40" strokeWidth="1" strokeLinecap="round"/>
    </svg>
  ),
};

function pickFileIcon(name) {
  const lower = name.toLowerCase();
  if (lower.endsWith(".md")) return Icon.fileMd;
  if (lower.endsWith(".json")) return Icon.fileJson;
  if (lower.endsWith(".yaml") || lower.endsWith(".yml") || lower.endsWith(".toml") || lower.endsWith(".cfg") || lower.endsWith(".tf")) return Icon.fileYml;
  if (lower.endsWith(".py") || lower.endsWith(".go") || lower.endsWith(".mod") || lower.endsWith(".mjs") || lower.endsWith(".ts") || lower.endsWith(".tsx") || lower.endsWith(".rs")) return Icon.fileCode;
  if (lower.endsWith(".pdf") || lower.endsWith(".txt") || lower.endsWith(".svg")) return Icon.fileDoc;
  if (lower.startsWith("dockerfile") || lower.startsWith("makefile") || lower.startsWith(".env")) return Icon.fileCode;
  return Icon.fileDoc;
}

window.Icon = Icon;
window.pickFileIcon = pickFileIcon;
