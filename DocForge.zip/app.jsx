/* === Root app + router + global state === */

const App = () => {
  // ---- Auth state ----
  const [user, setUser] = useState(null); // { name, email, githubToken? }

  // ---- Route ----
  const [route, setRoute] = useState({ name: "home" });

  // ---- Projects ----
  const [projects, setProjects] = useState(MOCK_PROJECTS.map(p => ({ ...p })));
  const [activeProject, setActiveProject] = useState(null);

  // ---- Modals ----
  const [githubOpen, setGithubOpen] = useState(false);
  const [howOpen, setHowOpen] = useState(false);

  // ---- Tweaks ----
  const [tweaks, setTweak] = useTweaks(window.__DF_TWEAKS);

  // Apply theme reactively
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", tweaks.theme);
  }, [tweaks.theme]);

  // ---- Auto-login user on first load for demo convenience ----
  // (Real app would redirect to /login)
  useEffect(() => {
    if (!user) {
      // Show login screen
    }
  }, [user]);

  if (!user) {
    return (
      <ToastProvider>
        <LoginPage onLogin={(account) => {
          setUser({ ...account, githubToken: "ghp_demo_present" });
        }} />
        <TweaksPanelWrapper tweaks={tweaks} setTweak={setTweak} />
      </ToastProvider>
    );
  }

  // ---- Create project ----
  const createProject = ({ title, mode, template }) => {
    const key = `DF-${1043 + projects.length}`;
    const proj = {
      key, title,
      repo: "",
      stage: 1, status: "in-progress",
      updated: Date.now(), owner: "you",
      blankMode: mode === "blank",
      template,
      activeStage: 1, maxReached: 1
    };
    setProjects(ps => [proj, ...ps]);
    setActiveProject(proj);
    setRoute({ name: "project", key });
  };

  // ---- Open project ----
  const openProject = (key) => {
    const p = projects.find(x => x.key === key);
    if (!p) return;
    setActiveProject(p);
    setRoute({ name: "project", key });
  };

  const updateActiveProject = (patch) => {
    setActiveProject(p => {
      if (!p) return p;
      const next = { ...p, ...patch, updated: Date.now() };
      setProjects(ps => ps.map(x => x.key === next.key ? next : x));
      return next;
    });
  };

  // ---- Render route ----
  const renderRoute = () => {
    switch (route.name) {
      case "home":
        return <HomePage
          onNavigate={(r) => { if (r.name === "project") openProject(r.key); else setRoute(r); }}
          projects={projects} user={user}
          onOpenGithub={() => setGithubOpen(true)}
          onCreateProject={createProject} />;
      case "project":
        const p = activeProject || projects.find(x => x.key === route.key);
        if (!p) return <HomePage onNavigate={setRoute} projects={projects} user={user}
          onOpenGithub={() => setGithubOpen(true)} onCreateProject={createProject} />;
        return <ProjectWorkspace
          key={p.key}
          project={p} blankMode={p.blankMode}
          onUpdate={updateActiveProject}
          onNavigate={setRoute} />;
      case "editor": return <DocumentEditor onNavigate={setRoute} />;
      case "techspec": return <TechSpecBot />;
      case "faq": return <FAQ />;
      default: return null;
    }
  };

  return (
    <ToastProvider>
      <Navbar
        route={route} onNavigate={setRoute} user={user}
        onSignOut={() => { setUser(null); setRoute({ name: "home" }); }}
        onOpenGithub={() => setGithubOpen(true)}
        onOpenHowItWorks={() => setHowOpen(true)}
      />
      {renderRoute()}

      <GithubModal open={githubOpen} onClose={() => setGithubOpen(false)} user={user}
        onSave={(token) => setUser(u => ({ ...u, githubToken: token }))} />
      <HowItWorksModal open={howOpen} onClose={() => setHowOpen(false)} />

      <TweaksPanelWrapper tweaks={tweaks} setTweak={setTweak} />
    </ToastProvider>
  );
};

const TweaksPanelWrapper = ({ tweaks, setTweak }) => (
  <TweaksPanel title="Tweaks">
    <TweakSection label="Theme" />
    <TweakRadio label="Mode" value={tweaks.theme} options={["light", "dark"]}
      onChange={v => setTweak("theme", v)} />

    <TweakSection label="Layout" />
    <TweakRadio label="Density" value={tweaks.density} options={["compact", "comfortable"]}
      onChange={v => setTweak("density", v)} />
    <TweakToggle label="Show stage numbers" value={tweaks.showStageNumbers}
      onChange={v => setTweak("showStageNumbers", v)} />
  </TweaksPanel>
);

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
