/* === Tech Spec Bot === */

const TechSpecBot = () => {
  const [messages, setMessages] = useState([
    { role: "agent", text: "Hi — I'm the Tech Spec Bot. Ask me about any spec in the knowledge base. I can pull excerpts and link the source documents.", suggestions: [
      "How does payment 3DS work?",
      "What's the refund flow?",
      "Show me the PCI compliance checklist",
      "Architecture of payments-api"
    ]}
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const msgsRef = useRef(null);

  useEffect(() => {
    if (msgsRef.current) msgsRef.current.scrollTop = msgsRef.current.scrollHeight;
  }, [messages, thinking]);

  const askQ = (q) => {
    if (!q.trim()) return;
    setMessages(m => [...m, { role: "user", text: q.trim() }]);
    setInput(""); setThinking(true);
    setTimeout(() => {
      const { text, docs } = answer(q);
      setMessages(m => [...m, { role: "agent", text, docs }]);
      setThinking(false);
    }, 1100);
  };

  const answer = (q) => {
    const lower = q.toLowerCase();
    if (lower.includes("3ds") || lower.includes("step-up") || lower.includes("authentication")) {
      return {
        text: "3DS (3-D Secure) is a step-up authentication challenge initiated by the issuer when our PSP requests it. Today the service supports it for North American card networks; an EEA expansion is in flight under feature flag `feature.threeds_step_up`. The flow: client POSTs charge → PSP decides → service returns 202 with `next_action` → client renders ChallengeFrame → completion resumes charge.",
        docs: [FAISS_DOCS[0], FAISS_DOCS[3]]
      };
    }
    if (lower.includes("refund")) {
      return {
        text: "Refunds are async. The client calls `POST /v1/refunds` referencing a charge. The service validates state (must be `succeeded`), enqueues to the PSP, and emits `refund.created`. Partial refunds are supported up to the captured amount. Idempotency keys are required.",
        docs: [FAISS_DOCS[1]]
      };
    }
    if (lower.includes("pci") || lower.includes("compliance")) {
      return {
        text: "PCI-DSS scope is reduced because cardholder data never traverses our systems — the PSP tokenizes at the iframe boundary. Quarterly compliance review checklist is COMPL-PCI-1.",
        docs: [FAISS_DOCS[4]]
      };
    }
    if (lower.includes("arch") || lower.includes("payments-api")) {
      return {
        text: "payments-api is a FastAPI service deployed on EKS. Key modules: `charges/` (charge lifecycle), `webhooks/` (outbound delivery), `auth/` (3DS + PSD2 hooks), `persistence/` (Postgres). State is durably stored in Postgres; idempotency keys are kept in Redis for 24h.",
        docs: [FAISS_DOCS[2]]
      };
    }
    if (lower.includes("runbook") || lower.includes("on-call")) {
      return {
        text: "The on-call runbook for payments covers the top alerts (charge backlog, webhook backpressure, PSP outage), the rollback procedure for each feature flag, and contact rotations.",
        docs: [FAISS_DOCS[5]]
      };
    }
    return {
      text: `I couldn't find a specific match for "${q}". Here are the top candidates from the FAISS index — let me know which one to drill into.`,
      docs: FAISS_DOCS.slice(0, 3)
    };
  };

  return (
    <div className="page-narrow" data-screen-label="techspec-bot">
      <div style={{ marginBottom: 18, display: "flex", alignItems: "center", gap: 12 }}>
        <div className="tile-icon" style={{ width: 36, height: 36 }}><IconBot size={18} /></div>
        <div>
          <h1 style={{ fontSize: 22 }}>Tech Spec Bot</h1>
          <p style={{ color: "var(--fg-2)", fontSize: 13 }}>Ask anything about the spec library — answers come with source documents.</p>
        </div>
      </div>

      <Card padded={false} style={{ height: "calc(100vh - 220px)", minHeight: 480, display: "flex", flexDirection: "column" }}>
        <div className="chat-msgs" ref={msgsRef} style={{ flex: 1, padding: 18 }}>
          {messages.map((m, i) => (
            <div key={i} className={`chat-msg ${m.role}`} style={{ maxWidth: "100%" }}>
              <div className="chat-avatar">{m.role === "user" ? "U" : "DF"}</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, maxWidth: "calc(100% - 34px)" }}>
                <div className="chat-bubble" style={{ whiteSpace: "pre-wrap" }}>{m.text}</div>
                {m.docs && m.docs.length > 0 && (
                  <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                    {m.docs.map(d => (
                      <div key={d.id} style={{
                        display: "flex", alignItems: "center", gap: 9,
                        padding: "8px 11px",
                        border: "1px solid var(--border)", borderRadius: "var(--r-md)",
                        background: "var(--bg-2)", fontSize: 12.5
                      }}>
                        <IconDocument size={13} style={{ color: "var(--fg-2)" }} />
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 500 }}>{d.title}</div>
                          <div style={{ fontSize: 11, color: "var(--fg-3)", fontFamily: "var(--font-mono)" }}>{d.path}</div>
                        </div>
                        <Button size="sm" variant="ghost" icon={<IconDownload size={11} />}>Download</Button>
                      </div>
                    ))}
                  </div>
                )}
                {m.suggestions && (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 4 }}>
                    {m.suggestions.map(s => (
                      <button key={s} className="btn btn-sm"
                        onClick={() => askQ(s)}>{s}</button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {thinking && (
            <div className="chat-msg agent">
              <div className="chat-avatar">DF</div>
              <div className="chat-bubble" style={{ display: "flex", gap: 3 }}>
                <span className="dot" style={{ animation: "pulse 1s infinite", color: "var(--fg-3)" }} />
                <span className="dot" style={{ animation: "pulse 1s 0.2s infinite", color: "var(--fg-3)" }} />
                <span className="dot" style={{ animation: "pulse 1s 0.4s infinite", color: "var(--fg-3)" }} />
              </div>
            </div>
          )}
        </div>
        <div className="chat-input-row" style={{ padding: 12 }}>
          <input className="input" placeholder="Ask about a spec, API, runbook…"
            value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && askQ(input)} />
          <Button variant="primary" icon={<IconSend size={12} />}
            disabled={!input.trim() || thinking}
            onClick={() => askQ(input)} />
        </div>
      </Card>
    </div>
  );
};

window.TechSpecBot = TechSpecBot;
