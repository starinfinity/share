/* === Fixtures & mock data === */

const SUPPORTED_LANGUAGES = ["Python", "TypeScript", "JavaScript", "Go", "Java"];
const MAX_FILES_SUPPORT = 250;

// Github metadata fixture (mocked)
const GITHUB_METADATA = [
  { name: "payments-api", owner: "acme-corp", description: "Stripe-backed payment service. FastAPI + Postgres.", stars: 142, language: "Python", files: 87, updated: 1716499200000, topics: ["payments", "fastapi", "stripe"] },
  { name: "payments-ui", owner: "acme-corp", description: "React frontend for Acme payments.", stars: 64, language: "TypeScript", files: 156, updated: 1716326400000, topics: ["payments", "react"] },
  { name: "checkout-service", owner: "acme-corp", description: "Checkout flow orchestration.", stars: 23, language: "Python", files: 41, updated: 1715635200000 },
  { name: "billing-engine", owner: "acme-corp", description: "Subscription billing & invoice generation.", stars: 88, language: "Python", files: 199, updated: 1716412800000 },
  { name: "auth-service", owner: "acme-corp", description: "OAuth + SSO identity provider integration.", stars: 51, language: "Go", files: 64 },
  { name: "notification-svc", owner: "acme-corp", description: "Email, SMS, push notification dispatcher.", stars: 33, language: "Python", files: 52 },
  { name: "reports-portal", owner: "acme-corp", description: "Internal BI dashboards.", stars: 12, language: "TypeScript", files: 280 },
  { name: "data-pipeline", owner: "acme-corp", description: "Airflow + dbt analytics pipeline.", stars: 19, language: "Python", files: 134 },
  { name: "mobile-app", owner: "acme-corp", description: "Customer-facing React Native app.", stars: 78, language: "TypeScript", files: 412 },
  { name: "shared-libs", owner: "acme-corp", description: "Shared Python utilities.", stars: 9, language: "Python", files: 48 }
];

// FAISS document fixture
const FAISS_DOCS = [
  { id: "TS-PAY-014", title: "Payment Processing Tech Spec v3.2", path: "/nas/specs/payments/TS-PAY-014.docx", type: "DOCX", updated: 1715376000000, owner: "P. Chen", size: 184320 },
  { id: "TS-PAY-009", title: "Refund Flow Functional Requirements", path: "/nas/specs/payments/TS-PAY-009.docx", type: "DOCX", updated: 1713388800000, owner: "M. Diaz", size: 92160 },
  { id: "ARCH-027", title: "Acme Payments Architecture Overview", path: "/nas/specs/architecture/ARCH-027.pptx", type: "PPTX", updated: 1714857600000, owner: "S. Kapoor", size: 4423680 },
  { id: "API-PAY-002", title: "Payment Service API Reference", path: "/nas/specs/payments/API-PAY-002.md", type: "MD", updated: 1716412800000, owner: "P. Chen", size: 21504 },
  { id: "COMPL-PCI-1", title: "PCI-DSS Compliance Checklist", path: "/nas/specs/compliance/COMPL-PCI-1.pdf", type: "PDF", updated: 1712188800000, owner: "L. Park", size: 819200 },
  { id: "RUN-PAY-005", title: "Payments Runbook & On-call Playbook", path: "/nas/runbooks/RUN-PAY-005.md", type: "MD", updated: 1716067200000, owner: "Ops Team", size: 31744 }
];

// Project templates (for empty new project)
const PROJECT_TEMPLATES = [
  { id: "tpl-tech-spec", name: "Technical Specification", desc: "Engineering-facing spec with architecture, data model, APIs.", icon: "📋" },
  { id: "tpl-prd", name: "Product Requirements Document", desc: "User stories, acceptance criteria, scope.", icon: "📐" },
  { id: "tpl-runbook", name: "Operations Runbook", desc: "On-call response, escalation paths, recovery procedures.", icon: "🛠" },
  { id: "tpl-api-ref", name: "API Reference", desc: "Endpoint catalog with auth, request/response examples.", icon: "🔌" },
  { id: "tpl-rfc", name: "RFC / Design Doc", desc: "Decision record for major changes.", icon: "📝" },
  { id: "tpl-blank", name: "Blank Document", desc: "Start from scratch.", icon: "○" }
];

// Pattern-based readme rules from spec
const README_REPO_PATTERNS = ["payments-", "billing-", "auth-"];

// Mock existing projects
const MOCK_PROJECTS = [
  { key: "DF-1042", title: "Add 3DS step-up authentication", repo: "acme-corp/payments-api", stage: 5, status: "in-progress", updated: Date.now() - 3 * 60 * 60 * 1000, owner: "you" },
  { key: "DF-1037", title: "Webhook retry policy refactor", repo: "acme-corp/notification-svc", stage: 6, status: "pr-open", updated: Date.now() - 26 * 60 * 60 * 1000, owner: "you" },
  { key: "DF-1029", title: "Add refunds API to billing-engine", repo: "acme-corp/billing-engine", stage: 4, status: "in-progress", updated: Date.now() - 3 * 24 * 60 * 60 * 1000, owner: "you" },
  { key: "DF-1018", title: "Mobile checkout copy revamp", repo: "acme-corp/mobile-app", stage: 6, status: "merged", updated: Date.now() - 6 * 24 * 60 * 60 * 1000, owner: "you" },
  { key: "DF-1006", title: "Reports portal RBAC update", repo: "acme-corp/reports-portal", stage: 2, status: "abandoned", updated: Date.now() - 18 * 24 * 60 * 60 * 1000, owner: "S. Kapoor" }
];

const STAGES = [
  { idx: 1, title: "Requirements", sub: "Extract from documents", short: "Extract" },
  { idx: 2, title: "Repository", sub: "Locate or upload code", short: "Repo" },
  { idx: 3, title: "Context Docs", sub: "Find supporting specs", short: "Docs" },
  { idx: 4, title: "Planning", sub: "Tasks & detailed plan", short: "Plan" },
  { idx: 5, title: "Document Update", sub: "Updated spec + chat", short: "Doc" },
  { idx: 6, title: "Code & PR", sub: "Open pull request", short: "PR" }
];

// Default extracted MD (mock)
const SAMPLE_EXTRACTED_MD = `# Add 3-D Secure Step-Up Authentication

**Project:** DF-1042
**Source:** payments-step-up-prd-v4.docx
**Submitted by:** you · just now

---

## Problem
European card auth volume has grown 38% YoY but our PSP rejects ~4.6% of authentications without offering a step-up challenge. PSD2/SCA compliance requires that we honor the issuer's challenge request and fall back gracefully to frictionless flow when allowed.

## Goals
1. Implement the 3DS 2.2 step-up challenge for card transactions originating from EEA-issued cards.
2. Surface a hosted challenge iframe in the existing checkout SDK.
3. Reduce uncategorized rejections to **< 1.0%** within one quarter.

## Non-goals
- Adding 3DS support for the legacy v1 SDK.
- Changing the underlying tokenization scheme.

## Constraints
- Must not increase median checkout time by more than 250ms for non-challenged users.
- Backwards-compatible with all existing webhook consumers (\`charge.succeeded\`, \`charge.failed\`).
- Roll out behind a feature flag (\`feature.threeds_step_up\`).

## In Scope
- \`/v1/charges\` API: accept \`return_url\` and \`browser_info\`.
- Checkout SDK: add \`ChallengeFrame\` component.
- Webhook: add new event \`charge.requires_action\`.

## Out of Scope
- Marketplace-Connect accounts (deferred to Q3).
- Apple Pay / Google Pay (already handled by wallet).

## Acceptance Criteria
- 95% of EEA card challenges complete within 4s.
- All challenge attempts logged to BigQuery (\`payments.threeds_attempts\`).
- Runbook updated with rollback procedure.

## References
- Spec doc: ARCH-027
- PSP guidance: vendor portal § 4.2
- Existing rejection metrics: dashboards/payments/auth-failures`;

Object.assign(window, {
  SUPPORTED_LANGUAGES, MAX_FILES_SUPPORT, GITHUB_METADATA, FAISS_DOCS,
  PROJECT_TEMPLATES, README_REPO_PATTERNS, MOCK_PROJECTS, STAGES, SAMPLE_EXTRACTED_MD
});
