/* === FAQ === */

const FAQ_ENTRIES = [
  {
    q: "What's the difference between 'Create project' and 'Create new project'?",
    a: "Create project runs all 6 stages and requires an existing GitHub repo — DocForge will update its code and open a PR. Create new project skips the repo-discovery stage (Stage 3) and uses a template; it's for generating documentation from scratch."
  },
  {
    q: "Why am I being asked for a GitHub token?",
    a: "DocForge clones the repo, reads files, and pushes commits as you. You need a personal access token with `repo` and `read:org` scopes. Tokens are encrypted at rest with AES-256 and never logged."
  },
  {
    q: "What does Stage 2 do if my repo is too large?",
    a: "If the count of files in supported languages exceeds the configured maximum, Stage 2 blocks you from proceeding. Scope the change to a smaller repo, or split the work."
  },
  {
    q: "How does Stage 3 decide whether to use the repo README?",
    a: "If the repo name starts with a configured pattern (e.g. `payments-`, `billing-`), DocForge will pull the README automatically. Otherwise you'll be prompted to upload your own docs or search the NAS via FAISS."
  },
  {
    q: "Can I edit the achievable task list in Stage 4?",
    a: "Yes — add, edit, delete, and check/uncheck any task. Only checked tasks are passed to the planner. Unachievable tasks are read-only and surfaced for transparency."
  },
  {
    q: "What does the chatbot in Stage 5 / 6 do?",
    a: "It lets you iterate on the generated document (Stage 5) or pull request (Stage 6) in natural language. The agent will edit and re-commit on your behalf."
  },
  {
    q: "Where is project data stored?",
    a: "Every project gets a unique key like DF-1042 and its own folder under /projects/<user>/. A metadata file logs every stage transition, user input, and completion status."
  },
  {
    q: "Does DocForge log my usage?",
    a: "Yes — we log SSO username, time-on-stage, and stage completion for product analytics. We do not log file contents."
  },
  {
    q: "What if SSO is disabled in my environment?",
    a: "When SSO_ENABLED=false, two dummy accounts from the .env file are surfaced on the login screen for development."
  },
  {
    q: "How do I report a bug?",
    a: "Use the help (?) button in the navbar or message #docforge in Slack. Include your project key (DF-XXXX) so we can grab the logs."
  }
];

const FAQ = () => {
  const [open, setOpen] = useState(0);
  const [filter, setFilter] = useState("");

  const filtered = FAQ_ENTRIES.filter(f =>
    !filter || f.q.toLowerCase().includes(filter.toLowerCase()) ||
    f.a.toLowerCase().includes(filter.toLowerCase()));

  return (
    <div className="page-narrow" data-screen-label="faq">
      <div className="page-h">
        <h1>Frequently asked questions</h1>
        <p>If something's not covered here, check the How it works modal or ping #docforge.</p>
      </div>

      <div style={{ position: "relative", marginBottom: 18 }}>
        <input className="input"
          placeholder="Search the FAQ…"
          value={filter} onChange={e => setFilter(e.target.value)}
          style={{ paddingLeft: 32 }} />
        <IconSearch size={13} style={{
          position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)",
          color: "var(--fg-3)"
        }} />
      </div>

      <Card padded={false}>
        {filtered.map((f, i) => (
          <div key={i}>
            <div
              onClick={() => setOpen(open === i ? -1 : i)}
              style={{
                padding: "14px 18px", cursor: "pointer",
                display: "flex", alignItems: "center", gap: 10,
                background: open === i ? "var(--bg-2)" : "transparent",
                transition: "background 120ms"
              }}>
              <IconChevronRight size={12} style={{
                color: "var(--fg-3)",
                transform: open === i ? "rotate(90deg)" : "rotate(0)",
                transition: "transform 140ms"
              }} />
              <span style={{ fontWeight: 500, fontSize: 13.5, flex: 1 }}>{f.q}</span>
            </div>
            {open === i && (
              <div style={{
                padding: "0 18px 16px 38px",
                fontSize: 13.5, color: "var(--fg-2)", lineHeight: 1.6,
                animation: "slideUp 200ms"
              }}>
                {f.a}
              </div>
            )}
            {i < filtered.length - 1 && <div className="divider" />}
          </div>
        ))}
        {filtered.length === 0 && (
          <Empty title="No matches">Try a different search term.</Empty>
        )}
      </Card>

      <div style={{
        marginTop: 22, padding: 16,
        border: "1px solid var(--border)", borderRadius: "var(--r-md)",
        background: "var(--bg-2)", fontSize: 13, color: "var(--fg-2)",
        display: "flex", alignItems: "center", gap: 12
      }}>
        <IconHelp size={16} style={{ flexShrink: 0 }} />
        <div style={{ flex: 1 }}>
          <strong style={{ color: "var(--fg)" }}>Still stuck?</strong> Ask the Tech Spec Bot or message #docforge in Slack.
        </div>
        <Button size="sm" variant="ghost" icon={<IconBot size={12} />}>Ask the bot</Button>
      </div>
    </div>
  );
};

window.FAQ = FAQ;
