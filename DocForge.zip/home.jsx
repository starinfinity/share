/* === Home page === */

const HomePage = ({ onNavigate, projects, user, onOpenGithub, onCreateProject }) => {
  const [filter, setFilter] = useState("");
  const [sort, setSort] = useState("recent");
  const [confirmNew, setConfirmNew] = useState(null); // null | "withRepo" | "blank"

  const filtered = useMemo(() => {
    let p = [...projects];
    if (filter) p = p.filter(x =>
      x.title.toLowerCase().includes(filter.toLowerCase()) ||
      x.key.toLowerCase().includes(filter.toLowerCase()) ||
      x.repo.toLowerCase().includes(filter.toLowerCase())
    );
    if (sort === "recent") p.sort((a, b) => b.updated - a.updated);
    return p;
  }, [projects, filter, sort]);

  const needsToken = !user?.githubToken;

  return (
    <div className="page" data-screen-label="home">
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: 28, letterSpacing: "-0.02em", marginBottom: 6 }}>
          Welcome back, {user?.name?.split(" ")[0] || "there"}.
        </h1>
        <p style={{ color: "var(--fg-2)", fontSize: 14 }}>
          Generate, update, and ship tech specs and code changes — six stages, end to end.
        </p>
      </div>

      {needsToken && (
        <div style={{ marginBottom: 18 }}>
          <Status tone="warn" icon={<IconWarn size={13} />}>
            Connect a GitHub token to create or edit projects.{" "}
            <a onClick={onOpenGithub} style={{ textDecoration: "underline", cursor: "pointer", marginLeft: 4 }}>
              Connect now →
            </a>
          </Status>
        </div>
      )}

      {/* Primary actions */}
      <div className="sect-h"><h3>Start</h3></div>
      <div className="tile-grid" style={{ marginBottom: 28 }}>
        <div className="tile" onClick={() => !needsToken && setConfirmNew("withRepo")}
             style={{ opacity: needsToken ? 0.5 : 1, cursor: needsToken ? "not-allowed" : "pointer" }}>
          <div className="tile-icon"><IconPlus size={16} /></div>
          <h3>Create project</h3>
          <p>Start a new 6-stage run from a requirements document. Connects to an existing GitHub repo.</p>
          <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--fg-3)", fontSize: 12 }}>
            <span>All 6 stages</span> · <span>Repo required</span>
          </div>
        </div>
        <div className="tile" onClick={() => !needsToken && setConfirmNew("blank")}
             style={{ opacity: needsToken ? 0.5 : 1, cursor: needsToken ? "not-allowed" : "pointer" }}>
          <div className="tile-icon"><IconSparkles size={16} /></div>
          <h3>Create new project</h3>
          <p>Generate a brand-new spec from a template. Skips repo discovery (no existing code).</p>
          <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--fg-3)", fontSize: 12 }}>
            <span>Stages 1, 2, 4, 5, 6</span> · <span>Template-driven</span>
          </div>
        </div>
        <div className="tile" onClick={() => onNavigate({ name: "editor" })}>
          <div className="tile-icon"><IconDocument size={16} /></div>
          <h3>Document Editor</h3>
          <p>Create or edit a document with GitHub code and your inputs — no full project run required.</p>
        </div>
        <div className="tile" onClick={() => onNavigate({ name: "techspec" })}>
          <div className="tile-icon"><IconBot size={16} /></div>
          <h3>Tech Spec Bot</h3>
          <p>Ask questions and pull answers (and source docs) from the FAISS knowledge base.</p>
        </div>
      </div>

      {/* Recent projects */}
      <div className="sect-h" style={{ marginTop: 6 }}>
        <h3>Recent projects</h3>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <div style={{ position: "relative" }}>
            <input
              className="input"
              placeholder="Search…"
              value={filter}
              onChange={e => setFilter(e.target.value)}
              style={{ height: 28, paddingLeft: 28, width: 220, fontSize: 12 }}
            />
            <IconSearch size={12} style={{
              position: "absolute", left: 9, top: "50%", transform: "translateY(-50%)",
              color: "var(--fg-3)"
            }} />
          </div>
          <Button size="sm" variant="ghost" icon={<IconFilter size={12} />}>All</Button>
        </div>
      </div>
      <Card padded={false}>
        {filtered.length === 0 ? (
          <Empty icon={<IconFolder size={28} />} title="No projects">
            Start your first run with the buttons above.
          </Empty>
        ) : (
          <>
            <div className="proj-row" style={{
              background: "var(--bg-2)", color: "var(--fg-3)",
              fontSize: 11, letterSpacing: "0.04em", textTransform: "uppercase",
              fontFamily: "var(--font-mono)", cursor: "default"
            }}>
              <span>Project</span>
              <span>Repository</span>
              <span>Stage</span>
              <span>Status</span>
              <span>Updated</span>
            </div>
            {filtered.map(p => (
              <div key={p.key} className="proj-row" onClick={() => onNavigate({ name: "project", key: p.key })}>
                <div>
                  <div className="title">{p.title}</div>
                  <div className="pk">{p.key}</div>
                </div>
                <div className="mono" style={{ fontSize: 12, color: "var(--fg-2)" }}>{p.repo}</div>
                <div>
                  <Badge>Stage {p.stage}/6</Badge>
                </div>
                <div>
                  <StatusBadge status={p.status} />
                </div>
                <div style={{ color: "var(--fg-3)", fontSize: 12 }}>
                  {fmtRel(p.updated)}
                </div>
              </div>
            ))}
          </>
        )}
      </Card>

      <CreateProjectModal
        open={confirmNew !== null}
        mode={confirmNew}
        onClose={() => setConfirmNew(null)}
        onConfirm={(payload) => { setConfirmNew(null); onCreateProject(payload); }}
      />
    </div>
  );
};

const StatusBadge = ({ status }) => {
  const map = {
    "in-progress": { tone: "info", label: "In progress" },
    "pr-open": { tone: "warn", label: "PR open" },
    "merged": { tone: "success", label: "Merged" },
    "abandoned": { tone: undefined, label: "Abandoned" }
  };
  const m = map[status] || { tone: undefined, label: status };
  return <Badge tone={m.tone}><span className="dot" />{m.label}</Badge>;
};

const CreateProjectModal = ({ open, mode, onClose, onConfirm }) => {
  const [title, setTitle] = useState("");
  const [template, setTemplate] = useState(null);

  useEffect(() => {
    if (open) { setTitle(""); setTemplate(null); }
  }, [open]);

  const ready = title.trim() && (mode === "withRepo" || template);

  return (
    <Modal open={open} onClose={onClose}
      title={mode === "blank" ? "Create new project (no repo)" : "Create project"}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="primary" disabled={!ready}
            onClick={() => onConfirm({ title: title.trim(), mode, template })}>
            Continue to Stage 1 <IconArrowRight size={12} />
          </Button>
        </>
      }>
      <div className="label">Project title</div>
      <input className="input" placeholder="e.g. Add 3DS step-up authentication"
        value={title} onChange={e => setTitle(e.target.value)} autoFocus />
      <div className="footnote">
        <IconKey size={12} />
        <span>A unique key like <span className="mono">DF-1043</span> will be assigned on save.</span>
      </div>

      {mode === "blank" && (
        <>
          <div className="label" style={{ marginTop: 18 }}>Choose a template</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {PROJECT_TEMPLATES.map(t => (
              <div key={t.id}
                onClick={() => setTemplate(t.id)}
                style={{
                  padding: 12,
                  border: `1px solid ${template === t.id ? "var(--fg)" : "var(--border)"}`,
                  borderRadius: "var(--r-md)",
                  cursor: "pointer",
                  background: template === t.id ? "var(--bg-2)" : "var(--bg)",
                  transition: "border-color 120ms"
                }}>
                <div style={{ fontSize: 18, marginBottom: 4 }}>{t.icon}</div>
                <div style={{ fontSize: 13, fontWeight: 500 }}>{t.name}</div>
                <div style={{ fontSize: 11.5, color: "var(--fg-3)", marginTop: 3, lineHeight: 1.4 }}>{t.desc}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </Modal>
  );
};

Object.assign(window, { HomePage, StatusBadge });
