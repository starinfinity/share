/* === SSO Login === */

const LoginPage = ({ onLogin }) => {
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(null);

  const dummyAccounts = [
    { name: "Priya Chen", email: "priya.chen@acme-corp.com", role: "Staff Engineer" },
    { name: "Marcus Diaz", email: "marcus.diaz@acme-corp.com", role: "PM, Payments" }
  ];

  const handleSSO = (account) => {
    setSelected(account.email);
    setLoading(true);
    setTimeout(() => onLogin(account), 900);
  };

  return (
    <div className="login-shell" data-screen-label="login">
      <div className="login-card">
        <div className="login-h">
          <div style={{ display: "flex", justifyContent: "center", gap: 12, alignItems: "center", marginBottom: 18 }}>
            <OrgLogoSlot />
            <span style={{ color: "var(--fg-3)", fontSize: 16 }}>×</span>
            <DocforgeLogo />
          </div>
          <h1 style={{ fontSize: 22, marginBottom: 6 }}>Sign in to DocForge</h1>
          <p style={{ color: "var(--fg-2)", fontSize: 13 }}>
            Use your organization SSO to continue.
          </p>
        </div>

        <Card padded={false}>
          <div style={{ padding: 18 }}>
            <Button
              variant="primary" size="lg"
              icon={<IconLock size={14} />}
              style={{ width: "100%" }}
              onClick={() => handleSSO(dummyAccounts[0])}
              disabled={loading}
            >
              {loading ? <span className="spinner" /> : <span>Continue with Acme SSO</span>}
            </Button>

            <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "16px 0" }}>
              <span className="divider" style={{ flex: 1 }} />
              <span style={{ fontSize: 11, color: "var(--fg-3)" }}>OR DEV ACCOUNTS</span>
              <span className="divider" style={{ flex: 1 }} />
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {dummyAccounts.map(a => (
                <div key={a.email}
                  onClick={() => !loading && handleSSO(a)}
                  style={{
                    display: "flex", alignItems: "center", gap: 10,
                    padding: "9px 11px",
                    border: "1px solid var(--border)", borderRadius: "var(--r-md)",
                    cursor: loading ? "not-allowed" : "pointer",
                    background: selected === a.email ? "var(--bg-2)" : "var(--bg)",
                    transition: "background 120ms"
                  }}>
                  <span className="avatar" style={{ width: 28, height: 28, fontSize: 12 }}>
                    {a.name.split(" ").map(n => n[0]).join("")}
                  </span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{a.name}</div>
                    <div style={{ fontSize: 11, color: "var(--fg-3)" }}>{a.email}</div>
                  </div>
                  {selected === a.email && loading
                    ? <span className="spinner" />
                    : <IconArrowRight size={12} style={{ color: "var(--fg-3)" }} />}
                </div>
              ))}
            </div>

            <div className="footnote" style={{ marginTop: 14 }}>
              <IconWarn size={12} />
              <span>
                <code style={{ fontFamily: "var(--font-mono)" }}>SSO_ENABLED=false</code> in env → dummy accounts active.
              </span>
            </div>
          </div>

          <div style={{
            padding: "11px 18px", borderTop: "1px solid var(--border)",
            background: "var(--bg-2)", fontSize: 11, color: "var(--fg-3)",
            display: "flex", justifyContent: "space-between"
          }}>
            <span>DocForge v2.4.1</span>
            <span>© Acme Engineering Platform</span>
          </div>
        </Card>
      </div>
    </div>
  );
};

window.LoginPage = LoginPage;
