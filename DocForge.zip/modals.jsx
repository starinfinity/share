/* === Modals: GitHub Integration + How it works === */

const GithubModal = ({ open, onClose, user, onSave }) => {
  const [token, setToken] = useState("");
  const [show, setShow] = useState(false);
  const [validating, setValidating] = useState(false);
  const [validation, setValidation] = useState(null);

  useEffect(() => {
    if (!open) { setToken(""); setValidation(null); }
  }, [open]);

  const validate = () => {
    setValidating(true);
    setValidation(null);
    setTimeout(() => {
      if (token.startsWith("ghp_") || token.startsWith("github_pat_")) {
        setValidation({ ok: true, scopes: ["repo", "read:org", "workflow"], expiresIn: 23, login: user?.name || "you" });
      } else {
        setValidation({ ok: false, error: "Invalid token format. Expected token starting with ghp_ or github_pat_." });
      }
      setValidating(false);
    }, 800);
  };

  const save = () => {
    onSave(token);
    onClose();
  };

  const existing = user?.githubToken;

  return (
    <Modal open={open} onClose={onClose} title="GitHub Integration"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          {existing && !token && (
            <Button variant="danger" icon={<IconTrash size={12} />} onClick={() => { onSave(null); onClose(); }}>
              Delete token
            </Button>
          )}
          {!existing && (
            <Button variant="primary" onClick={save} disabled={!validation?.ok}>
              Save token
            </Button>
          )}
          {existing && token && (
            <Button variant="primary" onClick={save} disabled={!validation?.ok}>
              Update token
            </Button>
          )}
        </>
      }>
      {existing && (
        <div style={{ marginBottom: 16 }}>
          <div className="sect-h"><h3>Current token</h3></div>
          <div style={{
            padding: "11px 13px", border: "1px solid var(--border)", borderRadius: "var(--r-md)",
            display: "grid", gridTemplateColumns: "1fr auto", gap: 8, alignItems: "center"
          }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span className="mono" style={{ fontSize: 13 }}>ghp_••••••••••••••8a3F</span>
                <Badge tone="success"><span className="dot" /> Active</Badge>
              </div>
              <div style={{ fontSize: 11.5, color: "var(--fg-3)", marginTop: 4 }}>
                Scopes: <span className="mono">repo, read:org, workflow</span> · Expires in 23 days
              </div>
            </div>
            <Button size="sm" variant="ghost" icon={<IconRefresh size={12} />} onClick={validate}>Revalidate</Button>
          </div>
        </div>
      )}

      <div className="sect-h">
        <h3>{existing ? "Replace with new token" : "Add a personal access token"}</h3>
      </div>
      <div style={{ display: "flex", gap: 6 }}>
        <div style={{ position: "relative", flex: 1 }}>
          <input
            className="input"
            type={show ? "text" : "password"}
            placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
            value={token}
            onChange={e => { setToken(e.target.value); setValidation(null); }}
            style={{ paddingRight: 32 }}
          />
          <button
            onClick={() => setShow(s => !s)}
            style={{
              position: "absolute", right: 4, top: 4, height: 26, width: 26,
              background: "transparent", border: 0, cursor: "pointer", color: "var(--fg-3)"
            }}>
            {show ? <IconEyeOff size={13} /> : <IconEye size={13} />}
          </button>
        </div>
        <Button onClick={validate} disabled={!token || validating}>
          {validating ? <span className="spinner" /> : "Validate"}
        </Button>
      </div>

      {validation && (
        <div style={{ marginTop: 12 }}>
          {validation.ok ? (
            <Status tone="success" icon={<IconCheck size={13} />}>
              Valid. Authenticated as <strong>{validation.login}</strong> · scopes:{" "}
              <span className="mono">{validation.scopes.join(", ")}</span> · expires in {validation.expiresIn} days.
            </Status>
          ) : (
            <Status tone="danger" icon={<IconWarn size={13} />}>{validation.error}</Status>
          )}
        </div>
      )}

      <div className="footnote" style={{ marginTop: 12 }}>
        <IconLock size={12} />
        <span>
          Tokens are encrypted with AES-256 and stored in MySQL. Required scopes:{" "}
          <span className="mono">repo, read:org</span>. You can't create or edit projects without a valid token.
        </span>
      </div>
    </Modal>
  );
};

// ===========================

const HowItWorksModal = ({ open, onClose }) => {
  const [tab, setTab] = useState("arch");
  return (
    <Modal open={open} onClose={onClose} size="lg" title="How DocForge works">
      <Tabs value={tab} onChange={setTab} options={[
        { value: "arch", label: "Architecture" },
        { value: "flow", label: "6-Stage Flow" },
        { value: "video", label: "Walkthrough video" }
      ]} />

      {tab === "arch" && <ArchitectureDiagram />}
      {tab === "flow" && <FlowDiagram />}
      {tab === "video" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{
            aspectRatio: "16/9", border: "1px solid var(--border)", borderRadius: "var(--r-md)",
            background: "var(--bg-3)", position: "relative", overflow: "hidden",
            display: "flex", alignItems: "center", justifyContent: "center"
          }}>
            <div className="img-ph" style={{ position: "absolute", inset: 0, fontSize: 11 }}>video · 4:18</div>
            <button className="btn btn-primary" style={{
              position: "relative", height: 48, width: 48, borderRadius: 999, padding: 0
            }}>
              <IconPlay size={16} />
            </button>
          </div>
          <p style={{ color: "var(--fg-2)", fontSize: 13 }}>
            Watch a 4-minute walkthrough of a typical DocForge run: from PRD upload to merged PR.
          </p>
        </div>
      )}
    </Modal>
  );
};

const ArchitectureDiagram = () => {
  const blocks = [
    { label: "React Frontend", side: "client" },
    { label: "FastAPI Backend", side: "server" },
    { label: "MySQL (tokens, metadata)", side: "data" },
    { label: "FAISS Index (~2k docs)", side: "data" },
    { label: "GitHub API", side: "ext" },
    { label: "NAS File Store", side: "ext" },
    { label: "LLM Service", side: "ext" },
    { label: "SSO Provider", side: "ext" }
  ];
  return (
    <div>
      <p style={{ color: "var(--fg-2)", fontSize: 13, marginBottom: 14 }}>
        DocForge orchestrates extraction, retrieval, planning, and code generation across these layers:
      </p>

      <div style={{
        border: "1px solid var(--border)", borderRadius: "var(--r-lg)",
        padding: 18, background: "var(--bg-2)"
      }}>
        <ArchRow label="Client" tone="info">
          <ArchBlock>React SPA</ArchBlock>
          <ArchBlock>Stage UI · Tweaks · Chatbots</ArchBlock>
        </ArchRow>
        <ArchConnector />
        <ArchRow label="API" tone="success">
          <ArchBlock>FastAPI</ArchBlock>
          <ArchBlock>Stage orchestrator</ArchBlock>
          <ArchBlock>Auth middleware</ArchBlock>
        </ArchRow>
        <ArchConnector />
        <ArchRow label="Data" tone="warn">
          <ArchBlock>MySQL</ArchBlock>
          <ArchBlock>FAISS</ArchBlock>
          <ArchBlock>Per-user filesystem</ArchBlock>
        </ArchRow>
        <ArchConnector />
        <ArchRow label="External" tone="danger">
          <ArchBlock>GitHub API</ArchBlock>
          <ArchBlock>NAS</ArchBlock>
          <ArchBlock>LLM</ArchBlock>
          <ArchBlock>SSO</ArchBlock>
        </ArchRow>
      </div>

      <div className="footnote" style={{ marginTop: 12 }}>
        <IconSparkles size={12} />
        <span>Every project gets a unique key, its own folder under <code>/projects/&lt;user&gt;/</code>, and a metadata file logging every stage transition.</span>
      </div>
    </div>
  );
};

const ArchRow = ({ label, tone, children }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
    <div style={{ width: 70, flexShrink: 0 }}>
      <Badge tone={tone}>{label}</Badge>
    </div>
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", flex: 1 }}>
      {children}
    </div>
  </div>
);
const ArchBlock = ({ children }) => (
  <div style={{
    padding: "8px 12px", background: "var(--bg)",
    border: "1px solid var(--border)", borderRadius: "var(--r-md)",
    fontSize: 12.5, fontFamily: "var(--font-mono)"
  }}>{children}</div>
);
const ArchConnector = () => (
  <div style={{ height: 12, marginLeft: 32, borderLeft: "1px dashed var(--border-2)", width: 1 }} />
);

const FlowDiagram = () => (
  <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
    {STAGES.map(s => (
      <div key={s.idx} style={{
        display: "flex", gap: 14, alignItems: "flex-start",
        padding: 14, border: "1px solid var(--border)", borderRadius: "var(--r-md)"
      }}>
        <div className="stage-num" style={{ marginTop: 2 }}>{s.idx}</div>
        <div>
          <div style={{ fontWeight: 600, fontSize: 13 }}>{s.title}</div>
          <div style={{ fontSize: 12.5, color: "var(--fg-2)", marginTop: 2 }}>
            {flowDescriptions[s.idx]}
          </div>
        </div>
      </div>
    ))}
  </div>
);

const flowDescriptions = {
  1: "Upload PPT, DOCX, TXT, image. Backend extracts requirements and renders as Markdown for review.",
  2: "Match against a GitHub metadata catalog. Search or add a custom repo. Validate file count is under the supported limit.",
  3: "If the repo matches a pattern, use its README. Otherwise upload or search the NAS via FAISS — top-2 results with relevance scores.",
  4: "LLM produces achievable + unachievable task lists. Edit, approve, then generate a detailed code-change plan.",
  5: "Update the supporting document with the plan. Chat with the agent to refine further.",
  6: "Apply the plan to the repo and open a pull request prefixed Docforge-. Chat with the agent to iterate on the PR."
};

Object.assign(window, { GithubModal, HowItWorksModal });
