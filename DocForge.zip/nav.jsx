/* === Top navbar === */

const Navbar = ({ route, onNavigate, user, onSignOut, onOpenGithub, onOpenHowItWorks }) => {
  const [userMenu, setUserMenu] = useState(false);
  const userMenuRef = useRef(null);
  useOutsideClick(userMenuRef, () => setUserMenu(false));

  const tokenStatus = user?.githubToken
    ? { tone: "success", label: "Connected", days: 23 }
    : { tone: "danger", label: "Not connected" };

  return (
    <div className="navbar" data-screen-label="navbar">
      <div className="nav-logos">
        <OrgLogoSlot />
        <span className="nav-sep" />
        <span style={{ cursor: "pointer" }} onClick={() => onNavigate({ name: "home" })}>
          <DocforgeLogo />
        </span>
      </div>

      <span className="nav-sep" style={{ margin: "0 6px" }} />

      <div className="nav-links">
        <span className={`nav-link ${route.name === "home" ? "active" : ""}`}
              onClick={() => onNavigate({ name: "home" })}>
          <IconHome size={13} /> Home
        </span>
        <span className={`nav-link ${route.name === "editor" ? "active" : ""}`}
              onClick={() => onNavigate({ name: "editor" })}>
          <IconDocument size={13} /> Document Editor
        </span>
        <span className={`nav-link ${route.name === "techspec" ? "active" : ""}`}
              onClick={() => onNavigate({ name: "techspec" })}>
          <IconBot size={13} /> Tech Spec Bot
        </span>
        <span className={`nav-link ${route.name === "faq" ? "active" : ""}`}
              onClick={() => onNavigate({ name: "faq" })}>
          <IconHelp size={13} /> FAQ
        </span>
      </div>

      <div className="nav-spacer" />

      <div className="nav-right">
        <Button variant="ghost" size="sm" icon={<IconSparkles size={13} />} onClick={onOpenHowItWorks}>
          How it works
        </Button>

        <button className="btn btn-ghost btn-sm" onClick={onOpenGithub} title="GitHub integration">
          <IconGithub size={13} />
          <span style={{ marginLeft: 4 }}>GitHub</span>
          <span className={`dot`} style={{
            marginLeft: 4,
            color: user?.githubToken ? "var(--success)" : "var(--danger)"
          }} />
        </button>

        <div style={{ position: "relative" }} ref={userMenuRef}>
          <div className="user-chip" onClick={() => setUserMenu(v => !v)}>
            <span className="avatar">{(user?.name || "?").slice(0, 1).toUpperCase()}</span>
            <span>{user?.name || "Sign in"}</span>
            <IconChevron size={11} />
          </div>
          {userMenu && (
            <div className="menu">
              <div className="menu-label">Signed in as</div>
              <div style={{ padding: "0 9px 8px", fontSize: 12 }}>
                <div style={{ fontWeight: 500 }}>{user?.name}</div>
                <div style={{ color: "var(--fg-3)" }}>{user?.email}</div>
              </div>
              <div className="menu-sep" />
              <div className="menu-item" onClick={() => { setUserMenu(false); onOpenGithub(); }}>
                <IconKey size={13} /> GitHub Integration
                <span style={{ marginLeft: "auto", fontSize: 11, color: "var(--fg-3)" }}>
                  {tokenStatus.label}
                </span>
              </div>
              <div className="menu-item" onClick={() => { setUserMenu(false); onOpenHowItWorks(); }}>
                <IconHelp size={13} /> How it works
              </div>
              <div className="menu-sep" />
              <div className="menu-item danger" onClick={onSignOut}>
                <IconLogout size={13} /> Sign out
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

window.Navbar = Navbar;
