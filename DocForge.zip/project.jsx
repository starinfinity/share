/* === Project workspace shell with stepper === */

const ProjectWorkspace = ({ project, onUpdate, onNavigate, blankMode }) => {
  const [active, setActive] = useState(project.activeStage || 1);
  const [maxReached, setMaxReached] = useState(project.maxReached || 1);
  const toast = useToast();

  // For blank-mode projects, stage 3 is skipped
  const stages = blankMode
    ? STAGES.filter(s => s.idx !== 3)
    : STAGES;

  const stageStatus = (idx) => {
    if (idx < maxReached) return "done";
    if (idx === active) return "active";
    if (idx > maxReached) return "locked";
    return "available";
  };

  const goTo = (idx) => {
    if (idx <= maxReached) setActive(idx);
  };

  const nextStage = () => {
    const upcoming = blankMode && active === 2 ? 4 : active + 1;
    setMaxReached(Math.max(maxReached, upcoming));
    setActive(upcoming);
    onUpdate({ activeStage: upcoming, maxReached: Math.max(maxReached, upcoming) });
    window.scrollTo({ top: 0 });
    toast("Saved progress to Stage " + upcoming, "success");
  };

  const prevStage = () => {
    const previous = blankMode && active === 4 ? 2 : active - 1;
    if (previous >= 1) setActive(previous);
    window.scrollTo({ top: 0 });
  };

  const completeProject = () => {
    onUpdate({ status: "pr-open" });
    toast("Project marked complete — PR is open.", "success");
    onNavigate({ name: "home" });
  };

  const renderStage = () => {
    const u = (patch) => onUpdate(patch);
    switch (active) {
      case 1: return <Stage1 project={project} onUpdate={u} onNext={nextStage} />;
      case 2: return <Stage2 project={project} onUpdate={u} onNext={nextStage} onPrev={prevStage} />;
      case 3: return <Stage3 project={project} onUpdate={u} onNext={nextStage} onPrev={prevStage} />;
      case 4: return <Stage4 project={project} onUpdate={u} onNext={nextStage} onPrev={prevStage} />;
      case 5: return <Stage5 project={project} onUpdate={u} onNext={nextStage} onPrev={prevStage} />;
      case 6: return <Stage6 project={project} onUpdate={u} onPrev={prevStage} onComplete={completeProject} />;
      default: return null;
    }
  };

  return (
    <div className="ws-shell" data-screen-label="project-workspace">
      {/* Stepper sidebar */}
      <div className="stage-sidebar">
        <div className="stage-side-h">
          <div>
            <div style={{ fontWeight: 600, fontSize: 13 }}>
              {project.title.length > 28 ? project.title.slice(0, 28) + "…" : project.title}
            </div>
            <div className="pk">{project.key}</div>
          </div>
          <Button variant="ghost" size="sm" icon={<IconHome size={12} />} onClick={() => onNavigate({ name: "home" })} />
        </div>

        {stages.map(s => {
          const status = stageStatus(s.idx);
          return (
            <div key={s.idx} className={`stage-item ${status === "active" ? "active" : ""} ${status === "done" ? "done" : ""} ${status === "locked" ? "locked" : ""}`}
                 onClick={() => goTo(s.idx)}>
              <div className="stage-num">
                {status === "done" ? <IconCheck size={11} stroke={2.4} /> : s.idx}
              </div>
              <div className="stage-info">
                <div className="stage-title">{s.title}</div>
                <div className="stage-sub">{s.sub}</div>
              </div>
              <div className="stage-rule" />
            </div>
          );
        })}

        <div style={{ marginTop: "auto", padding: "12px 8px 0", borderTop: "1px solid var(--border)" }}>
          <div style={{ fontSize: 11, color: "var(--fg-3)", marginBottom: 6, letterSpacing: "0.04em", textTransform: "uppercase", fontFamily: "var(--font-mono)" }}>
            Repo
          </div>
          {project.stage2?.selectedRepo ? (
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
              <IconGithub size={11} />
              <span className="mono">{project.stage2.selectedRepo.owner}/{project.stage2.selectedRepo.name}</span>
            </div>
          ) : blankMode ? (
            <Badge>blank · no repo</Badge>
          ) : (
            <span style={{ fontSize: 12, color: "var(--fg-3)" }}>—</span>
          )}
        </div>
      </div>

      {/* Stage main */}
      <div className="stage-main">
        {renderStage()}
      </div>
    </div>
  );
};

window.ProjectWorkspace = ProjectWorkspace;
