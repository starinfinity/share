/* === Stage 2: Repository match === */

const Stage2 = ({ project, onUpdate, onNext, onPrev }) => {
  const [phase, setPhase] = useState(project.stage2?.selectedRepo ? "selected" : "matching");
  const [search, setSearch] = useState("");
  const [showAll, setShowAll] = useState(false);
  const [customMode, setCustomMode] = useState(false);
  const [customUrl, setCustomUrl] = useState("");
  const [selected, setSelected] = useState(project.stage2?.selectedRepo || null);
  const [scanResult, setScanResult] = useState(project.stage2?.scanResult || null);
  const [scanning, setScanning] = useState(false);

  // Auto-match on mount
  useEffect(() => {
    if (phase === "matching" && !selected) {
      const t = setTimeout(() => {
        // suggested repo based on title
        const sug = GITHUB_METADATA.find(r => /payment/i.test(project.title)) || GITHUB_METADATA[0];
        setPhase("suggested");
      }, 1200);
      return () => clearTimeout(t);
    }
  }, [phase, selected]);

  const suggested = useMemo(() =>
    GITHUB_METADATA.find(r => /payment/i.test(project.title)) || GITHUB_METADATA[0],
    [project.title]
  );

  const filteredRepos = useMemo(() => {
    if (!search) return GITHUB_METADATA;
    return GITHUB_METADATA.filter(r =>
      r.name.toLowerCase().includes(search.toLowerCase()) ||
      (r.description || "").toLowerCase().includes(search.toLowerCase())
    );
  }, [search]);

  const selectRepo = (repo, fromCustom = false) => {
    setSelected({ ...repo, custom: fromCustom });
    setPhase("selected");
    setScanning(true);
    setScanResult(null);
    setTimeout(() => {
      const fileCount = fromCustom ? Math.floor(Math.random() * 600) + 50 : repo.files;
      const overLimit = fileCount > MAX_FILES_SUPPORT;
      const langs = SUPPORTED_LANGUAGES.slice(0, 3).map(l => ({
        lang: l,
        count: Math.floor(fileCount * (l === repo.language ? 0.6 : 0.15))
      }));
      const result = { fileCount, supported: !overLimit, langs };
      setScanResult(result);
      setScanning(false);
      onUpdate({ stage2: { selectedRepo: { ...repo, custom: fromCustom }, scanResult: result } });
    }, 1400);
  };

  return (
    <div data-screen-label="stage-2">
      <div className="stage-head">
        <div>
          <div className="stage-eyebrow">Stage 2 of 6</div>
          <h1>Repository</h1>
          <p style={{ color: "var(--fg-2)", fontSize: 13.5, marginTop: 4 }}>
            Locate the repo for this change. DocForge will validate it's within the supported size.
          </p>
        </div>
        {selected && <Badge tone={scanResult?.supported ? "success" : "danger"}>
          <span className="dot" />{selected.owner}/{selected.name}
        </Badge>}
      </div>

      {/* Matching */}
      {phase === "matching" && (
        <Card>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span className="spinner spinner-lg" />
            <div>
              <div style={{ fontWeight: 500 }}>Searching github_metadata…</div>
              <div style={{ fontSize: 12, color: "var(--fg-3)" }}>Matching keywords from Stage 1 requirements against {GITHUB_METADATA.length} indexed repos.</div>
            </div>
          </div>
        </Card>
      )}

      {/* Suggested */}
      {phase === "suggested" && !selected && (
        <>
          <div className="sect-h">
            <h3>Suggested match</h3>
            <span className="sect-sub">based on requirements keywords</span>
          </div>
          <div className="repo-card selected" onClick={() => selectRepo(suggested)}>
            <RepoCardInner repo={suggested} suggested />
            <Button variant="primary" size="sm">Use this repo <IconArrowRight size={11} /></Button>
          </div>

          <div className="sect-h" style={{ marginTop: 22 }}>
            <h3>Or pick another</h3>
            <span className="sect-sub">{GITHUB_METADATA.length} repos in metadata</span>
          </div>

          <div style={{ position: "relative", marginBottom: 10 }}>
            <input className="input"
              placeholder="Search repos by name or description…"
              value={search} onChange={e => setSearch(e.target.value)}
              style={{ paddingLeft: 32 }} />
            <IconSearch size={13} style={{
              position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)",
              color: "var(--fg-3)"
            }} />
          </div>

          {filteredRepos.slice(0, showAll ? undefined : 4).map(r => (
            <div className="repo-card" key={r.name} onClick={() => selectRepo(r)}>
              <RepoCardInner repo={r} />
            </div>
          ))}

          {filteredRepos.length > 4 && !showAll && (
            <Button variant="ghost" size="sm" onClick={() => setShowAll(true)} style={{ marginTop: 8 }}>
              Show {filteredRepos.length - 4} more
            </Button>
          )}

          {/* Not in list */}
          <div style={{ marginTop: 22 }}>
            <div className="sect-h"><h3>Repo not in list?</h3></div>
            {!customMode ? (
              <Button variant="ghost" icon={<IconPlus size={13} />} onClick={() => setCustomMode(true)}>
                Add custom repository
              </Button>
            ) : (
              <div style={{ display: "flex", gap: 8 }}>
                <input className="input mono"
                  placeholder="owner/repo or https://github.com/…"
                  value={customUrl}
                  onChange={e => setCustomUrl(e.target.value)}
                  style={{ flex: 1 }} />
                <Button variant="primary" disabled={!customUrl.trim()}
                  onClick={() => {
                    const slug = customUrl.replace(/^https:\/\/github\.com\//, "").replace(/\/$/, "");
                    const [owner, name] = slug.includes("/") ? slug.split("/") : ["custom", slug];
                    selectRepo({ owner, name, description: "Custom repository (validated on connect)", language: "Python", stars: 0 }, true);
                  }}>
                  Connect <IconArrowRight size={12} />
                </Button>
                <Button variant="ghost" onClick={() => { setCustomMode(false); setCustomUrl(""); }}>Cancel</Button>
              </div>
            )}
          </div>
        </>
      )}

      {/* Selected — scan results */}
      {phase === "selected" && selected && (
        <>
          <Card>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 14, justifyContent: "space-between" }}>
              <RepoCardInner repo={selected} />
              <Button variant="ghost" size="sm" onClick={() => { setSelected(null); setPhase("suggested"); setScanResult(null); onUpdate({ stage2: null }); }}>
                Change
              </Button>
            </div>
          </Card>

          <div style={{ marginTop: 18 }}>
            <div className="sect-h">
              <h3>Repository scan</h3>
              <span className="sect-sub">supported languages: {SUPPORTED_LANGUAGES.join(", ")}</span>
            </div>

            {scanning && (
              <Card>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <span className="spinner" />
                  <div>
                    <div style={{ fontWeight: 500, fontSize: 13 }}>Cloning shallow & counting files…</div>
                    <div style={{ fontSize: 12, color: "var(--fg-3)" }}>This usually takes a few seconds.</div>
                  </div>
                </div>
              </Card>
            )}

            {scanResult && (
              <>
                {!scanResult.supported ? (
                  <Status tone="danger" icon={<IconWarn size={14} />}>
                    Repo has <strong>{scanResult.fileCount}</strong> supported files — over the limit of {MAX_FILES_SUPPORT}.
                    Pick a smaller repo or scope the change.
                  </Status>
                ) : (
                  <Status tone="success" icon={<IconCheck size={14} />}>
                    {scanResult.fileCount} supported files indexed — well within the {MAX_FILES_SUPPORT}-file limit.
                  </Status>
                )}
                <div style={{
                  marginTop: 12, display: "grid",
                  gridTemplateColumns: "repeat(3, 1fr)", gap: 10
                }}>
                  {scanResult.langs.map(l => (
                    <div key={l.lang} style={{
                      padding: 12, border: "1px solid var(--border)", borderRadius: "var(--r-md)"
                    }}>
                      <div style={{ fontSize: 11, color: "var(--fg-3)", fontFamily: "var(--font-mono)" }}>{l.lang.toUpperCase()}</div>
                      <div style={{ fontSize: 22, fontWeight: 600, marginTop: 2 }}>{l.count}</div>
                      <div style={{ fontSize: 11, color: "var(--fg-3)" }}>files</div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </>
      )}

      <div className="stage-foot">
        <Button variant="ghost" icon={<IconArrowLeft size={12} />} onClick={onPrev}>Back</Button>
        <Button variant="primary" disabled={!scanResult?.supported} onClick={onNext}
          iconRight={<IconArrowRight size={12} />}>
          Continue to Stage 3
        </Button>
      </div>
    </div>
  );
};

const RepoCardInner = ({ repo, suggested }) => (
  <div style={{ display: "flex", gap: 12, alignItems: "flex-start", flex: 1, minWidth: 0 }}>
    <div className="gh-mark"><IconGithub size={16} /></div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
        <span className="mono" style={{ fontSize: 13, fontWeight: 500 }}>
          {repo.owner}/{repo.name}
        </span>
        {suggested && <Badge tone="info">suggested</Badge>}
        {repo.custom && <Badge>custom</Badge>}
      </div>
      <div style={{ fontSize: 12.5, color: "var(--fg-2)", marginTop: 3 }}>
        {repo.description || "—"}
      </div>
      <div className="repo-meta">
        {repo.language && <span>● {repo.language}</span>}
        {typeof repo.stars === "number" && <span>★ {repo.stars}</span>}
        {repo.files && <span>{repo.files} files</span>}
        {repo.updated && <span>updated {fmtRel(repo.updated)}</span>}
      </div>
    </div>
  </div>
);

window.Stage2 = Stage2;
