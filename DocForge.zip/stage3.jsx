/* === Stage 3: Context documents === */

const Stage3 = ({ project, onUpdate, onNext, onPrev }) => {
  const repo = project.stage2?.selectedRepo;
  const repoName = repo ? `${repo.owner}/${repo.name}` : "";
  const patternMatched = repo && README_REPO_PATTERNS.some(p => repo.name.startsWith(p));
  const [mode, setMode] = useState(patternMatched ? "readme" : (project.stage3?.mode || "search"));
  const [query, setQuery] = useState(project.stage3?.query || project.title || "");
  const [searching, setSearching] = useState(false);
  const [searched, setSearched] = useState(!!project.stage3?.results);
  const [results, setResults] = useState(project.stage3?.results || []);
  const [selected, setSelected] = useState(project.stage3?.selected || []);
  const [preview, setPreview] = useState(null);
  const [uploadedFiles, setUploadedFiles] = useState(project.stage3?.uploaded || []);
  const fileRef = useRef(null);

  const runSearch = () => {
    setSearching(true);
    setTimeout(() => {
      // Mock results — top 2 from FAISS, plus more if "search more"
      const scored = FAISS_DOCS.map(d => ({
        ...d,
        score: 0.5 + Math.random() * 0.5
      })).sort((a, b) => b.score - a.score).slice(0, 2);
      setResults(scored);
      setSearching(false);
      setSearched(true);
    }, 1000);
  };

  const searchMore = () => {
    setSearching(true);
    setTimeout(() => {
      const moreIds = new Set(results.map(r => r.id));
      const extra = FAISS_DOCS.filter(d => !moreIds.has(d.id)).map(d => ({
        ...d,
        score: 0.3 + Math.random() * 0.4
      })).sort((a, b) => b.score - a.score);
      setResults([...results, ...extra]);
      setSearching(false);
    }, 700);
  };

  const toggleSelect = (doc) => {
    setSelected(s =>
      s.find(x => x.id === doc.id) ? s.filter(x => x.id !== doc.id) : [...s, doc]
    );
  };

  const handleUpload = (list) => {
    const next = [...uploadedFiles];
    Array.from(list).forEach(f => next.push({ name: f.name, size: f.size, id: Math.random().toString(36).slice(2) }));
    setUploadedFiles(next);
  };

  // Auto-run search on mount when search mode
  useEffect(() => {
    if (mode === "search" && !searched && project.title) runSearch();
  }, [mode]);

  // Persist
  useEffect(() => {
    onUpdate({ stage3: { mode, query, results, selected, uploaded: uploadedFiles, readmeUsed: patternMatched } });
  }, [mode, results, selected, uploadedFiles]);

  const totalSelected = selected.length + uploadedFiles.length + (mode === "readme" ? 1 : 0);
  const canContinue = totalSelected > 0;

  return (
    <div data-screen-label="stage-3">
      <div className="stage-head">
        <div>
          <div className="stage-eyebrow">Stage 3 of 6</div>
          <h1>Context documents</h1>
          <p style={{ color: "var(--fg-2)", fontSize: 13.5, marginTop: 4 }}>
            DocForge needs supporting documentation to ground the plan it generates next.
          </p>
        </div>
        <Badge>{totalSelected} doc{totalSelected !== 1 ? "s" : ""} selected</Badge>
      </div>

      {patternMatched && (
        <Status tone="info" icon={<IconSparkles size={13} />}>
          Repo <span className="mono">{repoName}</span> matches pattern <span className="mono">payments-*</span> — using <span className="mono">README.md</span> from the repo automatically.
        </Status>
      )}

      <Tabs value={mode} onChange={setMode} options={[
        ...(patternMatched ? [{ value: "readme", label: "Repo README" }] : []),
        { value: "search", label: "Search NAS (FAISS)" },
        { value: "upload", label: "Upload your own" }
      ]} />

      {mode === "readme" && (
        <Card padded={false} className="md-pane" style={{ marginTop: 4 }}>
          <div className="md-pane-h">
            <span className="t">{repoName}/README.md</span>
            <Badge tone="success"><span className="dot" /> auto-included</Badge>
          </div>
          <div className="md-body">
            <h1>{repo?.name}</h1>
            <p>{repo?.description}</p>
            <h2>Overview</h2>
            <p>Stripe-backed payment service handling card authorization, capture, refunds, and webhooks for the Acme platform. Built with FastAPI on Python 3.11, deployed on EKS.</p>
            <h2>Architecture</h2>
            <ul>
              <li><code>charges/</code> — charge lifecycle, idempotency, status machine</li>
              <li><code>webhooks/</code> — outbound delivery with exponential backoff</li>
              <li><code>auth/</code> — 3DS hooks, PSD2 SCA flags (currently disabled)</li>
              <li><code>persistence/</code> — Postgres adapters, migrations</li>
            </ul>
            <h2>Running locally</h2>
            <pre><code>make dev{"\n"}make test</code></pre>
            <h2>Deployment</h2>
            <p>CI: GitHub Actions → ECR → ArgoCD. Owners: <code>@payments-platform</code>.</p>
          </div>
        </Card>
      )}

      {mode === "search" && (
        <>
          <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
            <div style={{ position: "relative", flex: 1 }}>
              <input className="input"
                placeholder="Search FAISS index (≈ 2k documents)…"
                value={query} onChange={e => setQuery(e.target.value)}
                style={{ paddingLeft: 32 }}
                onKeyDown={(e) => e.key === "Enter" && runSearch()} />
              <IconSearch size={13} style={{
                position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)",
                color: "var(--fg-3)"
              }} />
            </div>
            <Button variant="primary" disabled={!query || searching} onClick={runSearch}
              icon={searching ? <span className="spinner" /> : <IconSearch size={13} />}>
              {searching ? "Searching" : "Search"}
            </Button>
          </div>

          {searched && (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <div style={{ fontSize: 11.5, color: "var(--fg-3)", letterSpacing: "0.04em", textTransform: "uppercase", fontFamily: "var(--font-mono)" }}>
                Top {results.length <= 2 ? "2" : results.length} results
              </div>
              {results.map((doc, i) => {
                const isSelected = selected.find(s => s.id === doc.id);
                const isTop = i < 2;
                return (
                  <div key={doc.id} style={{
                    border: `1px solid ${isSelected ? "var(--fg)" : "var(--border)"}`,
                    borderRadius: "var(--r-md)",
                    padding: 14,
                    background: isSelected ? "var(--bg-2)" : "var(--bg)",
                    display: "flex", alignItems: "flex-start", gap: 12,
                    transition: "border-color 120ms"
                  }}>
                    <Checkbox checked={!!isSelected} onChange={() => toggleSelect(doc)} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                        <span style={{ fontSize: 13.5, fontWeight: 500 }}>{doc.title}</span>
                        <Badge>{doc.type}</Badge>
                        {isTop && <Badge tone="info">top-{i + 1}</Badge>}
                      </div>
                      <div style={{ fontSize: 12, color: "var(--fg-3)", marginTop: 3, fontFamily: "var(--font-mono)" }}>
                        {doc.path}
                      </div>
                      <div style={{ display: "flex", gap: 12, marginTop: 6, fontSize: 11.5, color: "var(--fg-2)", alignItems: "center" }}>
                        <Relevance score={doc.score} />
                        <span>· {doc.owner}</span>
                        <span>· {fmtBytes(doc.size)}</span>
                        <span>· updated {fmtRel(doc.updated)}</span>
                      </div>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-end" }}>
                      <Button size="sm" variant="ghost" icon={<IconEye size={12} />} onClick={() => setPreview(doc)}>
                        Preview
                      </Button>
                      <Button size="sm" variant={isSelected ? "default" : "primary"}
                        icon={isSelected ? <IconCheck size={12} /> : <IconPlus size={12} />}
                        onClick={() => toggleSelect(doc)}>
                        {isSelected ? "Selected" : "Select"}
                      </Button>
                    </div>
                  </div>
                );
              })}
              {!searching && (
                <Button variant="ghost" size="sm" icon={<IconSearch size={12} />}
                  onClick={searchMore} style={{ alignSelf: "flex-start", marginTop: 6 }}>
                  Search more in NAS
                </Button>
              )}
            </div>
          )}
        </>
      )}

      {mode === "upload" && (
        <>
          <div className="dropzone"
            onClick={() => fileRef.current?.click()}
            onDragOver={e => e.preventDefault()}
            onDrop={e => { e.preventDefault(); handleUpload(e.dataTransfer.files); }}>
            <input type="file" multiple ref={fileRef}
              style={{ display: "none" }}
              accept=".pdf,.doc,.docx,.md,.txt,.ppt,.pptx"
              onChange={e => e.target.files && handleUpload(e.target.files)} />
            <div style={{ color: "var(--fg-3)", marginBottom: 6 }}><IconUpload size={20} /></div>
            <div style={{ fontWeight: 500, marginBottom: 4 }}>Upload reference documents</div>
            <div style={{ fontSize: 12, color: "var(--fg-3)" }}>PDF, DOCX, MD, TXT, PPT</div>
          </div>
          {uploadedFiles.length > 0 && (
            <div style={{ marginTop: 12 }}>
              {uploadedFiles.map((f, i) => (
                <FileRow key={f.id} name={f.name} size={fmtBytes(f.size)}
                  status={<Badge tone="success">ready</Badge>}
                  onRemove={() => setUploadedFiles(uploadedFiles.filter((_, j) => j !== i))} />
              ))}
            </div>
          )}
        </>
      )}

      {(selected.length > 0 || uploadedFiles.length > 0) && (
        <Card style={{ marginTop: 20, background: "var(--bg-2)" }}>
          <div className="sect-h">
            <h3>Documents to include ({totalSelected})</h3>
            <Button size="sm" variant="ghost" onClick={() => { setSelected([]); setUploadedFiles([]); }}>
              Clear all
            </Button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {patternMatched && <FileRow name={`${repoName}/README.md`} status={<Badge tone="info">repo</Badge>} />}
            {selected.map(d => (
              <FileRow key={d.id} name={d.title}
                status={<Badge>{d.type}</Badge>}
                onRemove={() => toggleSelect(d)} />
            ))}
            {uploadedFiles.map((f, i) => (
              <FileRow key={f.id} name={f.name}
                status={<Badge>upload</Badge>}
                onRemove={() => setUploadedFiles(uploadedFiles.filter((_, j) => j !== i))} />
            ))}
          </div>
        </Card>
      )}

      <Modal open={!!preview} onClose={() => setPreview(null)} size="lg"
        title={preview?.title}>
        {preview && (
          <>
            <div style={{ display: "flex", gap: 12, marginBottom: 12, fontSize: 12, color: "var(--fg-2)" }}>
              <Badge>{preview.type}</Badge>
              <span className="mono">{preview.path}</span>
              <Relevance score={preview.score} />
            </div>
            <div className="md-body" style={{ borderTop: "1px solid var(--border)", paddingTop: 14, maxHeight: 320 }}>
              <p style={{ color: "var(--fg-3)", fontSize: 12, marginBottom: 12 }}>— preview of first 400 words —</p>
              <h2>{preview.title}</h2>
              <p>This document covers the technical specification for the payments service authentication layer. It defines the contract between checkout, the PSP, and our internal token store…</p>
              <p>Section 2.3 details the 3DS step-up flow currently implemented for North American card networks. EEA-specific requirements are tracked separately in COMPL-PCI-1.</p>
              <ul>
                <li>Authentication state machine</li>
                <li>Webhook contract <code>charge.requires_action</code></li>
                <li>SCA exemptions handled by the PSP</li>
              </ul>
              <p style={{ color: "var(--fg-3)" }}>…</p>
            </div>
          </>
        )}
      </Modal>

      <div className="stage-foot">
        <Button variant="ghost" icon={<IconArrowLeft size={12} />} onClick={onPrev}>Back</Button>
        <Button variant="primary" disabled={!canContinue} onClick={onNext}
          iconRight={<IconArrowRight size={12} />}>
          Continue to Stage 4
        </Button>
      </div>
    </div>
  );
};

window.Stage3 = Stage3;
