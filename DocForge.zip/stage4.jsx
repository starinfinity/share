/* === Stage 4: Planning === */

const DEFAULT_ACHIEVABLE = [
  "Add 3DS 2.2 challenge endpoint to /v1/charges accepting browser_info and return_url",
  "Introduce ChallengeFrame component to checkout SDK that renders the issuer's iframe",
  "Add webhook event charge.requires_action with idempotent delivery",
  "Wire feature flag feature.threeds_step_up to gate all new code paths",
  "Emit BigQuery events to payments.threeds_attempts on every challenge attempt",
  "Update Payments Runbook with rollback steps and challenge-failure diagnostics"
];

const DEFAULT_UNACHIEVABLE = [
  { task: "Achieve < 250 ms median checkout for non-challenged users on first deploy", reason: "Latency budget needs platform-level changes (DB pool sizing) outside this repo." },
  { task: "Marketplace-Connect 3DS support", reason: "Explicitly out of scope per PRD. Tracked separately for Q3." },
  { task: "Backfill historical un-challenged rejections", reason: "No retroactive challenge possible — requires re-auth of card on user device." }
];

const SAMPLE_PLAN = `# Detailed Implementation Plan

**Project:** {{key}} — {{title}}
**Target repo:** {{repo}}
**Generated:** just now

---

## 1. Scope Summary
Implement 3-D Secure 2.2 step-up authentication behind feature flag \`feature.threeds_step_up\`. The flow adds a synchronous challenge step when the PSP requests one, surfaces a hosted iframe in the checkout SDK, and emits a new webhook event.

## 2. Files to Change

### 2.1 \`charges/service.py\` — orchestration
- Add \`maybe_request_challenge(charge_id, browser_info)\` helper.
- Move state-machine transition for \`requires_action\` into \`StateMachine.transition\`.

### 2.2 \`charges/api.py\` — public endpoint
- Extend \`POST /v1/charges\` body schema with optional \`browser_info\` and \`return_url\`.
- Return \`202 Accepted\` with \`next_action\` payload when challenge is required.

### 2.3 \`webhooks/dispatcher.py\` — new event
- Register \`charge.requires_action\` event type and payload schema.
- Add to canary delivery list.

### 2.4 \`feature_flags/registry.py\`
- Define \`feature.threeds_step_up\` with default \`off\`. Document rollout plan.

### 2.5 \`tests/test_threeds.py\` (new)
- Unit tests for \`maybe_request_challenge\`, frictionless fallback, expired challenge.
- Contract tests against PSP sandbox.

## 3. Sequence
1. Land flag + state-machine changes (no behavior change).
2. Ship webhook event (consumers opt-in).
3. Ship SDK \`ChallengeFrame\` to staging.
4. Enable flag for 5% EEA traffic; monitor \`auth-failures\` dashboard.
5. Roll to 100% over 48 hours.

## 4. Risks & Mitigations
| Risk | Mitigation |
|---|---|
| Latency regression on non-challenged path | Run synthetic latency suite in CI; alert at p95 > 220 ms. |
| Webhook consumer surprise | Pre-announce in #payments-platform; consumers opt-in via subscription update. |
| Issuer iframe blocked by CSP | Pin allowed origins per PSP; add CSP report-only first. |

## 5. Acceptance
- All tests green in CI.
- Synthetic challenge succeeds end-to-end in staging.
- Runbook updated; on-call sign-off.`;

const Stage4 = ({ project, onUpdate, onNext, onPrev }) => {
  const [phase, setPhase] = useState(project.stage4?.plan ? "plan" : "tasks");
  const [generating, setGenerating] = useState(!project.stage4?.achievable);
  const [achievable, setAchievable] = useState(project.stage4?.achievable || []);
  const [unachievable, setUnachievable] = useState(project.stage4?.unachievable || []);
  const [special, setSpecial] = useState(project.stage4?.special || "");
  const [editIdx, setEditIdx] = useState(null);
  const [newTask, setNewTask] = useState("");
  const [planning, setPlanning] = useState(false);
  const [plan, setPlan] = useState(project.stage4?.plan || "");

  // Generate tasks on mount
  useEffect(() => {
    if (achievable.length === 0) {
      const t = setTimeout(() => {
        setAchievable(DEFAULT_ACHIEVABLE.map((task, i) => ({ id: "a-" + i, task, checked: true })));
        setUnachievable(DEFAULT_UNACHIEVABLE);
        setGenerating(false);
      }, 1500);
      return () => clearTimeout(t);
    } else { setGenerating(false); }
  }, []);

  const generatePlan = () => {
    setPlanning(true); setPlan(""); setPhase("plan");
    const target = SAMPLE_PLAN
      .replace("{{key}}", project.key)
      .replace("{{title}}", project.title)
      .replace("{{repo}}", project.stage2?.selectedRepo ? `${project.stage2.selectedRepo.owner}/${project.stage2.selectedRepo.name}` : "—");
    let i = 0;
    const tick = () => {
      i += 80;
      setPlan(target.slice(0, i));
      if (i < target.length) setTimeout(tick, 12);
      else {
        setPlanning(false);
        onUpdate({ stage4: { achievable, unachievable, special, plan: target } });
      }
    };
    setTimeout(tick, 400);
  };

  const addTask = () => {
    if (!newTask.trim()) return;
    setAchievable([...achievable, { id: Math.random().toString(36).slice(2), task: newTask.trim(), checked: true }]);
    setNewTask("");
  };

  const deleteTask = (id) => setAchievable(achievable.filter(t => t.id !== id));
  const editTask = (id, val) => setAchievable(achievable.map(t => t.id === id ? { ...t, task: val } : t));
  const toggleTask = (id) => setAchievable(achievable.map(t => t.id === id ? { ...t, checked: !t.checked } : t));

  return (
    <div data-screen-label="stage-4">
      <div className="stage-head">
        <div>
          <div className="stage-eyebrow">Stage 4 of 6</div>
          <h1>Planning</h1>
          <p style={{ color: "var(--fg-2)", fontSize: 13.5, marginTop: 4 }}>
            Review achievable vs. unachievable tasks, then generate a detailed implementation plan.
          </p>
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          <Badge tone={phase === "tasks" ? "info" : "success"}>Tasks</Badge>
          <Badge tone={phase === "plan" ? "info" : undefined}>Plan</Badge>
        </div>
      </div>

      {generating && (
        <Card>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span className="spinner spinner-lg" />
            <div>
              <div style={{ fontWeight: 500 }}>Analyzing requirements, code, and context docs…</div>
              <div style={{ fontSize: 12, color: "var(--fg-3)" }}>
                Producing achievable + unachievable task lists.
              </div>
            </div>
          </div>
        </Card>
      )}

      {!generating && phase === "tasks" && (
        <>
          {/* Achievable */}
          <div className="sect-h" style={{ marginTop: 6 }}>
            <h3>
              <span className="dot" style={{ color: "var(--success)", marginRight: 6 }} />
              Achievable tasks
            </h3>
            <span className="sect-sub">{achievable.filter(t => t.checked).length}/{achievable.length} included</span>
          </div>

          {achievable.map(t => (
            <div key={t.id} className="task-row deletable">
              <Checkbox checked={t.checked} onChange={() => toggleTask(t.id)} />
              {editIdx === t.id ? (
                <input className="input" value={t.task}
                  onChange={e => editTask(t.id, e.target.value)}
                  onBlur={() => setEditIdx(null)}
                  onKeyDown={e => e.key === "Enter" && setEditIdx(null)}
                  autoFocus
                  style={{ flex: 1, height: 28 }} />
              ) : (
                <span style={{ flex: 1, fontSize: 13.5, opacity: t.checked ? 1 : 0.5, textDecoration: t.checked ? "none" : "line-through" }}>
                  {t.task}
                </span>
              )}
              <button className="task-edit-btn" onClick={() => setEditIdx(t.id)}>
                <IconEdit size={12} />
              </button>
              <button className="task-edit-btn" onClick={() => deleteTask(t.id)}>
                <IconTrash size={12} />
              </button>
            </div>
          ))}

          <div style={{ display: "flex", gap: 6, marginTop: 10 }}>
            <input className="input" placeholder="Add a task…"
              value={newTask}
              onChange={e => setNewTask(e.target.value)}
              onKeyDown={e => e.key === "Enter" && addTask()} />
            <Button icon={<IconPlus size={12} />} disabled={!newTask.trim()} onClick={addTask}>Add</Button>
          </div>

          {/* Unachievable */}
          <div className="sect-h" style={{ marginTop: 24 }}>
            <h3>
              <span className="dot" style={{ color: "var(--danger)", marginRight: 6 }} />
              Unachievable in this run
            </h3>
            <span className="sect-sub">read-only · for transparency</span>
          </div>

          {unachievable.map((u, i) => (
            <div key={i} style={{
              padding: "10px 12px",
              border: "1px solid var(--border)", borderRadius: "var(--r-md)",
              background: "var(--bg-2)",
              marginBottom: 6
            }}>
              <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
                <IconX size={12} style={{ color: "var(--danger)", marginTop: 4, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 13, color: "var(--fg)" }}>{u.task}</div>
                  <div style={{ fontSize: 12, color: "var(--fg-2)", marginTop: 3 }}>
                    <strong>Why:</strong> {u.reason}
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Special request */}
          <div className="sect-h" style={{ marginTop: 24 }}>
            <h3>Special instructions</h3>
            <span className="sect-sub">optional · added to the planner prompt</span>
          </div>
          <textarea className="textarea"
            placeholder="e.g. Use existing FeatureFlagAdapter; keep ChallengeFrame WCAG AA compliant; avoid touching webhook auth."
            value={special} onChange={e => setSpecial(e.target.value)}
            rows={3} />

          <div style={{ marginTop: 20, display: "flex", gap: 8 }}>
            <Button variant="primary" icon={<IconSparkles size={13} />} onClick={generatePlan}
              disabled={achievable.filter(t => t.checked).length === 0}>
              Generate detailed plan
            </Button>
            <Button variant="ghost" icon={<IconRefresh size={12} />}
              onClick={() => { setAchievable([]); setUnachievable([]); setGenerating(true); setTimeout(() => {
                setAchievable(DEFAULT_ACHIEVABLE.map((task, i) => ({ id: "a-" + i, task, checked: true })));
                setUnachievable(DEFAULT_UNACHIEVABLE);
                setGenerating(false);
              }, 1200); }}>
              Regenerate tasks
            </Button>
          </div>
        </>
      )}

      {phase === "plan" && (
        <>
          <div className="md-pane">
            <div className="md-pane-h">
              <span className="t">plan.md</span>
              {planning ? <span style={{ fontSize: 11, color: "var(--fg-3)" }}><span className="spinner" /> planning…</span>
                : <span style={{ fontSize: 11, color: "var(--fg-3)" }}>{plan.length} chars · ~{Math.ceil(plan.length / 280)} min read</span>}
            </div>
            <div className="md-body" style={{ maxHeight: 460 }}>
              <RenderMarkdown text={plan} />
            </div>
          </div>

          <div style={{ marginTop: 14, display: "flex", gap: 8 }}>
            <Button variant="ghost" icon={<IconRefresh size={12} />}
              onClick={() => setPhase("tasks")}>
              Plan again with different tasks
            </Button>
            <Button variant="ghost" icon={<IconCopy size={12} />}>Copy plan</Button>
            <Button variant="ghost" icon={<IconDownload size={12} />}>Download .md</Button>
          </div>
        </>
      )}

      <div className="stage-foot">
        <Button variant="ghost" icon={<IconArrowLeft size={12} />} onClick={onPrev}>Back</Button>
        <Button variant="primary" disabled={!plan || planning} onClick={onNext}
          iconRight={<IconArrowRight size={12} />}>
          Approve plan & continue
        </Button>
      </div>
    </div>
  );
};

window.Stage4 = Stage4;
window.SAMPLE_PLAN = SAMPLE_PLAN;
