/* === Stage 5: Document update + chatbot === */

const STAGE5_DOC_BEFORE = `# Payment Processing Tech Spec v3.2

## 5. Authentication
The payments service relies on the PSP's risk engine to determine when an
authentication challenge is required. For card payments originating from
**North American card networks**, the service supports a synchronous 3DS
challenge step.

### 5.1 Supported regions
- North America
- ~~EEA~~ *(not currently supported)*

### 5.2 Flow
1. Client submits charge via \`POST /v1/charges\`.
2. Service forwards to PSP.
3. PSP decides; if challenge required, service returns 402 (legacy).
`;

const STAGE5_DOC_AFTER = `# Payment Processing Tech Spec v3.3

> **Updated by DocForge** — {{key}} — {{date}}
> Adds EEA 3-D Secure 2.2 step-up authentication.

## 5. Authentication
The payments service relies on the PSP's risk engine to determine when an
authentication challenge is required. For card payments originating from
**North American or EEA card networks**, the service supports a synchronous
3DS 2.2 step-up challenge step, gated behind \`feature.threeds_step_up\`.

### 5.1 Supported regions
- North America
- **EEA** *(new — gated by feature flag during rollout)*

### 5.2 Flow
1. Client submits charge via \`POST /v1/charges\` with optional \`browser_info\` and \`return_url\`.
2. Service forwards to PSP.
3. PSP decides; if challenge required, service returns **202 Accepted** with a \`next_action\` payload and emits webhook \`charge.requires_action\`.
4. Client renders \`ChallengeFrame\` from the checkout SDK; on completion, charge resumes.

### 5.3 New Webhook Event
\`\`\`
charge.requires_action {
  charge_id: string,
  next_action: { type: "threeds_challenge", url: string },
  expires_at: timestamp
}
\`\`\`

### 5.4 Telemetry
All challenge attempts emit to \`payments.threeds_attempts\` in BigQuery.
Latency SLOs:
- p50 challenge-issued: ≤ 800 ms
- p95 challenge-complete: ≤ 4 s

### 5.5 Rollback
Toggle \`feature.threeds_step_up\` to \`off\`. The webhook event continues to be delivered to opted-in subscribers; the SDK falls back gracefully.
`;

const Stage5 = ({ project, onUpdate, onNext, onPrev }) => {
  const [generating, setGenerating] = useState(!project.stage5?.doc);
  const [doc, setDoc] = useState(project.stage5?.doc || "");
  const [view, setView] = useState("after"); // before | after | diff
  const [chatMessages, setChatMessages] = useState(project.stage5?.chat || [
    { role: "agent", text: "I've updated Payment Processing Tech Spec v3.2 → v3.3 based on the approved plan. What else would you like to adjust?" }
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);

  useEffect(() => {
    if (generating) {
      const target = STAGE5_DOC_AFTER
        .replace("{{key}}", project.key)
        .replace("{{date}}", new Date().toLocaleDateString());
      let i = 0;
      const tick = () => {
        i += 60;
        setDoc(target.slice(0, i));
        if (i < target.length) setTimeout(tick, 10);
        else { setGenerating(false); onUpdate({ stage5: { doc: target, chat: chatMessages } }); }
      };
      setTimeout(tick, 600);
    }
  }, []);

  const send = () => {
    if (!input.trim()) return;
    const userMsg = { role: "user", text: input.trim() };
    setChatMessages(m => [...m, userMsg]);
    setInput(""); setThinking(true);
    setTimeout(() => {
      const reply = generateReply(userMsg.text);
      setChatMessages(m => [...m, { role: "agent", text: reply }]);
      setThinking(false);
    }, 900);
  };

  const generateReply = (q) => {
    const lower = q.toLowerCase();
    if (lower.includes("rollback") || lower.includes("revert")) {
      return "I expanded section 5.5 Rollback with a step-by-step procedure and added a paragraph on dual-write behavior during the toggle window. The version label is now v3.3-rc1.";
    }
    if (lower.includes("diagram") || lower.includes("sequence")) {
      return "Added a sequence diagram placeholder in section 5.2 referencing the charge → PSP → SDK round-trip. You'll want to drop the actual Mermaid block before publishing.";
    }
    if (lower.includes("compliance") || lower.includes("pci")) {
      return "Cross-linked COMPL-PCI-1 in section 5 and added a note clarifying that step-up does not change cardholder data handling — PSP remains the merchant of record.";
    }
    return "Updated. Section 5 now reflects your change. Want me to also propagate it to the API Reference (API-PAY-002)?";
  };

  return (
    <div data-screen-label="stage-5">
      <div className="stage-head">
        <div>
          <div className="stage-eyebrow">Stage 5 of 6</div>
          <h1>Document update</h1>
          <p style={{ color: "var(--fg-2)", fontSize: 13.5, marginTop: 4 }}>
            DocForge applied the plan to the supporting document. Refine it via chat before continuing.
          </p>
        </div>
        <Badge tone="success">v3.2 → v3.3</Badge>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16, alignItems: "flex-start" }}>
        {/* Document */}
        <div className="md-pane">
          <div className="md-pane-h">
            <div style={{ display: "flex", gap: 4 }}>
              <span className={`tab ${view === "before" ? "active" : ""}`}
                onClick={() => setView("before")} style={{ padding: "4px 10px", fontSize: 11, marginBottom: 0, borderBottom: 0 }}>
                Before
              </span>
              <span className={`tab ${view === "after" ? "active" : ""}`}
                onClick={() => setView("after")} style={{ padding: "4px 10px", fontSize: 11, marginBottom: 0, borderBottom: 0 }}>
                After
              </span>
              <span className={`tab ${view === "diff" ? "active" : ""}`}
                onClick={() => setView("diff")} style={{ padding: "4px 10px", fontSize: 11, marginBottom: 0, borderBottom: 0 }}>
                Diff
              </span>
            </div>
            <span style={{ fontSize: 11, color: "var(--fg-3)" }}>
              {generating ? <><span className="spinner" /> applying plan…</> : "TS-PAY-014.md"}
            </span>
          </div>
          <div className="md-body" style={{ maxHeight: 520 }}>
            {view === "before" && <RenderMarkdown text={STAGE5_DOC_BEFORE} />}
            {view === "after" && <RenderMarkdown text={doc} />}
            {view === "diff" && <DocDiff />}
          </div>
        </div>

        {/* Chatbot */}
        <div className="chat-shell" style={{ height: 560, position: "sticky", top: 70 }}>
          <div className="chat-h">
            <IconBot size={14} />
            <span style={{ fontWeight: 500, fontSize: 12.5 }}>DocForge agent</span>
            <Badge tone="success" style={{ marginLeft: "auto" }}><span className="dot" /> ready</Badge>
          </div>
          <div className="chat-msgs" style={{ flex: 1 }}>
            {chatMessages.map((m, i) => (
              <div key={i} className={`chat-msg ${m.role}`}>
                <div className="chat-avatar">{m.role === "user" ? "U" : "DF"}</div>
                <div className="chat-bubble">{m.text}</div>
              </div>
            ))}
            {thinking && (
              <div className="chat-msg agent">
                <div className="chat-avatar">DF</div>
                <div className="chat-bubble" style={{ display: "flex", gap: 3 }}>
                  <span className="dot" style={{ animation: "pulse 1s infinite", color: "var(--fg-3)" }} />
                  <span className="dot" style={{ animation: "pulse 1s 0.2s infinite", color: "var(--fg-3)" }} />
                  <span className="dot" style={{ animation: "pulse 1s 0.4s infinite", color: "var(--fg-3)" }} />
                </div>
              </div>
            )}
          </div>
          <div className="chat-input-row">
            <input className="input" placeholder="Refine the doc…" value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && send()} />
            <Button variant="primary" icon={<IconSend size={12} />} onClick={send}
              disabled={!input.trim() || thinking} />
          </div>
        </div>
      </div>

      <div style={{ marginTop: 14, display: "flex", gap: 8, fontSize: 12, color: "var(--fg-3)" }}>
        <Button variant="ghost" size="sm" icon={<IconDownload size={12} />}>Download .docx</Button>
        <Button variant="ghost" size="sm" icon={<IconExternal size={12} />}>Open in NAS</Button>
        <Button variant="ghost" size="sm" icon={<IconCopy size={12} />}>Copy markdown</Button>
      </div>

      <div className="stage-foot">
        <Button variant="ghost" icon={<IconArrowLeft size={12} />} onClick={onPrev}>Back</Button>
        <Button variant="primary" disabled={generating} onClick={onNext}
          iconRight={<IconArrowRight size={12} />}>
          Continue to Stage 6
        </Button>
      </div>
    </div>
  );
};

const DocDiff = () => (
  <div className="diff">
    <span className="ctx"># Payment Processing Tech Spec </span>
    <span className="rem">- v3.2</span>
    <span className="add">+ v3.3</span>
    <span className="ctx"> </span>
    <span className="add">+ &gt; **Updated by DocForge** — DF-1042</span>
    <span className="add">+ &gt; Adds EEA 3-D Secure 2.2 step-up authentication.</span>
    <span className="ctx"> </span>
    <span className="ctx">## 5. Authentication</span>
    <span className="ctx">The payments service relies on the PSP's risk engine…</span>
    <span className="rem">- For card payments originating from **North American card networks**</span>
    <span className="add">+ For card payments originating from **North American or EEA card networks**</span>
    <span className="add">+ The service supports a synchronous 3DS 2.2 step-up challenge step,</span>
    <span className="add">+ gated behind `feature.threeds_step_up`.</span>
    <span className="ctx"> </span>
    <span className="ctx">### 5.1 Supported regions</span>
    <span className="ctx">- North America</span>
    <span className="rem">- - ~~EEA~~ *(not currently supported)*</span>
    <span className="add">+ - **EEA** *(new — gated by feature flag during rollout)*</span>
    <span className="ctx"> </span>
    <span className="add">+ ### 5.3 New Webhook Event</span>
    <span className="add">+ ```</span>
    <span className="add">+ charge.requires_action {`{...}`}</span>
    <span className="add">+ ```</span>
    <span className="add">+ ### 5.4 Telemetry</span>
    <span className="add">+ All challenge attempts emit to payments.threeds_attempts.</span>
    <span className="add">+ ### 5.5 Rollback</span>
    <span className="add">+ Toggle feature.threeds_step_up off…</span>
  </div>
);

window.Stage5 = Stage5;
