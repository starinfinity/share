/* === Stage 6: Code change & PR === */

const PR_CHANGES = [
  { file: "charges/api.py", add: 28, rem: 4 },
  { file: "charges/service.py", add: 41, rem: 2 },
  { file: "webhooks/dispatcher.py", add: 18, rem: 0 },
  { file: "feature_flags/registry.py", add: 6, rem: 0 },
  { file: "tests/test_threeds.py", add: 132, rem: 0 },
  { file: "docs/threeds-rollout.md", add: 47, rem: 0 }
];

const Stage6 = ({ project, onUpdate, onPrev, onComplete }) => {
  const [phase, setPhase] = useState(project.stage6?.prUrl ? "open" : "applying");
  const [progress, setProgress] = useState(0);
  const [branch, setBranch] = useState(project.stage6?.branch || `Docforge-${project.key.toLowerCase()}-3ds-step-up`);
  const [prUrl, setPrUrl] = useState(project.stage6?.prUrl || "");
  const [chatMessages, setChatMessages] = useState(project.stage6?.chat || [
    { role: "agent", text: "PR opened. CI is running. Want a different commit grouping, additional tests, or a tweak to the PR description?" }
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);

  // simulate progress
  useEffect(() => {
    if (phase === "applying") {
      let p = 0;
      const tick = () => {
        p += Math.random() * 22 + 6;
        if (p >= 100) {
          setProgress(100);
          setTimeout(() => {
            setPhase("open");
            setPrUrl(`https://github.com/${project.stage2?.selectedRepo?.owner || "acme-corp"}/${project.stage2?.selectedRepo?.name || "payments-api"}/pull/${1400 + Math.floor(Math.random() * 99)}`);
          }, 500);
        } else {
          setProgress(p);
          setTimeout(tick, 250);
        }
      };
      setTimeout(tick, 400);
    }
  }, []);

  useEffect(() => {
    if (prUrl) onUpdate({ stage6: { branch, prUrl, chat: chatMessages } });
  }, [prUrl, chatMessages]);

  const send = () => {
    if (!input.trim()) return;
    setChatMessages(m => [...m, { role: "user", text: input.trim() }]);
    const q = input.toLowerCase();
    setInput(""); setThinking(true);
    setTimeout(() => {
      let reply = "Done. Force-pushed an updated commit; CI is re-running.";
      if (q.includes("test")) reply = "Added 4 more cases to test_threeds.py covering expired challenge, malformed browser_info, double-submit idempotency, and PSP timeout. CI re-running.";
      if (q.includes("description") || q.includes("title")) reply = "Updated the PR description with a Risks & Mitigations table and linked the runbook. The title is now \"feat(payments): 3DS 2.2 step-up authentication (EEA)\".";
      if (q.includes("revert") || q.includes("undo")) reply = "Reverted the last commit. The branch is back to the state right after the initial push.";
      setChatMessages(m => [...m, { role: "agent", text: reply }]);
      setThinking(false);
    }, 900);
  };

  return (
    <div data-screen-label="stage-6">
      <div className="stage-head">
        <div>
          <div className="stage-eyebrow">Stage 6 of 6</div>
          <h1>Code change & pull request</h1>
          <p style={{ color: "var(--fg-2)", fontSize: 13.5, marginTop: 4 }}>
            DocForge applies the plan to {project.stage2?.selectedRepo?.name || "the repo"} and opens a PR you can iterate on.
          </p>
        </div>
        {phase === "open" && <Badge tone="success">PR opened</Badge>}
      </div>

      {phase === "applying" && (
        <Card>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
            <span className="spinner spinner-lg" />
            <div>
              <div style={{ fontWeight: 500 }}>Applying changes to <span className="mono">{branch}</span></div>
              <div style={{ fontSize: 12, color: "var(--fg-3)" }}>Editing files, running formatters, committing.</div>
            </div>
          </div>
          <div style={{ height: 4, background: "var(--bg-3)", borderRadius: 999, overflow: "hidden" }}>
            <div style={{ height: "100%", background: "var(--accent)", width: `${progress}%`, transition: "width 250ms" }} />
          </div>
          <div style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 4, fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--fg-2)" }}>
            {[
              "git checkout -b " + branch,
              "applying patch to charges/api.py",
              "applying patch to charges/service.py",
              "applying patch to webhooks/dispatcher.py",
              "running ruff + black",
              "running pytest -k threeds",
              "git commit -m \"feat: 3DS step-up\"",
              "git push origin " + branch,
              "opening pull request…"
            ].slice(0, Math.ceil(progress / 12)).map((l, i) => (
              <div key={i}>$ {l}</div>
            ))}
          </div>
        </Card>
      )}

      {phase === "open" && (
        <>
          <Card>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
              <div className="tile-icon" style={{ width: 36, height: 36, background: "var(--success-bg)", borderColor: "var(--success)" }}>
                <IconPullRequest size={16} stroke={1.8} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontWeight: 600, fontSize: 14 }}>
                    feat({project.stage2?.selectedRepo?.name?.split("-")[0] || "payments"}): {project.title.toLowerCase()}
                  </span>
                  <Badge tone="success"><span className="dot" /> Open</Badge>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 6, fontSize: 12, color: "var(--fg-2)" }}>
                  <IconBranch size={12} />
                  <span className="mono">{branch}</span>
                  <span>→</span>
                  <span className="mono">main</span>
                </div>
                <div style={{ display: "flex", gap: 12, marginTop: 8, fontSize: 11.5, color: "var(--fg-3)" }}>
                  <span><strong style={{ color: "var(--success)" }}>+{PR_CHANGES.reduce((s, c) => s + c.add, 0)}</strong> additions</span>
                  <span><strong style={{ color: "var(--danger)" }}>−{PR_CHANGES.reduce((s, c) => s + c.rem, 0)}</strong> deletions</span>
                  <span>{PR_CHANGES.length} files changed</span>
                </div>
              </div>
              <Button variant="primary" icon={<IconExternal size={12} />}
                onClick={() => window.open(prUrl, "_blank")}>
                View on GitHub
              </Button>
            </div>
          </Card>

          <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16, marginTop: 18, alignItems: "flex-start" }}>
            {/* Files changed */}
            <div>
              <div className="sect-h"><h3>Files changed</h3><span className="sect-sub">{PR_CHANGES.length} files</span></div>
              {PR_CHANGES.map(f => (
                <div key={f.file} style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "9px 12px",
                  border: "1px solid var(--border)", borderRadius: "var(--r-md)",
                  marginBottom: 6
                }}>
                  <IconCode size={14} style={{ color: "var(--fg-3)" }} />
                  <span className="mono" style={{ fontSize: 12.5, flex: 1 }}>{f.file}</span>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 11.5 }}>
                    <span style={{ color: "var(--success)" }}>+{f.add}</span>
                    {f.rem > 0 && <span style={{ color: "var(--danger)", marginLeft: 4 }}>−{f.rem}</span>}
                  </span>
                  <div style={{ display: "flex", width: 50, height: 6, gap: 1 }}>
                    {Array(Math.min(10, f.add + f.rem)).fill().map((_, i) => (
                      <span key={i} style={{
                        flex: 1, borderRadius: 1,
                        background: i < (f.add / (f.add + f.rem)) * 10 ? "var(--success)" : "var(--danger)"
                      }} />
                    ))}
                  </div>
                </div>
              ))}

              <div style={{ marginTop: 14 }}>
                <div className="sect-h"><h3>CI checks</h3></div>
                {[
                  { name: "lint / ruff", status: "success", duration: "12s" },
                  { name: "lint / mypy", status: "success", duration: "31s" },
                  { name: "test / pytest", status: "running", duration: "1m 14s" },
                  { name: "build / docker", status: "queued", duration: "—" }
                ].map(c => (
                  <div key={c.name} style={{
                    display: "flex", alignItems: "center", gap: 10,
                    padding: "8px 12px",
                    border: "1px solid var(--border)", borderRadius: "var(--r-md)",
                    marginBottom: 5, fontSize: 12.5
                  }}>
                    {c.status === "success" && <span style={{ color: "var(--success)" }}><IconCheck size={13} /></span>}
                    {c.status === "running" && <span className="spinner" style={{ width: 12, height: 12 }} />}
                    {c.status === "queued" && <IconClock size={13} style={{ color: "var(--fg-3)" }} />}
                    <span className="mono" style={{ flex: 1 }}>{c.name}</span>
                    <span style={{ color: "var(--fg-3)", fontSize: 11 }}>{c.duration}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Chatbot */}
            <div className="chat-shell" style={{ height: 540, position: "sticky", top: 70 }}>
              <div className="chat-h">
                <IconBot size={14} />
                <span style={{ fontWeight: 500, fontSize: 12.5 }}>DocForge agent</span>
                <Badge tone="success" style={{ marginLeft: "auto" }}><span className="dot" /> ready</Badge>
              </div>
              <div className="chat-msgs" style={{ flex: 1 }}>
                {chatMessages.map((m, i) => (
                  <div key={i} className={`chat-msg ${m.role}`}>
                    <div className="chat-avatar">{m.role === "user" ? "U" : "DF"}</div>
                    <div className="chat-bubble">{m.text}</div>
                  </div>
                ))}
                {thinking && (
                  <div className="chat-msg agent">
                    <div className="chat-avatar">DF</div>
                    <div className="chat-bubble" style={{ display: "flex", gap: 3 }}>
                      <span className="dot" style={{ animation: "pulse 1s infinite", color: "var(--fg-3)" }} />
                      <span className="dot" style={{ animation: "pulse 1s 0.2s infinite", color: "var(--fg-3)" }} />
                      <span className="dot" style={{ animation: "pulse 1s 0.4s infinite", color: "var(--fg-3)" }} />
                    </div>
                  </div>
                )}
              </div>
              <div className="chat-input-row">
                <input className="input" placeholder="Iterate on the PR…" value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && send()} />
                <Button variant="primary" icon={<IconSend size={12} />} onClick={send}
                  disabled={!input.trim() || thinking} />
              </div>
            </div>
          </div>
        </>
      )}

      <div className="stage-foot">
        <Button variant="ghost" icon={<IconArrowLeft size={12} />} onClick={onPrev}>Back</Button>
        <Button variant="primary" disabled={phase !== "open"} onClick={onComplete}
          icon={<IconCheck size={13} />}>
          Mark project complete
        </Button>
      </div>
    </div>
  );
};

window.Stage6 = Stage6;
