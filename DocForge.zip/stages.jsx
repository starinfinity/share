/* === Stages 1–6 === */

/* ──────────────────────────────────────────────────────────────
   STAGE 1 — Requirements extraction
   ────────────────────────────────────────────────────────────── */

const Stage1 = ({ project, onUpdate, onNext }) => {
  const [files, setFiles] = useState(project.stage1?.files || []);
  const [extracting, setExtracting] = useState(false);
  const [md, setMd] = useState(project.stage1?.md || "");
  const [drag, setDrag] = useState(false);
  const fileRef = useRef(null);

  const accept = ".ppt,.pptx,.doc,.docx,.txt,.png,.jpg,.jpeg";

  const acceptedTypes = ["PPT", "PPTX", "DOC", "DOCX", "TXT", "PNG", "JPG"];

  const addFiles = (list) => {
    const next = [...files];
    Array.from(list).forEach(f => {
      next.push({ name: f.name, size: f.size, id: Math.random().toString(36).slice(2) });
    });
    setFiles(next);
  };

  const extract = () => {
    setExtracting(true);
    setMd("");
    // Simulate streaming extraction
    let i = 0;
    const target = project.title
      ? SAMPLE_EXTRACTED_MD.replace("Add 3-D Secure Step-Up Authentication", project.title)
                           .replace("DF-1042", project.key)
      : SAMPLE_EXTRACTED_MD;
    const chunk = 60;
    const tick = () => {
      i += chunk;
      setMd(target.slice(0, i));
      if (i < target.length) {
        setTimeout(tick, 12);
      } else {
        setExtracting(false);
        onUpdate({ stage1: { files, md: target, complete: true } });
      }
    };
    setTimeout(tick, 600);
  };

  const ready = files.length > 0;
  const hasMd = md.length > 0;

  return (
    <div data-screen-label="stage-1">
      <div className="stage-head">
        <div>
          <div className="stage-eyebrow">Stage 1 of 6</div>
          <h1>Requirements</h1>
          <p style={{ color: "var(--fg-2)", fontSize: 13.5, marginTop: 4 }}>
            Upload requirements documents. DocForge will extract them into structured Markdown.
          </p>
        </div>
        <Badge>{ready ? `${files.length} file${files.length > 1 ? "s" : ""}` : "no input"}</Badge>
      </div>

      {/* Upload zone */}
      <div className="sect-h"><h3>Inputs</h3><span className="sect-sub">Accepted: {acceptedTypes.join(", ")}</span></div>

      <div
        className={`dropzone ${drag ? "drag" : ""}`}
        onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault(); setDrag(false);
          if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
        }}
        onClick={() => fileRef.current?.click()}>
        <input type="file" ref={fileRef} multiple accept={accept}
          style={{ display: "none" }}
          onChange={(e) => e.target.files && addFiles(e.target.files)} />
        <div style={{ fontSize: 24, marginBottom: 6, color: "var(--fg-3)" }}>
          <IconUpload size={24} />
        </div>
        <div style={{ fontWeight: 500, marginBottom: 4 }}>
          Drop files or <span style={{ textDecoration: "underline" }}>browse</span>
        </div>
        <div style={{ fontSize: 12, color: "var(--fg-3)" }}>
          Up to 25 MB · multiple files allowed
        </div>
      </div>

      {files.length > 0 && (
        <div style={{ marginTop: 14 }}>
          {files.map((f, i) => (
            <FileRow key={f.id} name={f.name} size={fmtBytes(f.size)}
              status={<Badge tone="success">queued</Badge>}
              onRemove={() => setFiles(files.filter((_, j) => j !== i))} />
          ))}
        </div>
      )}

      <div style={{ marginTop: 16, display: "flex", gap: 8 }}>
        <Button variant="primary" disabled={!ready || extracting} onClick={extract}
          icon={extracting ? <span className="spinner" /> : <IconSparkles size={13} />}>
          {extracting ? "Extracting…" : (hasMd ? "Re-extract" : "Extract requirements")}
        </Button>
        {hasMd && (
          <Button variant="ghost" onClick={() => { setMd(""); }}>
            Clear
          </Button>
        )}
      </div>

      {/* Extracted MD */}
      {(extracting || hasMd) && (
        <div style={{ marginTop: 28 }} className="fade-in">
          <div className="sect-h">
            <h3>Extracted requirements</h3>
            <div style={{ display: "flex", gap: 6 }}>
              <Button size="sm" variant="ghost" icon={<IconCopy size={12} />}>Copy MD</Button>
              <Button size="sm" variant="ghost" icon={<IconDownload size={12} />}>Download .md</Button>
            </div>
          </div>
          <div className="md-pane">
            <div className="md-pane-h">
              <span className="t">requirements.md</span>
              <span style={{ fontSize: 11, color: "var(--fg-3)" }}>
                {extracting ? <><span className="spinner" /> writing…</> : `${md.length} chars`}
              </span>
            </div>
            <div className="md-body">
              <RenderMarkdown text={md} />
              {extracting && <span style={{ display: "inline-block", width: 8, height: 14, background: "var(--fg)", animation: "pulse 700ms infinite", verticalAlign: "middle" }} />}
            </div>
          </div>
        </div>
      )}

      <div className="stage-foot">
        <Button variant="ghost" disabled icon={<IconArrowLeft size={12} />}>Previous</Button>
        <Button variant="primary" disabled={!hasMd || extracting} onClick={onNext}
          iconRight={<IconArrowRight size={12} />}>
          Continue to Stage 2
        </Button>
      </div>
    </div>
  );
};

/* Lightweight markdown renderer (just enough) */
const RenderMarkdown = ({ text }) => {
  const blocks = useMemo(() => parseMd(text), [text]);
  return <>{blocks.map((b, i) => renderBlock(b, i))}</>;
};

const parseMd = (text) => {
  const lines = text.split("\n");
  const blocks = [];
  let i = 0;
  while (i < lines.length) {
    const ln = lines[i];
    if (/^#\s/.test(ln)) { blocks.push({ type: "h1", text: ln.slice(2) }); i++; }
    else if (/^##\s/.test(ln)) { blocks.push({ type: "h2", text: ln.slice(3) }); i++; }
    else if (/^###\s/.test(ln)) { blocks.push({ type: "h3", text: ln.slice(4) }); i++; }
    else if (/^---\s*$/.test(ln)) { blocks.push({ type: "hr" }); i++; }
    else if (/^[-*]\s/.test(ln)) {
      const items = [];
      while (i < lines.length && /^[-*]\s/.test(lines[i])) { items.push(lines[i].slice(2)); i++; }
      blocks.push({ type: "ul", items });
    } else if (/^\d+\.\s/.test(ln)) {
      const items = [];
      while (i < lines.length && /^\d+\.\s/.test(lines[i])) { items.push(lines[i].replace(/^\d+\.\s/, "")); i++; }
      blocks.push({ type: "ol", items });
    } else if (/^>\s/.test(ln)) { blocks.push({ type: "quote", text: ln.slice(2) }); i++; }
    else if (ln.trim() === "") { i++; }
    else { blocks.push({ type: "p", text: ln }); i++; }
  }
  return blocks;
};

const inlineMd = (text) => {
  // Handles **bold**, *italic*, `code` — simple regex pass.
  const parts = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|\*[^*]+\*)/g;
  let last = 0, m;
  let k = 0;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    const s = m[0];
    if (s.startsWith("**")) parts.push(<strong key={k++}>{s.slice(2, -2)}</strong>);
    else if (s.startsWith("`")) parts.push(<code key={k++}>{s.slice(1, -1)}</code>);
    else parts.push(<em key={k++}>{s.slice(1, -1)}</em>);
    last = m.index + s.length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
};

const renderBlock = (b, i) => {
  switch (b.type) {
    case "h1": return <h1 key={i}>{inlineMd(b.text)}</h1>;
    case "h2": return <h2 key={i}>{inlineMd(b.text)}</h2>;
    case "h3": return <h3 key={i}>{inlineMd(b.text)}</h3>;
    case "hr": return <hr key={i} />;
    case "p": return <p key={i}>{inlineMd(b.text)}</p>;
    case "ul": return <ul key={i}>{b.items.map((it, j) => <li key={j}>{inlineMd(it)}</li>)}</ul>;
    case "ol": return <ol key={i}>{b.items.map((it, j) => <li key={j}>{inlineMd(it)}</li>)}</ol>;
    case "quote": return <blockquote key={i}>{inlineMd(b.text)}</blockquote>;
    default: return null;
  }
};

window.Stage1 = Stage1;
window.RenderMarkdown = RenderMarkdown;
