/* === Shared UI primitives === */

const { useState, useEffect, useRef, useMemo, useCallback, createContext, useContext } = React;

// ==== Logo placeholder slots ====
const OrgLogoSlot = () => (
  <span className="logo-slot" title="Drop org logo here">ORG · LOGO</span>
);
const DocforgeLogo = () => (
  <span className="logo-doc">
    <span className="logo-doc-mark">D</span>
    <span>DocForge</span>
  </span>
);

// ==== Buttons ====
const Button = ({ variant = "default", size, icon, iconRight, children, className = "", ...rest }) => {
  const cls = [
    "btn",
    variant === "primary" && "btn-primary",
    variant === "ghost" && "btn-ghost",
    variant === "danger" && "btn-danger",
    size === "sm" && "btn-sm",
    size === "lg" && "btn-lg",
    className
  ].filter(Boolean).join(" ");
  return (
    <button className={cls} {...rest}>
      {icon}
      {children}
      {iconRight}
    </button>
  );
};

// ==== Card ====
const Card = ({ children, className = "", padded = true, ...rest }) => (
  <div className={`card ${padded ? "card-pad" : ""} ${className}`} {...rest}>{children}</div>
);

// ==== Badge ====
const Badge = ({ children, tone, className = "" }) => (
  <span className={`badge ${tone || ""} ${className}`}>{children}</span>
);

// ==== Status row ====
const Status = ({ tone = "info", icon, children }) => (
  <div className={`status-row ${tone}`}>
    {icon}
    <span>{children}</span>
  </div>
);

// ==== Modal ====
const Modal = ({ open, onClose, title, children, footer, size }) => {
  useEffect(() => {
    if (!open) return;
    const handler = (e) => { if (e.key === "Escape") onClose && onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className={`modal ${size === "lg" ? "modal-lg" : ""}`} onClick={e => e.stopPropagation()}>
        <div className="modal-h">
          <h2>{title}</h2>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><IconX size={14} /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
};

// ==== Empty ====
const Empty = ({ icon, title, children }) => (
  <div className="empty">
    {icon && <div style={{ marginBottom: 10, color: "var(--fg-3)" }}>{icon}</div>}
    {title && <div style={{ fontWeight: 500, color: "var(--fg)", marginBottom: 4 }}>{title}</div>}
    <div style={{ fontSize: 13 }}>{children}</div>
  </div>
);

// ==== Toast (minimal) ====
const ToastCtx = createContext(null);
const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((msg, tone = "info") => {
    const id = Math.random().toString(36).slice(2);
    setToasts(t => [...t, { id, msg, tone }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3000);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div style={{
        position: "fixed", bottom: 18, right: 18, zIndex: 200,
        display: "flex", flexDirection: "column", gap: 8, pointerEvents: "none"
      }}>
        {toasts.map(t => (
          <div key={t.id} className={`status-row ${t.tone}`}
            style={{ minWidth: 240, boxShadow: "var(--shadow-md)", animation: "slideUp 200ms" }}>
            {t.tone === "success" ? <IconCheck size={14} /> : <IconSparkles size={14} />}
            <span>{t.msg}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
};
const useToast = () => useContext(ToastCtx);

// ==== Relevance meter ====
const Relevance = ({ score }) => (
  <span className="relevance">
    <span className="relevance-bar"><i style={{ width: `${score * 100}%` }} /></span>
    <span>{(score * 100).toFixed(1)}%</span>
  </span>
);

// ==== Checkbox ====
const Checkbox = ({ checked, onChange, ...rest }) => (
  <button type="button"
    className={`task-checkbox ${checked ? "checked" : ""}`}
    onClick={() => onChange && onChange(!checked)}
    {...rest}>
    {checked && <IconCheck size={11} stroke={2.4} />}
  </button>
);

// ==== Toggle ====
const Toggle = ({ on, onChange }) => (
  <button type="button" className={`toggle ${on ? "on" : ""}`} onClick={() => onChange && onChange(!on)} />
);

// ==== Tabs ====
const Tabs = ({ value, onChange, options }) => (
  <div className="tabs">
    {options.map(o => (
      <div key={o.value}
        className={`tab ${value === o.value ? "active" : ""}`}
        onClick={() => onChange(o.value)}>
        {o.label}
      </div>
    ))}
  </div>
);

// ==== File icon by extension ====
const fileIconLabel = (name) => {
  const ext = (name.split(".").pop() || "").toLowerCase();
  return ext.slice(0, 4).toUpperCase();
};

const FileRow = ({ name, size, status, action, onRemove }) => (
  <div className="file-row">
    <div className="file-icon">{fileIconLabel(name)}</div>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{ fontSize: 13, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{name}</div>
      {size && <div style={{ fontSize: 11, color: "var(--fg-3)" }}>{size}</div>}
    </div>
    {status}
    {action}
    {onRemove && <button className="btn btn-ghost btn-icon" onClick={onRemove}><IconX size={12} /></button>}
  </div>
);

// ==== Image placeholder ====
const ImagePh = ({ label = "image", w = 120, h = 80 }) => (
  <div className="img-ph" style={{ width: w, height: h }}>{label}</div>
);

// ==== Hook: outside click ====
const useOutsideClick = (ref, onOutside) => {
  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) onOutside(); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [ref, onOutside]);
};

// ==== Format helpers ====
const fmtBytes = (b) => {
  if (b < 1024) return b + " B";
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " KB";
  return (b / 1024 / 1024).toFixed(1) + " MB";
};
const fmtRel = (ts) => {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d}d ago`;
  return new Date(ts).toLocaleDateString();
};

Object.assign(window, {
  OrgLogoSlot, DocforgeLogo, Button, Card, Badge, Status, Modal, Empty,
  ToastProvider, useToast, Relevance, Checkbox, Toggle, Tabs, FileRow, ImagePh,
  useOutsideClick, fmtBytes, fmtRel, fileIconLabel
});
