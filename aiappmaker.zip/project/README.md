# Bolt.new Clone - AI-Powered Code Generator

A full-stack application inspired by Bolt.new that generates React and Python applications using GPT-4.

## Features

- 🤖 **GPT-4 Integration**: Intelligent code generation using OpenAI's GPT-4
- ⚛️ **React Frontend**: Modern React app with Monaco editor
- 🐍 **Python Backend**: FastAPI backend with OpenAI integration
- 📁 **File Management**: Complete file explorer with project management
- 🎨 **Syntax Highlighting**: Monaco editor with language support
- 🔄 **Real-time Preview**: Live preview of generated applications
- 📋 **Project Templates**: Pre-built templates for React and Python projects

## Tech Stack

### Frontend
- React 18 with TypeScript
- Tailwind CSS for styling
- Monaco Editor for code editing
- Axios for API communication
- Lucide React for icons

### Backend
- Python 3.8+
- FastAPI for the web framework
- OpenAI API for GPT-4 integration
- Pydantic for data validation
- Uvicorn as ASGI server

## Getting Started

### Prerequisites
- Node.js 18+
- Python 3.8+
- OpenAI API key

### Backend Setup

1. Navigate to the backend directory:
```bash
cd backend
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables:
```bash
cp .env.example .env
# Edit .env and add your OpenAI API key
```

5. Start the backend server:
```bash
python main.py
```

The backend will be available at `http://localhost:8000`

### Frontend Setup

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

The frontend will be available at `http://localhost:5173`

## Usage

1. **Start the Backend**: Make sure the Python backend is running on port 8000
2. **Open the Frontend**: Navigate to http://localhost:5173
3. **Select Project Type**: Choose between React, Python, or Full Stack
4. **Enter Your Prompt**: Describe the application you want to create
5. **Generate**: Click the Generate button to create your application
6. **Edit and Preview**: Use the built-in editor to modify code and preview results

## Example Prompts

- "Create a todo app with drag and drop functionality"
- "Build a weather dashboard with charts and animations"
- "Make a simple blog with CRUD operations"
- "Create a chat application with real-time messaging"
- "Build a calculator with scientific functions"

## API Endpoints

- `GET /` - Health check
- `GET /api/templates/{project_type}` - Get project templates
- `POST /api/generate` - Generate code using GPT-4
- `POST /api/projects` - Save project
- `GET /api/projects/{project_id}` - Load project

## Environment Variables

### Backend (.env)
```
OPENAI_API_KEY=your_openai_api_key_here
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.

## Acknowledgments

- Inspired by Bolt.new
- Built with OpenAI's GPT-4
- Uses Monaco Editor (VS Code's editor)