# Bolt.new Clone Backend

Python FastAPI backend for the Bolt.new clone application.

## Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env and add your OpenAI API key
```

4. Run the server:
```bash
python main.py
```

The API will be available at http://localhost:8000

## API Endpoints

- `GET /` - Health check
- `GET /api/templates/{project_type}` - Get project templates
- `POST /api/generate` - Generate code using GPT-4
- `POST /api/projects` - Save project
- `GET /api/projects/{project_id}` - Load project

## Environment Variables

- `OPENAI_API_KEY` - Your OpenAI API key for GPT-4 access