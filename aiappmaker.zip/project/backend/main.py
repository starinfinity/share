from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import openai
import os
from typing import List, Optional, Dict, Any
from pydantic import BaseModel
import json
import uuid
from datetime import datetime

app = FastAPI(title="Bolt.new Clone API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# OpenAI configuration
openai.api_key = os.getenv("OPENAI_API_KEY")
if not openai.api_key:
    print("Warning: OPENAI_API_KEY environment variable not set")

class FileNode(BaseModel):
    id: str
    name: str
    type: str  # 'file' or 'folder'
    content: Optional[str] = None
    children: Optional[List['FileNode']] = None
    language: Optional[str] = None

class GenerationRequest(BaseModel):
    prompt: str
    project_type: str  # 'react', 'python', or 'fullstack'
    files: Optional[List[FileNode]] = None

class ApiResponse(BaseModel):
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None

# Project templates
REACT_TEMPLATE = {
    "package.json": """{
  "name": "generated-react-app",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@vitejs/plugin-react": "^4.0.0",
    "vite": "^4.4.0"
  }
}""",
    "vite.config.js": """import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
})""",
    "index.html": """<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Generated React App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>""",
    "src/main.jsx": """import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)""",
    "src/App.jsx": """import React from 'react'
import './App.css'

function App() {
  return (
    <div className="App">
      <h1>Generated React App</h1>
      <p>Your generated application will appear here.</p>
    </div>
  )
}

export default App""",
    "src/index.css": """body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}""",
    "src/App.css": """.App {
  text-align: center;
  padding: 2rem;
}"""
}

PYTHON_TEMPLATE = {
    "main.py": """#!/usr/bin/env python3
\"\"\"
Generated Python Application
\"\"\"

def main():
    print("Generated Python Application")
    print("Your generated code will appear here.")

if __name__ == "__main__":
    main()
""",
    "requirements.txt": """# Generated Python Application Dependencies
requests>=2.28.0
""",
    "README.md": """# Generated Python Application

This is a generated Python application.

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
python main.py
```
"""
}

def create_file_structure(template: Dict[str, str]) -> List[FileNode]:
    """Convert template dictionary to FileNode structure"""
    files = []
    
    for path, content in template.items():
        parts = path.split('/')
        file_id = str(uuid.uuid4())
        
        if len(parts) == 1:
            # Root file
            files.append(FileNode(
                id=file_id,
                name=parts[0],
                type='file',
                content=content,
                language=get_language_from_extension(parts[0])
            ))
        else:
            # File in directory - create directory structure
            folder_name = parts[0]
            file_name = parts[-1]
            
            # Find or create folder
            folder = None
            for f in files:
                if f.name == folder_name and f.type == 'folder':
                    folder = f
                    break
            
            if not folder:
                folder = FileNode(
                    id=str(uuid.uuid4()),
                    name=folder_name,
                    type='folder',
                    children=[]
                )
                files.append(folder)
            
            # Add file to folder
            if folder.children is None:
                folder.children = []
            
            folder.children.append(FileNode(
                id=file_id,
                name=file_name,
                type='file',
                content=content,
                language=get_language_from_extension(file_name)
            ))
    
    return files

def get_language_from_extension(filename: str) -> str:
    """Determine language from file extension"""
    ext = filename.split('.')[-1].lower()
    language_map = {
        'js': 'javascript',
        'jsx': 'javascript',
        'ts': 'typescript',
        'tsx': 'typescript',
        'py': 'python',
        'css': 'css',
        'html': 'html',
        'json': 'json',
        'md': 'markdown',
        'txt': 'plaintext'
    }
    return language_map.get(ext, 'plaintext')

async def generate_with_gpt4(prompt: str, project_type: str) -> Dict[str, Any]:
    """Generate code using GPT-4"""
    if not openai.api_key:
        raise HTTPException(status_code=500, detail="OpenAI API key not configured")
    
    system_prompt = f"""You are an expert software developer creating {project_type} applications.
Generate a complete, production-ready application based on the user's prompt.

For React applications:
- Use modern React with hooks
- Include proper component structure
- Add basic styling
- Use ES6+ syntax
- Include package.json with proper dependencies

For Python applications:
- Write clean, well-documented Python code
- Include proper imports and error handling
- Add requirements.txt with dependencies
- Follow PEP 8 standards

For full-stack applications:
- Create both frontend (React) and backend (Python/FastAPI)
- Include proper API endpoints
- Add database models if needed
- Include CORS configuration

Return the response as a JSON object with file paths as keys and file contents as values.
Example: {{"src/App.jsx": "content here", "package.json": "content here"}}
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo-preview",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            max_tokens=4000,
            temperature=0.7
        )
        
        content = response.choices[0].message.content
        
        # Try to parse as JSON
        try:
            files_dict = json.loads(content)
        except json.JSONDecodeError:
            # If not JSON, create a single file
            if project_type == 'react':
                files_dict = {"src/App.jsx": content}
            else:
                files_dict = {"main.py": content}
        
        return files_dict
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OpenAI API error: {str(e)}")

@app.get("/")
async def root():
    return {"message": "Bolt.new Clone API"}

@app.get("/api/templates/{project_type}")
async def get_template(project_type: str):
    """Get project template"""
    try:
        if project_type == 'react':
            files = create_file_structure(REACT_TEMPLATE)
        elif project_type == 'python':
            files = create_file_structure(PYTHON_TEMPLATE)
        elif project_type == 'fullstack':
            # Combine both templates
            combined = {**REACT_TEMPLATE, **PYTHON_TEMPLATE}
            files = create_file_structure(combined)
        else:
            raise HTTPException(status_code=400, detail="Invalid project type")
        
        return ApiResponse(success=True, data={"files": files})
    
    except Exception as e:
        return ApiResponse(success=False, error=str(e))

@app.post("/api/generate")
async def generate_code(request: GenerationRequest):
    """Generate code using GPT-4"""
    try:
        # Generate files using GPT-4
        generated_files = await generate_with_gpt4(request.prompt, request.project_type)
        
        # Convert to FileNode structure
        files = create_file_structure(generated_files)
        
        return ApiResponse(
            success=True,
            data={
                "files": files,
                "project_type": request.project_type,
                "generated_at": datetime.now().isoformat()
            }
        )
    
    except HTTPException:
        raise
    except Exception as e:
        return ApiResponse(success=False, error=str(e))

@app.post("/api/projects")
async def save_project(project: dict):
    """Save project (placeholder - implement with database)"""
    project_id = str(uuid.uuid4())
    # TODO: Implement database storage
    return ApiResponse(
        success=True,
        data={"project_id": project_id, "message": "Project saved successfully"}
    )

@app.get("/api/projects/{project_id}")
async def load_project(project_id: str):
    """Load project (placeholder - implement with database)"""
    # TODO: Implement database retrieval
    return ApiResponse(
        success=False,
        error="Project loading not implemented yet"
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)