import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { FileExplorer } from './components/FileExplorer';
import { CodeEditor } from './components/CodeEditor';
import { PromptPanel } from './components/PromptPanel';
import { PreviewPanel } from './components/PreviewPanel';
import { StatusBar } from './components/StatusBar';
import { FileNode, Project } from './types';
import { apiService } from './services/api';
import { createFileId, getFileLanguage } from './utils/fileUtils';

function App() {
  const [files, setFiles] = useState<FileNode[]>([]);
  const [selectedFileId, setSelectedFileId] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [projectType, setProjectType] = useState<'react' | 'python' | 'fullstack'>('react');
  const [isGenerating, setIsGenerating] = useState(false);

  // Load initial template
  useEffect(() => {
    const loadTemplate = async () => {
      const response = await apiService.getProjectTemplates(projectType);
      if (response.success && response.data?.files) {
        setFiles(response.data.files);
        // Select first file
        const firstFile = response.data.files.find((f: FileNode) => f.type === 'file');
        if (firstFile) {
          setSelectedFileId(firstFile.id);
          setSelectedFile(firstFile);
        }
      }
    };

    loadTemplate();
  }, [projectType]);

  // Update selected file when selectedFileId changes
  useEffect(() => {
    if (selectedFileId) {
      const file = findFileById(files, selectedFileId);
      setSelectedFile(file);
    }
  }, [selectedFileId, files]);

  const findFileById = (fileList: FileNode[], id: string): FileNode | null => {
    for (const file of fileList) {
      if (file.id === id) return file;
      if (file.children) {
        const found = findFileById(file.children, id);
        if (found) return found;
      }
    }
    return null;
  };

  const updateFileContent = (fileId: string, content: string) => {
    const updateFiles = (fileList: FileNode[]): FileNode[] => {
      return fileList.map(file => {
        if (file.id === fileId) {
          return { ...file, content };
        }
        if (file.children) {
          return { ...file, children: updateFiles(file.children) };
        }
        return file;
      });
    };

    setFiles(updateFiles(files));
    if (selectedFile?.id === fileId) {
      setSelectedFile({ ...selectedFile, content });
    }
  };

  const handleFileSelect = (fileId: string) => {
    setSelectedFileId(fileId);
  };

  const handleCreateFile = (parentId?: string) => {
    const fileName = prompt('Enter file name:');
    if (!fileName) return;

    const newFile: FileNode = {
      id: createFileId(),
      name: fileName,
      type: 'file',
      content: '',
      language: getFileLanguage(fileName)
    };

    if (parentId) {
      // Add to folder
      const updateFiles = (fileList: FileNode[]): FileNode[] => {
        return fileList.map(file => {
          if (file.id === parentId && file.type === 'folder') {
            return {
              ...file,
              children: [...(file.children || []), newFile]
            };
          }
          if (file.children) {
            return { ...file, children: updateFiles(file.children) };
          }
          return file;
        });
      };
      setFiles(updateFiles(files));
    } else {
      // Add to root
      setFiles([...files, newFile]);
    }

    setSelectedFileId(newFile.id);
  };

  const handleDeleteFile = (fileId: string) => {
    if (!confirm('Are you sure you want to delete this file?')) return;

    const deleteFromFiles = (fileList: FileNode[]): FileNode[] => {
      return fileList
        .filter(file => file.id !== fileId)
        .map(file => ({
          ...file,
          children: file.children ? deleteFromFiles(file.children) : undefined
        }));
    };

    setFiles(deleteFromFiles(files));
    if (selectedFileId === fileId) {
      setSelectedFileId(null);
      setSelectedFile(null);
    }
  };

  const handleGenerate = async (prompt: string, type: 'react' | 'python' | 'fullstack') => {
    setIsGenerating(true);
    setProjectType(type);

    try {
      const response = await apiService.generateCode({
        prompt,
        projectType: type,
        files
      });

      if (response.success && response.data?.files) {
        setFiles(response.data.files);
        // Select first file
        const firstFile = response.data.files.find((f: FileNode) => f.type === 'file');
        if (firstFile) {
          setSelectedFileId(firstFile.id);
          setSelectedFile(firstFile);
        }
      } else {
        alert(`Error: ${response.error || 'Failed to generate code'}`);
      }
    } catch (error) {
      console.error('Generation error:', error);
      alert('Failed to generate code. Please check the console for details.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gray-100">
      <Header />
      
      <div className="flex-1 flex">
        <FileExplorer
          files={files}
          selectedFile={selectedFileId}
          onFileSelect={handleFileSelect}
          onCreateFile={handleCreateFile}
          onDeleteFile={handleDeleteFile}
        />
        
        <div className="flex-1 flex flex-col">
          {selectedFile ? (
            <CodeEditor
              value={selectedFile.content || ''}
              language={selectedFile.language || 'plaintext'}
              onChange={(value) => updateFileContent(selectedFile.id, value)}
            />
          ) : (
            <div className="flex-1 flex items-center justify-center bg-gray-900 text-gray-400">
              <div className="text-center">
                <p className="text-lg mb-2">No file selected</p>
                <p className="text-sm">Select a file from the explorer or create a new one</p>
              </div>
            </div>
          )}
        </div>
        
        <PreviewPanel
          projectType={projectType}
          files={files}
        />
      </div>
      
      <PromptPanel
        onGenerate={handleGenerate}
        isGenerating={isGenerating}
      />
      
      <StatusBar
        selectedFile={selectedFile?.name}
        isGenerating={isGenerating}
      />
    </div>
  );
}

export default App;