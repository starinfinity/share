import React, { useState } from 'react';
import { ChevronRight, ChevronDown, File, Folder, FolderOpen, Plus, Trash2 } from 'lucide-react';
import { FileNode } from '../types';

interface FileExplorerProps {
  files: FileNode[];
  selectedFile: string | null;
  onFileSelect: (fileId: string) => void;
  onCreateFile: (parentId?: string) => void;
  onDeleteFile: (fileId: string) => void;
}

interface FileItemProps {
  node: FileNode;
  level: number;
  selectedFile: string | null;
  onFileSelect: (fileId: string) => void;
  onCreateFile: (parentId?: string) => void;
  onDeleteFile: (fileId: string) => void;
}

const FileItem: React.FC<FileItemProps> = ({
  node,
  level,
  selectedFile,
  onFileSelect,
  onCreateFile,
  onDeleteFile
}) => {
  const [isExpanded, setIsExpanded] = useState(true);

  const handleToggle = () => {
    if (node.type === 'folder') {
      setIsExpanded(!isExpanded);
    } else {
      onFileSelect(node.id);
    }
  };

  const getIcon = () => {
    if (node.type === 'folder') {
      return isExpanded ? <FolderOpen size={16} /> : <Folder size={16} />;
    }
    return <File size={16} />;
  };

  const getLanguageColor = () => {
    switch (node.language) {
      case 'typescript':
      case 'javascript':
        return 'text-yellow-400';
      case 'python':
        return 'text-blue-400';
      case 'css':
        return 'text-pink-400';
      case 'html':
        return 'text-orange-400';
      case 'json':
        return 'text-green-400';
      default:
        return 'text-gray-400';
    }
  };

  return (
    <div>
      <div
        className={`flex items-center gap-2 px-2 py-1 hover:bg-gray-700 cursor-pointer group ${
          selectedFile === node.id ? 'bg-blue-600/20 border-r-2 border-blue-400' : ''
        }`}
        style={{ paddingLeft: `${8 + level * 16}px` }}
        onClick={handleToggle}
      >
        {node.type === 'folder' && (
          <div className="w-4 h-4 flex items-center justify-center">
            {isExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          </div>
        )}
        <div className={`w-4 h-4 flex items-center justify-center ${getLanguageColor()}`}>
          {getIcon()}
        </div>
        <span className="text-sm text-gray-200 flex-1 truncate">{node.name}</span>
        <div className="hidden group-hover:flex items-center gap-1">
          {node.type === 'folder' && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onCreateFile(node.id);
              }}
              className="p-1 hover:bg-gray-600 rounded"
            >
              <Plus size={12} />
            </button>
          )}
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDeleteFile(node.id);
            }}
            className="p-1 hover:bg-red-600 rounded text-red-400"
          >
            <Trash2 size={12} />
          </button>
        </div>
      </div>
      {node.type === 'folder' && isExpanded && node.children && (
        <div>
          {node.children.map((child) => (
            <FileItem
              key={child.id}
              node={child}
              level={level + 1}
              selectedFile={selectedFile}
              onFileSelect={onFileSelect}
              onCreateFile={onCreateFile}
              onDeleteFile={onDeleteFile}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export const FileExplorer: React.FC<FileExplorerProps> = ({
  files,
  selectedFile,
  onFileSelect,
  onCreateFile,
  onDeleteFile
}) => {
  return (
    <div className="w-64 bg-gray-800 border-r border-gray-700 flex flex-col">
      <div className="p-3 border-b border-gray-700 flex items-center justify-between">
        <h3 className="text-sm font-medium text-gray-200">Explorer</h3>
        <button
          onClick={() => onCreateFile()}
          className="p-1 hover:bg-gray-700 rounded text-gray-400 hover:text-gray-200"
        >
          <Plus size={16} />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        {files.map((file) => (
          <FileItem
            key={file.id}
            node={file}
            level={0}
            selectedFile={selectedFile}
            onFileSelect={onFileSelect}
            onCreateFile={onCreateFile}
            onDeleteFile={onDeleteFile}
          />
        ))}
      </div>
    </div>
  );
};