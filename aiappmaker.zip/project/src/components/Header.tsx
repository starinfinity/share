import React from 'react';
import { Code2, Github, Settings, Sparkles } from 'lucide-react';

interface HeaderProps {
  onSettingsClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSettingsClick }) => {
  return (
    <header className="h-14 bg-gray-900 border-b border-gray-700 flex items-center justify-between px-4">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Code2 size={18} className="text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gray-100">Bolt.new Clone</h1>
            <p className="text-xs text-gray-400 -mt-1">AI-Powered Code Generator</p>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-2 ml-6">
          <div className="flex items-center gap-1 px-2 py-1 bg-green-500/10 rounded-full">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs text-green-400">GPT-4 Ready</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={onSettingsClick}
          className="p-2 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-gray-200 transition-colors"
          title="Settings"
        >
          <Settings size={18} />
        </button>
        <a
          href="https://github.com"
          target="_blank"
          rel="noopener noreferrer"
          className="p-2 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-gray-200 transition-colors"
          title="GitHub"
        >
          <Github size={18} />
        </a>
        <div className="w-px h-6 bg-gray-700"></div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-lg border border-blue-500/20">
          <Sparkles size={14} className="text-blue-400" />
          <span className="text-sm text-blue-400 font-medium">v1.0.0</span>
        </div>
      </div>
    </header>
  );
};