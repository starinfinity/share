import React, { useState } from 'react';
import { Play, Square, RefreshCw, ExternalLink } from 'lucide-react';

interface PreviewPanelProps {
  projectType: 'react' | 'python' | 'fullstack';
  files: any[];
}

export const PreviewPanel: React.FC<PreviewPanelProps> = ({ projectType, files }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [output, setOutput] = useState('');

  const handleRun = async () => {
    setIsRunning(true);
    setOutput('Starting application...\n');
    
    // Simulate running the application
    setTimeout(() => {
      if (projectType === 'react') {
        setOutput(prev => prev + '> npm run dev\n> Local: http://localhost:5173\n> Ready in 1.2s\n');
      } else if (projectType === 'python') {
        setOutput(prev => prev + '> python main.py\n> Server running on http://localhost:8000\n');
      } else {
        setOutput(prev => prev + '> Starting full-stack application...\n> Frontend: http://localhost:3000\n> Backend: http://localhost:8000\n');
      }
      setIsRunning(false);
    }, 2000);
  };

  const handleStop = () => {
    setIsRunning(false);
    setOutput(prev => prev + '\n> Application stopped\n');
  };

  return (
    <div className="w-96 bg-gray-800 border-l border-gray-700 flex flex-col">
      <div className="p-3 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-medium text-gray-200">Preview</h3>
          <div className="flex items-center gap-2">
            <button
              onClick={handleRun}
              disabled={isRunning}
              className="p-1.5 hover:bg-gray-700 rounded text-green-400 hover:text-green-300 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Run"
            >
              <Play size={14} />
            </button>
            <button
              onClick={handleStop}
              disabled={!isRunning}
              className="p-1.5 hover:bg-gray-700 rounded text-red-400 hover:text-red-300 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Stop"
            >
              <Square size={14} />
            </button>
            <button
              onClick={() => setOutput('')}
              className="p-1.5 hover:bg-gray-700 rounded text-gray-400 hover:text-gray-200"
              title="Clear"
            >
              <RefreshCw size={14} />
            </button>
            <button
              className="p-1.5 hover:bg-gray-700 rounded text-blue-400 hover:text-blue-300"
              title="Open in new tab"
            >
              <ExternalLink size={14} />
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        {/* Console Output */}
        <div className="flex-1 p-3 bg-gray-900 font-mono text-sm overflow-y-auto">
          <div className="text-gray-300 whitespace-pre-wrap">
            {output || 'Click the play button to run your application...'}
          </div>
        </div>

        {/* Preview Frame */}
        {projectType === 'react' && (
          <div className="h-64 border-t border-gray-700">
            <div className="w-full h-full bg-white rounded-b-lg flex items-center justify-center">
              <div className="text-gray-500 text-sm">
                React app preview will appear here
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};