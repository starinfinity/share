import React, { useState } from 'react';
import { Send, Loader2, Sparkles, Code2, Terminal } from 'lucide-react';

interface PromptPanelProps {
  onGenerate: (prompt: string, projectType: 'react' | 'python' | 'fullstack') => void;
  isGenerating: boolean;
}

export const PromptPanel: React.FC<PromptPanelProps> = ({ onGenerate, isGenerating }) => {
  const [prompt, setPrompt] = useState('');
  const [projectType, setProjectType] = useState<'react' | 'python' | 'fullstack'>('react');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim() && !isGenerating) {
      onGenerate(prompt.trim(), projectType);
    }
  };

  const examplePrompts = [
    'Create a todo app with drag and drop functionality',
    'Build a weather dashboard with charts and animations',
    'Make a simple blog with CRUD operations',
    'Create a chat application with real-time messaging',
    'Build a calculator with scientific functions'
  ];

  return (
    <div className="bg-gray-800 border-t border-gray-700 p-4">
      <div className="max-w-4xl mx-auto space-y-4">
        {/* Project Type Selector */}
        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-300">Project Type:</span>
          <div className="flex gap-2">
            {[
              { type: 'react' as const, label: 'React', icon: Code2 },
              { type: 'python' as const, label: 'Python', icon: Terminal },
              { type: 'fullstack' as const, label: 'Full Stack', icon: Sparkles }
            ].map(({ type, label, icon: Icon }) => (
              <button
                key={type}
                onClick={() => setProjectType(type)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm transition-colors ${
                  projectType === type
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                <Icon size={16} />
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Example Prompts */}
        <div className="flex flex-wrap gap-2">
          <span className="text-sm text-gray-400 mr-2">Examples:</span>
          {examplePrompts.slice(0, 3).map((example, index) => (
            <button
              key={index}
              onClick={() => setPrompt(example)}
              className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded text-gray-300 transition-colors"
            >
              {example}
            </button>
          ))}
        </div>

        {/* Prompt Input */}
        <form onSubmit={handleSubmit} className="flex gap-3">
          <div className="flex-1 relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the application you want to create..."
              className="w-full px-4 py-3 bg-gray-900 border border-gray-600 rounded-lg text-gray-100 placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              rows={3}
              disabled={isGenerating}
            />
          </div>
          <button
            type="submit"
            disabled={!prompt.trim() || isGenerating}
            className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:from-gray-600 disabled:to-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-all duration-200 flex items-center gap-2 font-medium shadow-lg hover:shadow-xl"
          >
            {isGenerating ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Send size={18} />
                Generate
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};