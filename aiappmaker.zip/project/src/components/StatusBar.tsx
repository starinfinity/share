import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, Activity, AlertCircle } from 'lucide-react';
import { apiService } from '../services/api';

interface StatusBarProps {
  selectedFile?: string;
  isGenerating?: boolean;
}

export const StatusBar: React.FC<StatusBarProps> = ({ selectedFile, isGenerating }) => {
  const [backendStatus, setBackendStatus] = useState<'connected' | 'disconnected' | 'checking'>('checking');

  useEffect(() => {
    const checkBackendStatus = async () => {
      setBackendStatus('checking');
      const isHealthy = await apiService.healthCheck();
      setBackendStatus(isHealthy ? 'connected' : 'disconnected');
    };

    checkBackendStatus();
    const interval = setInterval(checkBackendStatus, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-6 bg-blue-600 flex items-center justify-between px-3 text-xs text-white">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          {backendStatus === 'connected' ? (
            <Wifi size={12} className="text-green-300" />
          ) : backendStatus === 'disconnected' ? (
            <WifiOff size={12} className="text-red-300" />
          ) : (
            <Activity size={12} className="text-yellow-300 animate-pulse" />
          )}
          <span>
            Backend: {backendStatus === 'connected' ? 'Connected' : 
                     backendStatus === 'disconnected' ? 'Disconnected' : 'Checking...'}
          </span>
        </div>
        
        {selectedFile && (
          <div className="flex items-center gap-2">
            <span>File: {selectedFile}</span>
          </div>
        )}

        {isGenerating && (
          <div className="flex items-center gap-2">
            <Activity size={12} className="animate-spin" />
            <span>Generating with GPT-4...</span>
          </div>
        )}
      </div>

      <div className="flex items-center gap-4">
        {backendStatus === 'disconnected' && (
          <div className="flex items-center gap-1 text-red-300">
            <AlertCircle size={12} />
            <span>Start Python backend on port 8000</span>
          </div>
        )}
        <span>Ready</span>
      </div>
    </div>
  );
};