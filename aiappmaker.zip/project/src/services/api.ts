import axios from 'axios';
import { GenerationRequest, ApiResponse, FileNode } from '../types';

const API_BASE_URL = 'http://localhost:8000/api';

class ApiService {
  private axiosInstance;

  constructor() {
    this.axiosInstance = axios.create({
      baseURL: API_BASE_URL,
      timeout: 60000, // Increased timeout for GPT-4 requests
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }

  async generateCode(request: GenerationRequest): Promise<ApiResponse> {
    try {
      const response = await this.axiosInstance.post('/generate', {
        prompt: request.prompt,
        project_type: request.projectType,
        files: request.files
      });
      return response.data;
    } catch (error: any) {
      console.error('API Error:', error);
      return {
        success: false,
        error: error.response?.data?.detail || error.message || 'Failed to generate code'
      };
    }
  }

  async getProjectTemplates(type: 'react' | 'python' | 'fullstack'): Promise<ApiResponse> {
    try {
      const response = await this.axiosInstance.get(`/templates/${type}`);
      return response.data;
    } catch (error: any) {
      console.error('Template Error:', error);
      return {
        success: false,
        error: error.response?.data?.detail || error.message || 'Failed to fetch templates'
      };
    }
  }

  async saveProject(project: any): Promise<ApiResponse> {
    try {
      const response = await this.axiosInstance.post('/projects', project);
      return response.data;
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.detail || error.message || 'Failed to save project'
      };
    }
  }

  async loadProject(projectId: string): Promise<ApiResponse> {
    try {
      const response = await this.axiosInstance.get(`/projects/${projectId}`);
      return response.data;
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.detail || error.message || 'Failed to load project'
      };
    }
  }

  async healthCheck(): Promise<boolean> {
    try {
      const response = await axios.get('http://localhost:8000/');
      return response.status === 200;
    } catch {
      return false;
    }
  }
}

export const apiService = new ApiService();