export interface FileNode {
  id: string;
  name: string;
  type: 'file' | 'folder';
  content?: string;
  children?: FileNode[];
  language?: string;
}

export interface Project {
  id: string;
  name: string;
  type: 'react' | 'python' | 'fullstack';
  files: FileNode[];
  createdAt: Date;
}

export interface GenerationRequest {
  prompt: string;
  projectType: 'react' | 'python' | 'fullstack';
  files?: FileNode[];
}

export interface ApiResponse {
  success: boolean;
  data?: any;
  error?: string;
}