import React from 'react';
import { useNavigate } from 'react-router-dom';
import ThemeSelector from './ThemeSelector';

const Home: React.FC = () => {
  const navigate = useNavigate();

  const features = [
    {
      icon: '🤖',
      title: 'AI-Powered Chat',
      description: 'Natural language processing with intelligent context understanding and dynamic responses.',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: '📊',
      title: 'Smart Data Display',
      description: 'Automatic formatting for tables, charts, and visual data representations.',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: '⚡',
      title: 'Instant Results',
      description: 'Lightning-fast query processing with real-time response generation.',
      gradient: 'from-yellow-500 to-orange-500'
    },
    {
      icon: '🔒',
      title: 'Secure & Private',
      description: 'Enterprise-grade security with encrypted data transmission and storage.',
      gradient: 'from-green-500 to-teal-500'
    },
  ];

  return (
    <div 
      className="min-h-screen relative overflow-hidden"
      style={{ background: 'var(--bg-primary)' }}
    >
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Animated Orbs */}
        <div className="absolute -top-40 -right-40 w-80 h-80 rounded-full bg-gradient-to-br from-blue-400/30 to-purple-600/30 animate-float-slow animate-fade-in-up"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-gradient-to-tr from-pink-400/30 to-yellow-600/30 animate-float-slow animate-fade-in-up" style={{ animationDelay: '0.5s' }}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full bg-gradient-to-r from-cyan-400/20 to-blue-600/20 animate-pulse-glow animate-fade-in-up" style={{ animationDelay: '1s' }}></div>
        
        {/* Floating Particles */}
        <div className="absolute top-20 left-20 w-4 h-4 rounded-full bg-blue-400/40 animate-float-particle" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-40 right-32 w-3 h-3 rounded-full bg-purple-400/40 animate-float-particle" style={{ animationDelay: '3s' }}></div>
        <div className="absolute bottom-32 left-1/3 w-5 h-5 rounded-full bg-pink-400/40 animate-float-particle" style={{ animationDelay: '4s' }}></div>
        <div className="absolute top-1/3 right-20 w-2 h-2 rounded-full bg-cyan-400/40 animate-float-particle" style={{ animationDelay: '5s' }}></div>
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-grid-pattern opacity-5 animate-fade-in" style={{ animationDelay: '1.5s' }}></div>
      </div>

      {/* Header */}
      <header 
        className="relative z-10 backdrop-blur-md border-b animate-slide-down"
        style={{ 
          background: 'var(--glass-bg)',
          borderColor: 'var(--glass-border)'
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-3 animate-fade-in-left">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg animate-bounce-gentle">
                <span className="text-white text-xl font-bold">🧠</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold" style={{ color: 'var(--text-primary)' }}>
                  DBChatbot
                </h1>
                <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
                  Intelligent Database Assistant
                </p>
              </div>
            </div>
            <div className="animate-fade-in-right">
              <ThemeSelector />
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 py-20">
        <div className="text-center mb-20 animate-fade-in-up">
          <div className="mb-8">
            <div className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium mb-6 animate-fade-in-up animate-bounce-gentle"
                 style={{ 
                   animationDelay: '0.3s',
                   background: 'var(--bg-accent)', 
                   color: 'var(--accent-primary)' 
                 }}>
              <span className="mr-2 animate-spin-slow">🚀</span>
              Next-Gen Database Intelligence
            </div>
          </div>
          
          <h2 className="text-6xl font-bold mb-6 leading-tight">
            <span className="animate-fade-in-up" style={{ color: 'var(--text-primary)', animationDelay: '0.5s' }}>Chat with Your</span>
            <br />
            <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent animate-fade-in-up animate-text-shimmer" style={{ animationDelay: '0.7s' }}>
              Database
            </span>
          </h2>
          
          <p className="text-xl mb-12 max-w-3xl mx-auto leading-relaxed animate-fade-in-up" style={{ color: 'var(--text-secondary)', animationDelay: '0.9s' }}>
            Transform complex database queries into simple conversations. Get instant insights, 
            generate reports, and download data with the power of AI-driven natural language processing.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in-up" style={{ animationDelay: '1.1s' }}>
            <button
              onClick={() => navigate('/chat')}
              className="group relative px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-2xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 flex items-center space-x-3 animate-pulse-button"
            >
              <span className="text-2xl animate-bounce-gentle">💬</span>
              <span className="text-lg">Start Chatting</span>
              <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </button>
            
            <button 
              className="px-8 py-4 font-semibold rounded-2xl border-2 transition-all duration-300 hover:scale-105 animate-fade-in-scale"
              style={{ 
                color: 'var(--text-primary)',
                borderColor: 'var(--border-secondary)',
                background: 'var(--bg-secondary)',
                animationDelay: '1.3s'
              }}
            >
              <span className="mr-2">📖</span>
              Learn More
            </button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative p-8 rounded-2xl transition-all duration-500 hover:scale-105 cursor-pointer animate-fade-in-up"
              style={{
                background: 'var(--glass-bg)',
                backdropFilter: 'blur(20px)',
                border: '1px solid var(--glass-border)',
                boxShadow: 'var(--shadow-lg)',
                animationDelay: `${1.5 + index * 0.2}s`
              }}
            >
              <div className="relative z-10">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.gradient} mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300 animate-bounce-gentle`} style={{ animationDelay: `${2 + index * 0.1}s` }}>
                  <span className="text-3xl">{feature.icon}</span>
                </div>
                <h3 className="text-xl font-bold mb-3" style={{ color: 'var(--text-primary)' }}>
                  {feature.title}
                </h3>
                <p style={{ color: 'var(--text-secondary)' }} className="leading-relaxed">
                  {feature.description}
                </p>
              </div>
              
              {/* Hover Effect */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
          ))}
        </div>

        {/* About Section */}
        <div 
          className="rounded-3xl p-12 relative overflow-hidden animate-fade-in-up"
          style={{
            background: 'var(--glass-bg)',
            backdropFilter: 'blur(20px)',
            border: '1px solid var(--glass-border)',
            boxShadow: 'var(--shadow-xl)',
            animationDelay: '2.3s'
          }}
        >
          <div className="relative z-10">
            <div className="text-center mb-12">
              <h3 className="text-4xl font-bold mb-4 animate-fade-in-up" style={{ color: 'var(--text-primary)', animationDelay: '2.5s' }}>
                Revolutionizing Database Interaction
              </h3>
              <p className="text-xl animate-fade-in-up" style={{ color: 'var(--text-secondary)', animationDelay: '2.7s' }}>
                Experience the future of data management with our AI-powered assistant
              </p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div className="animate-fade-in-left" style={{ animationDelay: '2.9s' }}>
                <h4 className="text-2xl font-bold mb-6 flex items-center" style={{ color: 'var(--text-primary)' }}>
                  <span className="mr-3 animate-bounce-gentle">🎯</span>
                  What Makes Us Different
                </h4>
                <div className="space-y-4">
                  {[
                    'Natural language understanding with 99% accuracy',
                    'Real-time SQL query generation and optimization',
                    'Multi-format output with intelligent data visualization',
                    'Enterprise-grade security and data protection'
                  ].map((item, index) => (
                    <div key={index} className="flex items-start space-x-3 animate-fade-in-left" style={{ animationDelay: `${3.1 + index * 0.1}s` }}>
                      <div className="w-6 h-6 rounded-full bg-gradient-to-r from-green-400 to-blue-500 flex items-center justify-center mt-0.5 animate-pulse-gentle">
                        <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <p style={{ color: 'var(--text-secondary)' }}>{item}</p>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="animate-fade-in-right" style={{ animationDelay: '3.1s' }}>
                <h4 className="text-2xl font-bold mb-6 flex items-center" style={{ color: 'var(--text-primary)' }}>
                  <span className="mr-3 animate-bounce-gentle">⚡</span>
                  How It Works
                </h4>
                <div className="space-y-6">
                  {[
                    { step: '1', title: 'Ask Naturally', desc: 'Type your question in plain English' },
                    { step: '2', title: 'AI Processing', desc: 'Advanced NLP understands your intent' },
                    { step: '3', title: 'Query Generation', desc: 'Optimized SQL queries are created' },
                    { step: '4', title: 'Smart Display', desc: 'Results formatted perfectly for you' }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center space-x-4 animate-fade-in-right" style={{ animationDelay: `${3.3 + index * 0.1}s` }}>
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold shadow-lg animate-bounce-gentle" style={{ animationDelay: `${3.5 + index * 0.1}s` }}>
                        {item.step}
                      </div>
                      <div>
                        <h5 className="font-semibold" style={{ color: 'var(--text-primary)' }}>{item.title}</h5>
                        <p className="text-sm" style={{ color: 'var(--text-muted)' }}>{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* Background Pattern */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-blue-500/10 to-transparent rounded-full animate-float-slow"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-purple-500/10 to-transparent rounded-full animate-float-slow" style={{ animationDelay: '2s' }}></div>
        </div>
      </main>
    </div>
  );
};

export default Home;