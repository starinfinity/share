import React, { createContext, useContext, useState, useEffect } from 'react';
import { Theme } from '../types';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>('light');

  // Load saved theme on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('dbchatbot-theme') as Theme;
    console.log('Loading saved theme:', savedTheme);
    if (savedTheme && ['light', 'dark', 'dark-purple', 'rose-pink'].includes(savedTheme)) {
      setTheme(savedTheme);
    }
  }, []);

  // Apply theme changes
  useEffect(() => {
    console.log('Applying theme:', theme);
    
    // Save to localStorage
    localStorage.setItem('dbchatbot-theme', theme);
    
    // Remove all existing theme classes
    const themeClasses = ['theme-light', 'theme-dark', 'theme-dark-purple', 'theme-rose-pink'];
    themeClasses.forEach(cls => {
      document.body.classList.remove(cls);
      document.documentElement.classList.remove(cls);
    });
    
    // Add new theme class to both body and html
    const newThemeClass = `theme-${theme}`;
    document.body.classList.add(newThemeClass);
    document.documentElement.classList.add(newThemeClass);
    
    console.log('Theme classes applied:', newThemeClass);
    console.log('Body classes:', document.body.className);
    
    // Force a repaint
    document.body.style.display = 'none';
    document.body.offsetHeight; // Trigger reflow
    document.body.style.display = '';
  }, [theme]);

  const handleSetTheme = (newTheme: Theme) => {
    console.log('Theme change requested from:', theme, 'to:', newTheme);
    setTheme(newTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme: handleSetTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};