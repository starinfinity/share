import React, { useState } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { Theme } from '../types';

const ThemeSelector: React.FC = () => {
  const { theme, setTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);

  const themes = [
    { 
      id: 'light' as Theme, 
      name: 'Light', 
      icon: '☀️',
      description: 'Clean and bright',
      preview: '#ffffff'
    },
    { 
      id: 'dark' as Theme, 
      name: 'Dark', 
      icon: '🌙',
      description: 'Easy on the eyes',
      preview: '#0f172a'
    },
    { 
      id: 'dark-purple' as Theme, 
      name: 'Cosmic', 
      icon: '🌌',
      description: 'Deep space vibes',
      preview: '#1a0b2e'
    },
    { 
      id: 'rose-pink' as Theme, 
      name: 'Blossom', 
      icon: '🌸',
      description: 'Soft and elegant',
      preview: '#fdf2f8'
    },
  ];

  const currentTheme = themes.find(t => t.id === theme) || themes[0];

  const handleThemeClick = (themeId: Theme) => {
    console.log('Theme clicked:', themeId);
    setTheme(themeId);
    setIsOpen(false);
  };

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="relative">
      {/* Theme Button */}
      <button
        onClick={toggleDropdown}
        className="flex items-center space-x-3 px-4 py-2.5 rounded-xl transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-blue-500"
        style={{
          background: 'var(--bg-secondary)',
          border: '1px solid var(--border-primary)',
          color: 'var(--text-primary)',
          boxShadow: 'var(--shadow-md)'
        }}
      >
        <span className="text-lg">{currentTheme.icon}</span>
        <span className="font-medium">{currentTheme.name}</span>
        <svg 
          className={`w-4 h-4 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      
      {/* Dropdown */}
      {isOpen && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 z-40" 
            onClick={() => setIsOpen(false)}
          />
          
          {/* Dropdown Menu */}
          <div 
            className="absolute right-0 mt-2 w-72 rounded-2xl shadow-2xl z-[9999] overflow-hidden"
            style={{
              background: 'var(--glass-bg)',
              backdropFilter: 'blur(20px)',
              border: '1px solid var(--glass-border)'
            }}
          >
            <div className="p-4">
              <h3 className="text-lg font-semibold mb-4 flex items-center" style={{ color: 'var(--text-primary)' }}>
                <span className="mr-2">🎨</span>
                Choose Theme
              </h3>
              
              <div className="space-y-2">
                {themes.map((themeOption) => {
                  const isSelected = theme === themeOption.id;
                  
                  return (
                    <div
                      key={themeOption.id}
                      onClick={() => handleThemeClick(themeOption.id)}
                      className={`w-full flex items-center space-x-4 p-3 rounded-xl transition-all duration-300 cursor-pointer hover:scale-[1.02] ${
                        isSelected ? 'ring-2 ring-blue-500' : ''
                      }`}
                      style={{
                        background: isSelected ? 'var(--accent-primary)' : 'var(--bg-secondary)',
                        color: isSelected ? 'white' : 'var(--text-primary)'
                      }}
                    >
                      {/* Theme Preview Circle */}
                      <div 
                        className="w-10 h-10 rounded-full border-2 border-white/20 flex items-center justify-center"
                        style={{ backgroundColor: themeOption.preview }}
                      >
                        <span className="text-lg">{themeOption.icon}</span>
                      </div>
                      
                      {/* Theme Info */}
                      <div className="flex-1 text-left">
                        <div className="font-semibold">{themeOption.name}</div>
                        <div className="text-sm opacity-70">{themeOption.description}</div>
                      </div>
                      
                      {/* Selection Indicator */}
                      {isSelected && (
                        <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center">
                          <svg className="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ThemeSelector;