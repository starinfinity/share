import { ChatResponse } from '../types';

const API_BASE_URL = 'http://localhost:8000';

export const sendMessage = async (message: string): Promise<ChatResponse> => {
  try {
    const response = await fetch(`${API_BASE_URL}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      throw new Error('Failed to send message');
    }

    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    // Fallback response for development
    return {
      content: 'Sorry, I encountered an error processing your message. Please make sure the Python backend is running on port 8000.',
      displayType: 'text',
    };
  }
};