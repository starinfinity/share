export interface Message {
  id: string;
  content: string;
  type: 'user' | 'bot';
  timestamp: Date;
  displayType?: 'text' | 'table' | 'file';
  sqlQuery?: string;
  fileName?: string;
}

export interface ChatResponse {
  content: string;
  displayType: 'text' | 'table' | 'file';
  sqlQuery?: string;
  fileName?: string;
}

export type Theme = 'light' | 'dark' | 'dark-purple' | 'rose-pink';