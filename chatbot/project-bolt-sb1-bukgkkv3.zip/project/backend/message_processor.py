#!/usr/bin/env python3
"""
Message Processor for DBChatbot
Handles message processing and generates appropriate responses
"""

import json
import re
import random
from typing import Dict, Any, Optional, List

class MessageProcessor:
    """Processes chat messages and generates responses"""
    
    def __init__(self):
        self.sample_data = self._generate_sample_data()
    
    def _generate_sample_data(self) -> List[Dict[str, Any]]:
        """Generate sample data for demonstrations"""
        return [
            {"id": 1, "name": "Alice Johnson", "department": "Engineering", "salary": 85000, "hire_date": "2022-01-15"},
            {"id": 2, "name": "Bob Smith", "department": "Marketing", "salary": 72000, "hire_date": "2021-08-22"},
            {"id": 3, "name": "Carol Davis", "department": "Engineering", "salary": 92000, "hire_date": "2020-03-10"},
            {"id": 4, "name": "David Wilson", "department": "Sales", "salary": 68000, "hire_date": "2023-02-01"},
            {"id": 5, "name": "Eva Brown", "department": "HR", "salary": 75000, "hire_date": "2022-11-30"},
        ]
    
    def process_message(self, message: str) -> Dict[str, Any]:
        """
        Process a user message and return appropriate response
        
        Args:
            message: The user's message
            
        Returns:
            Dictionary containing response data
        """
        message_lower = message.lower().strip()
        
        # Determine response type based on message content
        if self._is_table_request(message_lower):
            return self._generate_table_response(message)
        elif self._is_file_request(message_lower):
            return self._generate_file_response(message)
        else:
            return self._generate_text_response(message)
    
    def _is_table_request(self, message: str) -> bool:
        """Check if the message is requesting tabular data"""
        table_keywords = [
            'table', 'data', 'list', 'show', 'employees', 'users', 'records',
            'database', 'select', 'query', 'rows', 'columns'
        ]
        return any(keyword in message for keyword in table_keywords)
    
    def _is_file_request(self, message: str) -> bool:
        """Check if the message is requesting a file"""
        file_keywords = [
            'download', 'file', 'export', 'csv', 'report', 'generate file',
            'save as', 'create file'
        ]
        return any(keyword in message for keyword in file_keywords)
    
    def _generate_table_response(self, message: str) -> Dict[str, Any]:
        """Generate a table response"""
        # Filter data based on message content
        filtered_data = self.sample_data
        sql_query = "SELECT * FROM employees"
        
        if 'engineering' in message.lower():
            filtered_data = [emp for emp in self.sample_data if emp['department'] == 'Engineering']
            sql_query = "SELECT * FROM employees WHERE department = 'Engineering'"
        elif 'salary' in message.lower() and ('high' in message.lower() or '80000' in message.lower()):
            filtered_data = [emp for emp in self.sample_data if emp['salary'] >= 80000]
            sql_query = "SELECT * FROM employees WHERE salary >= 80000"
        elif 'marketing' in message.lower():
            filtered_data = [emp for emp in self.sample_data if emp['department'] == 'Marketing']
            sql_query = "SELECT * FROM employees WHERE department = 'Marketing'"
        
        return {
            'content': json.dumps(filtered_data),
            'displayType': 'table',
            'sqlQuery': sql_query
        }
    
    def _generate_file_response(self, message: str) -> Dict[str, Any]:
        """Generate a file response"""
        # Create CSV content
        csv_content = "ID,Name,Department,Salary,Hire Date\n"
        for emp in self.sample_data:
            csv_content += f"{emp['id']},{emp['name']},{emp['department']},{emp['salary']},{emp['hire_date']}\n"
        
        filename = "employees_report.csv"
        if 'engineering' in message.lower():
            filename = "engineering_employees.csv"
        elif 'salary' in message.lower():
            filename = "salary_report.csv"
        
        sql_query = "SELECT * FROM employees ORDER BY department, salary DESC"
        
        return {
            'content': csv_content,
            'displayType': 'file',
            'fileName': filename,
            'sqlQuery': sql_query
        }
    
    def _generate_text_response(self, message: str) -> Dict[str, Any]:
        """Generate a text response"""
        message_lower = message.lower()
        
        # Greeting responses
        if any(greeting in message_lower for greeting in ['hello', 'hi', 'hey', 'good morning', 'good afternoon']):
            return {
                'content': "Hello! I'm DBChatbot, your intelligent database assistant. I can help you query databases, generate reports, and provide insights. What would you like to know?",
                'displayType': 'text'
            }
        
        # Help responses
        if any(help_word in message_lower for help_word in ['help', 'what can you do', 'capabilities']):
            return {
                'content': """I can help you with:
• Database queries and data retrieval
• Generating reports in table format
• Creating downloadable files (CSV, reports)
• Providing data insights and analysis
• Showing SQL queries for transparency

Try asking me:
- "Show me all employees"
- "Generate a salary report file"
- "List engineering department employees"
- "What's the average salary by department?"
                """,
                'displayType': 'text'
            }
        
        # Database statistics
        if any(stat_word in message_lower for stat_word in ['statistics', 'stats', 'summary', 'overview']):
            avg_salary = sum(emp['salary'] for emp in self.sample_data) / len(self.sample_data)
            departments = set(emp['department'] for emp in self.sample_data)
            
            return {
                'content': f"""Database Statistics:
• Total Employees: {len(self.sample_data)}
• Departments: {', '.join(departments)}
• Average Salary: ${avg_salary:,.2f}
• Highest Salary: ${max(emp['salary'] for emp in self.sample_data):,}
• Lowest Salary: ${min(emp['salary'] for emp in self.sample_data):,}
                """,
                'displayType': 'text',
                'sqlQuery': "SELECT COUNT(*) as total_employees, AVG(salary) as avg_salary, MAX(salary) as max_salary, MIN(salary) as min_salary FROM employees"
            }
        
        # Default response
        responses = [
            "I understand you're looking for information. Could you be more specific about what data you need?",
            "I can help you query the database. Try asking for employee data, reports, or specific department information.",
            "Let me know what kind of data analysis or report you need, and I'll generate it for you.",
            "I'm ready to help with your database queries. What would you like to explore?"
        ]
        
        return {
            'content': random.choice(responses),
            'displayType': 'text'
        }

# Example usage
if __name__ == "__main__":
    processor = MessageProcessor()
    
    # Test different message types
    test_messages = [
        "Hello!",
        "Show me all employees",
        "Generate a file with employee data",
        "What are the database statistics?",
        "Help me understand what you can do"
    ]
    
    for msg in test_messages:
        print(f"\nMessage: {msg}")
        response = processor.process_message(msg)
        print(f"Response Type: {response['displayType']}")
        print(f"Content: {response['content'][:100]}...")
        if 'sqlQuery' in response:
            print(f"SQL: {response['sqlQuery']}")