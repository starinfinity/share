#!/usr/bin/env python3
"""
DBChatbot Backend Server
A simple HTTP server that processes chat messages and returns responses
in various formats (text, table, file) with optional SQL queries.
"""

import json
import http.server
import socketserver
import urllib.parse
from typing import Dict, Any, Optional
import logging
from message_processor import MessageProcessor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DBChatbotHandler(http.server.SimpleHTTPRequestHandler):
    """HTTP request handler for DBChatbot API endpoints"""
    
    def __init__(self, *args, **kwargs):
        self.message_processor = MessageProcessor()
        super().__init__(*args, **kwargs)
    
    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()
    
    def do_POST(self):
        """Handle POST requests to the chat endpoint"""
        if self.path == '/chat':
            try:
                # Read request body
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                
                # Parse JSON data
                data = json.loads(post_data.decode('utf-8'))
                message = data.get('message', '')
                
                logger.info(f"Received message: {message}")
                
                # Process the message
                response = self.message_processor.process_message(message)
                
                # Send response
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                
                response_json = json.dumps(response)
                self.wfile.write(response_json.encode('utf-8'))
                
                logger.info(f"Sent response: {response['displayType']}")
                
            except Exception as e:
                logger.error(f"Error processing request: {str(e)}")
                self.send_error_response(500, f"Internal server error: {str(e)}")
        else:
            self.send_error_response(404, "Endpoint not found")
    
    def send_error_response(self, status_code: int, message: str):
        """Send an error response"""
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        
        error_response = {
            'content': message,
            'displayType': 'text'
        }
        
        self.wfile.write(json.dumps(error_response).encode('utf-8'))

def run_server(port: int = 8000):
    """Run the DBChatbot server"""
    try:
        with socketserver.TCPServer(("", port), DBChatbotHandler) as httpd:
            logger.info(f"DBChatbot server running on port {port}")
            logger.info(f"Access the API at: http://localhost:{port}/chat")
            httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {str(e)}")

if __name__ == "__main__":
    run_server()