import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { sendMessage } from '../services/api';
import { Message } from '../types';
import MessageDisplay from './MessageDisplay';
import ThemeSelector from './ThemeSelector';

const Chat: React.FC = () => {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      type: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      const response = await sendMessage(inputMessage);
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: response.content,
        type: 'bot',
        timestamp: new Date(),
        displayType: response.displayType,
        sqlQuery: response.sqlQuery,
        fileName: response.fileName,
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: 'Sorry, I encountered an error processing your message. Please try again.',
        type: 'bot',
        timestamp: new Date(),
        displayType: 'text',
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickActions = [
    { icon: '👥', text: 'Show all employees', action: 'Show me all employees in the database' },
    { icon: '📊', text: 'Department stats', action: 'Give me statistics by department' },
    { icon: '💰', text: 'Salary report', action: 'Generate a salary report file' },
    { icon: '📈', text: 'Data overview', action: 'Show me database statistics and overview' },
  ];

  return (
    <div 
      className="min-h-screen flex flex-col relative overflow-hidden"
      style={{ background: 'var(--bg-primary)' }}
    >
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-20 w-64 h-64 rounded-full bg-gradient-to-br from-blue-400/10 to-purple-600/10 animate-float"></div>
        <div className="absolute bottom-20 left-20 w-80 h-80 rounded-full bg-gradient-to-tr from-pink-400/10 to-yellow-600/10 animate-float" style={{ animationDelay: '3s' }}></div>
      </div>

      {/* Header */}
      <header 
        className="relative z-10 backdrop-blur-md border-b"
        style={{ 
          background: 'var(--glass-bg)',
          borderColor: 'var(--glass-border)'
        }}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 hover:scale-105"
                style={{
                  background: 'var(--bg-secondary)',
                  color: 'var(--text-secondary)',
                  border: '1px solid var(--border-primary)'
                }}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                </svg>
                <span className="font-medium">Home</span>
              </button>
              
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                  <span className="text-white text-lg">🧠</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
                    DBChatbot
                  </h1>
                  <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                    AI Database Assistant
                  </p>
                </div>
              </div>
            </div>
            <ThemeSelector />
          </div>
        </div>
      </header>

      {/* Chat Messages */}
      <div className="flex-1 relative z-10 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-6 py-8">
          {messages.length === 0 ? (
            <div className="text-center py-20">
              <div className="mb-8">
                <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-2xl animate-bounce-slow">
                  <span className="text-4xl">🤖</span>
                </div>
              </div>
              
              <h3 className="text-3xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>
                Ready to Chat!
              </h3>
              <p className="text-lg mb-8" style={{ color: 'var(--text-secondary)' }}>
                Ask me anything about your database or try one of these quick actions:
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
                {quickActions.map((action, index) => (
                  <button
                    key={index}
                    onClick={() => setInputMessage(action.action)}
                    className="p-4 rounded-2xl transition-all duration-300 hover:scale-105 group"
                    style={{
                      background: 'var(--glass-bg)',
                      backdropFilter: 'blur(20px)',
                      border: '1px solid var(--glass-border)',
                      boxShadow: 'var(--shadow-md)'
                    }}
                  >
                    <div className="text-3xl mb-2 group-hover:scale-110 transition-transform duration-300">
                      {action.icon}
                    </div>
                    <div className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
                      {action.text}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {messages.map((message) => (
                <MessageDisplay key={message.id} message={message} />
              ))}
              {isLoading && (
                <div className="flex items-center justify-center space-x-4 py-8">
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 rounded-full bg-gradient-to-r from-blue-500 to-purple-500 animate-bounce"></div>
                    <div className="w-3 h-3 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 animate-bounce" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-3 h-3 rounded-full bg-gradient-to-r from-pink-500 to-red-500 animate-bounce" style={{animationDelay: '0.2s'}}></div>
                  </div>
                  <span className="text-lg font-medium" style={{ color: 'var(--text-secondary)' }}>
                    🧠 Thinking...
                  </span>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </div>

      {/* Message Input */}
      <div 
        className="relative z-10 backdrop-blur-md border-t p-6"
        style={{ 
          background: 'var(--glass-bg)',
          borderColor: 'var(--glass-border)'
        }}
      >
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSendMessage} className="flex space-x-4">
            <div className="flex-1 relative">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask me anything about your database..."
                className="w-full px-6 py-4 rounded-2xl text-lg transition-all duration-300 focus:scale-[1.02]"
                style={{
                  background: 'var(--bg-secondary)',
                  border: '2px solid var(--border-primary)',
                  color: 'var(--text-primary)',
                  boxShadow: 'var(--shadow-md)'
                }}
                disabled={isLoading}
              />
              <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                <span className="text-2xl">💭</span>
              </div>
            </div>
            
            <button
              type="submit"
              disabled={!inputMessage.trim() || isLoading}
              className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold rounded-2xl shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center space-x-2"
            >
              <span className="text-xl">🚀</span>
              <span>Send</span>
            </button>
          </form>
          
          <div className="flex items-center justify-center mt-4 space-x-6 text-sm" style={{ color: 'var(--text-muted)' }}>
            <div className="flex items-center space-x-2">
              <span>💡</span>
              <span>Try: "Show me all employees"</span>
            </div>
            <div className="flex items-center space-x-2">
              <span>📊</span>
              <span>Or: "Generate salary report"</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;