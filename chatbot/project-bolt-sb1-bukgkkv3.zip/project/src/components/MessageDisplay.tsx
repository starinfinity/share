import React, { useState } from 'react';
import { Message } from '../types';

interface MessageDisplayProps {
  message: Message;
}

const MessageDisplay: React.FC<MessageDisplayProps> = ({ message }) => {
  const [showSql, setShowSql] = useState(false);

  const handleDownload = () => {
    if (message.displayType === 'file' && message.fileName) {
      const blob = new Blob([message.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = message.fileName;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  const renderContent = () => {
    if (message.displayType === 'table') {
      try {
        const data = JSON.parse(message.content);
        if (Array.isArray(data) && data.length > 0) {
          const headers = Object.keys(data[0]);
          return (
            <div className="overflow-hidden rounded-xl">
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr style={{ background: 'var(--bg-accent)' }}>
                      {headers.map((header) => (
                        <th 
                          key={header} 
                          className="px-6 py-4 text-left font-semibold text-sm uppercase tracking-wider"
                          style={{ color: 'var(--text-primary)' }}
                        >
                          {header.replace('_', ' ')}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y" style={{ divideColor: 'var(--border-primary)' }}>
                    {data.map((row, index) => (
                      <tr 
                        key={index} 
                        className="transition-colors duration-200 hover:bg-opacity-50"
                        style={{ 
                          background: index % 2 === 0 ? 'var(--bg-secondary)' : 'var(--bg-primary)'
                        }}
                      >
                        {headers.map((header) => (
                          <td 
                            key={header} 
                            className="px-6 py-4 text-sm"
                            style={{ color: 'var(--text-secondary)' }}
                          >
                            {row[header]}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          );
        }
      } catch (error) {
        console.error('Error parsing table data:', error);
      }
    }

    if (message.displayType === 'file') {
      return (
        <div 
          className="p-6 rounded-2xl border-2 border-dashed transition-all duration-300 hover:scale-[1.02]"
          style={{ 
            borderColor: 'var(--accent-primary)',
            background: 'var(--bg-accent)'
          }}
        >
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-green-500 to-blue-500 flex items-center justify-center shadow-lg">
              <span className="text-3xl">📄</span>
            </div>
            <h4 className="text-lg font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
              File Ready for Download
            </h4>
            <p className="mb-4" style={{ color: 'var(--text-secondary)' }}>
              {message.fileName}
            </p>
            <button
              onClick={handleDownload}
              className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-500 to-blue-500 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              <span className="text-xl">⬇️</span>
              <span>Download File</span>
            </button>
          </div>
        </div>
      );
    }

    return (
      <div className="whitespace-pre-wrap leading-relaxed" style={{ color: 'var(--text-primary)' }}>
        {message.content}
      </div>
    );
  };

  return (
    <div className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'} mb-6`}>
      <div className={`max-w-3xl ${message.type === 'user' ? 'ml-12' : 'mr-12'}`}>
        {/* Message Bubble */}
        <div 
          className={`rounded-3xl p-6 shadow-lg transition-all duration-300 hover:shadow-xl ${
            message.type === 'user' 
              ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' 
              : ''
          }`}
          style={message.type === 'bot' ? {
            background: 'var(--glass-bg)',
            backdropFilter: 'blur(20px)',
            border: '1px solid var(--glass-border)'
          } : {}}
        >
          {/* User Avatar */}
          {message.type === 'user' && (
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center flex-shrink-0">
                <span className="text-lg">👤</span>
              </div>
              <div className="flex-1">
                <div className="text-white font-medium">{message.content}</div>
              </div>
            </div>
          )}

          {/* Bot Response */}
          {message.type === 'bot' && (
            <div className="flex items-start space-x-4">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center flex-shrink-0">
                <span className="text-white text-lg">🤖</span>
              </div>
              <div className="flex-1">
                {renderContent()}
                
                {/* SQL Query Spoiler */}
                {message.sqlQuery && (
                  <div className="mt-6 pt-4 border-t" style={{ borderColor: 'var(--border-primary)' }}>
                    <button
                      onClick={() => setShowSql(!showSql)}
                      className="flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-300 hover:scale-105"
                      style={{
                        background: 'var(--bg-secondary)',
                        color: 'var(--accent-primary)',
                        border: '1px solid var(--border-primary)'
                      }}
                    >
                      <span className="text-lg">🔍</span>
                      <span className="font-medium">SQL Query</span>
                      <svg 
                        className={`w-4 h-4 transition-transform duration-300 ${showSql ? 'rotate-180' : ''}`}
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>
                    
                    {showSql && (
                      <div 
                        className="mt-4 p-4 rounded-xl border overflow-x-auto"
                        style={{ 
                          background: 'var(--bg-tertiary)',
                          borderColor: 'var(--border-secondary)'
                        }}
                      >
                        <div className="flex items-center space-x-2 mb-3">
                          <span className="text-lg">⚡</span>
                          <span className="font-semibold text-sm" style={{ color: 'var(--text-primary)' }}>
                            Generated SQL Query
                          </span>
                        </div>
                        <pre className="text-sm font-mono leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                          <code>{message.sqlQuery}</code>
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
        
        {/* Timestamp */}
        <div className={`text-xs mt-2 ${message.type === 'user' ? 'text-right' : 'text-left'}`} style={{ color: 'var(--text-muted)' }}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </div>
      </div>
    </div>
  );
};

export default MessageDisplay;