import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout';
import Home from './pages/Home';
import Migration from './pages/Migration';
import Generator from './pages/Generator';
import AI from './pages/AI';
import AirflowIDE from './pages/AirflowIDE';

function App() {
  return (
    <ThemeProvider>
      <Router>
        <Layout>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/migration" element={<Migration />} />
            <Route path="/generator" element={<Generator />} />
            <Route path="/ai" element={<AI />} />
            <Route path="/airflow-ide" element={<AirflowIDE />} />
          </Routes>
        </Layout>
      </Router>
    </ThemeProvider>
  );
}

export default App;