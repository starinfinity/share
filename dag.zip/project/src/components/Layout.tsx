import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Moon, Sun, Database } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      <header className="bg-white dark:bg-gray-800 shadow-lg border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link to="/" className="flex items-center space-x-2 group">
              <div className="p-2 bg-primary-900 rounded-lg group-hover:bg-primary-950 transition-colors">
                <Database className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                DAG Manager
              </h1>
            </Link>
            
            <nav className="hidden md:flex space-x-8">
              <Link 
                to="/" 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location.pathname === '/' 
                    ? 'text-primary-900 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30' 
                    : 'text-gray-700 dark:text-gray-300 hover:text-primary-900 dark:hover:text-primary-400'
                }`}
              >
                Home
              </Link>
              <Link 
                to="/migration" 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location.pathname === '/migration' 
                    ? 'text-primary-900 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30' 
                    : 'text-gray-700 dark:text-gray-300 hover:text-primary-900 dark:hover:text-primary-400'
                }`}
              >
                Migration
              </Link>
              <Link 
                to="/generator" 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location.pathname === '/generator' 
                    ? 'text-primary-900 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30' 
                    : 'text-gray-700 dark:text-gray-300 hover:text-primary-900 dark:hover:text-primary-400'
                }`}
              >
                Generator
              </Link>
              <Link 
                to="/ai" 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location.pathname === '/ai' 
                    ? 'text-primary-900 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30' 
                    : 'text-gray-700 dark:text-gray-300 hover:text-primary-900 dark:hover:text-primary-400'
                }`}
              >
                DAG AI
              </Link>
              <Link 
                to="/airflow-ide" 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location.pathname === '/airflow-ide' 
                    ? 'text-primary-900 dark:text-primary-400 bg-primary-50 dark:bg-primary-900/30' 
                    : 'text-gray-700 dark:text-gray-300 hover:text-primary-900 dark:hover:text-primary-400'
                }`}
              >
                Airflow IDE
              </Link>
            </nav>

            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? (
                <Moon className="h-5 w-5 text-gray-700 dark:text-gray-300" />
              ) : (
                <Sun className="h-5 w-5 text-gray-700 dark:text-gray-300" />
              )}
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {children}
      </main>
    </div>
  );
};

export default Layout;