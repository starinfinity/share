import React, { useState, useRef, useEffect } from 'react';
import { 
  Code, 
  Play, 
  Download, 
  Copy, 
  Save, 
  Folder, 
  File, 
  Search, 
  Settings, 
  Terminal, 
  GitBranch,
  Bug,
  Zap,
  Eye,
  EyeOff,
  Maximize2,
  Minimize2,
  RefreshCw,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Cloud,
  Server
} from 'lucide-react';

interface FileNode {
  name: string;
  type: 'file' | 'folder';
  children?: FileNode[];
  content?: string;
}

const AirflowIDE: React.FC = () => {
  const [activeFile, setActiveFile] = useState('sample_dag.py');
  const [codeContent, setCodeContent] = useState(`# Airflow DAG - Advanced Pipeline
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bash_operator import BashOperator
from airflow.sensors.filesystem import FileSensor
from datetime import datetime, timedelta
import pandas as pd
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

default_args = {
    'owner': 'airflow-ide',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 2,
    'retry_delay': timedelta(minutes=5),
    'max_active_runs': 1
}

dag = DAG(
    'advanced_data_pipeline',
    default_args=default_args,
    description='Advanced data processing pipeline with monitoring',
    schedule_interval='@daily',
    catchup=False,
    tags=['production', 'data-pipeline', 'etl']
)

def extract_data(**context):
    """Extract data from multiple sources"""
    logger.info("Starting data extraction...")
    
    # Simulate data extraction
    data = {
        'users': pd.DataFrame({'id': range(1000), 'name': [f'user_{i}' for i in range(1000)]}),
        'orders': pd.DataFrame({'order_id': range(500), 'user_id': range(500)})
    }
    
    logger.info(f"Extracted {len(data['users'])} users and {len(data['orders'])} orders")
    return data

def transform_data(**context):
    """Transform and clean the data"""
    logger.info("Starting data transformation...")
    
    # Get data from previous task
    data = context['task_instance'].xcom_pull(task_ids='extract_data')
    
    # Perform transformations
    transformed_data = {
        'user_summary': data['users'].groupby('id').size(),
        'order_summary': data['orders'].groupby('user_id').size()
    }
    
    logger.info("Data transformation completed")
    return transformed_data

def load_data(**context):
    """Load data to destination"""
    logger.info("Starting data load...")
    
    # Get transformed data
    data = context['task_instance'].xcom_pull(task_ids='transform_data')
    
    # Simulate data loading
    logger.info(f"Loaded {len(data)} datasets to warehouse")
    return "Load completed successfully"

def validate_data(**context):
    """Validate data quality"""
    logger.info("Starting data validation...")
    
    # Perform data quality checks
    validation_results = {
        'row_count_check': True,
        'null_check': True,
        'schema_check': True,
        'business_rules_check': True
    }
    
    if all(validation_results.values()):
        logger.info("All data quality checks passed")
        return "PASSED"
    else:
        logger.error("Data quality checks failed")
        raise ValueError("Data validation failed")

# Define tasks
file_sensor = FileSensor(
    task_id='wait_for_file',
    filepath='/tmp/trigger_file.txt',
    fs_conn_id='fs_default',
    poke_interval=30,
    timeout=300,
    dag=dag
)

extract_task = PythonOperator(
    task_id='extract_data',
    python_callable=extract_data,
    dag=dag
)

transform_task = PythonOperator(
    task_id='transform_data',
    python_callable=transform_data,
    dag=dag
)

validate_task = PythonOperator(
    task_id='validate_data',
    python_callable=validate_data,
    dag=dag
)

load_task = PythonOperator(
    task_id='load_data',
    python_callable=load_data,
    dag=dag
)

cleanup_task = BashOperator(
    task_id='cleanup',
    bash_command='echo "Cleaning up temporary files..." && rm -f /tmp/temp_*',
    dag=dag
)

# Define task dependencies
file_sensor >> extract_task >> transform_task >> validate_task >> load_task >> cleanup_task

# Add parallel branch for monitoring
monitoring_task = PythonOperator(
    task_id='monitoring',
    python_callable=lambda: logger.info("Pipeline monitoring completed"),
    dag=dag
)

# Parallel execution
[validate_task, monitoring_task] >> load_task
`);
  
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showMinimap, setShowMinimap] = useState(true);
  const [terminalOutput, setTerminalOutput] = useState([
    '$ airflow dags list',
    'advanced_data_pipeline',
    'sample_dag',
    '$ airflow tasks list advanced_data_pipeline',
    'extract_data',
    'transform_data',
    'validate_data',
    'load_data',
    'cleanup',
    'monitoring',
    '$ '
  ]);
  const [searchQuery, setSearchQuery] = useState('');
  const [lineNumbers, setLineNumbers] = useState(true);
  const [deploymentStatus, setDeploymentStatus] = useState<'idle' | 'deploying' | 'success' | 'error'>('idle');

  const fileTree: FileNode[] = [
    {
      name: 'dags',
      type: 'folder',
      children: [
        { name: 'sample_dag.py', type: 'file' },
        { name: 'advanced_pipeline.py', type: 'file' },
        { name: 'etl_dag.py', type: 'file' }
      ]
    },
    {
      name: 'plugins',
      type: 'folder',
      children: [
        { name: 'custom_operators.py', type: 'file' },
        { name: 'hooks.py', type: 'file' }
      ]
    },
    {
      name: 'config',
      type: 'folder',
      children: [
        { name: 'airflow.cfg', type: 'file' },
        { name: 'connections.yaml', type: 'file' }
      ]
    },
    { name: 'requirements.txt', type: 'file' },
    { name: 'docker-compose.yml', type: 'file' }
  ];

  const handleDevDeploy = async () => {
    setDeploymentStatus('deploying');
    setTimeout(() => setDeploymentStatus('success'), 2000);
  };

  const handleStageDeploy = async () => {
    setDeploymentStatus('deploying');
    setTimeout(() => setDeploymentStatus('success'), 2500);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([codeContent], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = activeFile;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(codeContent);
  };

  const handleSave = () => {
    console.log('Saving file:', activeFile);
  };

  const handleRunCode = () => {
    setTerminalOutput(prev => [
      ...prev,
      `$ airflow dags test ${activeFile.replace('.py', '')}`,
      'Starting DAG test run...',
      'Task extract_data: SUCCESS',
      'Task transform_data: SUCCESS', 
      'Task validate_data: SUCCESS',
      'Task load_data: SUCCESS',
      'DAG test completed successfully!',
      '$ '
    ]);
  };

  const renderFileTree = (nodes: FileNode[], depth = 0) => {
    return nodes.map((node, index) => (
      <div key={index} style={{ marginLeft: `${depth * 16}px` }}>
        <div 
          className={`flex items-center py-1 px-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer rounded ${
            activeFile === node.name ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-900 dark:text-primary-400' : ''
          }`}
          onClick={() => node.type === 'file' && setActiveFile(node.name)}
        >
          {node.type === 'folder' ? (
            <Folder className="h-4 w-4 mr-2 text-blue-500" />
          ) : (
            <File className="h-4 w-4 mr-2 text-gray-500" />
          )}
          <span className="text-sm">{node.name}</span>
        </div>
        {node.children && renderFileTree(node.children, depth + 1)}
      </div>
    ));
  };

  const getDeploymentIcon = () => {
    switch (deploymentStatus) {
      case 'deploying':
        return <RefreshCw className="h-4 w-4 animate-spin" />;
      case 'success':
        return <CheckCircle className="h-4 w-4" />;
      case 'error':
        return <XCircle className="h-4 w-4" />;
      default:
        return <Cloud className="h-4 w-4" />;
    }
  };

  const getDeploymentColor = () => {
    switch (deploymentStatus) {
      case 'deploying':
        return 'bg-yellow-500 hover:bg-yellow-600';
      case 'success':
        return 'bg-green-500 hover:bg-green-600';
      case 'error':
        return 'bg-red-500 hover:bg-red-600';
      default:
        return 'bg-blue-500 hover:bg-blue-600';
    }
  };

  return (
    <div className={`${isFullscreen ? 'fixed inset-0 z-50' : 'min-h-screen'} bg-white dark:bg-gray-900 transition-colors duration-300`}>
      <div className="h-screen flex flex-col">
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-r from-primary-900 to-primary-950 rounded-lg">
                <Code className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                Airflow IDE
              </h1>
              <span className="px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400 text-xs font-medium rounded-full">
                Connected
              </span>
            </div>
            
            <div className="flex items-center space-x-2">
              <button
                onClick={handleDevDeploy}
                disabled={deploymentStatus === 'deploying'}
                className={`flex items-center px-4 py-2 ${getDeploymentColor()} text-white rounded-lg transition-colors font-medium`}
              >
                {getDeploymentIcon()}
                <span className="ml-2">Dev Deploy</span>
              </button>
              <button
                onClick={handleStageDeploy}
                disabled={deploymentStatus === 'deploying'}
                className={`flex items-center px-4 py-2 ${getDeploymentColor()} text-white rounded-lg transition-colors font-medium`}
              >
                <Server className="h-4 w-4 mr-2" />
                Stage Deploy
              </button>
              <button
                onClick={handleDownload}
                className="flex items-center px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </button>
              <button
                onClick={handleCopy}
                className="flex items-center px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors"
              >
                <Copy className="h-4 w-4 mr-2" />
                Copy
              </button>
              <button
                onClick={() => setIsFullscreen(!isFullscreen)}
                className="p-2 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
              >
                {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
              </button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Left Sidebar - File Explorer */}
          <div className="w-64 bg-gray-50 dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col">
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <div className="flex items-center space-x-2 mb-3">
                <Folder className="h-5 w-5 text-primary-900" />
                <h3 className="font-semibold text-gray-900 dark:text-white">Explorer</h3>
              </div>
              <div className="relative">
                <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search files..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-900 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-2">
              {renderFileTree(fileTree)}
            </div>
          </div>

          {/* Center - Code Editor */}
          <div className="flex-1 flex flex-col">
            {/* Editor Tabs */}
            <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2 px-3 py-1 bg-primary-50 dark:bg-primary-900/30 rounded-lg">
                    <File className="h-4 w-4 text-primary-900" />
                    <span className="text-sm font-medium text-primary-900 dark:text-primary-400">{activeFile}</span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setLineNumbers(!lineNumbers)}
                    className={`p-2 rounded-lg transition-colors ${lineNumbers ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-900' : 'bg-gray-100 dark:bg-gray-700 text-gray-600'}`}
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setShowMinimap(!showMinimap)}
                    className={`p-2 rounded-lg transition-colors ${showMinimap ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-900' : 'bg-gray-100 dark:bg-gray-700 text-gray-600'}`}
                  >
                    <Settings className="h-4 w-4" />
                  </button>
                  <button
                    onClick={handleRunCode}
                    className="flex items-center px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                  >
                    <Play className="h-4 w-4 mr-2" />
                    Run
                  </button>
                  <button
                    onClick={handleSave}
                    className="flex items-center px-3 py-2 bg-primary-900 hover:bg-primary-950 text-white rounded-lg transition-colors"
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </button>
                </div>
              </div>
            </div>

            {/* Code Editor Area */}
            <div className="flex-1 flex">
              <div className="flex-1 relative">
                {lineNumbers && (
                  <div className="absolute left-0 top-0 bottom-0 w-12 bg-gray-100 dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 text-xs text-gray-500 dark:text-gray-400 p-2 font-mono">
                    {codeContent.split('\n').map((_, index) => (
                      <div key={index} className="leading-6">
                        {index + 1}
                      </div>
                    ))}
                  </div>
                )}
                <textarea
                  value={codeContent}
                  onChange={(e) => setCodeContent(e.target.value)}
                  className={`w-full h-full font-mono text-sm bg-white dark:bg-gray-900 text-gray-900 dark:text-white resize-none focus:outline-none ${
                    lineNumbers ? 'pl-16' : 'pl-4'
                  } pr-4 py-4 leading-6`}
                  placeholder="Start coding your Airflow DAG..."
                  spellCheck={false}
                />
              </div>
              
              {/* Minimap */}
              {showMinimap && (
                <div className="w-32 bg-gray-50 dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 p-2">
                  <div className="text-xs text-gray-500 dark:text-gray-400 mb-2">Minimap</div>
                  <div className="text-xs font-mono text-gray-400 dark:text-gray-500 leading-tight overflow-hidden">
                    {codeContent.split('\n').slice(0, 50).map((line, index) => (
                      <div key={index} className="truncate">
                        {line || ' '}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Sidebar - Tools */}
          <div className="w-80 bg-gray-50 dark:bg-gray-800 border-l border-gray-200 dark:border-gray-700 flex flex-col">
            {/* DAG Visualization */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center">
                <GitBranch className="h-5 w-5 mr-2 text-primary-900" />
                DAG Graph
              </h3>
              <div className="bg-white dark:bg-gray-700 rounded-lg p-4 border border-gray-200 dark:border-gray-600">
                <div className="space-y-2 text-xs">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-blue-500 rounded"></div>
                    <span>wait_for_file</span>
                  </div>
                  <div className="ml-2 border-l-2 border-gray-300 pl-2 space-y-1">
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-green-500 rounded"></div>
                      <span>extract_data</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-yellow-500 rounded"></div>
                      <span>transform_data</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-purple-500 rounded"></div>
                      <span>validate_data</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-3 h-3 bg-red-500 rounded"></div>
                      <span>load_data</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Terminal */}
            <div className="flex-1 flex flex-col">
              <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                <h3 className="font-semibold text-gray-900 dark:text-white flex items-center">
                  <Terminal className="h-5 w-5 mr-2 text-primary-900" />
                  Terminal
                </h3>
              </div>
              <div className="flex-1 bg-black text-green-400 p-4 font-mono text-sm overflow-y-auto">
                {terminalOutput.map((line, index) => (
                  <div key={index} className="leading-6">
                    {line}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Status Bar */}
        <div className="bg-primary-900 text-white px-6 py-2 text-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <span>Python 3.9.7</span>
              <span>•</span>
              <span>Airflow 2.5.0</span>
              <span>•</span>
              <span>UTF-8</span>
            </div>
            <div className="flex items-center space-x-4">
              <span>Lines: {codeContent.split('\n').length}</span>
              <span>•</span>
              <span>Chars: {codeContent.length}</span>
              <span>•</span>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Connected</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AirflowIDE;