import React, { useState } from 'react';
import { Calendar, Plus, Settings, GripVertical, X, ChevronUp, ChevronDown } from 'lucide-react';

interface DAGFunction {
  id: string;
  name: string;
  description: string;
  parameters: { [key: string]: string };
}

interface SelectedFunction extends DAGFunction {
  order: number;
  values: { [key: string]: string };
  uniqueId: string;
}

const Generator: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedFunction, setSelectedFunction] = useState('');
  const [selectedFunctions, setSelectedFunctions] = useState<SelectedFunction[]>([]);
  const [editingFunction, setEditingFunction] = useState<SelectedFunction | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  // Mock backend data
  const availableFunctions: DAGFunction[] = [
    {
      id: 'extract_data',
      name: 'Extract Data',
      description: 'Extract data from various sources',
      parameters: {
        source: 'text',
        query: 'textarea',
        timeout: 'number'
      }
    },
    {
      id: 'transform_data',
      name: 'Transform Data',
      description: 'Apply transformations to the data',
      parameters: {
        transformation_type: 'select',
        columns: 'text',
        aggregation: 'select'
      }
    },
    {
      id: 'load_data',
      name: 'Load Data',
      description: 'Load processed data to destination',
      parameters: {
        destination: 'text',
        batch_size: 'number',
        mode: 'select'
      }
    },
    {
      id: 'validate_data',
      name: 'Validate Data',
      description: 'Validate data quality and integrity',
      parameters: {
        validation_rules: 'textarea',
        threshold: 'number'
      }
    }
  ];

  const handleAddFunction = () => {
    if (!selectedFunction) return;
    
    const func = availableFunctions.find(f => f.id === selectedFunction);
    if (!func) return;

    const newFunction: SelectedFunction = {
      ...func,
      order: selectedFunctions.length,
      values: {},
      uniqueId: `${func.id}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };

    setSelectedFunctions([...selectedFunctions, newFunction]);
    setSelectedFunction('');
  };

  const handleRemoveFunction = (uniqueId: string) => {
    const updatedFunctions = selectedFunctions
      .filter(f => f.uniqueId !== uniqueId)
      .map((f, index) => ({ ...f, order: index }));
    setSelectedFunctions(updatedFunctions);
  };

  const handleMoveFunction = (uniqueId: string, direction: 'up' | 'down') => {
    const currentIndex = selectedFunctions.findIndex(f => f.uniqueId === uniqueId);
    if (currentIndex === -1) return;

    const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (newIndex < 0 || newIndex >= selectedFunctions.length) return;

    const updatedFunctions = [...selectedFunctions];
    [updatedFunctions[currentIndex], updatedFunctions[newIndex]] = 
    [updatedFunctions[newIndex], updatedFunctions[currentIndex]];

    // Update order numbers
    updatedFunctions.forEach((func, index) => {
      func.order = index;
    });

    setSelectedFunctions(updatedFunctions);
  };

  const handleEditFunction = (func: SelectedFunction) => {
    setEditingFunction(func);
  };

  const handleSaveFunction = (updatedFunc: SelectedFunction) => {
    setSelectedFunctions(selectedFunctions.map(f => 
      f.uniqueId === updatedFunc.uniqueId ? updatedFunc : f
    ));
    setEditingFunction(null);
  };

  const handleGenerateDAG = async () => {
    if (!selectedDate || selectedFunctions.length === 0) return;
    
    setIsGenerating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsGenerating(false);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            DAG Generator
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Build custom DAGs by selecting and configuring functions
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Panel - Configuration */}
          <div className="space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Configuration
              </h2>
              
              {/* Date Selector */}
              <div className="space-y-3 mb-6">
                <label className="flex items-center text-sm font-medium text-gray-900 dark:text-white">
                  <Calendar className="h-4 w-4 mr-2 text-primary-900" />
                  Scheduled Date
                </label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-900 focus:border-primary-900 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                />
              </div>

              {/* Function Selector */}
              <div className="space-y-3">
                <label className="text-sm font-medium text-gray-900 dark:text-white">
                  Add Function
                </label>
                <div className="flex space-x-2">
                  <select
                    value={selectedFunction}
                    onChange={(e) => setSelectedFunction(e.target.value)}
                    className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-900 focus:border-primary-900 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    <option value="">Select a function...</option>
                    {availableFunctions.map(func => (
                      <option key={func.id} value={func.id}>
                        {func.name}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={handleAddFunction}
                    disabled={!selectedFunction}
                    className="px-4 py-2 bg-primary-900 hover:bg-primary-950 disabled:bg-gray-400 text-white rounded-lg transition-colors flex items-center"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerateDAG}
              disabled={!selectedDate || selectedFunctions.length === 0 || isGenerating}
              className="w-full bg-gradient-to-r from-primary-900 to-primary-950 hover:from-primary-800 hover:to-primary-900 disabled:from-gray-400 disabled:to-gray-500 text-white font-medium py-4 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 disabled:scale-100 disabled:cursor-not-allowed shadow-lg"
            >
              {isGenerating ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Generating DAG...
                </div>
              ) : (
                'Generate DAG'
              )}
            </button>
          </div>

          {/* Right Panel - Selected Functions */}
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-6">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
              Selected Functions ({selectedFunctions.length})
            </h2>
            
            {selectedFunctions.length === 0 ? (
              <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                <Settings className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No functions selected yet</p>
                <p className="text-sm">Add functions to build your DAG</p>
              </div>
            ) : (
              <div className="space-y-3">
                {selectedFunctions
                  .sort((a, b) => a.order - b.order)
                  .map((func, index) => (
                  <div
                    key={func.uniqueId}
                    className="flex items-center p-4 bg-gray-50 dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 hover:border-primary-900 dark:hover:border-primary-700 transition-colors"
                  >
                    <div className="flex flex-col space-y-1 mr-3">
                      <button
                        onClick={() => handleMoveFunction(func.uniqueId, 'up')}
                        disabled={index === 0}
                        className="p-1 text-gray-400 hover:text-primary-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                      >
                        <ChevronUp className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleMoveFunction(func.uniqueId, 'down')}
                        disabled={index === selectedFunctions.length - 1}
                        className="p-1 text-gray-400 hover:text-primary-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                      >
                        <ChevronDown className="h-4 w-4" />
                      </button>
                    </div>
                    
                    <GripVertical className="h-5 w-5 text-gray-400 mr-3" />
                    
                    <div className="flex-1 cursor-pointer" onClick={() => handleEditFunction(func)}>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium text-gray-900 dark:text-white">
                            {index + 1}. {func.name}
                          </h3>
                          <p className="text-sm text-gray-600 dark:text-gray-300">
                            {func.description}
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveFunction(func.uniqueId);
                      }}
                      className="p-1 text-red-500 hover:text-red-700 transition-colors ml-2"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Function Edit Modal */}
        {editingFunction && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                Configure {editingFunction.name}
              </h3>
              
              <div className="space-y-4">
                {Object.entries(editingFunction.parameters).map(([param, type]) => (
                  <div key={param}>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      {param.replace('_', ' ').toUpperCase()}
                    </label>
                    {type === 'textarea' ? (
                      <textarea
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-900 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        rows={3}
                        value={editingFunction.values[param] || ''}
                        onChange={(e) => setEditingFunction({
                          ...editingFunction,
                          values: { ...editingFunction.values, [param]: e.target.value }
                        })}
                      />
                    ) : type === 'select' ? (
                      <select
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-900 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        value={editingFunction.values[param] || ''}
                        onChange={(e) => setEditingFunction({
                          ...editingFunction,
                          values: { ...editingFunction.values, [param]: e.target.value }
                        })}
                      >
                        <option value="">Select...</option>
                        <option value="option1">Option 1</option>
                        <option value="option2">Option 2</option>
                      </select>
                    ) : (
                      <input
                        type={type}
                        className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-900 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                        value={editingFunction.values[param] || ''}
                        onChange={(e) => setEditingFunction({
                          ...editingFunction,
                          values: { ...editingFunction.values, [param]: e.target.value }
                        })}
                      />
                    )}
                  </div>
                ))}
              </div>

              <div className="flex space-x-3 mt-6">
                <button
                  onClick={() => handleSaveFunction(editingFunction)}
                  className="flex-1 bg-primary-900 hover:bg-primary-950 text-white py-2 px-4 rounded-lg transition-colors"
                >
                  Save
                </button>
                <button
                  onClick={() => setEditingFunction(null)}
                  className="flex-1 bg-gray-300 dark:bg-gray-600 hover:bg-gray-400 dark:hover:bg-gray-500 text-gray-700 dark:text-gray-300 py-2 px-4 rounded-lg transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Generator;