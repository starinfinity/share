import React from 'react';
import { Link } from 'react-router-dom';
import { GitBranch, Settings, Brain, Code } from 'lucide-react';

const Home: React.FC = () => {
  const features = [
    {
      title: 'DAG Migration',
      description: 'Migrate existing DAGs with advanced date selection and file upload capabilities',
      icon: GitBranch,
      path: '/migration',
      color: 'from-primary-900 to-primary-950',
      bgColor: 'bg-primary-50 dark:bg-primary-900/20',
      iconColor: 'text-primary-900 dark:text-primary-400'
    },
    {
      title: 'DAG Generator',
      description: 'Create new DAGs with customizable functions and intelligent ordering',
      icon: Settings,
      path: '/generator',
      color: 'from-primary-900 to-primary-950',
      bgColor: 'bg-primary-50 dark:bg-primary-900/20',
      iconColor: 'text-primary-900 dark:text-primary-400'
    },
    {
      title: 'DAG AI',
      description: 'AI-powered DAG optimization and intelligent recommendations',
      icon: Brain,
      path: '/ai',
      color: 'from-primary-900 to-primary-950',
      bgColor: 'bg-primary-50 dark:bg-primary-900/20',
      iconColor: 'text-primary-900 dark:text-primary-400'
    },
    {
      title: 'Airflow IDE',
      description: 'Advanced IDE for developing and deploying Airflow DAGs with real-time features',
      icon: Code,
      path: '/airflow-ide',
      color: 'from-primary-900 to-primary-950',
      bgColor: 'bg-primary-50 dark:bg-primary-900/20',
      iconColor: 'text-primary-900 dark:text-primary-400'
    }
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
            DAG Management
            <span className="block text-4xl bg-gradient-to-r from-primary-900 to-primary-700 bg-clip-text text-transparent">
              Made Simple
            </span>
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Streamline your data pipeline workflows with our comprehensive DAG management platform. 
            From migration to generation to AI-powered optimization.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Link
                key={index}
                to={feature.path}
                className="group relative overflow-hidden"
              >
                <div className={`${feature.bgColor} rounded-2xl p-8 h-full border border-gray-200 dark:border-gray-700 transition-all duration-300 group-hover:shadow-2xl group-hover:scale-105 group-hover:-translate-y-2`}>
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className={`p-4 rounded-2xl ${feature.bgColor} border border-gray-200 dark:border-gray-600`}>
                      <Icon className={`h-8 w-8 ${feature.iconColor}`} />
                    </div>
                    
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                      {feature.title}
                    </h3>
                    
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      {feature.description}
                    </p>
                    
                    <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium text-white bg-gradient-to-r ${feature.color} group-hover:shadow-lg transition-all duration-300`}>
                      Get Started
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Home;