import React, { useState } from 'react';
import { Upload, Calendar, FileText, CheckCircle } from 'lucide-react';

const Migration: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState('');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDate || !uploadedFile) return;
    
    setIsGenerating(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsGenerating(false);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            DAG Migration
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300">
            Upload your existing DAG files and migrate them with advanced configuration options
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
          <div className="p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Date Selector */}
              <div className="space-y-3">
                <label className="flex items-center text-lg font-medium text-gray-900 dark:text-white">
                  <Calendar className="h-5 w-5 mr-2 text-primary-900" />
                  Migration Date
                </label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-900 focus:border-primary-900 bg-white dark:bg-gray-700 text-gray-900 dark:text-white transition-colors"
                  required
                />
              </div>

              {/* File Upload */}
              <div className="space-y-3">
                <label className="flex items-center text-lg font-medium text-gray-900 dark:text-white">
                  <Upload className="h-5 w-5 mr-2 text-primary-900" />
                  DAG File Upload
                </label>
                <div className="relative">
                  <input
                    type="file"
                    onChange={handleFileUpload}
                    accept=".py,.yaml,.yml,.json"
                    className="hidden"
                    id="file-upload"
                    required
                  />
                  <label
                    htmlFor="file-upload"
                    className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg cursor-pointer bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                  >
                    {uploadedFile ? (
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-6 w-6 text-green-500" />
                        <span className="text-sm text-gray-700 dark:text-gray-300">
                          {uploadedFile.name}
                        </span>
                      </div>
                    ) : (
                      <>
                        <FileText className="h-8 w-8 text-gray-400 mb-2" />
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          Click to upload or drag and drop
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-500">
                          Supported: .py, .yaml, .yml, .json
                        </p>
                      </>
                    )}
                  </label>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={!selectedDate || !uploadedFile || isGenerating}
                className="w-full bg-gradient-to-r from-primary-900 to-primary-950 hover:from-primary-800 hover:to-primary-900 disabled:from-gray-400 disabled:to-gray-500 text-white font-medium py-4 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 disabled:scale-100 disabled:cursor-not-allowed shadow-lg"
              >
                {isGenerating ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Generating DAG...
                  </div>
                ) : (
                  'Generate Migrated DAG'
                )}
              </button>
            </form>
          </div>
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Supported Formats</h3>
            <p className="text-gray-600 dark:text-gray-300 text-sm">
              Python, YAML, JSON files up to 10MB
            </p>
          </div>
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Migration Features</h3>
            <p className="text-gray-600 dark:text-gray-300 text-sm">
              Auto-validation, dependency mapping, error detection
            </p>
          </div>
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Output Format</h3>
            <p className="text-gray-600 dark:text-gray-300 text-sm">
              Optimized DAG with best practices applied
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Migration;