/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f8f7ff',
          100: '#f0edff',
          200: '#e4deff',
          300: '#d1c4ff',
          400: '#b89fff',
          500: '#9d75ff',
          600: '#8b5cf6',
          700: '#7c3aed',
          800: '#6d28d9',
          900: '#341539',
          950: '#1e0a1f'
        }
      }
    },
  },
  plugins: [],
};