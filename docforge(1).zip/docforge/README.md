# DocForge

> Six-stage AI assistant: requirements → code & docs pull request.

Backend: FastAPI · Frontend: React + Vite · Storage: MySQL (index) + JSON (truth) · Vectors: FAISS · LLM: Anthropic.

---

## Layout

```
docforge/
├── backend/                FastAPI app
│   ├── app/                code
│   │   ├── api/v1/         REST endpoints
│   │   ├── core/           config, security, logging
│   │   ├── db/             SQLAlchemy session
│   │   ├── models/         User, GithubToken, Project, MetricEvent
│   │   ├── schemas/        Pydantic shapes
│   │   ├── services/       project, github, faiss, llm, metrics, doc-parser
│   │   └── stages/         stage1..stage6 orchestration
│   ├── config/             config.yaml + github_metadata.json
│   ├── projects/           per-user, per-project folders (created at runtime)
│   ├── storage/            uploads + templates
│   ├── faiss_index/        FAISS artifacts (index.faiss + meta.json)
│   └── requirements.txt
└── frontend/               React app
    ├── src/
    │   ├── api/            axios client
    │   ├── components/     Navbar, Modal, GithubTokenPanel, HowItWorksModal, StageTracker, ChatPanel, …
    │   ├── context/        AuthContext, ToastContext
    │   ├── pages/          Home, Login, Project, FAQ, DocEditor, TechSpecBot
    │   ├── stages/         Stage1..Stage6
    │   └── styles/         global.css
    └── package.json
```

## Backend setup

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env       # edit DB creds, set ANTHROPIC_API_KEY if you have one
```

### MySQL

Create a database matching `.env`:

```sql
CREATE DATABASE docforge CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'docforge'@'%' IDENTIFIED BY 'docforge';
GRANT ALL ON docforge.* TO 'docforge'@'%';
```

Tables are auto-created on startup (`Base.metadata.create_all`). Wire Alembic for prod.

### Run

```bash
uvicorn app.main:app --reload --port 8000
```

Visit `http://localhost:8000/docs` for the OpenAPI UI.

### FAISS index

The tech-spec-bot and Stage 3 search both need an index. To build one from a docs folder:

```python
from app.services.faiss_service import get_faiss
from pathlib import Path
get_faiss().build_index(Path("/path/to/your/nas/docs"))
```

Until then, the FAISS calls return zero hits (gracefully) and the app stays usable.

## Frontend setup

```bash
cd frontend
npm install
npm run dev
```

Vite serves at `http://localhost:5173` and proxies `/api` to the backend on `:8000`.

## Auth modes

`SSO_ENABLED=false` (default): the two dummy accounts from `.env` are usable on `/auth/login`. Try `alice / alice123` or `bob / bob123`.

`SSO_ENABLED=true`: `/auth/login` is rejected; clients use `/auth/sso/start` and `/auth/sso/callback`. The provided implementation is a stub — wire it to your IdP.

## GitHub token

Set via the navbar's *GitHub* button. Stored encrypted at rest (Fernet); `GITHUB_TOKEN_ENC_KEY` in `.env` should be a fixed value in prod so tokens survive restart. A valid token is required to create or edit any project, and to push Stage 6 PRs.

## Project types

| Type            | Stages run            | Notes                                |
| --------------- | --------------------- | ------------------------------------ |
| `full`          | 1–6                   | Default; existing GitHub repo        |
| `new_project`   | 1, 2, **skip 3**, 4–6 | Starts from a template, empty repo   |
| `doc_editor`    | n/a                   | One-shot doc create/edit             |
| `techspecbot`   | n/a                   | One project per user, holds history  |

## Per-project storage

```
backend/projects/<username>/<DF-XXXX...>/
├── metadata.json          ← source of truth (per-stage state, metrics, edits)
├── uploads/               ← Stage 1 / 3 uploads
├── repo/<name>/           ← Stage 2 clone
├── docs/                  ← Stage 3 selected/uploaded docs
└── artifacts/
    ├── stage1_requirements.md
    ├── stage4_plan.md
    └── stage5/*.updated.md
```

The MySQL `projects` table mirrors a tiny subset (`project_key`, `name`, `current_stage`, …) for fast list queries.

## Knobs (`backend/config/config.yaml`)

- `repo_analysis.supported_languages` — file extensions counted
- `repo_analysis.max_files_supported` — rejection threshold
- `doc_source.readme_repo_prefixes` — repos whose README becomes the Stage 3 doc
- `doc_source.faiss.top_k` — Stage 3 candidate count
- `templates` — list of templates for `new_project`
- `pull_request.branch_prefix` — defaults to `Docforge-`
