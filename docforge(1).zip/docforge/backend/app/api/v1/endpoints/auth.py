"""
Auth router.

Two modes, switched by SSO_ENABLED in .env:

  • SSO_ENABLED=true  → /auth/sso/start and /auth/sso/callback would broker
                        with the IdP. Stubbed here; wire to your IdP in prod.

  • SSO_ENABLED=false → /auth/login accepts one of the two dummy accounts
                        from .env (alice / bob).

Both paths mint the same JWT, so the rest of the API is unaware of mode.
"""
from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.core.config import get_settings
from app.core.security import hash_password, mint_jwt, verify_password
from app.db import get_db
from app.models import User
from app.schemas import LoginRequest, TokenResponse, UserOut
from app.services import metrics_service

router = APIRouter(prefix="/auth", tags=["auth"])
_settings = get_settings()


def _ensure_dummy_users(db: Session) -> None:
    """Idempotently create the two dummy accounts on first login."""
    seeds = [
        (
            _settings.env.DUMMY_USER_1_USERNAME,
            _settings.env.DUMMY_USER_1_PASSWORD,
            _settings.env.DUMMY_USER_1_EMAIL,
        ),
        (
            _settings.env.DUMMY_USER_2_USERNAME,
            _settings.env.DUMMY_USER_2_PASSWORD,
            _settings.env.DUMMY_USER_2_EMAIL,
        ),
    ]
    for username, pw, email in seeds:
        if not db.query(User).filter(User.username == username).first():
            db.add(
                User(
                    username=username,
                    email=email,
                    hashed_password=hash_password(pw),
                    is_sso=False,
                    is_active=True,
                )
            )
    db.commit()


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, db: Session = Depends(get_db)) -> TokenResponse:
    if _settings.env.SSO_ENABLED:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "SSO is enabled — use /auth/sso/start instead",
        )
    _ensure_dummy_users(db)
    user = db.query(User).filter(User.username == payload.username).first()
    if not user or not payload.password or not verify_password(payload.password, user.hashed_password or ""):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Bad credentials")
    user.last_login_at = datetime.utcnow()
    db.commit()
    metrics_service.record(
        db,
        user_id=user.id,
        username=user.username,
        project_key=None,
        event_type="login_dummy",
    )
    return TokenResponse(
        access_token=mint_jwt(user.username, {"is_sso": False}),
        username=user.username,
        email=user.email,
    )


@router.get("/sso/start")
def sso_start() -> dict:
    """Stub — in prod, redirect to the IdP authorize URL."""
    if not _settings.env.SSO_ENABLED:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "SSO disabled — use /auth/login")
    return {
        "redirect_to": (
            f"{_settings.env.SSO_PROVIDER_URL}/authorize"
            f"?client_id={_settings.env.SSO_CLIENT_ID}"
            f"&response_type=code"
        )
    }


@router.post("/sso/callback", response_model=TokenResponse)
def sso_callback(code: str, db: Session = Depends(get_db)) -> TokenResponse:
    """
    Stub: in prod, exchange `code` for an IdP token, fetch user info,
    upsert the User row, then mint our JWT.
    """
    if not _settings.env.SSO_ENABLED:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "SSO disabled")
    # Pretend the IdP returned this user
    username = "sso_user_demo"
    email = "demo@sso.example.com"
    user = db.query(User).filter(User.username == username).first()
    if not user:
        user = User(username=username, email=email, is_sso=True)
        db.add(user)
        db.commit()
        db.refresh(user)
    user.last_login_at = datetime.utcnow()
    db.commit()
    metrics_service.record(
        db, user_id=user.id, username=username, project_key=None, event_type="sso_login"
    )
    return TokenResponse(
        access_token=mint_jwt(username, {"is_sso": True}),
        username=username,
        email=email,
    )


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)) -> User:
    return user
