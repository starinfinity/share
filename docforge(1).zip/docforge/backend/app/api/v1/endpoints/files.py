"""File download endpoint — scoped to indexed-doc paths and project artifacts."""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse

from app.api.deps import get_current_user
from app.core.config import get_settings
from app.models import User

router = APIRouter(prefix="/files", tags=["files"])
_settings = get_settings()


def _is_allowed(path: Path) -> bool:
    """Only allow downloads from known roots — prevents arbitrary disk reads."""
    allowed_roots = [
        _settings.env.resolve(_settings.env.PROJECTS_DIR),
        _settings.env.resolve(_settings.env.FAISS_INDEX_DIR),
        Path(_settings.doc_source.get("faiss", {}).get("nas_mount", "/mnt/nas/tech-docs")),
    ]
    try:
        resolved = path.resolve()
    except Exception:
        return False
    return any(str(resolved).startswith(str(r.resolve())) for r in allowed_roots)


@router.get("/download")
def download(path: str, _user: User = Depends(get_current_user)):
    p = Path(path)
    if not p.exists() or not p.is_file():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "File not found")
    if not _is_allowed(p):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Path outside allowed roots")
    return FileResponse(p, filename=p.name)
