"""
GitHub token integration.

The token gates everything: project creation and edits are blocked unless
the user has a valid token. Validation hits /user with the token and records
the result + token expiry on each check.
"""
from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.core.security import decrypt_token, encrypt_token
from app.db import get_db
from app.models import GithubToken, User
from app.schemas import GithubTokenIn, GithubTokenStatus
from app.services import github_service, metrics_service

router = APIRouter(prefix="/github-token", tags=["github-token"])


def _get_or_404(db: Session, user: User) -> GithubToken:
    row = db.query(GithubToken).filter(GithubToken.user_id == user.id).first()
    if not row:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "No GitHub token on file")
    return row


def require_valid_token(db: Session, user: User) -> str:
    """Helper for other routers: return plaintext token or 400."""
    row = db.query(GithubToken).filter(GithubToken.user_id == user.id).first()
    if not row or row.last_validation_status != "ok":
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "A validated GitHub token is required for this action",
        )
    return decrypt_token(row.encrypted_token)


@router.post("", response_model=GithubTokenStatus)
def set_token(
    payload: GithubTokenIn,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> GithubTokenStatus:
    validation = github_service.validate_token(payload.token)
    if not validation["ok"]:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, f"Token rejected by GitHub: {validation['error']}"
        )

    row = db.query(GithubToken).filter(GithubToken.user_id == user.id).first()
    enc = encrypt_token(payload.token)
    now = datetime.utcnow()
    if row:
        row.encrypted_token = enc
        row.last_validated_at = now
        row.last_validation_status = "ok"
        row.expires_at = validation.get("expires_at")
    else:
        row = GithubToken(
            user_id=user.id,
            encrypted_token=enc,
            last_validated_at=now,
            last_validation_status="ok",
            expires_at=validation.get("expires_at"),
        )
        db.add(row)
    db.commit()
    metrics_service.record(
        db, user_id=user.id, username=user.username, project_key=None,
        event_type="github_token_set",
    )
    return GithubTokenStatus(
        present=True,
        last_validation_status="ok",
        last_validated_at=now,
        expires_at=validation.get("expires_at"),
    )


@router.post("/validate", response_model=GithubTokenStatus)
def revalidate(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> GithubTokenStatus:
    row = _get_or_404(db, user)
    plain = decrypt_token(row.encrypted_token)
    validation = github_service.validate_token(plain)
    row.last_validated_at = datetime.utcnow()
    if validation["ok"]:
        row.last_validation_status = "ok"
        row.expires_at = validation.get("expires_at")
    else:
        row.last_validation_status = "invalid"
    db.commit()
    return GithubTokenStatus(
        present=True,
        last_validation_status=row.last_validation_status,
        last_validated_at=row.last_validated_at,
        expires_at=row.expires_at,
    )


@router.get("/status", response_model=GithubTokenStatus)
def status_(
    db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> GithubTokenStatus:
    row = db.query(GithubToken).filter(GithubToken.user_id == user.id).first()
    if not row:
        return GithubTokenStatus(present=False)
    return GithubTokenStatus(
        present=True,
        last_validation_status=row.last_validation_status,
        last_validated_at=row.last_validated_at,
        expires_at=row.expires_at,
    )


@router.delete("", status_code=204)
def delete_token(
    db: Session = Depends(get_db), user: User = Depends(get_current_user)
) -> None:
    row = _get_or_404(db, user)
    db.delete(row)
    db.commit()
    metrics_service.record(
        db, user_id=user.id, username=user.username, project_key=None,
        event_type="github_token_deleted",
    )
