"""
Side features:
  • /templates                — list config-driven templates for "new project"
  • /faq                      — static FAQ entries
  • /how-it-works             — architecture + video URL
  • /doc-editor/create        — create-new-document flow
  • /doc-editor/edit          — edit-existing flow
  • /tech-spec-bot/ask        — FAISS-backed Q&A; offers doc download links
  • /metrics/summary          — admin-ish rollup
"""
from __future__ import annotations

import shutil
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.core.config import get_settings
from app.db import get_db
from app.models import MetricEvent, Project, User
from app.services import project_service
from app.services.document_parser import extract_text
from app.services.faiss_service import get_faiss
from app.services.llm_client import get_llm

_settings = get_settings()
router = APIRouter(tags=["misc"])


# -------- templates --------
@router.get("/templates")
def list_templates(_: User = Depends(get_current_user)) -> dict:
    return {"templates": _settings.templates}


# -------- FAQ --------
@router.get("/faq")
def faq() -> dict:
    return {
        "entries": [
            {
                "q": "What is DocForge?",
                "a": "A 6-stage assistant that turns requirements into code + documentation pull requests.",
            },
            {
                "q": "Do I need a GitHub token?",
                "a": "Yes. Project creation and edits require a validated token, stored encrypted at rest.",
            },
            {
                "q": "Where are my project files?",
                "a": "Each user gets a folder; each project a subfolder with metadata.json as source of truth.",
            },
            {
                "q": "Can I work without an existing repo?",
                "a": "Yes — pick 'Create new project' and choose a template. Stage 3 is skipped.",
            },
        ]
    }


@router.get("/how-it-works")
def how_it_works() -> dict:
    return {
        "architecture_image_url": "/static/architecture.png",
        "video_url": "/static/howitworks.mp4",
        "summary": (
            "DocForge orchestrates 6 stages: extract requirements, connect repo, "
            "select supporting docs, plan tasks, update docs, update code & open PR."
        ),
    }


# -------- document editor --------
@router.post("/doc-editor/create")
async def doc_editor_create(
    title: str = Form(...),
    inline_text: str | None = Form(default=None),
    repo_url: str | None = Form(default=None),
    files: list[UploadFile] = File(default=[]),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Spawns a project of type 'doc_editor' and generates a new doc."""
    proj = project_service.create_project(
        db, user, name=f"DocEditor: {title}", project_type="doc_editor"
    )
    base = project_service.project_dir(user.username, proj.project_key)
    uploads = base / "uploads"
    uploads.mkdir(parents=True, exist_ok=True)

    pieces: list[str] = []
    if inline_text:
        pieces.append(inline_text)
    for f in files:
        dest = uploads / f.filename
        with dest.open("wb") as fh:
            shutil.copyfileobj(f.file, fh)
        try:
            pieces.append(extract_text(dest))
        except Exception:
            pass

    system = (
        "You are writing a fresh technical document from the provided inputs. "
        "Produce clean Markdown."
    )
    user_prompt = f"TITLE: {title}\n\nINPUTS:\n\n" + "\n\n---\n\n".join(pieces)
    md = get_llm().complete(system, user_prompt, max_tokens=3000)
    out = base / "artifacts" / "document.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(md, encoding="utf-8")
    return {"project_key": proj.project_key, "doc_path": str(out), "markdown": md}


@router.post("/doc-editor/edit")
async def doc_editor_edit(
    project_key: str = Form(...),
    instruction: str = Form(...),
    files: list[UploadFile] = File(default=[]),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    proj = project_service.get_project(db, user, project_key)
    if not proj:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found")
    base = project_service.project_dir(user.username, project_key)
    doc = base / "artifacts" / "document.md"
    if not doc.exists():
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No existing document to edit")
    current = doc.read_text(encoding="utf-8")

    extras: list[str] = []
    if files:
        ud = base / "uploads"
        ud.mkdir(parents=True, exist_ok=True)
        for f in files:
            dest = ud / f.filename
            with dest.open("wb") as fh:
                shutil.copyfileobj(f.file, fh)
            try:
                extras.append(extract_text(dest))
            except Exception:
                pass

    system = "You are revising a Markdown document per the instruction. Return only the revised Markdown."
    user_prompt = (
        "CURRENT:\n" + current + "\n\nINSTRUCTION:\n" + instruction +
        ("\n\nEXTRA INPUTS:\n" + "\n\n".join(extras) if extras else "")
    )
    revised = get_llm().complete(system, user_prompt, max_tokens=4000)
    doc.write_text(revised, encoding="utf-8")
    return {"doc_path": str(doc), "markdown": revised}


# -------- tech spec bot --------
@router.post("/tech-spec-bot/ask")
def techspec_ask(
    question: str = Form(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    # Ensure a single tech-spec-bot project exists per user
    proj = (
        db.query(Project)
        .filter(Project.user_id == user.id, Project.project_type == "techspecbot")
        .first()
    )
    if not proj:
        proj = project_service.create_project(
            db, user, name="Tech Spec Bot", project_type="techspecbot"
        )

    hits = get_faiss().search(question, top_k=4)
    citations = [
        {"title": h.title, "path": h.path, "score": h.score, "snippet": h.snippet}
        for h in hits
    ]
    context_blob = "\n\n".join(
        f"# {h.title}\n{Path(h.path).read_text(encoding='utf-8', errors='replace')[:4000]}"
        for h in hits if Path(h.path).exists()
    )
    system = (
        "You are a tech-spec assistant. Answer the user's question using the "
        "provided context. If context is empty or insufficient, say so. Be concise."
    )
    answer = get_llm().complete(
        system,
        f"CONTEXT:\n{context_blob}\n\nQUESTION:\n{question}",
        max_tokens=1200,
    )
    return {
        "answer": answer,
        "citations": citations,
        "downloads": [
            {"title": c["title"], "url": f"/api/v1/files/download?path={c['path']}"}
            for c in citations
        ],
    }


# -------- metrics --------
@router.get("/metrics/summary")
def metrics_summary(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> dict:
    sso_logins = (
        db.query(func.count(MetricEvent.id))
        .filter(MetricEvent.event_type == "sso_login")
        .scalar()
    )
    by_user = (
        db.query(User.username, func.count(MetricEvent.id))
        .join(MetricEvent, MetricEvent.user_id == User.id)
        .group_by(User.username)
        .all()
    )
    return {
        "sso_login_count": int(sso_logins or 0),
        "events_per_user": {u: int(c) for u, c in by_user},
    }
