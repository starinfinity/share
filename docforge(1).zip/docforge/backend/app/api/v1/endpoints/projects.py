"""Projects router — create, list, fetch metadata."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.api.v1.endpoints.github_token import require_valid_token
from app.db import get_db
from app.models import User
from app.schemas import ProjectCreate, ProjectOut
from app.services import project_service

router = APIRouter(prefix="/projects", tags=["projects"])


@router.post("", response_model=ProjectOut)
def create(
    payload: ProjectCreate,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> ProjectOut:
    # Gate: must have a valid GitHub token before creating any project
    require_valid_token(db, user)

    if payload.project_type == "new_project" and not payload.template_id:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST, "template_id is required for new_project"
        )

    proj = project_service.create_project(
        db, user, name=payload.name, project_type=payload.project_type,
        template_id=payload.template_id,
    )
    return proj


@router.get("", response_model=list[ProjectOut])
def list_(
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> list[ProjectOut]:
    return project_service.list_projects(db, user)


@router.get("/{project_key}", response_model=ProjectOut)
def get_one(
    project_key: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> ProjectOut:
    proj = project_service.get_project(db, user, project_key)
    if not proj:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found")
    return proj


@router.get("/{project_key}/metadata")
def get_metadata(
    project_key: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
) -> dict:
    proj = project_service.get_project(db, user, project_key)
    if not proj:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found")
    return project_service.read_metadata(user.username, project_key)
