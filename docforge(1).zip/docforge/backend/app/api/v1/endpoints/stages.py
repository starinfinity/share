"""
Stage endpoints — each one corresponds to a button click on the frontend.

Path layout:
  POST /stages/{key}/1/upload          → run Stage 1
  GET  /stages/{key}/2/candidates      → search github_metadata
  POST /stages/{key}/2/connect         → clone repo + count files
  GET  /stages/{key}/3/auto            → README or FAISS top-K
  POST /stages/{key}/3/search          → free-text NAS search
  POST /stages/{key}/3/finalize        → commit selected/uploaded docs
  POST /stages/{key}/4/split           → propose achievable/unachievable
  POST /stages/{key}/4/plan            → build detailed plan
  POST /stages/{key}/5/apply           → update docs
  POST /stages/{key}/5/chat            → refine a doc
  POST /stages/{key}/6/apply           → produce + commit code edits
  POST /stages/{key}/6/pr              → push branch + open PR
  POST /stages/{key}/6/chat            → follow-up edits + force-push
  POST /stages/{key}/advance           → mark current stage complete, move forward
"""
from __future__ import annotations

import shutil
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.api.v1.endpoints.github_token import require_valid_token
from app.db import get_db
from app.models import User
from app.schemas import (
    ChatRequest,
    DocSelection,
    PlanRequest,
    PullRequestResult,
    RepoSelect,
)
from app.services import project_service
from app.stages import stage1, stage2, stage3, stage4, stage5, stage6

router = APIRouter(prefix="/stages", tags=["stages"])


def _require_project(db: Session, user: User, key: str):
    proj = project_service.get_project(db, user, key)
    if not proj:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Project not found")
    return proj


# ----------------------------- Stage 1 -----------------------------
@router.post("/{project_key}/1/upload")
async def stage1_upload(
    project_key: str,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    upload_dir = project_service.project_dir(user.username, project_key) / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    dest = upload_dir / file.filename
    with dest.open("wb") as fh:
        shutil.copyfileobj(file.file, fh)
    try:
        return stage1.run(user.username, project_key, dest)
    except Exception as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))


# ----------------------------- Stage 2 -----------------------------
@router.get("/{project_key}/2/candidates")
def stage2_candidates(
    project_key: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    return {"candidates": stage2.find_repo_candidates(user.username, project_key)}


@router.get("/{project_key}/2/search")
def stage2_search(
    project_key: str,
    q: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    from app.services.github_service import search_metadata

    _require_project(db, user, project_key)
    return {"candidates": search_metadata(q, stage2.load_catalog())}


@router.post("/{project_key}/2/connect")
def stage2_connect(
    project_key: str,
    payload: RepoSelect,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    token = require_valid_token(db, user)
    try:
        analysis = stage2.connect_repo(user.username, project_key, payload.url, token)
    except Exception as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))
    return analysis


# ----------------------------- Stage 3 -----------------------------
@router.get("/{project_key}/3/auto")
def stage3_auto(
    project_key: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    meta = project_service.read_metadata(user.username, project_key)
    cloned = meta["stages"].get("2", {}).get("cloned_path")
    if cloned:
        repo_name = Path(cloned).name
        if stage3.should_use_readme(repo_name):
            readme = stage3.take_readme(user.username, project_key, Path(cloned))
            if readme:
                return {"mode": "readme", "doc_path": str(readme)}
    return {"mode": "faiss", "hits": stage3.search_docs(user.username, project_key)}


@router.post("/{project_key}/3/search")
def stage3_search(
    project_key: str,
    q: str = Form(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    return {"hits": stage3.free_text_search(q)}


@router.post("/{project_key}/3/upload")
async def stage3_upload(
    project_key: str,
    files: list[UploadFile] = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    upload_dir = project_service.project_dir(user.username, project_key) / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    saved: list[str] = []
    for f in files:
        dest = upload_dir / f.filename
        with dest.open("wb") as fh:
            shutil.copyfileobj(f.file, fh)
        saved.append(str(dest))
    return {"uploaded": saved}


@router.post("/{project_key}/3/finalize")
def stage3_finalize(
    project_key: str,
    payload: DocSelection,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    upload_dir = project_service.project_dir(user.username, project_key) / "uploads"
    uploaded_paths = [upload_dir / n for n in payload.uploaded_filenames]

    # Convert FAISS doc_ids back into paths via metadata index
    from app.services.faiss_service import get_faiss

    store = get_faiss()
    store._ensure_index()  # noqa: SLF001 — internal access acceptable in scaffold
    id_to_path = {m["doc_id"]: m["path"] for m in store._meta}  # noqa: SLF001
    selected_paths = [id_to_path[d] for d in payload.selected_doc_ids if d in id_to_path]

    return stage3.finalize_selection(
        user.username, project_key, selected_paths, uploaded_paths
    )


# ----------------------------- Stage 4 -----------------------------
@router.post("/{project_key}/4/split")
def stage4_split(
    project_key: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    return stage4.split_tasks(user.username, project_key)


@router.post("/{project_key}/4/plan")
def stage4_plan(
    project_key: str,
    payload: PlanRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    return stage4.build_plan(
        user.username,
        project_key,
        [t.model_dump() for t in payload.achievable],
        payload.special_request,
    )


# ----------------------------- Stage 5 -----------------------------
@router.post("/{project_key}/5/apply")
def stage5_apply(
    project_key: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    try:
        paths = stage5.apply_plan(user.username, project_key)
    except FileNotFoundError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))
    return {"updated_doc_paths": paths}


@router.post("/{project_key}/5/chat")
def stage5_chat(
    project_key: str,
    doc_path: str,
    payload: ChatRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    user_msg = payload.messages[-1].content if payload.messages else ""
    revised = stage5.chat(user.username, project_key, doc_path, user_msg)
    return {"reply": revised, "updated_artifact_path": doc_path}


# ----------------------------- Stage 6 -----------------------------
@router.post("/{project_key}/6/apply")
def stage6_apply(
    project_key: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    try:
        applied = stage6.apply_plan_to_code(user.username, project_key)
    except FileNotFoundError as exc:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(exc))
    return {"edits": applied}


@router.post("/{project_key}/6/pr", response_model=PullRequestResult)
def stage6_pr(
    project_key: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    token = require_valid_token(db, user)
    return stage6.open_pr(user.username, project_key, token)


@router.post("/{project_key}/6/chat")
def stage6_chat(
    project_key: str,
    payload: ChatRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    token = require_valid_token(db, user)
    user_msg = payload.messages[-1].content if payload.messages else ""
    return stage6.chat(user.username, project_key, user_msg, token)


# ----------------------------- Advance -----------------------------
@router.post("/{project_key}/{stage}/advance")
def advance(
    project_key: str,
    stage: int,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    _require_project(db, user, project_key)
    project_service.advance_stage(db, user, project_key, stage)
    return {"ok": True}
