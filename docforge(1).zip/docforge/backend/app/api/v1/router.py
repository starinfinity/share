"""Aggregate all v1 routers under /api/v1."""
from fastapi import APIRouter

from app.api.v1.endpoints import auth, files, github_token, misc, projects, stages

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(auth.router)
api_router.include_router(github_token.router)
api_router.include_router(projects.router)
api_router.include_router(stages.router)
api_router.include_router(files.router)
api_router.include_router(misc.router)
