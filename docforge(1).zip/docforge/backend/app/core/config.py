"""
Application settings.

Two sources, merged at import time:
  • .env  — secrets, infrastructure endpoints (env-specific)
  • config/config.yaml — feature knobs (languages, prefixes, templates)

Anything secret goes in .env; anything an ops person might want to tune
without a code change goes in YAML.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_ROOT = Path(__file__).resolve().parents[2]
CONFIG_YAML_PATH = BACKEND_ROOT / "config" / "config.yaml"


class EnvSettings(BaseSettings):
    """Values pulled from .env / process environment."""

    model_config = SettingsConfigDict(
        env_file=BACKEND_ROOT / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # App
    APP_NAME: str = "DocForge"
    APP_ENV: str = "dev"
    SECRET_KEY: str = "dev-secret-change-me"
    LOG_LEVEL: str = "INFO"

    # MySQL
    MYSQL_HOST: str = "localhost"
    MYSQL_PORT: int = 3306
    MYSQL_USER: str = "docforge"
    MYSQL_PASSWORD: str = "docforge"
    MYSQL_DB: str = "docforge"

    # SSO
    SSO_ENABLED: bool = False
    SSO_PROVIDER_URL: str = ""
    SSO_CLIENT_ID: str = ""
    SSO_CLIENT_SECRET: str = ""

    DUMMY_USER_1_USERNAME: str = "alice"
    DUMMY_USER_1_PASSWORD: str = "alice123"
    DUMMY_USER_1_EMAIL: str = "alice@example.com"
    DUMMY_USER_2_USERNAME: str = "bob"
    DUMMY_USER_2_PASSWORD: str = "bob123"
    DUMMY_USER_2_EMAIL: str = "bob@example.com"

    # LLM
    ANTHROPIC_API_KEY: str = ""
    LLM_MODEL: str = "claude-opus-4-7"

    # GitHub
    GITHUB_TOKEN_ENC_KEY: str = ""

    # Paths (resolved against BACKEND_ROOT)
    PROJECTS_DIR: str = "./projects"
    UPLOADS_DIR: str = "./storage/uploads"
    TEMPLATES_DIR: str = "./storage/templates"
    FAISS_INDEX_DIR: str = "./faiss_index"

    # CORS
    CORS_ORIGINS: str = "http://localhost:5173"

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def db_url(self) -> str:
        return (
            f"mysql+pymysql://{self.MYSQL_USER}:{self.MYSQL_PASSWORD}"
            f"@{self.MYSQL_HOST}:{self.MYSQL_PORT}/{self.MYSQL_DB}"
        )

    def resolve(self, relative: str) -> Path:
        p = Path(relative)
        return p if p.is_absolute() else (BACKEND_ROOT / p).resolve()


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


class Settings:
    """Composite settings — env values + YAML feature config."""

    def __init__(self) -> None:
        self.env = EnvSettings()
        self.yaml: dict[str, Any] = _load_yaml(CONFIG_YAML_PATH)

    # Convenience accessors for YAML sections
    @property
    def repo_analysis(self) -> dict[str, Any]:
        return self.yaml.get("repo_analysis", {})

    @property
    def doc_source(self) -> dict[str, Any]:
        return self.yaml.get("doc_source", {})

    @property
    def templates(self) -> list[dict[str, Any]]:
        return self.yaml.get("templates", [])

    @property
    def pull_request(self) -> dict[str, Any]:
        return self.yaml.get("pull_request", {})

    @property
    def stage_names(self) -> dict[int, str]:
        return self.yaml.get("stage_names", {})

    @property
    def metrics(self) -> dict[str, Any]:
        return self.yaml.get("metrics", {})


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
