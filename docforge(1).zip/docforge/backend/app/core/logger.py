"""Loguru-backed logger. Single import point."""
from __future__ import annotations

import sys

from loguru import logger as _logger

from app.core.config import get_settings


def _configure() -> None:
    settings = get_settings()
    _logger.remove()
    _logger.add(
        sys.stdout,
        level=settings.env.LOG_LEVEL,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> "
            "<level>{level: <8}</level> "
            "<cyan>{name}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
        ),
    )


_configure()
logger = _logger
