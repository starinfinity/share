"""
Security primitives.

  • JWT mint / verify for session tokens
  • Fernet symmetric encryption for storing GitHub tokens at rest
  • Password hashing (used only for dummy SSO mode)
"""
from __future__ import annotations

import base64
import os
from datetime import datetime, timedelta, timezone
from typing import Any

from cryptography.fernet import Fernet
from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import get_settings
from app.core.logger import logger

_settings = get_settings()
_pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")

JWT_ALG = "HS256"
JWT_TTL_HOURS = 12


# ---------- passwords ----------
def hash_password(plain: str) -> str:
    return _pwd.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    return _pwd.verify(plain, hashed)


# ---------- JWT ----------
def mint_jwt(subject: str, extra: dict[str, Any] | None = None) -> str:
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": subject,
        "iat": now,
        "exp": now + timedelta(hours=JWT_TTL_HOURS),
    }
    if extra:
        payload.update(extra)
    return jwt.encode(payload, _settings.env.SECRET_KEY, algorithm=JWT_ALG)


def decode_jwt(token: str) -> dict[str, Any] | None:
    try:
        return jwt.decode(token, _settings.env.SECRET_KEY, algorithms=[JWT_ALG])
    except JWTError as exc:
        logger.debug(f"JWT decode failed: {exc}")
        return None


# ---------- GitHub token encryption ----------
def _ensure_fernet_key() -> bytes:
    key = _settings.env.GITHUB_TOKEN_ENC_KEY
    if not key:
        # Generate one and warn — in prod this must be persisted
        gen = Fernet.generate_key().decode()
        logger.warning(
            "GITHUB_TOKEN_ENC_KEY missing; generated ephemeral key. "
            "Tokens will be unreadable after restart. Set this in .env."
        )
        os.environ["GITHUB_TOKEN_ENC_KEY"] = gen
        return gen.encode()
    # Accept either a raw urlsafe-b64 Fernet key or arbitrary text (we derive)
    try:
        Fernet(key.encode())
        return key.encode()
    except Exception:
        # Derive a Fernet key by sha256(text) → urlsafe b64
        import hashlib

        derived = base64.urlsafe_b64encode(hashlib.sha256(key.encode()).digest())
        return derived


_fernet = Fernet(_ensure_fernet_key())


def encrypt_token(plaintext: str) -> str:
    return _fernet.encrypt(plaintext.encode()).decode()


def decrypt_token(ciphertext: str) -> str:
    return _fernet.decrypt(ciphertext.encode()).decode()
