"""DocForge FastAPI entrypoint."""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1.router import api_router
from app.core.config import get_settings
from app.core.logger import logger
from app.db import Base, engine
from app.models import GithubToken, MetricEvent, Project, User  # noqa: F401  (register metadata)

_settings = get_settings()
app = FastAPI(
    title=_settings.env.APP_NAME,
    version="0.1.0",
    description="DocForge — 6-stage AI documentation & code-change assistant.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=_settings.env.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup() -> None:
    logger.info(f"Starting {_settings.env.APP_NAME} (env={_settings.env.APP_ENV})")
    # Best-effort schema creation for dev. Use alembic in prod.
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database schema verified")
    except Exception as exc:
        logger.warning(f"Could not create tables (DB may be down): {exc}")


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


app.include_router(api_router)
