"""GitHub token storage — ciphertext at rest, scoped per user."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.db import Base


class GithubToken(Base):
    __tablename__ = "github_tokens"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(
        Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True
    )
    # Fernet ciphertext — never stored or logged in plaintext
    encrypted_token = Column(Text, nullable=False)
    # GitHub-reported expiry (fine-grained tokens have one; classic PATs may not)
    expires_at = Column(DateTime, nullable=True)
    last_validated_at = Column(DateTime, nullable=True)
    last_validation_status = Column(String(32), nullable=True)  # "ok" | "expired" | "invalid"
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    user = relationship("User", backref="github_token", uselist=False)
