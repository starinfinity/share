"""
MySQL index of projects (source of truth lives in each project's metadata.json).

Stored here only to make 'list projects', 'search by key', 'recent activity'
queries cheap — anything richer (stage state, full payloads) lives in the JSON.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from app.db import Base


class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, autoincrement=True)
    project_key = Column(String(64), unique=True, nullable=False, index=True)
    name = Column(String(255), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    # "full" (all 6 stages) | "new_project" (skip stage 3) | "techspecbot" | "doc_editor"
    project_type = Column(String(32), nullable=False, default="full")
    current_stage = Column(Integer, default=1, nullable=False)
    status = Column(String(32), default="in_progress", nullable=False)
    folder_path = Column(String(512), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class MetricEvent(Base):
    """
    Per-event metrics — login, stage entry/exit, dwell time, action counts.
    Aggregated in the metadata.json per-project; also rolled up here for cross-user reporting.
    """

    __tablename__ = "metric_events"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=True)
    project_key = Column(String(64), nullable=True, index=True)
    event_type = Column(String(64), nullable=False)  # e.g. "stage_enter", "stage_exit", "sso_login"
    stage = Column(Integer, nullable=True)
    dwell_ms = Column(Integer, nullable=True)
    payload = Column(Text, nullable=True)  # JSON blob for free-form context
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
