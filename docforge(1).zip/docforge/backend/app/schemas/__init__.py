"""Pydantic schemas — request/response shapes for the API."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, EmailStr, Field


# ---------- auth ----------
class LoginRequest(BaseModel):
    username: str
    password: str | None = None  # only used in dummy-SSO mode


class TokenResponse(BaseModel):
    access_token: str
    token_type: Literal["bearer"] = "bearer"
    username: str
    email: EmailStr


class UserOut(BaseModel):
    id: int
    username: str
    email: EmailStr
    is_sso: bool

    model_config = {"from_attributes": True}


# ---------- github token ----------
class GithubTokenIn(BaseModel):
    token: str = Field(..., min_length=10)


class GithubTokenStatus(BaseModel):
    present: bool
    last_validation_status: str | None = None
    last_validated_at: datetime | None = None
    expires_at: datetime | None = None


# ---------- projects ----------
ProjectType = Literal["full", "new_project", "techspecbot", "doc_editor"]


class ProjectCreate(BaseModel):
    name: str
    project_type: ProjectType = "full"
    template_id: str | None = None  # required when project_type == "new_project"


class ProjectOut(BaseModel):
    project_key: str
    name: str
    project_type: ProjectType
    current_stage: int
    status: str
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


# ---------- stage 1 ----------
class Stage1Result(BaseModel):
    markdown: str
    raw_text_excerpt: str
    source_filename: str


# ---------- stage 2 ----------
class RepoSearchHit(BaseModel):
    name: str
    url: str
    description: str
    topics: list[str]
    score: float


class RepoSelect(BaseModel):
    url: str
    custom: bool = False


class RepoAnalysis(BaseModel):
    supported_file_count: int
    max_files_supported: int
    over_limit: bool
    languages_seen: dict[str, int]
    cloned_path: str


# ---------- stage 3 ----------
class DocSearchHit(BaseModel):
    doc_id: str
    title: str
    path: str
    score: float
    snippet: str


class DocSelection(BaseModel):
    selected_doc_ids: list[str] = []
    uploaded_filenames: list[str] = []


# ---------- stage 4 ----------
class TaskItem(BaseModel):
    id: str
    title: str
    detail: str


class TaskLists(BaseModel):
    achievable: list[TaskItem]
    unachievable: list[TaskItem]


class PlanRequest(BaseModel):
    achievable: list[TaskItem]
    special_request: str | None = None


class DetailedPlan(BaseModel):
    summary: str
    steps: list[dict[str, Any]]


# ---------- stages 5 & 6 ----------
class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    messages: list[ChatMessage]


class ChatResponse(BaseModel):
    reply: str
    updated_artifact_path: str | None = None


class PullRequestResult(BaseModel):
    branch_name: str
    pr_url: str | None = None
    status: Literal["created", "draft", "failed"]
    message: str
