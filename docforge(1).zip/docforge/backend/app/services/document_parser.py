"""
Extract plain text from the formats accepted in Stage 1 / Document Editor.

Supported in this scaffold:
  • .txt              → read directly
  • .docx             → python-docx
  • .pptx             → python-pptx
  • .png/.jpg/.jpeg   → pytesseract (requires tesseract binary on host)
  • .doc / .ppt       → not supported natively in Python; route through libreoffice
                        externally, or upgrade the file. Stub returns a clear error.
"""
from __future__ import annotations

from pathlib import Path

from app.core.logger import logger


class UnsupportedFormat(Exception):
    pass


def extract_text(path: Path) -> str:
    ext = path.suffix.lower()
    if ext == ".txt":
        return path.read_text(encoding="utf-8", errors="replace")
    if ext == ".docx":
        return _from_docx(path)
    if ext == ".pptx":
        return _from_pptx(path)
    if ext in {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff"}:
        return _from_image(path)
    if ext in {".doc", ".ppt"}:
        raise UnsupportedFormat(
            f"{ext} requires LibreOffice conversion — wire that in for production."
        )
    raise UnsupportedFormat(f"Unsupported extension: {ext}")


def _from_docx(path: Path) -> str:
    from docx import Document  # python-docx

    doc = Document(str(path))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            cells = [c.text.strip() for c in row.cells]
            parts.append(" | ".join(cells))
    return "\n".join(parts)


def _from_pptx(path: Path) -> str:
    from pptx import Presentation

    prs = Presentation(str(path))
    parts: list[str] = []
    for i, slide in enumerate(prs.slides, 1):
        parts.append(f"## Slide {i}")
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    text = "".join(run.text for run in para.runs).strip()
                    if text:
                        parts.append(text)
    return "\n".join(parts)


def _from_image(path: Path) -> str:
    try:
        import pytesseract
        from PIL import Image
    except Exception as exc:  # pragma: no cover
        logger.error(f"OCR deps not available: {exc}")
        raise UnsupportedFormat("OCR not available in this environment") from exc
    return pytesseract.image_to_string(Image.open(path))
