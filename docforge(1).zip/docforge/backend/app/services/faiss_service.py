"""
FAISS-backed similarity search over ~2000 NAS technical documents.

Design notes:
  • Flat L2 index is plenty fast at 2k vectors (<10ms search).
  • The index, the doc-id list, and a small metadata JSON live side-by-side
    in FAISS_INDEX_DIR. build_index() rebuilds from a directory of docs.
  • Embeddings are normalized so cosine-equivalent distance is just L2.
  • The model is loaded lazily — first call pays the cost, subsequent
    calls reuse the singleton.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from app.core.config import get_settings
from app.core.logger import logger
from app.services.document_parser import extract_text

_settings = get_settings()


@dataclass
class DocHit:
    doc_id: str
    title: str
    path: str
    score: float
    snippet: str


class FaissStore:
    def __init__(self) -> None:
        self.index_dir = _settings.env.resolve(_settings.env.FAISS_INDEX_DIR)
        self.index_dir.mkdir(parents=True, exist_ok=True)
        self._index = None
        self._meta: list[dict[str, Any]] = []
        self._model = None

    # ---------- lazy loaders ----------
    def _ensure_model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer

            model_name = _settings.doc_source.get("faiss", {}).get(
                "embedding_model", "sentence-transformers/all-MiniLM-L6-v2"
            )
            logger.info(f"Loading embedding model {model_name}")
            self._model = SentenceTransformer(model_name)
        return self._model

    def _ensure_index(self) -> bool:
        if self._index is not None:
            return True
        import faiss

        idx_path = self.index_dir / "index.faiss"
        meta_path = self.index_dir / "meta.json"
        if not idx_path.exists() or not meta_path.exists():
            return False
        self._index = faiss.read_index(str(idx_path))
        self._meta = json.loads(meta_path.read_text(encoding="utf-8"))
        return True

    # ---------- build ----------
    def build_index(self, docs_dir: Path) -> int:
        """
        Walk docs_dir, parse each file, embed, write index + meta.
        Returns number of documents indexed.
        """
        import faiss

        model = self._ensure_model()
        texts: list[str] = []
        meta: list[dict[str, Any]] = []
        for path in sorted(docs_dir.rglob("*")):
            if not path.is_file():
                continue
            try:
                text = extract_text(path)
            except Exception as exc:
                logger.debug(f"Skipping {path}: {exc}")
                continue
            if not text.strip():
                continue
            texts.append(text)
            meta.append(
                {
                    "doc_id": str(len(meta)),
                    "title": path.stem,
                    "path": str(path),
                    "snippet": text[:240].replace("\n", " "),
                }
            )
        if not texts:
            logger.warning(f"No docs found under {docs_dir}; index not built")
            return 0

        emb = model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
        emb = np.asarray(emb, dtype="float32")
        idx = faiss.IndexFlatIP(emb.shape[1])  # inner product on normalized = cosine
        idx.add(emb)
        faiss.write_index(idx, str(self.index_dir / "index.faiss"))
        (self.index_dir / "meta.json").write_text(json.dumps(meta), encoding="utf-8")
        self._index = idx
        self._meta = meta
        logger.info(f"Indexed {len(meta)} docs from {docs_dir}")
        return len(meta)

    # ---------- search ----------
    def search(self, query: str, top_k: int | None = None) -> list[DocHit]:
        if not self._ensure_index():
            logger.info("FAISS index empty — returning no hits")
            return []
        model = self._ensure_model()
        k = top_k or int(_settings.doc_source.get("faiss", {}).get("top_k", 2))
        q_emb = model.encode([query], normalize_embeddings=True)
        q_emb = np.asarray(q_emb, dtype="float32")
        scores, idxs = self._index.search(q_emb, k)
        hits: list[DocHit] = []
        for score, i in zip(scores[0], idxs[0]):
            if i < 0 or i >= len(self._meta):
                continue
            m = self._meta[i]
            hits.append(
                DocHit(
                    doc_id=m["doc_id"],
                    title=m["title"],
                    path=m["path"],
                    score=float(score),
                    snippet=m["snippet"],
                )
            )
        return hits


_singleton: FaissStore | None = None


def get_faiss() -> FaissStore:
    global _singleton
    if _singleton is None:
        _singleton = FaissStore()
    return _singleton
