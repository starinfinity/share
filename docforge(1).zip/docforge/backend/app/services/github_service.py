"""
GitHub helpers.

  • validate_token        — hits /user, returns username + scopes + expiry
  • clone_repo            — PyGithub-resolves the repo, then GitPython clones it
                            into the project folder
  • count_supported_files — walks the cloned tree, applies skip_dirs and
                            supported_languages from config
"""
from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

from github import Auth, Github, GithubException

from app.core.config import get_settings
from app.core.logger import logger

_settings = get_settings()


def validate_token(token: str) -> dict[str, Any]:
    """
    Returns dict with keys: ok (bool), username, scopes, expires_at (datetime|None), error.
    Does not raise — packages errors into the result so the API layer can format.
    """
    try:
        gh = Github(auth=Auth.Token(token))
        user = gh.get_user()
        login = user.login  # forces request
        # PyGithub exposes scopes via last response headers
        headers = gh._Github__requester.last_response_headers if hasattr(gh, "_Github__requester") else {}
        scopes_hdr = (headers or {}).get("x-oauth-scopes", "")
        expires_hdr = (headers or {}).get("github-authentication-token-expiration", "")
        expires_at: datetime | None = None
        if expires_hdr:
            try:
                # Format example: '2026-08-01 12:34:56 UTC'
                expires_at = datetime.strptime(expires_hdr.split(" UTC")[0], "%Y-%m-%d %H:%M:%S")
            except Exception:
                expires_at = None
        return {
            "ok": True,
            "username": login,
            "scopes": [s.strip() for s in scopes_hdr.split(",") if s.strip()],
            "expires_at": expires_at,
            "error": None,
        }
    except GithubException as exc:
        return {"ok": False, "error": f"GitHub error {exc.status}: {exc.data}"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def search_metadata(query: str, catalog: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """
    Very simple keyword search against the github_metadata.json catalog.
    Production would use BM25 or embeddings.
    """
    q = query.lower()
    scored: list[tuple[float, dict[str, Any]]] = []
    for repo in catalog:
        haystack = " ".join(
            [
                repo.get("name", ""),
                repo.get("description", ""),
                " ".join(repo.get("topics", [])),
            ]
        ).lower()
        # Score = sum of token hits, biased by name match
        tokens = [t for t in q.split() if t]
        if not tokens:
            continue
        score = sum(haystack.count(tok) for tok in tokens)
        if repo.get("name", "").lower() in q:
            score += 5
        if score > 0:
            scored.append((float(score), repo))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [
        {**repo, "score": score / max(1, len(q.split()))} for score, repo in scored[:5]
    ]


def clone_repo(token: str, repo_url: str, dest_dir: Path) -> Path:
    """
    Clone repo into dest_dir/<repo_name>. Resolves owner/name via PyGithub first
    so we fail fast on bad URLs and surface the API error rather than a git stderr.
    """
    from git import Repo

    owner, name = _parse_repo_url(repo_url)
    gh = Github(auth=Auth.Token(token))
    repo_obj = gh.get_repo(f"{owner}/{name}")  # raises if missing/no-access
    clone_path = dest_dir / name
    if clone_path.exists():
        logger.info(f"Repo already cloned at {clone_path}; removing and re-cloning")
        shutil.rmtree(clone_path)

    # Embed token in HTTPS URL so the clone is authenticated
    auth_url = f"https://x-access-token:{token}@github.com/{owner}/{name}.git"
    Repo.clone_from(auth_url, str(clone_path), depth=1)
    logger.info(f"Cloned {owner}/{name} → {clone_path}")
    # Stamp default branch onto the path's git config for later push (Stage 6)
    return clone_path


def _parse_repo_url(url: str) -> tuple[str, str]:
    cleaned = url.rstrip("/").removesuffix(".git")
    if "github.com" not in cleaned:
        raise ValueError(f"Not a GitHub URL: {url}")
    parts = cleaned.split("github.com/", 1)[1].split("/")
    if len(parts) < 2:
        raise ValueError(f"Malformed GitHub URL: {url}")
    return parts[0], parts[1]


def count_supported_files(repo_path: Path) -> dict[str, Any]:
    """Walk repo and count files matching configured supported_languages."""
    cfg = _settings.repo_analysis
    exts = set(cfg.get("supported_languages", []))
    skip_dirs = set(cfg.get("skip_dirs", []))
    max_files = int(cfg.get("max_files_supported", 1500))

    languages_seen: dict[str, int] = {}
    total = 0
    for path in repo_path.rglob("*"):
        if not path.is_file():
            continue
        # Skip any path that contains a skip_dir component
        if any(part in skip_dirs for part in path.parts):
            continue
        suf = path.suffix.lower()
        if suf in exts:
            languages_seen[suf] = languages_seen.get(suf, 0) + 1
            total += 1

    return {
        "supported_file_count": total,
        "max_files_supported": max_files,
        "over_limit": total > max_files,
        "languages_seen": languages_seen,
        "cloned_path": str(repo_path),
    }
