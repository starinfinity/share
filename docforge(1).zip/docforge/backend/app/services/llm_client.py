"""
LLM client.

If ANTHROPIC_API_KEY is configured, calls the real API. Otherwise returns
a deterministic stub so the rest of the app can run end-to-end in dev.
"""
from __future__ import annotations

from typing import Any

from app.core.config import get_settings
from app.core.logger import logger

_settings = get_settings()


class LLMClient:
    def __init__(self) -> None:
        self.api_key = _settings.env.ANTHROPIC_API_KEY
        self.model = _settings.env.LLM_MODEL
        self._client: Any | None = None
        if self.api_key:
            try:
                import anthropic

                self._client = anthropic.Anthropic(api_key=self.api_key)
            except Exception as exc:
                logger.warning(f"Anthropic SDK init failed; falling back to stub: {exc}")

    def complete(self, system: str, user: str, max_tokens: int = 2000) -> str:
        if not self._client:
            return self._stub(system, user)
        try:
            resp = self._client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
            )
            # The SDK returns a list of content blocks; concatenate text blocks
            return "".join(
                block.text for block in resp.content if getattr(block, "type", "") == "text"
            )
        except Exception as exc:
            logger.error(f"LLM call failed: {exc}")
            return self._stub(system, user)

    @staticmethod
    def _stub(system: str, user: str) -> str:
        # Deterministic placeholder so downstream code can keep flowing in dev
        head = user.strip().splitlines()[0] if user.strip() else "(empty)"
        return (
            "[stub-llm] System role: "
            + system.strip().splitlines()[0]
            + "\nFirst user line: "
            + head
        )


_singleton: LLMClient | None = None


def get_llm() -> LLMClient:
    global _singleton
    if _singleton is None:
        _singleton = LLMClient()
    return _singleton
