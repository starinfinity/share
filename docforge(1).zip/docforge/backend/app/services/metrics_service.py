"""Metrics recorder. Writes to MySQL and to the project's metadata.json."""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.models import MetricEvent
from app.services import project_service

_settings = get_settings()


def record(
    db: Session,
    *,
    user_id: int | None,
    username: str | None,
    project_key: str | None,
    event_type: str,
    stage: int | None = None,
    dwell_ms: int | None = None,
    payload: dict[str, Any] | None = None,
) -> None:
    if not _settings.metrics.get("enabled", True):
        return

    row = MetricEvent(
        user_id=user_id,
        project_key=project_key,
        event_type=event_type,
        stage=stage,
        dwell_ms=dwell_ms,
        payload=json.dumps(payload) if payload else None,
    )
    db.add(row)
    db.commit()

    # Mirror into the project metadata if we have one
    if project_key and username:
        try:
            meta = project_service.read_metadata(username, project_key)
            meta.setdefault("metrics", {}).setdefault("events", []).append(
                {
                    "ts": datetime.utcnow().isoformat(),
                    "type": event_type,
                    "stage": stage,
                    "dwell_ms": dwell_ms,
                    "payload": payload or {},
                }
            )
            if stage and dwell_ms:
                bucket = meta["metrics"].setdefault("stage_dwell_ms", {})
                bucket[str(stage)] = bucket.get(str(stage), 0) + dwell_ms
            project_service.write_metadata(username, project_key, meta)
        except FileNotFoundError:
            # No project yet — fine, MySQL row is sufficient
            pass
