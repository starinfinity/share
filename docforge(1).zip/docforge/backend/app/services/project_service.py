"""
Project lifecycle.

  • Each project lives in   projects/<username>/<project_key>/
  • Source of truth is      projects/<username>/<project_key>/metadata.json
  • A row in `projects` MySQL table mirrors a tiny subset for indexed queries.

The metadata.json schema is intentionally permissive — it grows per stage
without migrations.
"""
from __future__ import annotations

import json
import secrets
import string
from datetime import datetime
from pathlib import Path
from typing import Any

from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.logger import logger
from app.models import Project, User

_settings = get_settings()


def _generate_key() -> str:
    alphabet = string.ascii_uppercase + string.digits
    # 10 chars ≈ 60 bits, plenty for project keys
    return "DF-" + "".join(secrets.choice(alphabet) for _ in range(10))


def _projects_root() -> Path:
    root = _settings.env.resolve(_settings.env.PROJECTS_DIR)
    root.mkdir(parents=True, exist_ok=True)
    return root


def user_dir(username: str) -> Path:
    d = _projects_root() / username
    d.mkdir(parents=True, exist_ok=True)
    return d


def project_dir(username: str, project_key: str) -> Path:
    return user_dir(username) / project_key


def metadata_path(username: str, project_key: str) -> Path:
    return project_dir(username, project_key) / "metadata.json"


def read_metadata(username: str, project_key: str) -> dict[str, Any]:
    p = metadata_path(username, project_key)
    if not p.exists():
        raise FileNotFoundError(f"No metadata for project {project_key}")
    return json.loads(p.read_text(encoding="utf-8"))


def write_metadata(username: str, project_key: str, data: dict[str, Any]) -> None:
    p = metadata_path(username, project_key)
    p.parent.mkdir(parents=True, exist_ok=True)
    data["updated_at"] = datetime.utcnow().isoformat()
    p.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")


def update_metadata(username: str, project_key: str, patch: dict[str, Any]) -> dict[str, Any]:
    data = read_metadata(username, project_key)
    # Shallow merge — callers pass nested dicts where needed
    for k, v in patch.items():
        data[k] = v
    write_metadata(username, project_key, data)
    return data


def create_project(
    db: Session,
    user: User,
    name: str,
    project_type: str = "full",
    template_id: str | None = None,
) -> Project:
    key = _generate_key()
    folder = project_dir(user.username, key)
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "uploads").mkdir(exist_ok=True)
    (folder / "repo").mkdir(exist_ok=True)
    (folder / "docs").mkdir(exist_ok=True)
    (folder / "artifacts").mkdir(exist_ok=True)

    metadata = {
        "project_key": key,
        "name": name,
        "owner": user.username,
        "project_type": project_type,
        "template_id": template_id,
        "current_stage": 1,
        "status": "in_progress",
        "created_at": datetime.utcnow().isoformat(),
        "stages": {
            # Filled in as each stage completes
            "1": {"status": "pending"},
            "2": {"status": "pending"},
            "3": {"status": "pending"},
            "4": {"status": "pending"},
            "5": {"status": "pending"},
            "6": {"status": "pending"},
        },
        "user_inputs": [],
        "metrics": {"stage_dwell_ms": {}, "events": []},
    }
    # new_project skips stage 3
    if project_type == "new_project":
        metadata["stages"]["3"] = {"status": "skipped"}

    write_metadata(user.username, key, metadata)

    row = Project(
        project_key=key,
        name=name,
        user_id=user.id,
        project_type=project_type,
        current_stage=1,
        status="in_progress",
        folder_path=str(folder),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    logger.info(f"Created project {key} for user {user.username} (type={project_type})")
    return row


def list_projects(db: Session, user: User) -> list[Project]:
    return (
        db.query(Project)
        .filter(Project.user_id == user.id)
        .order_by(Project.updated_at.desc())
        .all()
    )


def get_project(db: Session, user: User, project_key: str) -> Project | None:
    return (
        db.query(Project)
        .filter(Project.user_id == user.id, Project.project_key == project_key)
        .first()
    )


def advance_stage(db: Session, user: User, project_key: str, stage: int) -> None:
    """Mark a stage complete and bump current_stage forward."""
    proj = get_project(db, user, project_key)
    if not proj:
        raise ValueError(f"Project {project_key} not found")
    meta = read_metadata(user.username, project_key)
    meta["stages"][str(stage)]["status"] = "complete"
    meta["stages"][str(stage)]["completed_at"] = datetime.utcnow().isoformat()
    next_stage = stage + 1
    # new_project skips stage 3
    if meta["project_type"] == "new_project" and next_stage == 3:
        next_stage = 4
    meta["current_stage"] = next_stage
    write_metadata(user.username, project_key, meta)
    proj.current_stage = next_stage
    db.commit()
