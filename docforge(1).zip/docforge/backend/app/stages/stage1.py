"""
Stage 1 — Requirement Extraction

Input:  uploaded ppt/pptx/doc/docx/txt/image
Output: a markdown summary of the requirements, saved to
        projects/<user>/<key>/artifacts/stage1_requirements.md
"""
from __future__ import annotations

from pathlib import Path

from app.core.logger import logger
from app.services import project_service
from app.services.document_parser import extract_text
from app.services.llm_client import get_llm

SYSTEM = (
    "You are a senior software engineer extracting structured requirements from a "
    "stakeholder document. Produce concise Markdown with the sections: "
    "Title, Summary, Functional Requirements, Non-Functional Requirements, "
    "Out of Scope, Open Questions. Use bullet points. Be faithful to the source."
)


def run(username: str, project_key: str, uploaded_path: Path) -> dict:
    raw = extract_text(uploaded_path)
    excerpt = raw[:1200]

    user_prompt = (
        f"Source filename: {uploaded_path.name}\n\n"
        f"--- BEGIN DOCUMENT ---\n{raw}\n--- END DOCUMENT ---\n\n"
        "Produce the Markdown now."
    )
    md = get_llm().complete(SYSTEM, user_prompt, max_tokens=2000)

    artifact_dir = project_service.project_dir(username, project_key) / "artifacts"
    artifact_dir.mkdir(parents=True, exist_ok=True)
    out_path = artifact_dir / "stage1_requirements.md"
    out_path.write_text(md, encoding="utf-8")

    project_service.update_metadata(
        username,
        project_key,
        {
            "stages": {
                **project_service.read_metadata(username, project_key)["stages"],
                "1": {
                    "status": "ready_for_review",
                    "artifact_path": str(out_path),
                    "source_filename": uploaded_path.name,
                },
            }
        },
    )
    logger.info(f"Stage 1 complete for {project_key} → {out_path}")
    return {
        "markdown": md,
        "raw_text_excerpt": excerpt,
        "source_filename": uploaded_path.name,
    }
