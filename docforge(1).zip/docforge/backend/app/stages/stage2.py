"""
Stage 2 — Repo Selection & Connection

Steps:
  1. Read github_metadata.json and try to match against Stage 1 requirements.
  2. If user picks one (or supplies a custom URL), clone it via GitPython
     into projects/<user>/<key>/repo/<repo_name>.
  3. Count files in supported languages; reject if over the configured cap.
"""
from __future__ import annotations

import json
from pathlib import Path

from app.core.config import get_settings
from app.core.logger import logger
from app.services import github_service, project_service

_settings = get_settings()
_METADATA_PATH = Path(__file__).resolve().parents[2] / "config" / "github_metadata.json"


def load_catalog() -> list[dict]:
    if not _METADATA_PATH.exists():
        logger.warning(f"github_metadata.json missing at {_METADATA_PATH}")
        return []
    return json.loads(_METADATA_PATH.read_text(encoding="utf-8")).get("repos", [])


def find_repo_candidates(username: str, project_key: str) -> list[dict]:
    """Use the Stage 1 markdown as the query against the catalog."""
    meta = project_service.read_metadata(username, project_key)
    stage1 = meta.get("stages", {}).get("1", {})
    artifact = stage1.get("artifact_path")
    if not artifact or not Path(artifact).exists():
        return []
    query = Path(artifact).read_text(encoding="utf-8")
    return github_service.search_metadata(query, load_catalog())


def connect_repo(username: str, project_key: str, repo_url: str, token: str) -> dict:
    repo_dir = project_service.project_dir(username, project_key) / "repo"
    repo_dir.mkdir(parents=True, exist_ok=True)
    cloned_path = github_service.clone_repo(token, repo_url, repo_dir)
    analysis = github_service.count_supported_files(cloned_path)

    # Persist into metadata
    meta = project_service.read_metadata(username, project_key)
    meta["stages"]["2"] = {
        "status": "complete" if not analysis["over_limit"] else "rejected_too_large",
        "repo_url": repo_url,
        "cloned_path": analysis["cloned_path"],
        "supported_file_count": analysis["supported_file_count"],
        "languages_seen": analysis["languages_seen"],
        "over_limit": analysis["over_limit"],
    }
    project_service.write_metadata(username, project_key, meta)
    return analysis
