"""
Stage 3 — Doc Source Selection

Branches:
  • Repo name matches one of `readme_repo_prefixes` → use README.md from cloned repo
    as the canonical doc, skip FAISS/NAS.
  • Otherwise → FAISS top-K (default 2) over the indexed NAS docs, plus
    user can: pick from results, upload their own, or NAS-search again.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from app.core.config import get_settings
from app.core.logger import logger
from app.services import project_service
from app.services.faiss_service import get_faiss

_settings = get_settings()


def should_use_readme(repo_name: str) -> bool:
    prefixes = _settings.doc_source.get("readme_repo_prefixes", [])
    return any(repo_name.startswith(p) for p in prefixes)


def take_readme(username: str, project_key: str, cloned_path: Path) -> Path | None:
    """Copy the cloned repo's README.md into the project's docs/ folder."""
    readme = cloned_path / "README.md"
    if not readme.exists():
        # case-insensitive fallback
        for candidate in cloned_path.iterdir():
            if candidate.name.lower() == "readme.md" and candidate.is_file():
                readme = candidate
                break
        else:
            return None
    docs = project_service.project_dir(username, project_key) / "docs"
    docs.mkdir(parents=True, exist_ok=True)
    dest = docs / "README.md"
    shutil.copy2(readme, dest)
    return dest


def search_docs(username: str, project_key: str) -> list[dict]:
    """Run the FAISS top-K against the Stage 1 markdown."""
    meta = project_service.read_metadata(username, project_key)
    stage1 = meta.get("stages", {}).get("1", {})
    artifact_path = stage1.get("artifact_path")
    if not artifact_path or not Path(artifact_path).exists():
        return []
    query = Path(artifact_path).read_text(encoding="utf-8")
    hits = get_faiss().search(query)
    return [
        {
            "doc_id": h.doc_id,
            "title": h.title,
            "path": h.path,
            "score": h.score,
            "snippet": h.snippet,
        }
        for h in hits
    ]


def free_text_search(query: str, top_k: int = 5) -> list[dict]:
    """User-driven 'search more in NAS' query."""
    hits = get_faiss().search(query, top_k=top_k)
    return [
        {
            "doc_id": h.doc_id,
            "title": h.title,
            "path": h.path,
            "score": h.score,
            "snippet": h.snippet,
        }
        for h in hits
    ]


def finalize_selection(
    username: str,
    project_key: str,
    selected_paths: list[str],
    uploaded_paths: list[Path],
) -> dict:
    """Copy all chosen / uploaded docs into the project's docs/ folder."""
    docs_dir = project_service.project_dir(username, project_key) / "docs"
    docs_dir.mkdir(parents=True, exist_ok=True)
    final: list[str] = []
    for sp in selected_paths:
        src = Path(sp)
        if src.exists():
            dest = docs_dir / src.name
            shutil.copy2(src, dest)
            final.append(str(dest))
        else:
            logger.warning(f"Selected doc not found: {sp}")
    for up in uploaded_paths:
        dest = docs_dir / up.name
        if up.resolve() != dest.resolve():
            shutil.copy2(up, dest)
        final.append(str(dest))

    meta = project_service.read_metadata(username, project_key)
    meta["stages"]["3"] = {
        "status": "complete",
        "doc_paths": final,
    }
    project_service.write_metadata(username, project_key, meta)
    return {"doc_paths": final}
