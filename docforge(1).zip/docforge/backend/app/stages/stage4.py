"""
Stage 4 — Task Planning

Two LLM passes:
  a) split_tasks  — given Stage 1 reqs + Stage 2 code overview + Stage 3 docs,
                    return JSON {achievable: [...], unachievable: [...]}
  b) build_plan   — given the edited achievable list + special request,
                    produce a Markdown detailed plan.
"""
from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

from app.core.logger import logger
from app.services import project_service
from app.services.llm_client import get_llm

SPLIT_SYSTEM = (
    "You are a senior tech lead. Given a requirements document, a summary of an "
    "existing code repository, and a set of supporting documents, produce a JSON "
    "object with two arrays: 'achievable' (tasks you can complete given the code "
    "and docs) and 'unachievable' (tasks blocked by missing code surface or info). "
    "Each item has fields: id, title, detail. Output JSON only."
)

PLAN_SYSTEM = (
    "You are a senior tech lead writing an implementation plan. Given the "
    "achievable tasks, any special request, the requirements, code overview, and "
    "supporting docs, produce a Markdown plan with sections: Overview, "
    "Code Change Steps, Doc Update Steps, Validation Plan, Risks. Be specific "
    "about files and functions where possible."
)


def _gather_context(username: str, project_key: str) -> dict[str, str]:
    meta = project_service.read_metadata(username, project_key)
    s1 = meta["stages"].get("1", {})
    s2 = meta["stages"].get("2", {})
    s3 = meta["stages"].get("3", {})

    reqs_md = ""
    if s1.get("artifact_path") and Path(s1["artifact_path"]).exists():
        reqs_md = Path(s1["artifact_path"]).read_text(encoding="utf-8")

    code_overview = json.dumps(
        {
            "repo_url": s2.get("repo_url"),
            "supported_file_count": s2.get("supported_file_count"),
            "languages_seen": s2.get("languages_seen"),
        }
    )

    doc_paths = s3.get("doc_paths", [])
    docs_blob = ""
    for p in doc_paths[:4]:  # cap context for stub mode
        path = Path(p)
        if path.exists() and path.stat().st_size < 200_000:
            docs_blob += f"\n\n# {path.name}\n" + path.read_text(
                encoding="utf-8", errors="replace"
            )

    return {"reqs": reqs_md, "code_overview": code_overview, "docs": docs_blob}


def split_tasks(username: str, project_key: str) -> dict[str, list[dict[str, Any]]]:
    ctx = _gather_context(username, project_key)
    user = (
        "REQUIREMENTS:\n"
        + ctx["reqs"]
        + "\n\nCODE OVERVIEW:\n"
        + ctx["code_overview"]
        + "\n\nDOCS:\n"
        + ctx["docs"]
        + "\n\nReturn JSON now."
    )
    raw = get_llm().complete(SPLIT_SYSTEM, user, max_tokens=2500)

    parsed = _safe_json(raw)
    if not parsed:
        # Stub fallback so the UI keeps flowing
        parsed = {
            "achievable": [
                {
                    "id": str(uuid.uuid4())[:8],
                    "title": "Wire up requirement extraction endpoint",
                    "detail": "Stub task — replace with real LLM output.",
                }
            ],
            "unachievable": [],
        }

    # Ensure every item has an id
    for bucket in ("achievable", "unachievable"):
        for item in parsed.get(bucket, []):
            item.setdefault("id", str(uuid.uuid4())[:8])

    meta = project_service.read_metadata(username, project_key)
    meta["stages"]["4"] = {
        "status": "tasks_proposed",
        "achievable": parsed.get("achievable", []),
        "unachievable": parsed.get("unachievable", []),
    }
    project_service.write_metadata(username, project_key, meta)
    return parsed


def build_plan(
    username: str,
    project_key: str,
    achievable: list[dict[str, Any]],
    special_request: str | None,
) -> dict[str, Any]:
    ctx = _gather_context(username, project_key)
    user = (
        "ACHIEVABLE TASKS (user-edited):\n"
        + json.dumps(achievable, indent=2)
        + "\n\nSPECIAL REQUEST:\n"
        + (special_request or "(none)")
        + "\n\nREQUIREMENTS:\n"
        + ctx["reqs"]
        + "\n\nCODE OVERVIEW:\n"
        + ctx["code_overview"]
        + "\n\nDOCS:\n"
        + ctx["docs"]
        + "\n\nProduce the Markdown plan now."
    )
    md = get_llm().complete(PLAN_SYSTEM, user, max_tokens=3000)

    artifact_dir = project_service.project_dir(username, project_key) / "artifacts"
    artifact_dir.mkdir(parents=True, exist_ok=True)
    plan_path = artifact_dir / "stage4_plan.md"
    plan_path.write_text(md, encoding="utf-8")

    meta = project_service.read_metadata(username, project_key)
    meta["stages"]["4"] = {
        **meta["stages"].get("4", {}),
        "status": "plan_ready",
        "plan_path": str(plan_path),
        "achievable_final": achievable,
        "special_request": special_request,
    }
    project_service.write_metadata(username, project_key, meta)
    return {"summary": md[:400], "plan_path": str(plan_path), "markdown": md}


def _safe_json(text: str) -> dict | None:
    """LLMs love to wrap JSON in prose; strip code fences and try."""
    if not text:
        return None
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.startswith("json"):
            cleaned = cleaned[4:]
    # Try direct, then locate the first '{' to last '}'
    for candidate in (cleaned, cleaned[cleaned.find("{") : cleaned.rfind("}") + 1]):
        try:
            return json.loads(candidate)
        except Exception:
            continue
    logger.warning("Could not parse LLM JSON; using fallback")
    return None
