"""
Stage 5 — Document Update

  • apply_plan_to_docs(): run the Stage 4 plan against each Stage 3 doc
    and write updated copies under artifacts/stage5/.
  • chat(): refinement chatbot over the updated artifacts.
"""
from __future__ import annotations

from pathlib import Path

from app.core.logger import logger
from app.services import project_service
from app.services.llm_client import get_llm

UPDATE_SYSTEM = (
    "You are updating a technical document to reflect the planned code changes. "
    "Apply the plan precisely: preserve the document's original tone and "
    "section structure. Add new sections only when the plan introduces new "
    "behaviour. Output the full revised document in Markdown."
)

CHAT_SYSTEM = (
    "You are refining a technical document with the user. Each turn, you "
    "receive the current document and an instruction. Return only the revised "
    "Markdown document. No commentary."
)


def apply_plan(username: str, project_key: str) -> list[str]:
    meta = project_service.read_metadata(username, project_key)
    plan_path = meta["stages"].get("4", {}).get("plan_path")
    if not plan_path or not Path(plan_path).exists():
        raise FileNotFoundError("Stage 4 plan not found — complete Stage 4 first")
    plan = Path(plan_path).read_text(encoding="utf-8")

    docs = meta["stages"].get("3", {}).get("doc_paths", [])
    out_dir = project_service.project_dir(username, project_key) / "artifacts" / "stage5"
    out_dir.mkdir(parents=True, exist_ok=True)

    updated_paths: list[str] = []
    for doc_path in docs:
        p = Path(doc_path)
        if not p.exists():
            continue
        original = p.read_text(encoding="utf-8", errors="replace")
        user_prompt = (
            "PLAN:\n" + plan + "\n\nORIGINAL DOC:\n" + original + "\n\nReturn the revised Markdown now."
        )
        updated = get_llm().complete(UPDATE_SYSTEM, user_prompt, max_tokens=4000)
        dest = out_dir / (p.stem + ".updated.md")
        dest.write_text(updated, encoding="utf-8")
        updated_paths.append(str(dest))

    meta["stages"]["5"] = {
        "status": "ready_for_review",
        "updated_doc_paths": updated_paths,
    }
    project_service.write_metadata(username, project_key, meta)
    logger.info(f"Stage 5: produced {len(updated_paths)} updated docs for {project_key}")
    return updated_paths


def chat(
    username: str,
    project_key: str,
    doc_path: str,
    user_message: str,
) -> str:
    p = Path(doc_path)
    current = p.read_text(encoding="utf-8")
    user_prompt = (
        "CURRENT DOC:\n" + current + "\n\nINSTRUCTION:\n" + user_message + "\n\nReturn revised doc."
    )
    revised = get_llm().complete(CHAT_SYSTEM, user_prompt, max_tokens=4000)
    p.write_text(revised, encoding="utf-8")
    return revised
