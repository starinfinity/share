/**
 * API client.
 * Single axios instance; reads token from localStorage on each request so
 * login/logout in any component propagates immediately.
 */
import axios from 'axios';

const TOKEN_KEY = 'docforge.token';

const api = axios.create({
  baseURL: '/api/v1',
  timeout: 60000,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem(TOKEN_KEY);
      // Let the AuthContext observer reload — listening via 'storage' below
      window.dispatchEvent(new Event('docforge-logout'));
    }
    return Promise.reject(err);
  },
);

export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

// ---------- typed-ish endpoint helpers ----------
export const authApi = {
  login: (username, password) =>
    api.post('/auth/login', { username, password }).then((r) => r.data),
  me: () => api.get('/auth/me').then((r) => r.data),
  ssoStart: () => api.get('/auth/sso/start').then((r) => r.data),
};

export const ghTokenApi = {
  status: () => api.get('/github-token/status').then((r) => r.data),
  set: (token) => api.post('/github-token', { token }).then((r) => r.data),
  validate: () => api.post('/github-token/validate').then((r) => r.data),
  remove: () => api.delete('/github-token'),
};

export const projectApi = {
  list: () => api.get('/projects').then((r) => r.data),
  create: (payload) => api.post('/projects', payload).then((r) => r.data),
  get: (key) => api.get(`/projects/${key}`).then((r) => r.data),
  metadata: (key) => api.get(`/projects/${key}/metadata`).then((r) => r.data),
};

export const stageApi = {
  // Stage 1
  s1Upload: (key, file) => {
    const fd = new FormData();
    fd.append('file', file);
    return api
      .post(`/stages/${key}/1/upload`, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
      .then((r) => r.data);
  },
  // Stage 2
  s2Candidates: (key) => api.get(`/stages/${key}/2/candidates`).then((r) => r.data),
  s2Search: (key, q) => api.get(`/stages/${key}/2/search`, { params: { q } }).then((r) => r.data),
  s2Connect: (key, url, custom) =>
    api.post(`/stages/${key}/2/connect`, { url, custom }).then((r) => r.data),
  // Stage 3
  s3Auto: (key) => api.get(`/stages/${key}/3/auto`).then((r) => r.data),
  s3Search: (key, q) => {
    const fd = new FormData();
    fd.append('q', q);
    return api.post(`/stages/${key}/3/search`, fd).then((r) => r.data);
  },
  s3Upload: (key, files) => {
    const fd = new FormData();
    for (const f of files) fd.append('files', f);
    return api
      .post(`/stages/${key}/3/upload`, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
      .then((r) => r.data);
  },
  s3Finalize: (key, payload) =>
    api.post(`/stages/${key}/3/finalize`, payload).then((r) => r.data),
  // Stage 4
  s4Split: (key) => api.post(`/stages/${key}/4/split`).then((r) => r.data),
  s4Plan: (key, payload) => api.post(`/stages/${key}/4/plan`, payload).then((r) => r.data),
  // Stage 5
  s5Apply: (key) => api.post(`/stages/${key}/5/apply`).then((r) => r.data),
  s5Chat: (key, docPath, messages) =>
    api
      .post(`/stages/${key}/5/chat`, { messages }, { params: { doc_path: docPath } })
      .then((r) => r.data),
  // Stage 6
  s6Apply: (key) => api.post(`/stages/${key}/6/apply`).then((r) => r.data),
  s6Pr: (key) => api.post(`/stages/${key}/6/pr`).then((r) => r.data),
  s6Chat: (key, messages) => api.post(`/stages/${key}/6/chat`, { messages }).then((r) => r.data),
  // Advance
  advance: (key, stage) => api.post(`/stages/${key}/${stage}/advance`).then((r) => r.data),
};

export const miscApi = {
  templates: () => api.get('/templates').then((r) => r.data),
  faq: () => api.get('/faq').then((r) => r.data),
  howItWorks: () => api.get('/how-it-works').then((r) => r.data),
  docCreate: (form) =>
    api.post('/doc-editor/create', form, { headers: { 'Content-Type': 'multipart/form-data' } }).then((r) => r.data),
  docEdit: (form) =>
    api.post('/doc-editor/edit', form, { headers: { 'Content-Type': 'multipart/form-data' } }).then((r) => r.data),
  techspecAsk: (question) => {
    const fd = new FormData();
    fd.append('question', question);
    return api.post('/tech-spec-bot/ask', fd).then((r) => r.data);
  },
};

export default api;
