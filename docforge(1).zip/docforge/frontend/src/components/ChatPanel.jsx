import { useState, useRef, useEffect } from 'react';

export default function ChatPanel({ onSend, placeholder = 'Ask for a change…' }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const logRef = useRef(null);

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const submit = async () => {
    if (!input.trim() || busy) return;
    const userMsg = { role: 'user', content: input };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setBusy(true);
    try {
      const reply = await onSend([...messages, userMsg]);
      setMessages((m) => [...m, { role: 'assistant', content: reply || '(no reply)' }]);
    } catch (e) {
      setMessages((m) => [
        ...m,
        { role: 'assistant', content: 'Error: ' + (e?.response?.data?.detail || e.message) },
      ]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="chat-wrap">
      <div className="chat-log" ref={logRef}>
        {messages.length === 0 && (
          <div style={{ color: 'var(--text-mute)', fontSize: 13, textAlign: 'center', marginTop: 30 }}>
            No messages yet.
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`chat-msg ${m.role === 'user' ? 'user' : 'bot'}`}>
            {m.content}
          </div>
        ))}
        {busy && <div className="chat-msg bot"><span className="spinner" /> Thinking…</div>}
      </div>
      <div className="chat-input">
        <input
          value={input}
          placeholder={placeholder}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && submit()}
          disabled={busy}
        />
        <button className="btn primary" onClick={submit} disabled={busy || !input.trim()}>
          Send
        </button>
      </div>
    </div>
  );
}
