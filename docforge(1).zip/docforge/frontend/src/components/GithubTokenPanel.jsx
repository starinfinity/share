import { useEffect, useState } from 'react';
import Modal from './Modal';
import { ghTokenApi } from '../api/client';
import { useToast, reportError } from '../context/ToastContext';

function daysUntil(iso) {
  if (!iso) return null;
  const ms = new Date(iso).getTime() - Date.now();
  return Math.round(ms / (1000 * 60 * 60 * 24));
}

export default function GithubTokenPanel({ onClose }) {
  const toast = useToast();
  const [status, setStatus] = useState(null);
  const [token, setToken] = useState('');
  const [busy, setBusy] = useState(false);

  const load = async () => {
    try {
      setStatus(await ghTokenApi.status());
    } catch (e) {
      reportError(toast, e, 'Could not load token status');
    }
  };
  useEffect(() => {
    load();
  }, []);

  const save = async () => {
    if (!token) return;
    setBusy(true);
    try {
      await ghTokenApi.set(token);
      toast.ok('Token saved and validated');
      setToken('');
      await load();
    } catch (e) {
      reportError(toast, e, 'Token save failed');
    } finally {
      setBusy(false);
    }
  };

  const validate = async () => {
    setBusy(true);
    try {
      const r = await ghTokenApi.validate();
      toast.ok(`Status: ${r.last_validation_status}`);
      await load();
    } catch (e) {
      reportError(toast, e, 'Validation failed');
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!confirm('Delete the stored GitHub token?')) return;
    setBusy(true);
    try {
      await ghTokenApi.remove();
      toast.ok('Token deleted');
      await load();
    } catch (e) {
      reportError(toast, e, 'Delete failed');
    } finally {
      setBusy(false);
    }
  };

  const expiringSoon = status?.expires_at && daysUntil(status.expires_at) <= 14;

  return (
    <Modal title="GitHub Integration" onClose={onClose}>
      <p className="card-sub" style={{ marginTop: -6 }}>
        Required for repo connections and pull requests. Stored encrypted at rest.
      </p>

      {status && (
        <div className="card tight" style={{ marginBottom: 18, background: 'var(--bg-elev-2)' }}>
          <div className="row between">
            <span className="eyebrow">Current token</span>
            {status.present ? (
              <span
                className={`pill ${
                  status.last_validation_status === 'ok' ? 'ok' : 'err'
                }`}
              >
                {status.last_validation_status || 'unchecked'}
              </span>
            ) : (
              <span className="pill warn">none</span>
            )}
          </div>
          {status.present && (
            <div style={{ marginTop: 10, fontSize: 13, color: 'var(--text-dim)' }}>
              <div>
                Last validated:{' '}
                {status.last_validated_at
                  ? new Date(status.last_validated_at).toLocaleString()
                  : '—'}
              </div>
              <div>
                Expires:{' '}
                {status.expires_at ? (
                  <>
                    {new Date(status.expires_at).toLocaleString()}{' '}
                    <span
                      className={`pill ${expiringSoon ? 'warn' : ''}`}
                      style={{ marginLeft: 6 }}
                    >
                      in {daysUntil(status.expires_at)}d
                    </span>
                  </>
                ) : (
                  'no expiry reported'
                )}
              </div>
            </div>
          )}
          {status.present && (
            <div className="row" style={{ marginTop: 12 }}>
              <button className="btn sm" onClick={validate} disabled={busy}>
                Re-validate
              </button>
              <button className="btn sm danger" onClick={remove} disabled={busy}>
                Delete
              </button>
            </div>
          )}
        </div>
      )}

      <label className="field">
        <span>{status?.present ? 'Replace token' : 'Set token'}</span>
        <input
          type="password"
          value={token}
          onChange={(e) => setToken(e.target.value)}
          placeholder="ghp_… or github_pat_…"
          autoComplete="off"
        />
      </label>
      <button className="btn primary" onClick={save} disabled={!token || busy}>
        {busy ? <span className="spinner" /> : null} Save & validate
      </button>
    </Modal>
  );
}
