import { useEffect, useState } from 'react';
import Modal from './Modal';
import { miscApi } from '../api/client';

export default function HowItWorksModal({ onClose }) {
  const [data, setData] = useState(null);
  useEffect(() => {
    miscApi.howItWorks().then(setData).catch(() => {});
  }, []);
  return (
    <Modal title="How DocForge Works" onClose={onClose} width={720}>
      {!data ? (
        <div className="empty">Loading…</div>
      ) : (
        <>
          <p style={{ marginTop: 0 }}>{data.summary}</p>
          <h4 className="serif" style={{ marginTop: 18 }}>Architecture</h4>
          <div
            style={{
              border: '1px solid var(--surface-line)',
              borderRadius: 'var(--radius)',
              background: 'var(--bg-elev-2)',
              padding: 16,
            }}
          >
            <img
              src={data.architecture_image_url}
              alt="Architecture"
              style={{ width: '100%', borderRadius: 6 }}
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                e.currentTarget.nextSibling.style.display = 'block';
              }}
            />
            <pre
              style={{
                display: 'none',
                background: 'transparent',
                border: 'none',
                padding: 0,
                color: 'var(--text-mute)',
                fontSize: 12,
                lineHeight: 1.5,
                whiteSpace: 'pre',
              }}
            >{`
   ┌────────┐   ┌─────────┐   ┌────────┐   ┌────────┐
   │ Upload │ → │ Extract │ → │  Repo  │ → │  Docs  │
   │  Reqs  │   │  → MD   │   │ Clone  │   │ FAISS  │
   └────────┘   └─────────┘   └────────┘   └────────┘
                                                │
   ┌────────┐   ┌─────────┐   ┌─────────────────▼┐
   │   PR   │ ← │  Docs   │ ← │     Plan        │
   │ Open   │   │ Update  │   │ (LLM, edited)   │
   └────────┘   └─────────┘   └─────────────────┘
`}</pre>
          </div>

          <h4 className="serif" style={{ marginTop: 22 }}>Walkthrough video</h4>
          <video
            controls
            style={{
              width: '100%',
              borderRadius: 'var(--radius)',
              background: 'black',
              border: '1px solid var(--surface-line)',
            }}
          >
            <source src={data.video_url} />
            Your browser does not support the video tag.
          </video>
        </>
      )}
    </Modal>
  );
}
