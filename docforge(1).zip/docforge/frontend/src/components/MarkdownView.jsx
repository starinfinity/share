import ReactMarkdown from 'react-markdown';

export default function MarkdownView({ source }) {
  return (
    <div className="md-render">
      <ReactMarkdown>{source || ''}</ReactMarkdown>
    </div>
  );
}
