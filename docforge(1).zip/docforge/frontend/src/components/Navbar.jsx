import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import GithubTokenPanel from './GithubTokenPanel';
import HowItWorksModal from './HowItWorksModal';

function OrgLogo() {
  // Placeholder org mark — replace with real SVG asset in your deploy
  return (
    <svg width="28" height="28" viewBox="0 0 32 32" aria-label="Organization">
      <rect x="2" y="2" width="28" height="28" rx="6" fill="none" stroke="#c7bcb1" strokeWidth="1.6"/>
      <path d="M9 22 L16 8 L23 22" stroke="#c7bcb1" strokeWidth="1.6" fill="none" strokeLinejoin="round"/>
      <line x1="12" y1="17" x2="20" y2="17" stroke="#c7bcb1" strokeWidth="1.6"/>
    </svg>
  );
}

function DocForgeLogo() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <svg width="26" height="26" viewBox="0 0 64 64" aria-label="DocForge">
        <path
          d="M16 18 L16 46 L32 46 Q44 46 44 32 Q44 18 32 18 Z"
          fill="none"
          stroke="#f97316"
          strokeWidth="4"
          strokeLinejoin="round"
        />
        <circle cx="46" cy="20" r="3" fill="#f97316" />
      </svg>
      <span
        style={{
          fontFamily: 'var(--font-display)',
          fontSize: 20,
          fontWeight: 600,
          letterSpacing: '-0.01em',
        }}
      >
        Doc<span style={{ color: 'var(--accent)' }}>Forge</span>
      </span>
    </div>
  );
}

export default function Navbar() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [showTokenPanel, setShowTokenPanel] = useState(false);
  const [showHow, setShowHow] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const close = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  return (
    <>
      <nav
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '14px 28px',
          borderBottom: '1px solid var(--surface-line)',
          background: 'rgba(12, 10, 9, 0.85)',
          backdropFilter: 'saturate(140%) blur(10px)',
          position: 'sticky',
          top: 0,
          zIndex: 50,
        }}
      >
        {/* LEFT — two logos */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <OrgLogo />
          <div style={{ width: 1, height: 24, background: 'var(--surface-line-strong)' }} />
          <Link to="/" style={{ display: 'flex', color: 'inherit' }}>
            <DocForgeLogo />
          </Link>
        </div>

        {/* RIGHT */}
        {user && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <button className="btn ghost sm" onClick={() => setShowHow(true)}>
              How it works
            </button>
            <button className="btn ghost sm" onClick={() => setShowTokenPanel(true)}>
              GitHub
            </button>

            <div style={{ position: 'relative' }} ref={menuRef}>
              <button
                className="btn ghost sm"
                onClick={() => setMenuOpen((v) => !v)}
                style={{ gap: 6 }}
              >
                <span
                  style={{
                    width: 24,
                    height: 24,
                    borderRadius: '50%',
                    background: 'var(--accent-deep)',
                    color: '#fff',
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 12,
                    fontWeight: 600,
                  }}
                >
                  {user.username.slice(0, 1).toUpperCase()}
                </span>
                {user.username}
              </button>
              {menuOpen && (
                <div
                  style={{
                    position: 'absolute',
                    right: 0,
                    top: 'calc(100% + 6px)',
                    minWidth: 180,
                    background: 'var(--bg-elev-2)',
                    border: '1px solid var(--surface-line-strong)',
                    borderRadius: 'var(--radius)',
                    boxShadow: 'var(--shadow-2)',
                    padding: 6,
                  }}
                >
                  <div
                    style={{
                      padding: '8px 10px',
                      fontSize: 12,
                      color: 'var(--text-mute)',
                      borderBottom: '1px solid var(--surface-line)',
                      marginBottom: 4,
                    }}
                  >
                    {user.email}
                  </div>
                  <button
                    className="btn ghost sm"
                    style={{ width: '100%', justifyContent: 'flex-start' }}
                    onClick={() => {
                      logout();
                      setMenuOpen(false);
                      nav('/login');
                    }}
                  >
                    Sign out
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </nav>

      {showTokenPanel && <GithubTokenPanel onClose={() => setShowTokenPanel(false)} />}
      {showHow && <HowItWorksModal onClose={() => setShowHow(false)} />}
    </>
  );
}
