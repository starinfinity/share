import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div style={{ padding: 60, textAlign: 'center', color: 'var(--text-mute)' }}>
        <span className="spinner" /> Checking session…
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  return children;
}
