const STAGES = [
  { num: 1, label: 'Requirements' },
  { num: 2, label: 'Repo' },
  { num: 3, label: 'Docs' },
  { num: 4, label: 'Plan' },
  { num: 5, label: 'Doc Update' },
  { num: 6, label: 'Code & PR' },
];

export default function StageTracker({ project, onSelect }) {
  const current = project.current_stage;
  const isNewProject = project.project_type === 'new_project';

  return (
    <div className="stage-tracker">
      {STAGES.map((s) => {
        const skipped = isNewProject && s.num === 3;
        const done = s.num < current && !skipped;
        const active = s.num === current;
        const reachable = done || active;
        return (
          <button
            key={s.num}
            className={`stage-step ${active ? 'active' : ''} ${done ? 'done' : ''}`}
            disabled={!reachable || skipped}
            onClick={() => reachable && onSelect && onSelect(s.num)}
            title={skipped ? 'Skipped for new-project mode' : ''}
          >
            <span className="stage-num">{s.num}</span>
            <span>{s.label}</span>
            {skipped && <span className="pill" style={{ marginLeft: 6 }}>skipped</span>}
          </button>
        );
      })}
    </div>
  );
}
