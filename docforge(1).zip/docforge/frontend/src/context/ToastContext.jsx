import { createContext, useCallback, useContext, useState } from 'react';

const ToastContext = createContext(null);
let nextId = 1;

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const push = useCallback((message, kind = 'info', ttl = 4000) => {
    const id = nextId++;
    setToasts((t) => [...t, { id, message, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), ttl);
  }, []);

  return (
    <ToastContext.Provider
      value={{
        info: (m) => push(m, 'info'),
        ok: (m) => push(m, 'ok'),
        err: (m) => push(m, 'err'),
      }}
    >
      {children}
      <div className="toast-host">
        {toasts.map((t) => (
          <div key={t.id} className={`toast ${t.kind}`}>{t.message}</div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be inside ToastProvider');
  return ctx;
}

export function reportError(toast, err, fallback = 'Something went wrong') {
  const detail = err?.response?.data?.detail || err?.message || fallback;
  toast.err(typeof detail === 'string' ? detail : JSON.stringify(detail));
}
