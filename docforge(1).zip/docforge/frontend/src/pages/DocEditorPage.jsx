import { useState } from 'react';
import { miscApi } from '../api/client';
import MarkdownView from '../components/MarkdownView';
import { useToast, reportError } from '../context/ToastContext';

export default function DocEditorPage() {
  const toast = useToast();
  const [tab, setTab] = useState('create'); // 'create' | 'edit'

  // create
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [repoUrl, setRepoUrl] = useState('');
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [output, setOutput] = useState('');
  const [activeKey, setActiveKey] = useState('');

  // edit
  const [editKey, setEditKey] = useState('');
  const [instruction, setInstruction] = useState('');
  const [editFiles, setEditFiles] = useState([]);

  const submitCreate = async () => {
    if (!title) return;
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append('title', title);
      if (text) fd.append('inline_text', text);
      if (repoUrl) fd.append('repo_url', repoUrl);
      for (const f of files) fd.append('files', f);
      const r = await miscApi.docCreate(fd);
      setOutput(r.markdown);
      setActiveKey(r.project_key);
      toast.ok(`Doc created · ${r.project_key}`);
    } catch (e) {
      reportError(toast, e, 'Create failed');
    } finally {
      setBusy(false);
    }
  };

  const submitEdit = async () => {
    if (!editKey || !instruction) return;
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append('project_key', editKey);
      fd.append('instruction', instruction);
      for (const f of editFiles) fd.append('files', f);
      const r = await miscApi.docEdit(fd);
      setOutput(r.markdown);
      toast.ok('Doc updated');
    } catch (e) {
      reportError(toast, e, 'Edit failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page">
      <span className="eyebrow">Tool</span>
      <h1 style={{ marginTop: 6 }}>Document Editor</h1>

      <div className="row" style={{ marginBottom: 22 }}>
        <button
          className={`btn ${tab === 'create' ? 'primary' : ''}`}
          onClick={() => setTab('create')}
        >
          Create new
        </button>
        <button className={`btn ${tab === 'edit' ? 'primary' : ''}`} onClick={() => setTab('edit')}>
          Edit existing
        </button>
      </div>

      <div className="grid-2">
        <div className="card">
          {tab === 'create' ? (
            <>
              <h3 style={{ marginTop: 0 }}>New document</h3>
              <label className="field">
                <span>Title</span>
                <input value={title} onChange={(e) => setTitle(e.target.value)} />
              </label>
              <label className="field">
                <span>Inline text</span>
                <textarea
                  rows={4}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Optional — paste notes here"
                />
              </label>
              <label className="field">
                <span>GitHub repo URL (optional)</span>
                <input value={repoUrl} onChange={(e) => setRepoUrl(e.target.value)} />
              </label>
              <label className="field">
                <span>Upload files (optional)</span>
                <input
                  type="file"
                  multiple
                  accept=".txt,.doc,.docx,.ppt,.pptx,.png,.jpg,.jpeg"
                  onChange={(e) => setFiles(Array.from(e.target.files || []))}
                />
              </label>
              <button className="btn primary" onClick={submitCreate} disabled={busy || !title}>
                {busy && <span className="spinner" />} Generate
              </button>
            </>
          ) : (
            <>
              <h3 style={{ marginTop: 0 }}>Edit existing</h3>
              <label className="field">
                <span>Project key</span>
                <input
                  value={editKey}
                  onChange={(e) => setEditKey(e.target.value)}
                  placeholder="DF-XXXXXXXXXX"
                />
              </label>
              <label className="field">
                <span>Instruction</span>
                <textarea
                  rows={3}
                  value={instruction}
                  onChange={(e) => setInstruction(e.target.value)}
                  placeholder="e.g. Add a section on rate limiting"
                />
              </label>
              <label className="field">
                <span>Extra inputs (optional)</span>
                <input
                  type="file"
                  multiple
                  accept=".txt,.doc,.docx,.ppt,.pptx,.png,.jpg,.jpeg"
                  onChange={(e) => setEditFiles(Array.from(e.target.files || []))}
                />
              </label>
              <button
                className="btn primary"
                onClick={submitEdit}
                disabled={busy || !editKey || !instruction}
              >
                {busy && <span className="spinner" />} Apply edit
              </button>
            </>
          )}
        </div>

        <div>
          <div className="row between" style={{ marginBottom: 8 }}>
            <h3 style={{ margin: 0 }}>Output</h3>
            {activeKey && <span className="pill accent">{activeKey}</span>}
          </div>
          {output ? (
            <MarkdownView source={output} />
          ) : (
            <div className="empty">Generated document will appear here.</div>
          )}
        </div>
      </div>
    </div>
  );
}
