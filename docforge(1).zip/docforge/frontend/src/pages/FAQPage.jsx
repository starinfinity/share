import { useEffect, useState } from 'react';
import { miscApi } from '../api/client';

export default function FAQPage() {
  const [entries, setEntries] = useState([]);
  useEffect(() => {
    miscApi.faq().then((r) => setEntries(r.entries || []));
  }, []);
  return (
    <div className="page narrow">
      <span className="eyebrow">Help</span>
      <h1 style={{ marginTop: 6 }}>Frequently asked</h1>
      <div className="col" style={{ marginTop: 18 }}>
        {entries.map((e, i) => (
          <details
            key={i}
            className="card"
            style={{ cursor: 'pointer' }}
          >
            <summary
              style={{
                fontFamily: 'var(--font-display)',
                fontSize: 18,
                fontWeight: 500,
                listStyle: 'none',
                outline: 'none',
              }}
            >
              {e.q}
            </summary>
            <p style={{ marginTop: 12, color: 'var(--text-dim)' }}>{e.a}</p>
          </details>
        ))}
      </div>
    </div>
  );
}
