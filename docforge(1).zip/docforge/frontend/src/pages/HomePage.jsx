import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ghTokenApi, miscApi, projectApi } from '../api/client';
import { useToast, reportError } from '../context/ToastContext';
import Modal from '../components/Modal';

function ActionTile({ title, subtitle, accent, onClick }) {
  return (
    <button
      className="card"
      onClick={onClick}
      style={{
        cursor: 'pointer',
        textAlign: 'left',
        background: accent ? 'linear-gradient(135deg, var(--bg-elev) 0%, rgba(249,115,22,0.06) 100%)' : undefined,
        borderColor: accent ? 'var(--accent-deep)' : undefined,
        transition: 'transform 0.15s, border-color 0.15s',
      }}
      onMouseEnter={(e) => (e.currentTarget.style.transform = 'translateY(-2px)')}
      onMouseLeave={(e) => (e.currentTarget.style.transform = 'translateY(0)')}
    >
      <h3 className="serif" style={{ marginBottom: 6 }}>{title}</h3>
      <div style={{ color: 'var(--text-mute)', fontSize: 14 }}>{subtitle}</div>
    </button>
  );
}

function CreateProjectModal({ kind, onClose, onCreated }) {
  const toast = useToast();
  const [name, setName] = useState('');
  const [templates, setTemplates] = useState([]);
  const [templateId, setTemplateId] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (kind === 'new_project') {
      miscApi.templates().then((r) => {
        setTemplates(r.templates || []);
        if (r.templates?.length) setTemplateId(r.templates[0].id);
      });
    }
  }, [kind]);

  const create = async () => {
    setBusy(true);
    try {
      const payload = { name, project_type: kind };
      if (kind === 'new_project') payload.template_id = templateId;
      const p = await projectApi.create(payload);
      toast.ok(`Project ${p.project_key} created`);
      onCreated(p);
    } catch (e) {
      reportError(toast, e, 'Create failed');
    } finally {
      setBusy(false);
    }
  };

  const title = kind === 'new_project' ? 'Create new project (empty repo)' : 'New DocForge project';

  return (
    <Modal title={title} onClose={onClose}>
      <label className="field">
        <span>Project name</span>
        <input value={name} onChange={(e) => setName(e.target.value)} autoFocus />
      </label>
      {kind === 'new_project' && (
        <label className="field">
          <span>Template</span>
          <select value={templateId} onChange={(e) => setTemplateId(e.target.value)}>
            {templates.map((t) => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>
        </label>
      )}
      <button className="btn primary" disabled={!name || busy} onClick={create}>
        {busy && <span className="spinner" />} Create
      </button>
      <div style={{ fontSize: 12, color: 'var(--text-faint)', marginTop: 14 }}>
        Requires a validated GitHub token. Set one via the GitHub button in the navbar.
      </div>
    </Modal>
  );
}

function OpenProjectModal({ onClose, onChoose }) {
  const toast = useToast();
  const [projects, setProjects] = useState(null);
  useEffect(() => {
    projectApi
      .list()
      .then(setProjects)
      .catch((e) => reportError(toast, e, 'Could not load projects'));
  }, []);
  return (
    <Modal title="Open existing project" onClose={onClose}>
      {!projects ? (
        <div className="empty"><span className="spinner" /> Loading…</div>
      ) : projects.length === 0 ? (
        <div className="empty">No projects yet.</div>
      ) : (
        <div className="col">
          {projects.map((p) => (
            <div
              key={p.project_key}
              className="card tight"
              style={{ background: 'var(--bg-elev-2)', cursor: 'pointer' }}
              onClick={() => onChoose(p)}
            >
              <div className="row between">
                <div>
                  <div style={{ fontWeight: 600 }}>{p.name}</div>
                  <div className="mono" style={{ fontSize: 12, color: 'var(--text-mute)' }}>
                    {p.project_key}
                  </div>
                </div>
                <div className="row" style={{ gap: 6 }}>
                  <span className="pill accent">stage {p.current_stage}</span>
                  <span className="pill">{p.project_type}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
}

export default function HomePage() {
  const nav = useNavigate();
  const toast = useToast();
  const [modal, setModal] = useState(null); // 'full' | 'new_project' | 'open'
  const [tokenOk, setTokenOk] = useState(false);

  useEffect(() => {
    ghTokenApi
      .status()
      .then((s) => setTokenOk(!!s.present && s.last_validation_status === 'ok'))
      .catch(() => setTokenOk(false));
  }, []);

  const openProjectChosen = (p) => nav(`/projects/${p.project_key}`);
  const created = (p) => {
    setModal(null);
    nav(`/projects/${p.project_key}`);
  };

  const startNew = (kind) => {
    if (!tokenOk) {
      toast.err('Set a valid GitHub token first (button in navbar)');
      return;
    }
    setModal(kind);
  };

  return (
    <div className="page">
      <div style={{ maxWidth: 700, marginBottom: 36 }}>
        <span className="eyebrow">DocForge</span>
        <h1 style={{ marginTop: 8 }}>
          <span className="serif" style={{ fontStyle: 'italic', color: 'var(--text-dim)' }}>
            From requirements,
          </span>{' '}
          <br />
          a pull request.
        </h1>
        <p style={{ color: 'var(--text-mute)', fontSize: 16, marginTop: 4 }}>
          Six stages: extract requirements → connect a repo → gather docs → plan → update docs →
          ship code with an automated PR.
        </p>
      </div>

      <div className="grid-3">
        <ActionTile
          title="Create project"
          subtitle="New DocForge project against an existing GitHub repo. Runs all six stages."
          accent
          onClick={() => startNew('full')}
        />
        <ActionTile
          title="Open existing"
          subtitle="Pick up where you left off. Resumes at the current stage."
          onClick={() => setModal('open')}
        />
        <ActionTile
          title="Create new project"
          subtitle="Start from a template. Empty repo, skips Stage 3."
          onClick={() => startNew('new_project')}
        />
      </div>

      <hr className="sep" style={{ margin: '40px 0 26px' }} />

      <h2 className="serif">More tools</h2>
      <div className="grid-3" style={{ marginTop: 12 }}>
        <ActionTile
          title="Document Editor"
          subtitle="Create new or edit existing docs from code & uploads."
          onClick={() => nav('/doc-editor')}
        />
        <ActionTile
          title="Tech Spec Bot"
          subtitle="Ask questions across all indexed tech specs."
          onClick={() => nav('/tech-spec-bot')}
        />
        <ActionTile title="FAQ" subtitle="How DocForge works, in plain language." onClick={() => nav('/faq')} />
      </div>

      {modal === 'full' && (
        <CreateProjectModal kind="full" onClose={() => setModal(null)} onCreated={created} />
      )}
      {modal === 'new_project' && (
        <CreateProjectModal kind="new_project" onClose={() => setModal(null)} onCreated={created} />
      )}
      {modal === 'open' && (
        <OpenProjectModal onClose={() => setModal(null)} onChoose={openProjectChosen} />
      )}
    </div>
  );
}
