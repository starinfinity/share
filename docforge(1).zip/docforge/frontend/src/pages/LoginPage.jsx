import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast, reportError } from '../context/ToastContext';
import { authApi } from '../api/client';

export default function LoginPage() {
  const { login } = useAuth();
  const toast = useToast();
  const nav = useNavigate();
  const [username, setUsername] = useState('alice');
  const [password, setPassword] = useState('alice123');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await login(username, password);
      toast.ok(`Welcome, ${username}`);
      nav('/');
    } catch (err) {
      reportError(toast, err, 'Login failed');
    } finally {
      setBusy(false);
    }
  };

  const ssoStart = async () => {
    try {
      const r = await authApi.ssoStart();
      window.location.href = r.redirect_to;
    } catch (e) {
      reportError(toast, e, 'SSO unavailable');
    }
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
      }}
    >
      <div className="card" style={{ width: 420, maxWidth: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <svg width="48" height="48" viewBox="0 0 64 64">
            <path
              d="M16 18 L16 46 L32 46 Q44 46 44 32 Q44 18 32 18 Z"
              fill="none"
              stroke="#f97316"
              strokeWidth="4"
              strokeLinejoin="round"
            />
            <circle cx="46" cy="20" r="3" fill="#f97316" />
          </svg>
          <h1 style={{ marginTop: 12, marginBottom: 4 }}>
            Doc<span style={{ color: 'var(--accent)' }}>Forge</span>
          </h1>
          <div className="card-sub">Requirements → code & documentation</div>
        </div>

        <form onSubmit={submit}>
          <label className="field">
            <span>Username</span>
            <input value={username} onChange={(e) => setUsername(e.target.value)} autoFocus />
          </label>
          <label className="field">
            <span>Password</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>
          <button className="btn primary" style={{ width: '100%' }} disabled={busy}>
            {busy ? <span className="spinner" /> : null} Sign in
          </button>
        </form>

        <hr className="sep" />
        <button className="btn" style={{ width: '100%' }} onClick={ssoStart}>
          Sign in with SSO
        </button>
        <div
          style={{
            fontSize: 12,
            color: 'var(--text-faint)',
            textAlign: 'center',
            marginTop: 16,
          }}
        >
          Dev mode: try <span className="mono">alice / alice123</span> or{' '}
          <span className="mono">bob / bob123</span>
        </div>
      </div>
    </div>
  );
}
