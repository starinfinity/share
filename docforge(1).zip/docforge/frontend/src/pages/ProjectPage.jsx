import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { projectApi } from '../api/client';
import StageTracker from '../components/StageTracker';
import Stage1 from '../stages/Stage1';
import Stage2 from '../stages/Stage2';
import Stage3 from '../stages/Stage3';
import Stage4 from '../stages/Stage4';
import Stage5 from '../stages/Stage5';
import Stage6 from '../stages/Stage6';
import { useToast, reportError } from '../context/ToastContext';

const STAGE_COMPONENTS = {
  1: Stage1, 2: Stage2, 3: Stage3, 4: Stage4, 5: Stage5, 6: Stage6,
};

export default function ProjectPage() {
  const { key } = useParams();
  const toast = useToast();
  const [project, setProject] = useState(null);
  const [activeStage, setActiveStage] = useState(null);

  const reload = async () => {
    try {
      const p = await projectApi.get(key);
      setProject(p);
      setActiveStage((prev) => prev || p.current_stage);
    } catch (e) {
      reportError(toast, e, 'Could not load project');
    }
  };

  useEffect(() => {
    reload();
  }, [key]);

  if (!project) {
    return (
      <div className="page">
        <div className="empty"><span className="spinner" /> Loading project…</div>
      </div>
    );
  }

  const Active = STAGE_COMPONENTS[activeStage] || Stage1;

  return (
    <div className="page">
      <div className="row between" style={{ marginBottom: 6 }}>
        <div>
          <span className="eyebrow">Project</span>
          <h1 style={{ margin: '6px 0 0' }}>{project.name}</h1>
          <div className="mono" style={{ color: 'var(--text-mute)', fontSize: 13 }}>
            {project.project_key}
          </div>
        </div>
        <div className="row" style={{ gap: 6 }}>
          <span className="pill">{project.project_type}</span>
          <span className="pill accent">stage {project.current_stage}</span>
        </div>
      </div>

      <StageTracker project={project} onSelect={setActiveStage} />

      <Active
        project={project}
        onAdvance={() => {
          // Reload then jump tracker forward
          reload().then(() => setActiveStage((s) => Math.min(6, s + 1)));
        }}
      />
    </div>
  );
}
