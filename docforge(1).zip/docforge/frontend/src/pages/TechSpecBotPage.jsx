import { useState } from 'react';
import { miscApi } from '../api/client';
import MarkdownView from '../components/MarkdownView';
import { useToast, reportError } from '../context/ToastContext';

export default function TechSpecBotPage() {
  const toast = useToast();
  const [history, setHistory] = useState([]);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);

  const ask = async () => {
    if (!q.trim()) return;
    setBusy(true);
    const question = q;
    setQ('');
    setHistory((h) => [...h, { role: 'user', content: question }]);
    try {
      const r = await miscApi.techspecAsk(question);
      setHistory((h) => [
        ...h,
        {
          role: 'bot',
          content: r.answer,
          citations: r.citations,
          downloads: r.downloads,
        },
      ]);
    } catch (e) {
      reportError(toast, e, 'Ask failed');
      setHistory((h) => [...h, { role: 'bot', content: 'Error.' }]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page narrow">
      <span className="eyebrow">Tool</span>
      <h1 style={{ marginTop: 6 }}>Tech Spec Bot</h1>
      <p style={{ color: 'var(--text-mute)' }}>
        Ask anything across the indexed NAS docs. Source documents are linked for download.
      </p>

      <div className="col" style={{ marginTop: 18 }}>
        {history.length === 0 && (
          <div className="empty">No questions yet. Try "How does the auth gateway sign tokens?"</div>
        )}
        {history.map((m, i) =>
          m.role === 'user' ? (
            <div
              key={i}
              className="card tight"
              style={{ background: 'var(--accent-deep)', color: '#fff', maxWidth: 600, alignSelf: 'flex-end' }}
            >
              {m.content}
            </div>
          ) : (
            <div key={i} className="card">
              <MarkdownView source={m.content} />
              {m.citations?.length > 0 && (
                <>
                  <hr className="sep" />
                  <div className="eyebrow" style={{ marginBottom: 8 }}>Sources</div>
                  <div className="col">
                    {m.citations.map((c, j) => (
                      <div
                        key={j}
                        className="card tight"
                        style={{ background: 'var(--bg-elev-2)' }}
                      >
                        <div className="row between">
                          <div>
                            <div style={{ fontWeight: 600 }}>{c.title}</div>
                            <div
                              className="mono"
                              style={{ fontSize: 12, color: 'var(--text-mute)' }}
                            >
                              {c.path}
                            </div>
                          </div>
                          {m.downloads?.[j] && (
                            <a
                              className="btn sm"
                              href={m.downloads[j].url}
                              target="_blank"
                              rel="noreferrer"
                            >
                              Download
                            </a>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          ),
        )}
        {busy && (
          <div className="card tight">
            <span className="spinner" /> Searching…
          </div>
        )}
      </div>

      <div className="row" style={{ marginTop: 22, gap: 8 }}>
        <input
          placeholder="Ask the tech spec bot…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && ask()}
        />
        <button className="btn primary" onClick={ask} disabled={busy || !q.trim()}>
          Ask
        </button>
      </div>
    </div>
  );
}
