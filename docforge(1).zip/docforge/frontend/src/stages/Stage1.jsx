import { useState, useEffect } from 'react';
import { stageApi, projectApi } from '../api/client';
import MarkdownView from '../components/MarkdownView';
import { useToast, reportError } from '../context/ToastContext';

const ACCEPT = '.txt,.doc,.docx,.ppt,.pptx,.png,.jpg,.jpeg';

export default function Stage1({ project, onAdvance }) {
  const toast = useToast();
  const [file, setFile] = useState(null);
  const [md, setMd] = useState('');
  const [busy, setBusy] = useState(false);
  const [sourceName, setSourceName] = useState('');

  // Hydrate from metadata if Stage 1 already ran
  useEffect(() => {
    projectApi.metadata(project.project_key).then((meta) => {
      const s1 = meta?.stages?.['1'];
      if (s1?.artifact_path && s1.status !== 'pending') {
        setSourceName(s1.source_filename || '');
        // The artifact lives server-side; we don't fetch raw contents here.
        // The result of /1/upload returns markdown directly, so we keep last result in state.
      }
    });
  }, [project.project_key]);

  const upload = async () => {
    if (!file) return;
    setBusy(true);
    try {
      const r = await stageApi.s1Upload(project.project_key, file);
      setMd(r.markdown);
      setSourceName(r.source_filename);
      toast.ok('Requirements extracted');
    } catch (e) {
      reportError(toast, e, 'Extraction failed');
    } finally {
      setBusy(false);
    }
  };

  const proceed = async () => {
    try {
      await stageApi.advance(project.project_key, 1);
      onAdvance();
    } catch (e) {
      reportError(toast, e);
    }
  };

  return (
    <div className="card">
      <span className="eyebrow">Stage 1</span>
      <h2 style={{ marginTop: 6 }}>Upload your requirements</h2>
      <p className="card-sub">
        Drop a PPT, Word doc, text file, or image of the spec. DocForge extracts a clean Markdown summary.
      </p>

      <div
        style={{
          border: '1px dashed var(--surface-line-strong)',
          borderRadius: 'var(--radius)',
          padding: 22,
          textAlign: 'center',
          background: 'var(--bg-elev-2)',
        }}
      >
        <input
          id="s1-file"
          type="file"
          accept={ACCEPT}
          onChange={(e) => setFile(e.target.files?.[0])}
          style={{ display: 'none' }}
        />
        <label htmlFor="s1-file" className="btn">Choose file</label>
        <div style={{ marginTop: 10, color: 'var(--text-mute)', fontSize: 13 }}>
          {file ? file.name : sourceName || 'No file selected'}
        </div>
        <div style={{ marginTop: 12 }}>
          <button className="btn primary" onClick={upload} disabled={!file || busy}>
            {busy && <span className="spinner" />} Extract requirements
          </button>
        </div>
      </div>

      {md && (
        <>
          <hr className="sep" />
          <div className="row between" style={{ marginBottom: 10 }}>
            <h3 style={{ margin: 0 }}>Generated requirements</h3>
            <span className="pill ok">ready</span>
          </div>
          <MarkdownView source={md} />
          <div className="row" style={{ marginTop: 18, justifyContent: 'flex-end' }}>
            <button className="btn primary" onClick={proceed}>Proceed to Stage 2 →</button>
          </div>
        </>
      )}
    </div>
  );
}
