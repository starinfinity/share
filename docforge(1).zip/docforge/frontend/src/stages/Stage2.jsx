import { useEffect, useState } from 'react';
import { stageApi } from '../api/client';
import { useToast, reportError } from '../context/ToastContext';

export default function Stage2({ project, onAdvance }) {
  const toast = useToast();
  const [candidates, setCandidates] = useState([]);
  const [searchQ, setSearchQ] = useState('');
  const [customMode, setCustomMode] = useState(false);
  const [customUrl, setCustomUrl] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [busy, setBusy] = useState(false);
  const [loadedAuto, setLoadedAuto] = useState(false);

  useEffect(() => {
    stageApi
      .s2Candidates(project.project_key)
      .then((r) => setCandidates(r.candidates || []))
      .catch(() => {})
      .finally(() => setLoadedAuto(true));
  }, [project.project_key]);

  const search = async () => {
    if (!searchQ.trim()) return;
    try {
      const r = await stageApi.s2Search(project.project_key, searchQ);
      setCandidates(r.candidates || []);
    } catch (e) {
      reportError(toast, e, 'Search failed');
    }
  };

  const connect = async (url, custom = false) => {
    setBusy(true);
    setAnalysis(null);
    try {
      const a = await stageApi.s2Connect(project.project_key, url, custom);
      setAnalysis(a);
      if (a.over_limit) {
        toast.err(`Repo has ${a.supported_file_count} files — over the ${a.max_files_supported} limit`);
      } else {
        toast.ok(`Connected. ${a.supported_file_count} files in supported languages.`);
      }
    } catch (e) {
      reportError(toast, e, 'Connect failed');
    } finally {
      setBusy(false);
    }
  };

  const proceed = async () => {
    try {
      await stageApi.advance(project.project_key, 2);
      onAdvance();
    } catch (e) {
      reportError(toast, e);
    }
  };

  const canProceed = analysis && !analysis.over_limit;

  return (
    <div className="card">
      <span className="eyebrow">Stage 2</span>
      <h2 style={{ marginTop: 6 }}>Connect a repository</h2>
      <p className="card-sub">
        DocForge searches its known repo catalog using your requirements. If nothing fits, search
        manually or add a custom URL.
      </p>

      {/* Search bar */}
      <div className="row" style={{ marginBottom: 14 }}>
        <input
          placeholder="Search repos by name, topic, description…"
          value={searchQ}
          onChange={(e) => setSearchQ(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && search()}
        />
        <button className="btn" onClick={search}>Search</button>
        <button
          className={`btn ${customMode ? 'primary' : ''}`}
          onClick={() => setCustomMode((v) => !v)}
        >
          Repo not in list
        </button>
      </div>

      {/* Custom URL */}
      {customMode && (
        <div className="card tight" style={{ marginBottom: 14, background: 'var(--bg-elev-2)' }}>
          <label className="field" style={{ marginBottom: 8 }}>
            <span>Custom repo URL</span>
            <input
              placeholder="https://github.com/org/repo"
              value={customUrl}
              onChange={(e) => setCustomUrl(e.target.value)}
            />
          </label>
          <button
            className="btn primary"
            onClick={() => connect(customUrl, true)}
            disabled={!customUrl || busy}
          >
            {busy && <span className="spinner" />} Connect
          </button>
        </div>
      )}

      {/* Candidates */}
      {loadedAuto && candidates.length === 0 && !customMode && (
        <div className="empty">
          No catalog matches. Try a manual search or add a custom repo URL.
        </div>
      )}
      <div className="col">
        {candidates.map((c) => (
          <div key={c.url} className="card tight" style={{ background: 'var(--bg-elev-2)' }}>
            <div className="row between">
              <div>
                <div style={{ fontWeight: 600 }}>
                  {c.name}{' '}
                  <span className="pill accent" style={{ marginLeft: 6 }}>
                    score {c.score.toFixed(2)}
                  </span>
                </div>
                <div style={{ fontSize: 13, color: 'var(--text-mute)' }}>{c.description}</div>
                <div style={{ marginTop: 6, fontSize: 12, color: 'var(--text-faint)' }}>
                  {(c.topics || []).map((t) => (
                    <span key={t} className="pill" style={{ marginRight: 4 }}>{t}</span>
                  ))}
                </div>
              </div>
              <button className="btn primary sm" onClick={() => connect(c.url)} disabled={busy}>
                Connect
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Analysis result */}
      {analysis && (
        <>
          <hr className="sep" />
          <div className="row between">
            <h3 style={{ margin: 0 }}>Repo analysis</h3>
            <span className={`pill ${analysis.over_limit ? 'err' : 'ok'}`}>
              {analysis.over_limit ? 'too large' : 'within limit'}
            </span>
          </div>
          <div style={{ marginTop: 10, color: 'var(--text-dim)' }}>
            {analysis.supported_file_count} supported-language files (limit{' '}
            {analysis.max_files_supported})
          </div>
          <div style={{ marginTop: 12, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {Object.entries(analysis.languages_seen).map(([ext, n]) => (
              <span key={ext} className="pill">
                <span className="mono">{ext}</span> · {n}
              </span>
            ))}
          </div>
          {analysis.over_limit ? (
            <p style={{ color: 'var(--err)', marginTop: 14, fontSize: 13 }}>
              This repo exceeds the configured limit. Pick a smaller repo or raise the limit in
              <span className="mono"> config/config.yaml</span>.
            </p>
          ) : (
            <div className="row" style={{ marginTop: 18, justifyContent: 'flex-end' }}>
              <button className="btn primary" onClick={proceed} disabled={!canProceed}>
                Proceed to Stage 3 →
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
