import { useEffect, useState } from 'react';
import { stageApi } from '../api/client';
import { useToast, reportError } from '../context/ToastContext';

function HitCard({ hit, selected, onToggle, onPreview }) {
  return (
    <div
      className="card tight"
      style={{
        background: 'var(--bg-elev-2)',
        borderColor: selected ? 'var(--accent)' : undefined,
      }}
    >
      <div className="row between">
        <div>
          <div style={{ fontWeight: 600 }}>
            {hit.title}{' '}
            <span className="pill accent" style={{ marginLeft: 6 }}>
              {hit.score.toFixed(3)}
            </span>
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-mute)' }} className="mono">
            {hit.path}
          </div>
          <div style={{ fontSize: 13, color: 'var(--text-dim)', marginTop: 6 }}>
            {hit.snippet}
          </div>
        </div>
        <div className="row" style={{ gap: 6 }}>
          <button className="btn sm" onClick={() => onPreview(hit)}>Preview</button>
          <button
            className={`btn sm ${selected ? 'primary' : ''}`}
            onClick={() => onToggle(hit.doc_id)}
          >
            {selected ? 'Selected' : 'Select'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Stage3({ project, onAdvance }) {
  const toast = useToast();
  const [autoLoading, setAutoLoading] = useState(true);
  const [mode, setMode] = useState(null); // 'readme' | 'faiss'
  const [readmePath, setReadmePath] = useState('');
  const [hits, setHits] = useState([]);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [uploadedNames, setUploadedNames] = useState([]);
  const [searchQ, setSearchQ] = useState('');
  const [preview, setPreview] = useState(null);

  useEffect(() => {
    stageApi
      .s3Auto(project.project_key)
      .then((r) => {
        setMode(r.mode);
        if (r.mode === 'readme') setReadmePath(r.doc_path);
        else setHits(r.hits || []);
      })
      .catch((e) => reportError(toast, e))
      .finally(() => setAutoLoading(false));
  }, [project.project_key]);

  const toggle = (id) => {
    setSelectedIds((s) => {
      const n = new Set(s);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  };

  const searchMore = async () => {
    if (!searchQ.trim()) return;
    try {
      const r = await stageApi.s3Search(project.project_key, searchQ);
      // Merge — keep already-selected hits at top
      const merged = [...hits];
      for (const h of r.hits || []) {
        if (!merged.find((x) => x.doc_id === h.doc_id)) merged.push(h);
      }
      setHits(merged);
    } catch (e) {
      reportError(toast, e, 'NAS search failed');
    }
  };

  const upload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    try {
      await stageApi.s3Upload(project.project_key, files);
      setUploadedNames((u) => [...u, ...files.map((f) => f.name)]);
      toast.ok(`Uploaded ${files.length} file(s)`);
    } catch (err) {
      reportError(toast, err, 'Upload failed');
    }
  };

  const finalize = async () => {
    try {
      if (mode === 'readme') {
        // README mode — nothing to finalize; advance directly
        await stageApi.advance(project.project_key, 3);
        onAdvance();
        return;
      }
      await stageApi.s3Finalize(project.project_key, {
        selected_doc_ids: [...selectedIds],
        uploaded_filenames: uploadedNames,
      });
      await stageApi.advance(project.project_key, 3);
      onAdvance();
    } catch (e) {
      reportError(toast, e, 'Finalize failed');
    }
  };

  if (autoLoading) {
    return (
      <div className="card">
        <span className="spinner" /> Looking up source docs…
      </div>
    );
  }

  return (
    <div className="card">
      <span className="eyebrow">Stage 3</span>
      <h2 style={{ marginTop: 6 }}>Select supporting documents</h2>

      {mode === 'readme' ? (
        <>
          <p className="card-sub">
            Repo name matches a configured prefix — using the repo's README.md as the canonical doc.
          </p>
          <div className="card tight" style={{ background: 'var(--bg-elev-2)' }}>
            <div className="mono" style={{ fontSize: 13 }}>{readmePath}</div>
          </div>
          <div className="row" style={{ justifyContent: 'flex-end', marginTop: 18 }}>
            <button className="btn primary" onClick={finalize}>Proceed to Stage 4 →</button>
          </div>
        </>
      ) : (
        <>
          <p className="card-sub">
            Top FAISS hits against your requirements. Pick any, upload your own, or search more.
          </p>

          {/* FAISS hits */}
          {hits.length === 0 && (
            <div className="empty">
              No matches yet. Upload a doc or search the NAS for one.
            </div>
          )}
          <div className="col">
            {hits.map((h) => (
              <HitCard
                key={h.doc_id}
                hit={h}
                selected={selectedIds.has(h.doc_id)}
                onToggle={toggle}
                onPreview={setPreview}
              />
            ))}
          </div>

          <hr className="sep" />

          {/* NAS free-text */}
          <h3 style={{ marginTop: 0 }}>Search more in NAS</h3>
          <div className="row" style={{ marginBottom: 14 }}>
            <input
              placeholder="Free-text search across NAS docs…"
              value={searchQ}
              onChange={(e) => setSearchQ(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && searchMore()}
            />
            <button className="btn" onClick={searchMore}>Search</button>
          </div>

          {/* Upload */}
          <h3>Upload your own</h3>
          <input
            id="s3-upload"
            type="file"
            multiple
            accept=".txt,.md,.doc,.docx,.ppt,.pptx,.pdf"
            onChange={upload}
            style={{ display: 'none' }}
          />
          <label htmlFor="s3-upload" className="btn">Choose files…</label>
          {uploadedNames.length > 0 && (
            <div style={{ marginTop: 10, fontSize: 13, color: 'var(--text-mute)' }}>
              Uploaded: {uploadedNames.join(', ')}
            </div>
          )}

          <hr className="sep" />
          <div className="row between">
            <div style={{ color: 'var(--text-mute)', fontSize: 13 }}>
              {selectedIds.size} selected · {uploadedNames.length} uploaded
            </div>
            <button
              className="btn primary"
              disabled={selectedIds.size + uploadedNames.length === 0}
              onClick={finalize}
            >
              Proceed to Stage 4 →
            </button>
          </div>
        </>
      )}

      {/* Preview modal */}
      {preview && (
        <div
          onClick={() => setPreview(null)}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.7)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
          }}
        >
          <div
            className="card"
            onClick={(e) => e.stopPropagation()}
            style={{ width: 600, maxWidth: '90vw' }}
          >
            <div className="row between" style={{ marginBottom: 10 }}>
              <h3 style={{ margin: 0 }}>{preview.title}</h3>
              <button className="btn ghost sm" onClick={() => setPreview(null)}>✕</button>
            </div>
            <div className="mono" style={{ fontSize: 12, color: 'var(--text-mute)' }}>
              {preview.path}
            </div>
            <hr className="sep" />
            <div style={{ fontSize: 14, color: 'var(--text-dim)', whiteSpace: 'pre-wrap' }}>
              {preview.snippet}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
