import { useState } from 'react';
import { stageApi } from '../api/client';
import MarkdownView from '../components/MarkdownView';
import { useToast, reportError } from '../context/ToastContext';

function randId() {
  return Math.random().toString(36).slice(2, 8);
}

function TaskEditor({ tasks, setTasks }) {
  const update = (idx, field, value) => {
    const copy = [...tasks];
    copy[idx] = { ...copy[idx], [field]: value };
    setTasks(copy);
  };
  const remove = (idx) => setTasks(tasks.filter((_, i) => i !== idx));
  const add = () =>
    setTasks([...tasks, { id: randId(), title: 'New task', detail: '' }]);

  return (
    <div className="col">
      {tasks.length === 0 && <div className="empty">No tasks yet.</div>}
      {tasks.map((t, i) => (
        <div key={t.id} className="card tight" style={{ background: 'var(--bg-elev-2)' }}>
          <div className="row between" style={{ marginBottom: 6 }}>
            <input
              value={t.title}
              onChange={(e) => update(i, 'title', e.target.value)}
              style={{ fontWeight: 600 }}
            />
            <button className="btn ghost sm danger" onClick={() => remove(i)}>Delete</button>
          </div>
          <textarea
            value={t.detail}
            onChange={(e) => update(i, 'detail', e.target.value)}
            rows={2}
          />
        </div>
      ))}
      <button className="btn sm" style={{ alignSelf: 'flex-start' }} onClick={add}>
        + Add task
      </button>
    </div>
  );
}

export default function Stage4({ project, onAdvance }) {
  const toast = useToast();
  const [achievable, setAchievable] = useState(null);
  const [unachievable, setUnachievable] = useState(null);
  const [special, setSpecial] = useState('');
  const [plan, setPlan] = useState('');
  const [busySplit, setBusySplit] = useState(false);
  const [busyPlan, setBusyPlan] = useState(false);

  const split = async () => {
    setBusySplit(true);
    try {
      const r = await stageApi.s4Split(project.project_key);
      setAchievable(r.achievable || []);
      setUnachievable(r.unachievable || []);
      toast.ok('Tasks proposed');
    } catch (e) {
      reportError(toast, e, 'Task split failed');
    } finally {
      setBusySplit(false);
    }
  };

  const buildPlan = async () => {
    setBusyPlan(true);
    setPlan('');
    try {
      const r = await stageApi.s4Plan(project.project_key, {
        achievable,
        special_request: special || null,
      });
      setPlan(r.markdown);
      toast.ok('Plan ready');
    } catch (e) {
      reportError(toast, e, 'Plan build failed');
    } finally {
      setBusyPlan(false);
    }
  };

  const proceed = async () => {
    try {
      await stageApi.advance(project.project_key, 4);
      onAdvance();
    } catch (e) {
      reportError(toast, e);
    }
  };

  return (
    <div className="card">
      <span className="eyebrow">Stage 4</span>
      <h2 style={{ marginTop: 6 }}>Plan the work</h2>
      <p className="card-sub">
        Generate achievable / unachievable task lists, edit the achievable list, and build a
        detailed plan.
      </p>

      {achievable === null && (
        <button className="btn primary" onClick={split} disabled={busySplit}>
          {busySplit && <span className="spinner" />} Propose tasks
        </button>
      )}

      {achievable !== null && (
        <>
          <div className="grid-2">
            <div>
              <div className="row between" style={{ marginBottom: 8 }}>
                <h3 style={{ margin: 0 }}>Achievable</h3>
                <span className="pill ok">{achievable.length}</span>
              </div>
              <TaskEditor tasks={achievable} setTasks={setAchievable} />
            </div>
            <div>
              <div className="row between" style={{ marginBottom: 8 }}>
                <h3 style={{ margin: 0 }}>Unachievable</h3>
                <span className="pill err">{unachievable.length}</span>
              </div>
              <div className="col">
                {unachievable.length === 0 && <div className="empty">None.</div>}
                {unachievable.map((t) => (
                  <div
                    key={t.id}
                    className="card tight"
                    style={{ background: 'var(--bg-elev-2)', opacity: 0.7 }}
                  >
                    <div style={{ fontWeight: 600 }}>{t.title}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-mute)' }}>{t.detail}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <hr className="sep" />
          <label className="field">
            <span>Special request</span>
            <textarea
              value={special}
              onChange={(e) => setSpecial(e.target.value)}
              placeholder="Anything else the plan should account for…"
            />
          </label>

          <div className="row" style={{ gap: 8 }}>
            <button className="btn primary" onClick={buildPlan} disabled={busyPlan}>
              {busyPlan && <span className="spinner" />} Build detailed plan
            </button>
            <button className="btn" onClick={split} disabled={busySplit}>
              Re-propose tasks
            </button>
          </div>

          {plan && (
            <>
              <hr className="sep" />
              <div className="row between" style={{ marginBottom: 10 }}>
                <h3 style={{ margin: 0 }}>Detailed plan</h3>
                <span className="pill ok">ready</span>
              </div>
              <MarkdownView source={plan} />
              <div className="row" style={{ marginTop: 18, justifyContent: 'flex-end', gap: 8 }}>
                <button className="btn" onClick={buildPlan} disabled={busyPlan}>
                  Plan again
                </button>
                <button className="btn primary" onClick={proceed}>
                  Proceed to Stage 5 →
                </button>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
