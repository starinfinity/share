import { useState } from 'react';
import { stageApi } from '../api/client';
import ChatPanel from '../components/ChatPanel';
import { useToast, reportError } from '../context/ToastContext';

export default function Stage5({ project, onAdvance }) {
  const toast = useToast();
  const [docs, setDocs] = useState([]);
  const [activeDoc, setActiveDoc] = useState(null);
  const [busy, setBusy] = useState(false);

  const apply = async () => {
    setBusy(true);
    try {
      const r = await stageApi.s5Apply(project.project_key);
      setDocs(r.updated_doc_paths || []);
      if (r.updated_doc_paths?.length) setActiveDoc(r.updated_doc_paths[0]);
      toast.ok(`Updated ${r.updated_doc_paths?.length || 0} document(s)`);
    } catch (e) {
      reportError(toast, e, 'Doc update failed');
    } finally {
      setBusy(false);
    }
  };

  const sendChat = async (messages) => {
    if (!activeDoc) return '(no document selected)';
    const r = await stageApi.s5Chat(project.project_key, activeDoc, messages);
    return r.reply ? '✓ Document updated' : '(empty response)';
  };

  const proceed = async () => {
    try {
      await stageApi.advance(project.project_key, 5);
      onAdvance();
    } catch (e) {
      reportError(toast, e);
    }
  };

  return (
    <div className="card">
      <span className="eyebrow">Stage 5</span>
      <h2 style={{ marginTop: 6 }}>Update documents</h2>
      <p className="card-sub">
        Apply the plan to every Stage-3 doc. Use the chatbot to make further changes.
      </p>

      {docs.length === 0 ? (
        <button className="btn primary" onClick={apply} disabled={busy}>
          {busy && <span className="spinner" />} Apply plan to docs
        </button>
      ) : (
        <>
          <div className="row between">
            <h3 style={{ margin: 0 }}>Updated documents</h3>
            <button className="btn sm" onClick={apply} disabled={busy}>
              Re-apply
            </button>
          </div>
          <div className="col" style={{ marginTop: 10 }}>
            {docs.map((p) => (
              <div
                key={p}
                className="card tight"
                style={{
                  background: 'var(--bg-elev-2)',
                  borderColor: activeDoc === p ? 'var(--accent)' : undefined,
                  cursor: 'pointer',
                }}
                onClick={() => setActiveDoc(p)}
              >
                <div className="row between">
                  <div className="mono" style={{ fontSize: 13 }}>{p}</div>
                  {activeDoc === p && <span className="pill accent">active</span>}
                </div>
              </div>
            ))}
          </div>

          <hr className="sep" />
          <h3>Refine the active document</h3>
          <div style={{ fontSize: 12, color: 'var(--text-mute)', marginBottom: 8 }}>
            Editing: <span className="mono">{activeDoc || '(none)'}</span>
          </div>
          <ChatPanel onSend={sendChat} placeholder="e.g. Add a section about error handling…" />

          <div className="row" style={{ marginTop: 18, justifyContent: 'flex-end' }}>
            <button className="btn primary" onClick={proceed}>Proceed to Stage 6 →</button>
          </div>
        </>
      )}
    </div>
  );
}
