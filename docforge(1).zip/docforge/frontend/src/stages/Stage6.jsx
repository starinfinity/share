import { useState } from 'react';
import { stageApi } from '../api/client';
import ChatPanel from '../components/ChatPanel';
import { useToast, reportError } from '../context/ToastContext';

export default function Stage6({ project, onAdvance }) {
  const toast = useToast();
  const [edits, setEdits] = useState(null);
  const [pr, setPr] = useState(null);
  const [busyApply, setBusyApply] = useState(false);
  const [busyPr, setBusyPr] = useState(false);

  const apply = async () => {
    setBusyApply(true);
    try {
      const r = await stageApi.s6Apply(project.project_key);
      setEdits(r.edits || []);
      toast.ok(`Applied ${r.edits?.length || 0} edits`);
    } catch (e) {
      reportError(toast, e, 'Apply failed');
    } finally {
      setBusyApply(false);
    }
  };

  const openPr = async () => {
    setBusyPr(true);
    try {
      const r = await stageApi.s6Pr(project.project_key);
      setPr(r);
      if (r.status === 'created') toast.ok('PR opened');
      else toast.err(r.message || 'PR failed');
    } catch (e) {
      reportError(toast, e, 'PR open failed');
    } finally {
      setBusyPr(false);
    }
  };

  const sendChat = async (messages) => {
    const r = await stageApi.s6Chat(project.project_key, messages);
    if (r.updated_artifact_path) setPr({ ...(pr || {}), pr_url: r.updated_artifact_path });
    return r.reply;
  };

  const finish = async () => {
    try {
      await stageApi.advance(project.project_key, 6);
      onAdvance();
    } catch (e) {
      reportError(toast, e);
    }
  };

  return (
    <div className="card">
      <span className="eyebrow">Stage 6</span>
      <h2 style={{ marginTop: 6 }}>Code update & pull request</h2>
      <p className="card-sub">
        Generate edits, commit on a <span className="mono">Docforge-{project.project_key}</span>{' '}
        branch, and open a PR.
      </p>

      <div className="row" style={{ gap: 8 }}>
        <button className="btn primary" onClick={apply} disabled={busyApply}>
          {busyApply && <span className="spinner" />} Apply plan to code
        </button>
        <button className="btn" onClick={openPr} disabled={busyPr || !edits}>
          {busyPr && <span className="spinner" />} Push & open PR
        </button>
      </div>

      {edits && (
        <>
          <hr className="sep" />
          <h3 style={{ marginTop: 0 }}>Applied edits</h3>
          <div className="col">
            {edits.length === 0 && <div className="empty">No edits suggested.</div>}
            {edits.map((e, i) => (
              <div key={i} className="card tight" style={{ background: 'var(--bg-elev-2)' }}>
                <div className="row between">
                  <div className="mono" style={{ fontSize: 13 }}>{e.path}</div>
                  <div className="row" style={{ gap: 6 }}>
                    <span className="pill">{e.operation}</span>
                    <span className={`pill ${e.result === 'ok' ? 'ok' : 'warn'}`}>{e.result}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {pr && (
        <>
          <hr className="sep" />
          <div className="card tight" style={{ background: 'var(--bg-elev-2)' }}>
            <div className="row between">
              <div>
                <div style={{ fontWeight: 600 }}>Branch</div>
                <div className="mono" style={{ fontSize: 13 }}>{pr.branch_name}</div>
              </div>
              <span className={`pill ${pr.status === 'created' ? 'ok' : 'err'}`}>{pr.status}</span>
            </div>
            {pr.pr_url && (
              <div style={{ marginTop: 10 }}>
                <a href={pr.pr_url} target="_blank" rel="noreferrer">
                  Open PR ↗
                </a>
              </div>
            )}
            {pr.message && (
              <div style={{ fontSize: 13, color: 'var(--text-mute)', marginTop: 6 }}>
                {pr.message}
              </div>
            )}
          </div>

          <hr className="sep" />
          <h3>Refine the PR</h3>
          <ChatPanel
            onSend={sendChat}
            placeholder="e.g. Add input validation to the new endpoint…"
          />

          <div className="row" style={{ marginTop: 18, justifyContent: 'flex-end' }}>
            <button className="btn primary" onClick={finish}>Mark project complete →</button>
          </div>
        </>
      )}
    </div>
  );
}
