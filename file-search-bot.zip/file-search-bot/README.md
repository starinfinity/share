# File Search Bot

Semantic search + chat over ~2,000–3,000 mixed files (PDF, Word, PPT, CSV, Excel, txt/md).
Returns file paths with relevancy scores. Runs on Kubernetes.

## Architecture

```
                 ┌────────────────────────┐
  files volume ──►  Indexer (CronJob)     │  parse (Docling/pandas) → chunk → embed
                 │  SHA-256 diff per file │  (Azure text-embedding-3-large)
                 └───────────┬────────────┘
                             ▼ upsert / delete
                        ┌─────────┐
   POST /search ───────►│ Qdrant  │◄─────── POST /chat (mode: retrieve | rag)
   (FastAPI)            └─────────┘          RAG mode calls Azure GPT-5.5
```

- **One Qdrant point per chunk**; payload holds `file_path`, `file_type`, `chunk_index`, `text`.
- **File-level score** = best chunk score (cosine similarity, 0–1).
- **Incremental re-indexing**: only files whose SHA-256 changed are re-embedded; deleted
  files are purged from the index. Point IDs are deterministic per (path, chunk), so
  re-indexing overwrites cleanly.

## Local run

```bash
pip install -r requirements.txt
docker run -p 6333:6333 qdrant/qdrant:v1.12.4

export AZURE_OPENAI_ENDPOINT=https://<resource>.openai.azure.com
export AZURE_OPENAI_API_KEY=...
export FILES_ROOT=/path/to/files
export QDRANT_URL=http://localhost:6333
export STATE_DB_URL=sqlite:///./indexer.db

python -m indexer.run_indexer            # index once (or --watch --interval 300)
uvicorn app.main:app --reload            # start API
```

## API

### POST /search
```json
{ "query": "vendor contract renewal terms", "top_k": 5 }
```
Response:
```json
{
  "query": "...",
  "results": [
    {
      "file_path": "/data/files/legal/acme_msa.pdf",
      "file_type": "pdf",
      "score": 0.83,
      "matched_chunks": 4,
      "best_snippet": "..."
    }
  ]
}
```

### POST /chat
```json
{ "message": "What are our payment terms with Acme?", "mode": "rag", "top_k": 5 }
```
`mode: "retrieve"` → lists relevant files only (no LLM call, cheaper/faster).
`mode: "rag"` → GPT-5.5 answers from retrieved chunks, citing file paths; `sources` carries the scored files either way.

## Deploy to Kubernetes

```bash
docker build -f docker/Dockerfile -t <registry>/file-search-bot:latest .
docker push <registry>/file-search-bot:latest

kubectl apply -f k8s/config.yaml     # fill in endpoint + secret first
kubectl apply -f k8s/qdrant.yaml
kubectl apply -f k8s/app.yaml        # set your files PVC name
```

The indexer CronJob runs every 10 minutes with `concurrencyPolicy: Forbid`.
First full index of ~3k files takes a while (Docling OCR-free parsing is the bottleneck);
subsequent runs only touch changed files.

## Tuning

| Setting | Env var | Default |
|---|---|---|
| Chunk size / overlap (tokens) | `CHUNK_SIZE_TOKENS` / `CHUNK_OVERLAP_TOKENS` | 700 / 100 |
| Chunks fetched per file result | `CHUNK_FETCH_MULTIPLIER` | 8 |
| RAG context chunks | `RAG_CONTEXT_CHUNKS` | 8 |
| Minimum score floor | `MIN_SCORE` | 0.0 |

## Possible upgrades
- Hybrid search (dense + BM25 sparse vectors in Qdrant, RRF fusion) — better for exact codes/IDs in spreadsheets.
- BGE-reranker-v2-m3 sidecar for calibrated relevancy scores.
- Streaming chat responses (FastAPI `StreamingResponse` + Azure streaming).
- Auth (API key middleware or your org's OIDC ingress).
