"""Thin wrappers around Azure OpenAI: embeddings (batched, retried) and chat."""
from openai import AzureOpenAI
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import settings

_client = AzureOpenAI(
    azure_endpoint=settings.azure_openai_endpoint,
    api_key=settings.azure_openai_api_key,
    api_version=settings.azure_openai_api_version,
)


@retry(stop=stop_after_attempt(4), wait=wait_exponential(min=1, max=20))
def embed_texts(texts: list[str]) -> list[list[float]]:
    """Embed a list of texts, batching to respect API limits."""
    vectors: list[list[float]] = []
    bs = settings.embed_batch_size
    for i in range(0, len(texts), bs):
        batch = texts[i : i + bs]
        resp = _client.embeddings.create(
            model=settings.embedding_deployment,
            input=batch,
            dimensions=settings.embedding_dimensions,
        )
        vectors.extend(d.embedding for d in resp.data)
    return vectors


def embed_query(text: str) -> list[float]:
    return embed_texts([text])[0]


@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=1, max=15))
def chat_completion(system: str, user: str, temperature: float = 0.2) -> str:
    resp = _client.chat.completions.create(
        model=settings.chat_deployment,
        temperature=temperature,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    )
    return resp.choices[0].message.content or ""
