"""Central configuration. All values come from environment variables (K8s ConfigMap/Secret)."""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # --- Azure OpenAI ---
    azure_openai_endpoint: str  # e.g. https://<resource>.openai.azure.com
    azure_openai_api_key: str
    azure_openai_api_version: str = "2024-10-21"
    embedding_deployment: str = "text-embedding-3-large"
    embedding_dimensions: int = 3072
    chat_deployment: str = "gpt-5.5"

    # --- Qdrant ---
    qdrant_url: str = "http://qdrant:6333"
    qdrant_api_key: str | None = None
    qdrant_collection: str = "org_files"

    # --- Indexer ---
    files_root: str = "/data/files"          # mounted volume with the 2-3k files
    state_db_url: str = "sqlite:////data/state/indexer.db"  # or postgresql+psycopg://...
    chunk_size_tokens: int = 700
    chunk_overlap_tokens: int = 100
    embed_batch_size: int = 64

    # --- Reranker (no external downloads; uses your Azure deployment) ---
    reranker_mode: str = "off"               # off | azure
    reranker_deployment: str = ""            # empty = reuse chat_deployment
    rerank_candidates: int = 30              # chunks sent to the reranker

    # --- Search / RAG ---
    default_top_k_files: int = 5
    chunk_fetch_multiplier: int = 8          # fetch top_k * multiplier chunks, then group by file
    rag_context_chunks: int = 8
    min_score: float = 0.0                   # optional score floor

    class Config:
        env_file = ".env"


settings = Settings()
