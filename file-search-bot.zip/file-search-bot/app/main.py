"""REST API: file search + configurable chat (retrieve-only or RAG)."""
from fastapi import FastAPI

from app.models import (
    ChatMode,
    ChatRequest,
    ChatResponse,
    FileHit,
    SearchRequest,
    SearchResponse,
)
from app.rag import answer_with_rag, retrieve_files
from app.vectorstore import ensure_collection

app = FastAPI(title="File Search Bot", version="1.0.0")


@app.on_event("startup")
def startup() -> None:
    ensure_collection()


@app.get("/healthz")
def healthz() -> dict:
    return {"status": "ok"}


@app.post("/search", response_model=SearchResponse)
def search(req: SearchRequest) -> SearchResponse:
    """Return the top matching files with relevancy scores (cosine similarity)."""
    results = retrieve_files(req.query, req.top_k)
    return SearchResponse(query=req.query, results=[FileHit(**r) for r in results])


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    if req.mode == ChatMode.retrieve:
        files = retrieve_files(req.message, req.top_k)
        if files:
            listing = "\n".join(
                f"- {f['file_path']} (score {f['score']:.3f})" for f in files
            )
            answer = f"Here are the most relevant files:\n{listing}"
        else:
            answer = "No relevant files found."
        return ChatResponse(
            mode=req.mode, answer=answer, sources=[FileHit(**f) for f in files]
        )

    answer, files = answer_with_rag(req.message, req.top_k)
    return ChatResponse(
        mode=req.mode, answer=answer, sources=[FileHit(**f) for f in files]
    )
