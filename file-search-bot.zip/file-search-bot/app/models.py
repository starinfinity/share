"""API request/response schemas."""
from enum import Enum

from pydantic import BaseModel, Field


class FileHit(BaseModel):
    file_path: str
    file_type: str
    score: float
    matched_chunks: int
    best_snippet: str


class SearchRequest(BaseModel):
    query: str = Field(min_length=1)
    top_k: int = Field(default=5, ge=1, le=50)


class SearchResponse(BaseModel):
    query: str
    results: list[FileHit]


class ChatMode(str, Enum):
    retrieve = "retrieve"  # only find files + scores
    rag = "rag"            # answer from file content, with sources


class ChatRequest(BaseModel):
    message: str = Field(min_length=1)
    mode: ChatMode = ChatMode.rag
    top_k: int = Field(default=5, ge=1, le=20)


class ChatResponse(BaseModel):
    mode: ChatMode
    answer: str
    sources: list[FileHit]
