"""Retrieval + chat logic. Reranking (RERANKER_MODE=azure) is applied to both modes."""
from app.azure_clients import chat_completion, embed_query
from app.config import settings
from app.vectorstore import aggregate_by_file, search_chunks

SYSTEM_PROMPT = (
    "You are an internal document assistant. Answer the user's question using ONLY the "
    "provided context excerpts. Cite the file path of each excerpt you rely on, in the "
    "form [source: <path>]. If the context does not contain the answer, say so plainly."
)


def _retrieve_chunks(query: str, top_k: int) -> list[dict]:
    """Vector search, then optional LLM rerank. Returned chunks are score-sorted."""
    qvec = embed_query(query)
    if settings.reranker_mode == "azure":
        candidates = search_chunks(qvec, settings.rerank_candidates)
        from app.reranker import rerank
        return rerank(query, candidates)
    limit = top_k * settings.chunk_fetch_multiplier
    return search_chunks(qvec, limit)


def retrieve_files(query: str, top_k: int) -> list[dict]:
    chunks = _retrieve_chunks(query, top_k)
    return aggregate_by_file(chunks, top_k)


def answer_with_rag(query: str, top_k: int) -> tuple[str, list[dict]]:
    chunks = _retrieve_chunks(query, top_k)
    files = aggregate_by_file(chunks, top_k)
    context_chunks = chunks[: settings.rag_context_chunks]

    context = "\n\n---\n\n".join(
        f"[source: {c['file_path']} | chunk {c['chunk_index']} | score {c['score']:.3f}]\n{c['text']}"
        for c in context_chunks
    )
    user_msg = f"Context excerpts:\n\n{context}\n\nQuestion: {query}"
    answer = chat_completion(SYSTEM_PROMPT, user_msg)
    return answer, files
