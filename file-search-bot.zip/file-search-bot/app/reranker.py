"""LLM-based reranker using your Azure OpenAI deployment.

No Hugging Face / external model downloads. Sends candidate chunks to GPT in one
call and gets back a 0-10 relevance score per chunk, normalized to 0-1.
Falls back to the original cosine scores if the call or parsing fails.
"""
import json
import logging

from openai import AzureOpenAI

from app.config import settings

log = logging.getLogger(__name__)

_client = AzureOpenAI(
    azure_endpoint=settings.azure_openai_endpoint,
    api_key=settings.azure_openai_api_key,
    api_version=settings.azure_openai_api_version,
)

_SYSTEM = (
    "You are a search relevance judge. You will receive a query and a numbered list of "
    "document excerpts. Score each excerpt's relevance to the query from 0 (irrelevant) "
    "to 10 (directly answers it). Respond with ONLY a JSON array of objects like "
    '[{"i": 0, "s": 7}, ...] covering every excerpt. No other text, no markdown.'
)

_MAX_EXCERPT_CHARS = 600  # keep the rerank prompt small and cheap


def rerank(query: str, chunks: list[dict]) -> list[dict]:
    """Return chunks with `score` replaced by normalized LLM relevance (0-1).

    Each chunk dict must have a `text` key. On any failure, original chunks
    (with their cosine scores) are returned unchanged.
    """
    if not chunks:
        return chunks

    numbered = "\n\n".join(
        f"[{i}] {c['text'][:_MAX_EXCERPT_CHARS]}" for i, c in enumerate(chunks)
    )
    user = f"Query: {query}\n\nExcerpts:\n\n{numbered}"

    try:
        resp = _client.chat.completions.create(
            model=settings.reranker_deployment or settings.chat_deployment,
            temperature=0,
            messages=[
                {"role": "system", "content": _SYSTEM},
                {"role": "user", "content": user},
            ],
        )
        raw = (resp.choices[0].message.content or "").strip()
        raw = raw.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        scores = {int(item["i"]): float(item["s"]) for item in json.loads(raw)}
    except Exception:
        log.exception("Reranking failed; falling back to cosine scores")
        return chunks

    reranked = []
    for i, c in enumerate(chunks):
        if i in scores:
            c = {**c, "score": max(0.0, min(scores[i], 10.0)) / 10.0}
        reranked.append(c)
    reranked.sort(key=lambda c: c["score"], reverse=True)
    return reranked
