"""Qdrant access layer. One point per chunk; payload carries file metadata."""
import hashlib
import uuid

from qdrant_client import QdrantClient
from qdrant_client.models import (
    Distance,
    FieldCondition,
    Filter,
    MatchValue,
    PointStruct,
    VectorParams,
)

from app.config import settings

client = QdrantClient(url=settings.qdrant_url, api_key=settings.qdrant_api_key)
COLLECTION = settings.qdrant_collection


def ensure_collection() -> None:
    if not client.collection_exists(COLLECTION):
        client.create_collection(
            collection_name=COLLECTION,
            vectors_config=VectorParams(
                size=settings.embedding_dimensions, distance=Distance.COSINE
            ),
        )
        client.create_payload_index(COLLECTION, "file_path", field_schema="keyword")


def _point_id(file_path: str, chunk_index: int) -> str:
    """Deterministic ID so re-indexing a file overwrites its old chunks."""
    raw = f"{file_path}::{chunk_index}"
    return str(uuid.UUID(hashlib.md5(raw.encode()).hexdigest()))


def upsert_file_chunks(
    file_path: str, file_type: str, chunks: list[str], vectors: list[list[float]]
) -> None:
    points = [
        PointStruct(
            id=_point_id(file_path, i),
            vector=vec,
            payload={
                "file_path": file_path,
                "file_type": file_type,
                "chunk_index": i,
                "text": chunk,
            },
        )
        for i, (chunk, vec) in enumerate(zip(chunks, vectors))
    ]
    client.upsert(collection_name=COLLECTION, points=points)


def delete_file(file_path: str) -> None:
    client.delete(
        collection_name=COLLECTION,
        points_selector=Filter(
            must=[FieldCondition(key="file_path", match=MatchValue(value=file_path))]
        ),
    )


def search_chunks(query_vector: list[float], limit: int) -> list[dict]:
    hits = client.query_points(
        collection_name=COLLECTION,
        query=query_vector,
        limit=limit,
        with_payload=True,
    ).points
    return [
        {
            "file_path": h.payload["file_path"],
            "file_type": h.payload["file_type"],
            "chunk_index": h.payload["chunk_index"],
            "text": h.payload["text"],
            "score": h.score,
        }
        for h in hits
    ]


def aggregate_by_file(chunks: list[dict], top_k_files: int) -> list[dict]:
    """Aggregate chunk hits to file level. Score = best chunk score per file."""
    files: dict[str, dict] = {}
    for c in chunks:
        f = files.setdefault(
            c["file_path"],
            {
                "file_path": c["file_path"],
                "file_type": c["file_type"],
                "score": c["score"],
                "matched_chunks": 0,
                "best_snippet": c["text"][:300],
            },
        )
        f["matched_chunks"] += 1
        if c["score"] > f["score"]:
            f["score"] = c["score"]
            f["best_snippet"] = c["text"][:300]

    ranked = sorted(files.values(), key=lambda f: f["score"], reverse=True)
    ranked = [f for f in ranked if f["score"] >= settings.min_score]
    return ranked[:top_k_files]


def search_files(query_vector: list[float], top_k_files: int) -> list[dict]:
    """Search chunks, then aggregate to file level."""
    chunk_limit = top_k_files * settings.chunk_fetch_multiplier
    chunks = search_chunks(query_vector, chunk_limit)
    return aggregate_by_file(chunks, top_k_files)
