"""Token-based chunking with overlap, using tiktoken (cl100k works for embedding-3)."""
import tiktoken

from app.config import settings

_enc = tiktoken.get_encoding("cl100k_base")


def chunk_text(text: str) -> list[str]:
    size = settings.chunk_size_tokens
    overlap = settings.chunk_overlap_tokens
    tokens = _enc.encode(text)
    if not tokens:
        return []
    if len(tokens) <= size:
        return [text.strip()]

    chunks: list[str] = []
    step = size - overlap
    for start in range(0, len(tokens), step):
        window = tokens[start : start + size]
        chunk = _enc.decode(window).strip()
        if chunk:
            chunks.append(chunk)
        if start + size >= len(tokens):
            break
    return chunks
