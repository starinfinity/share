"""Extract text from Word / PDF / PPT / CSV / Excel / plain text.

Docling handles layout-aware extraction for PDF, DOCX, PPTX (tables included).
Tabular files are serialized with headers repeated per chunk downstream.
"""
import logging
from pathlib import Path

import pandas as pd

log = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {
    ".pdf", ".docx", ".doc", ".pptx", ".ppt",
    ".csv", ".tsv", ".xlsx", ".xlsm", ".xls",
    ".txt", ".md",
}

_DOCLING_TYPES = {".pdf", ".docx", ".doc", ".pptx", ".ppt"}

_converter = None  # lazy: docling model load is slow


def _docling():
    global _converter
    if _converter is None:
        from docling.document_converter import DocumentConverter
        _converter = DocumentConverter()
    return _converter


def _parse_docling(path: Path) -> str:
    result = _docling().convert(str(path))
    return result.document.export_to_markdown()


def _dataframe_to_text(df: pd.DataFrame, title: str) -> str:
    """Serialize a table: title + header + one line per row."""
    df = df.fillna("")
    header = " | ".join(str(c) for c in df.columns)
    lines = [f"# {title}", header]
    for _, row in df.iterrows():
        lines.append(" | ".join(str(v) for v in row.values))
    return "\n".join(lines)


def _parse_csv(path: Path) -> str:
    sep = "\t" if path.suffix.lower() == ".tsv" else ","
    df = pd.read_csv(path, sep=sep, dtype=str, on_bad_lines="skip")
    return _dataframe_to_text(df, path.name)


def _parse_excel(path: Path) -> str:
    sheets = pd.read_excel(path, sheet_name=None, dtype=str)
    parts = [
        _dataframe_to_text(df, f"{path.name} — sheet: {name}")
        for name, df in sheets.items()
        if not df.empty
    ]
    return "\n\n".join(parts)


def parse_file(path: Path) -> str | None:
    """Return extracted text, or None if unsupported/failed."""
    ext = path.suffix.lower()
    try:
        if ext in _DOCLING_TYPES:
            return _parse_docling(path)
        if ext in {".csv", ".tsv"}:
            return _parse_csv(path)
        if ext in {".xlsx", ".xlsm", ".xls"}:
            return _parse_excel(path)
        if ext in {".txt", ".md"}:
            return path.read_text(errors="replace")
    except Exception:
        log.exception("Failed to parse %s", path)
        return None
    return None
