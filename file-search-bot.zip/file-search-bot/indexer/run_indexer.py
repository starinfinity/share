"""Incremental indexer. Run as a K8s CronJob (or with --watch as a long-running loop).

Logic per run:
  1. Scan FILES_ROOT for supported files.
  2. Hash each file; compare with stored hash.
  3. New/changed -> parse, chunk, embed, upsert to Qdrant (old chunks deleted first).
  4. Files gone from disk -> delete their points and state record.
"""
import argparse
import logging
import time
from pathlib import Path

from app.azure_clients import embed_texts
from app.config import settings
from app.vectorstore import delete_file, ensure_collection, upsert_file_chunks
from indexer.chunking import chunk_text
from indexer.parsers import SUPPORTED_EXTENSIONS, parse_file
from indexer.state import (
    file_sha256,
    get_indexed_hashes,
    init_db,
    mark_indexed,
    remove_record,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("indexer")


def scan_files(root: Path) -> dict[str, Path]:
    return {
        str(p): p
        for p in root.rglob("*")
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTENSIONS
    }


def index_file(path: Path) -> bool:
    text = parse_file(path)
    if not text or not text.strip():
        log.warning("No text extracted from %s — skipping", path)
        return False
    chunks = chunk_text(text)
    if not chunks:
        return False
    vectors = embed_texts(chunks)
    delete_file(str(path))  # clear stale chunks (file may have shrunk)
    upsert_file_chunks(str(path), path.suffix.lower().lstrip("."), chunks, vectors)
    log.info("Indexed %s (%d chunks)", path, len(chunks))
    return True


def run_once() -> None:
    root = Path(settings.files_root)
    on_disk = scan_files(root)
    indexed = get_indexed_hashes()

    # Removed files
    for stale_path in set(indexed) - set(on_disk):
        log.info("Removing deleted file from index: %s", stale_path)
        delete_file(stale_path)
        remove_record(stale_path)

    # New / changed files
    changed = new = failed = 0
    for path_str, path in sorted(on_disk.items()):
        sha = file_sha256(path)
        if indexed.get(path_str) == sha:
            continue
        if index_file(path):
            mark_indexed(path_str, sha)
            new += path_str not in indexed
            changed += path_str in indexed
        else:
            failed += 1

    log.info(
        "Run complete: %d new, %d updated, %d failed, %d total on disk",
        new, changed, failed, len(on_disk),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--watch", action="store_true", help="loop forever")
    parser.add_argument("--interval", type=int, default=300, help="seconds between scans")
    args = parser.parse_args()

    init_db()
    ensure_collection()

    if args.watch:
        while True:
            run_once()
            time.sleep(args.interval)
    else:
        run_once()


if __name__ == "__main__":
    main()
