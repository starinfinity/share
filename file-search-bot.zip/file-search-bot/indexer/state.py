"""Tracks which version of each file is indexed (SHA-256).

DB is configurable: sqlite on a PVC for simplicity, or Postgres via STATE_DB_URL.
"""
import hashlib
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import DateTime, String, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column

from app.config import settings

engine = create_engine(settings.state_db_url)


class Base(DeclarativeBase):
    pass


class IndexedFile(Base):
    __tablename__ = "indexed_files"
    file_path: Mapped[str] = mapped_column(String, primary_key=True)
    sha256: Mapped[str] = mapped_column(String)
    indexed_at: Mapped[datetime] = mapped_column(DateTime)


def init_db() -> None:
    Base.metadata.create_all(engine)


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def get_indexed_hashes() -> dict[str, str]:
    with Session(engine) as s:
        return {r.file_path: r.sha256 for r in s.scalars(select(IndexedFile))}


def mark_indexed(file_path: str, sha: str) -> None:
    with Session(engine) as s:
        s.merge(
            IndexedFile(
                file_path=file_path, sha256=sha, indexed_at=datetime.now(timezone.utc)
            )
        )
        s.commit()


def remove_record(file_path: str) -> None:
    with Session(engine) as s:
        obj = s.get(IndexedFile, file_path)
        if obj:
            s.delete(obj)
            s.commit()
