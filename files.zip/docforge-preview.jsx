import React, { useState, useEffect, useRef, createContext, useContext } from 'react';
import {
  Send, Paperclip, Mic, Share2, MoreHorizontal, Sparkles, FileCode,
  Wand2, ListChecks, GitBranch, MessageSquare, FileText, LayoutGrid,
  Settings, Plus, BookOpen, Palette, Check, ChevronDown, FileBadge,
} from 'lucide-react';

// ─── Themes ───
const themes = [
  {
    id: 'royal-amethyst', name: 'Royal Amethyst',
    description: 'Deep purple noir with gilded accents',
    swatch: ['#1a0b2e', '#6d28d9', '#f9d57b', '#ffffff'],
    tokens: {
      bg: '#13081f',
      bgGradient: 'radial-gradient(ellipse at top left, #2d1659 0%, #1a0b2e 35%, #0b041a 100%)',
      surface: 'rgba(45, 22, 89, 0.55)', surfaceElevated: 'rgba(58, 28, 113, 0.72)',
      surfaceHover: 'rgba(76, 38, 140, 0.6)',
      sidebar: 'linear-gradient(180deg, #1a0b2e 0%, #0d0418 100%)', sidebarText: '#e9d5ff',
      textPrimary: '#fefefe', textSecondary: '#d4b8ff', textMuted: '#9d7ec9',
      border: 'rgba(180, 130, 255, 0.18)', borderStrong: 'rgba(180, 130, 255, 0.35)',
      accent: '#c084fc', accentHover: '#a855f7', accentText: '#1a0b2e',
      accentSoft: 'rgba(192, 132, 252, 0.18)', accent2: '#f9d57b',
      userBubble: 'linear-gradient(135deg, #7c3aed 0%, #a855f7 100%)', userBubbleText: '#ffffff',
      botBubble: 'rgba(45, 22, 89, 0.65)', botBubbleText: '#f3e8ff',
      shadow: '0 8px 32px rgba(124, 58, 237, 0.25)',
      shadowLg: '0 20px 60px rgba(124, 58, 237, 0.4)',
      innerShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.06)',
      glow: '0 0 40px rgba(192, 132, 252, 0.4)',
      success: '#86efac', danger: '#fda4af', warning: '#fcd34d',
      fontDisplay: '"Fraunces", serif', fontBody: '"Inter", sans-serif',
      fontMono: '"JetBrains Mono", monospace',
      radius: '14px', radiusLg: '22px', radiusSm: '8px', inputStyle: 'glass',
    },
  },
  {
    id: 'garnet-sunrise', name: 'Garnet Sunrise',
    description: 'Warm dawn — garnet, coral, peach, gold',
    swatch: ['#fef3e9', '#e85a4f', '#7a1f3d', '#f4a261'],
    tokens: {
      bg: '#fef3e9',
      bgGradient: 'linear-gradient(135deg, #fef3e9 0%, #fde0c8 40%, #fbc89e 100%)',
      surface: '#fffaf3', surfaceElevated: '#ffffff', surfaceHover: '#fde6d1',
      sidebar: 'linear-gradient(180deg, #7a1f3d 0%, #4a1226 100%)', sidebarText: '#fde0c8',
      textPrimary: '#3a0f1f', textSecondary: '#7a1f3d', textMuted: '#a85b6b',
      border: 'rgba(122, 31, 61, 0.14)', borderStrong: 'rgba(122, 31, 61, 0.28)',
      accent: '#e85a4f', accentHover: '#c8453b', accentText: '#ffffff',
      accentSoft: 'rgba(232, 90, 79, 0.14)', accent2: '#f4a261',
      userBubble: 'linear-gradient(135deg, #e85a4f 0%, #f4a261 100%)', userBubbleText: '#ffffff',
      botBubble: '#fffaf3', botBubbleText: '#3a0f1f',
      shadow: '0 6px 20px rgba(122, 31, 61, 0.1)',
      shadowLg: '0 16px 48px rgba(122, 31, 61, 0.18)',
      innerShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.8)',
      glow: '0 0 30px rgba(232, 90, 79, 0.3)',
      success: '#52b788', danger: '#c8453b', warning: '#f4a261',
      fontDisplay: '"DM Serif Display", serif', fontBody: '"Manrope", sans-serif',
      fontMono: '"JetBrains Mono", monospace',
      radius: '12px', radiusLg: '20px', radiusSm: '6px', inputStyle: 'soft',
    },
  },
  {
    id: 'stormy-morning', name: 'Stormy Morning',
    description: 'Overcast slate with rain-washed blues',
    swatch: ['#cbd5e1', '#475569', '#1e293b', '#7dd3fc'],
    tokens: {
      bg: '#e2e8f0',
      bgGradient: 'linear-gradient(180deg, #cbd5e1 0%, #94a3b8 50%, #64748b 100%)',
      surface: 'rgba(241, 245, 249, 0.85)', surfaceElevated: '#f8fafc',
      surfaceHover: 'rgba(226, 232, 240, 0.95)',
      sidebar: 'linear-gradient(180deg, #334155 0%, #1e293b 100%)', sidebarText: '#cbd5e1',
      textPrimary: '#1e293b', textSecondary: '#475569', textMuted: '#64748b',
      border: 'rgba(71, 85, 105, 0.18)', borderStrong: 'rgba(71, 85, 105, 0.35)',
      accent: '#0ea5e9', accentHover: '#0284c7', accentText: '#ffffff',
      accentSoft: 'rgba(14, 165, 233, 0.12)', accent2: '#7dd3fc',
      userBubble: 'linear-gradient(135deg, #475569 0%, #334155 100%)', userBubbleText: '#f1f5f9',
      botBubble: '#f8fafc', botBubbleText: '#1e293b',
      shadow: '0 4px 16px rgba(30, 41, 59, 0.12)',
      shadowLg: '0 12px 40px rgba(30, 41, 59, 0.2)',
      innerShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.6)',
      glow: '0 0 24px rgba(125, 211, 252, 0.35)',
      success: '#10b981', danger: '#ef4444', warning: '#f59e0b',
      fontDisplay: '"Fraunces", serif', fontBody: '"Inter", sans-serif',
      fontMono: '"JetBrains Mono", monospace',
      radius: '10px', radiusLg: '18px', radiusSm: '6px', inputStyle: 'flat',
    },
  },
  {
    id: 'skeuomorphism', name: 'Skeuomorphism',
    description: 'Tactile bevels, leather, and stitching',
    swatch: ['#e8dfd0', '#8b6f47', '#3d2817', '#d4a574'],
    tokens: {
      bg: '#e8dfd0',
      bgGradient: 'radial-gradient(ellipse at center, #f0e6d2 0%, #d8cdb8 100%)',
      surface: 'linear-gradient(180deg, #fefbf3 0%, #f0e6d2 100%)',
      surfaceElevated: 'linear-gradient(180deg, #ffffff 0%, #f5ecd6 100%)',
      surfaceHover: 'linear-gradient(180deg, #fff8e7 0%, #ebe0c4 100%)',
      sidebar: 'linear-gradient(180deg, #5c4028 0%, #3d2817 100%)', sidebarText: '#f0e6d2',
      textPrimary: '#3d2817', textSecondary: '#6b4f2e', textMuted: '#8b6f47',
      border: 'rgba(61, 40, 23, 0.22)', borderStrong: 'rgba(61, 40, 23, 0.4)',
      accent: '#a8632a', accentHover: '#8b4d1f', accentText: '#fff8e7',
      accentSoft: 'rgba(168, 99, 42, 0.16)', accent2: '#d4a574',
      userBubble: 'linear-gradient(180deg, #c4823d 0%, #a8632a 50%, #8b4d1f 100%)',
      userBubbleText: '#fff8e7',
      botBubble: 'linear-gradient(180deg, #fefbf3 0%, #ebe0c4 100%)', botBubbleText: '#3d2817',
      shadow: '0 4px 8px rgba(61, 40, 23, 0.25), 0 2px 4px rgba(61, 40, 23, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.6)',
      shadowLg: '0 12px 24px rgba(61, 40, 23, 0.3), 0 6px 12px rgba(61, 40, 23, 0.2), inset 0 1px 0 rgba(255, 255, 255, 0.6)',
      innerShadow: 'inset 0 2px 4px rgba(61, 40, 23, 0.2), inset 0 -1px 0 rgba(255, 255, 255, 0.5)',
      glow: '0 0 20px rgba(212, 165, 116, 0.5)',
      success: '#4a7c2e', danger: '#a83232', warning: '#c4823d',
      fontDisplay: '"Fraunces", serif', fontBody: '"Inter", sans-serif',
      fontMono: '"JetBrains Mono", monospace',
      radius: '14px', radiusLg: '20px', radiusSm: '8px', inputStyle: 'skeuo',
    },
  },
  {
    id: 'flat-design', name: 'Flat Design',
    description: 'No shadows. Pure colors. Bold geometry.',
    swatch: ['#ecf0f1', '#3498db', '#e74c3c', '#2c3e50'],
    tokens: {
      bg: '#ecf0f1', bgGradient: '#ecf0f1',
      surface: '#ffffff', surfaceElevated: '#ffffff', surfaceHover: '#dfe6e9',
      sidebar: '#2c3e50', sidebarText: '#ecf0f1',
      textPrimary: '#2c3e50', textSecondary: '#34495e', textMuted: '#7f8c8d',
      border: '#bdc3c7', borderStrong: '#95a5a6',
      accent: '#3498db', accentHover: '#2980b9', accentText: '#ffffff',
      accentSoft: '#d6eaf8', accent2: '#e74c3c',
      userBubble: '#3498db', userBubbleText: '#ffffff',
      botBubble: '#ffffff', botBubbleText: '#2c3e50',
      shadow: 'none', shadowLg: 'none', innerShadow: 'none', glow: 'none',
      success: '#2ecc71', danger: '#e74c3c', warning: '#f39c12',
      fontDisplay: '"Space Grotesk", sans-serif', fontBody: '"Space Grotesk", sans-serif',
      fontMono: '"JetBrains Mono", monospace',
      radius: '0px', radiusLg: '0px', radiusSm: '0px', inputStyle: 'sharp',
    },
  },
  {
    id: 'dark-mode', name: 'Dark Mode',
    description: 'Classic developer dark — easy on the eyes',
    swatch: ['#0d1117', '#21262d', '#58a6ff', '#e6edf3'],
    tokens: {
      bg: '#0d1117', bgGradient: '#0d1117',
      surface: '#161b22', surfaceElevated: '#21262d', surfaceHover: '#1f242b',
      sidebar: '#010409', sidebarText: '#c9d1d9',
      textPrimary: '#e6edf3', textSecondary: '#c9d1d9', textMuted: '#7d8590',
      border: '#30363d', borderStrong: '#484f58',
      accent: '#58a6ff', accentHover: '#79b8ff', accentText: '#0d1117',
      accentSoft: 'rgba(88, 166, 255, 0.12)', accent2: '#a371f7',
      userBubble: '#1f6feb', userBubbleText: '#ffffff',
      botBubble: '#161b22', botBubbleText: '#e6edf3',
      shadow: '0 4px 14px rgba(0, 0, 0, 0.4)',
      shadowLg: '0 12px 32px rgba(0, 0, 0, 0.5)',
      innerShadow: 'inset 0 1px 0 rgba(255, 255, 255, 0.03)',
      glow: '0 0 20px rgba(88, 166, 255, 0.25)',
      success: '#3fb950', danger: '#f85149', warning: '#d29922',
      fontDisplay: '"Inter", sans-serif', fontBody: '"Inter", sans-serif',
      fontMono: '"JetBrains Mono", monospace',
      radius: '8px', radiusLg: '14px', radiusSm: '6px', inputStyle: 'flat',
    },
  },
  {
    id: 'light-mode', name: 'Light Mode',
    description: 'Clean, airy, and timeless',
    swatch: ['#ffffff', '#f6f8fa', '#0969da', '#1f2328'],
    tokens: {
      bg: '#ffffff', bgGradient: '#ffffff',
      surface: '#f6f8fa', surfaceElevated: '#ffffff', surfaceHover: '#eaeef2',
      sidebar: '#f6f8fa', sidebarText: '#1f2328',
      textPrimary: '#1f2328', textSecondary: '#424a53', textMuted: '#6e7781',
      border: '#d0d7de', borderStrong: '#afb8c1',
      accent: '#0969da', accentHover: '#0860c7', accentText: '#ffffff',
      accentSoft: '#ddf4ff', accent2: '#8250df',
      userBubble: '#0969da', userBubbleText: '#ffffff',
      botBubble: '#f6f8fa', botBubbleText: '#1f2328',
      shadow: '0 1px 3px rgba(31, 35, 40, 0.08), 0 1px 2px rgba(31, 35, 40, 0.04)',
      shadowLg: '0 8px 24px rgba(31, 35, 40, 0.12)',
      innerShadow: 'inset 0 1px 0 rgba(255, 255, 255, 1)',
      glow: '0 0 16px rgba(9, 105, 218, 0.18)',
      success: '#1a7f37', danger: '#cf222e', warning: '#9a6700',
      fontDisplay: '"Inter", sans-serif', fontBody: '"Inter", sans-serif',
      fontMono: '"JetBrains Mono", monospace',
      radius: '8px', radiusLg: '14px', radiusSm: '6px', inputStyle: 'flat',
    },
  },
];

// ─── Inject fonts ───
function useFonts() {
  useEffect(() => {
    if (document.getElementById('df-fonts')) return;
    const link = document.createElement('link');
    link.id = 'df-fonts';
    link.rel = 'stylesheet';
    link.href = 'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&family=Space+Grotesk:wght@400;500;600;700&family=DM+Serif+Display&family=Manrope:wght@400;500;600;700;800&display=swap';
    document.head.appendChild(link);
  }, []);
}

// ─── Theme context ───
const ThemeCtx = createContext(null);

function ThemeProvider({ children }) {
  const [themeId, setThemeId] = useState('royal-amethyst');
  const theme = themes.find(t => t.id === themeId) || themes[0];

  useEffect(() => {
    const t = theme.tokens;
    const root = document.documentElement;
    const set = (k, v) => root.style.setProperty(k, v);
    Object.entries(t).forEach(([key, val]) => {
      const cssKey = '--' + key.replace(/([A-Z])/g, '-$1').toLowerCase();
      set(cssKey, val);
    });
    root.setAttribute('data-theme', themeId);
    root.setAttribute('data-input-style', t.inputStyle);
  }, [themeId, theme]);

  return (
    <ThemeCtx.Provider value={{ theme, themeId, setThemeId, allThemes: themes }}>
      {children}
    </ThemeCtx.Provider>
  );
}

const useTheme = () => useContext(ThemeCtx);

// ─── Styles ───
const styles = `
  * { box-sizing: border-box; margin: 0; padding: 0; }
  .df-app { display: flex; height: 100vh; width: 100%; background: var(--bg-gradient);
    color: var(--text-primary); font-family: var(--font-body);
    position: relative; overflow: hidden;
    -webkit-font-smoothing: antialiased;
    transition: background-color 0.4s ease, color 0.4s ease;
  }
  [data-theme='royal-amethyst'] .df-app::before {
    content: ''; position: absolute; inset: 0; pointer-events: none; z-index: 0;
    background: radial-gradient(circle at 80% 10%, rgba(249, 213, 123, 0.08) 0%, transparent 40%),
                radial-gradient(circle at 10% 90%, rgba(192, 132, 252, 0.12) 0%, transparent 50%);
  }
  [data-theme='skeuomorphism'] .df-app::before {
    content: ''; position: absolute; inset: 0; pointer-events: none; z-index: 0; opacity: 0.5;
    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2'/%3E%3CfeColorMatrix values='0 0 0 0 0.24 0 0 0 0 0.16 0 0 0 0 0.09 0 0 0 0.08 0'/%3E%3C/filter%3E%3Crect width='200' height='200' filter='url(%23n)'/%3E%3C/svg%3E");
  }

  .df-sidebar { width: 270px; background: var(--sidebar); color: var(--sidebar-text);
    display: flex; flex-direction: column; flex-shrink: 0;
    border-right: 1px solid var(--border); position: relative; z-index: 2;
    transition: background 0.4s ease;
  }
  [data-theme='flat-design'] .df-sidebar { border-right: 3px solid var(--accent); }

  .df-sidebar-header { padding: 20px 18px 16px; display: flex; align-items: center; gap: 12px;
    border-bottom: 1px solid rgba(255,255,255,0.06); }
  [data-theme='light-mode'] .df-sidebar-header,
  [data-theme='garnet-sunrise'] .df-sidebar-header,
  [data-theme='stormy-morning'] .df-sidebar-header { border-bottom: 1px solid var(--border); }

  .df-logo-mark { width: 36px; height: 36px; border-radius: var(--radius);
    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-2) 100%);
    display: grid; place-items: center; color: var(--accent-text); font-weight: 700;
    font-family: var(--font-display); font-size: 18px; flex-shrink: 0; box-shadow: var(--shadow); }
  [data-theme='skeuomorphism'] .df-logo-mark {
    background: linear-gradient(180deg, #d4a574 0%, #a8632a 50%, #8b4d1f 100%);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), inset 0 -1px 0 rgba(0,0,0,0.2), 0 3px 6px rgba(0,0,0,0.3);
  }

  .df-logo-text { font-family: var(--font-display); font-size: 18px; font-weight: 700; letter-spacing: -0.01em; }
  .df-accent-letter { color: var(--accent); font-style: italic; }
  [data-theme='flat-design'] .df-accent-letter { font-style: normal; }

  .df-new-chat { margin: 14px 12px 8px; padding: 10px 14px;
    background: var(--accent); color: var(--accent-text);
    border-radius: var(--radius); font-weight: 600; font-size: 13px;
    display: flex; align-items: center; justify-content: center; gap: 8px;
    box-shadow: var(--shadow); transition: all 0.18s ease; border: none; cursor: pointer;
  }
  .df-new-chat:hover { background: var(--accent-hover); transform: translateY(-1px); }
  [data-theme='skeuomorphism'] .df-new-chat {
    background: linear-gradient(180deg, #c4823d 0%, #a8632a 50%, #8b4d1f 100%);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), inset 0 -2px 0 rgba(0,0,0,0.2), 0 3px 6px rgba(61,40,23,0.3);
  }
  [data-theme='flat-design'] .df-new-chat:hover { transform: none; }

  .df-sidebar-section { padding: 12px 10px; flex-shrink: 0; }
  .df-section-title { font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em;
    font-weight: 600; color: var(--text-muted); padding: 0 10px 8px; opacity: 0.8; }

  .df-nav-item { display: flex; align-items: center; gap: 11px; padding: 9px 12px;
    border-radius: var(--radius-sm); cursor: pointer; font-size: 13px; font-weight: 500;
    color: var(--sidebar-text); opacity: 0.85; transition: all 0.15s ease;
    text-align: left; width: 100%; border: none; background: none;
  }
  .df-nav-item:hover { background: rgba(255,255,255,0.06); opacity: 1; }
  [data-theme='light-mode'] .df-nav-item:hover,
  [data-theme='garnet-sunrise'] .df-nav-item:hover,
  [data-theme='stormy-morning'] .df-nav-item:hover { background: rgba(0,0,0,0.05); }
  .df-nav-item.active { background: var(--accent-soft); color: var(--accent); opacity: 1; font-weight: 600; }
  [data-theme='flat-design'] .df-nav-item.active { background: var(--accent); color: var(--accent-text); }

  .df-conv-list { flex: 1; overflow-y: auto; padding: 4px 10px; }
  .df-conv-item { padding: 9px 12px; border-radius: var(--radius-sm); cursor: pointer;
    font-size: 13px; display: flex; align-items: center; gap: 10px; color: var(--sidebar-text);
    opacity: 0.7; transition: all 0.15s ease; white-space: nowrap; overflow: hidden;
    text-overflow: ellipsis; border: none; background: none; width: 100%; text-align: left;
  }
  .df-conv-item:hover { background: rgba(255,255,255,0.05); opacity: 1; }
  [data-theme='light-mode'] .df-conv-item:hover,
  [data-theme='garnet-sunrise'] .df-conv-item:hover,
  [data-theme='stormy-morning'] .df-conv-item:hover { background: rgba(0,0,0,0.04); }
  .df-conv-item.active { background: var(--accent-soft); color: var(--accent); opacity: 1; }

  .df-sidebar-footer { padding: 12px 14px; border-top: 1px solid rgba(255,255,255,0.06);
    display: flex; align-items: center; gap: 10px; }
  [data-theme='light-mode'] .df-sidebar-footer,
  [data-theme='garnet-sunrise'] .df-sidebar-footer,
  [data-theme='stormy-morning'] .df-sidebar-footer { border-top: 1px solid var(--border); }

  .df-avatar { width: 32px; height: 32px; border-radius: 50%;
    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-2) 100%);
    display: grid; place-items: center; font-weight: 600; font-size: 12px;
    color: var(--accent-text); flex-shrink: 0;
  }

  .df-main { flex: 1; display: flex; flex-direction: column; min-width: 0;
    position: relative; z-index: 1; }

  .df-topbar { height: 60px; padding: 0 24px; display: flex; align-items: center;
    justify-content: space-between; border-bottom: 1px solid var(--border);
    background: var(--surface); backdrop-filter: blur(20px); flex-shrink: 0;
  }
  [data-theme='royal-amethyst'] .df-topbar { background: rgba(26,11,46,0.6); }
  [data-theme='flat-design'] .df-topbar { border-bottom: 2px solid var(--text-primary); backdrop-filter: none; }

  .df-page-title { font-family: var(--font-display); font-size: 21px; font-weight: 600;
    letter-spacing: -0.015em; color: var(--text-primary); }
  .df-page-title .df-accent { color: var(--accent); font-style: italic; }
  [data-theme='flat-design'] .df-page-title .df-accent { font-style: normal; }

  .df-topbar-actions { display: flex; align-items: center; gap: 8px; }
  .df-icon-btn { width: 36px; height: 36px; border-radius: var(--radius-sm);
    display: grid; place-items: center; color: var(--text-secondary);
    transition: all 0.15s ease; border: 1px solid transparent; background: none; cursor: pointer;
  }
  .df-icon-btn:hover { background: var(--surface-hover); color: var(--text-primary); }

  .df-theme-btn { display: flex; align-items: center; gap: 8px; padding: 7px 11px;
    border-radius: var(--radius); background: var(--surface-elevated);
    border: 1px solid var(--border); color: var(--text-primary);
    font-size: 12px; font-weight: 500; transition: all 0.15s ease; cursor: pointer;
  }
  .df-theme-btn:hover { border-color: var(--border-strong); background: var(--surface-hover); }
  .df-swatches { display: flex; gap: 3px; }
  .df-swatch-dot { width: 9px; height: 9px; border-radius: 50%; border: 1px solid rgba(0,0,0,0.15); }
  [data-theme='flat-design'] .df-swatch-dot { border-radius: 0; }

  .df-theme-menu { position: absolute; top: calc(100% + 8px); right: 0; width: 320px;
    background: var(--surface-elevated); border: 1px solid var(--border);
    border-radius: var(--radius-lg); padding: 8px; box-shadow: var(--shadow-lg);
    z-index: 100; display: flex; flex-direction: column; gap: 3px;
    animation: dfMenuOpen 0.2s ease;
  }
  @keyframes dfMenuOpen { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
  .df-theme-option { padding: 11px 13px; border-radius: var(--radius-sm);
    display: flex; align-items: center; gap: 12px; cursor: pointer; transition: background 0.15s;
    text-align: left; width: 100%; border: 1px solid transparent; background: none;
  }
  .df-theme-option:hover { background: var(--surface-hover); }
  .df-theme-option.active { background: var(--accent-soft); border-color: var(--accent); }
  .df-theme-option-swatches { display: flex; gap: 0; }
  .df-theme-option-swatch { width: 13px; height: 26px; margin-left: -1px; }
  .df-theme-option-swatch:first-child { margin-left: 0; border-radius: var(--radius-sm) 0 0 var(--radius-sm); }
  .df-theme-option-swatch:last-child { border-radius: 0 var(--radius-sm) var(--radius-sm) 0; }
  .df-theme-option-info { flex: 1; min-width: 0; }
  .df-theme-option-name { font-size: 13px; font-weight: 600; color: var(--text-primary); }
  .df-theme-option-desc { font-size: 11px; color: var(--text-muted); margin-top: 2px; }
  .df-theme-option-check { color: var(--accent); opacity: 0; transition: opacity 0.15s; }
  .df-theme-option.active .df-theme-option-check { opacity: 1; }

  .df-menu-backdrop { position: fixed; inset: 0; z-index: 99; }

  .df-chat { flex: 1; display: flex; flex-direction: column; overflow: hidden; }
  .df-messages-area { flex: 1; overflow-y: auto; padding: 28px 0; scroll-behavior: smooth; }
  .df-messages-container { max-width: 760px; margin: 0 auto; padding: 0 24px;
    display: flex; flex-direction: column; gap: 20px;
  }

  .df-welcome { max-width: 760px; margin: auto; padding: 32px 24px; text-align: center;
    display: flex; flex-direction: column; align-items: center; gap: 16px;
  }
  .df-welcome-mark { width: 70px; height: 70px; border-radius: var(--radius-lg);
    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-2) 100%);
    display: grid; place-items: center; color: var(--accent-text);
    font-family: var(--font-display); font-size: 32px; font-weight: 700;
    box-shadow: var(--shadow-lg), var(--glow); margin-bottom: 6px;
  }
  [data-theme='skeuomorphism'] .df-welcome-mark {
    background: linear-gradient(180deg, #d4a574 0%, #a8632a 50%, #8b4d1f 100%);
    box-shadow: inset 0 2px 0 rgba(255,255,255,0.5), inset 0 -2px 0 rgba(0,0,0,0.25), 0 8px 20px rgba(61,40,23,0.4);
  }
  .df-welcome-title { font-family: var(--font-display); font-size: 34px; font-weight: 700;
    letter-spacing: -0.025em; line-height: 1.1; color: var(--text-primary); }
  .df-welcome-title .df-accent { color: var(--accent); font-style: italic; }
  [data-theme='flat-design'] .df-welcome-title .df-accent { font-style: normal; }
  .df-welcome-subtitle { font-size: 15px; color: var(--text-secondary); max-width: 460px; line-height: 1.55; }

  .df-suggestions { display: grid; grid-template-columns: repeat(2, 1fr);
    gap: 11px; width: 100%; margin-top: 14px;
  }
  .df-suggestion { padding: 15px 17px; background: var(--surface); border: 1px solid var(--border);
    border-radius: var(--radius); text-align: left; cursor: pointer; transition: all 0.18s ease;
    display: flex; flex-direction: column; gap: 4px; color: var(--text-primary);
  }
  .df-suggestion:hover { border-color: var(--accent); background: var(--surface-elevated);
    transform: translateY(-2px); box-shadow: var(--shadow); }
  [data-theme='flat-design'] .df-suggestion:hover { transform: none; background: var(--accent-soft); }
  [data-theme='skeuomorphism'] .df-suggestion { box-shadow: var(--shadow); }
  .df-suggestion-title { font-weight: 600; font-size: 13px; color: var(--text-primary); }
  .df-suggestion-desc { font-size: 11px; color: var(--text-muted); }

  .df-message { display: flex; gap: 13px; align-items: flex-start;
    animation: dfMessageIn 0.32s cubic-bezier(0.22, 1, 0.36, 1);
  }
  @keyframes dfMessageIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
  .df-message.user { flex-direction: row-reverse; }
  .df-message-avatar { width: 30px; height: 30px; border-radius: var(--radius-sm);
    display: grid; place-items: center; font-size: 11px; font-weight: 600; flex-shrink: 0;
  }
  .df-message.user .df-message-avatar { background: var(--user-bubble); color: var(--user-bubble-text); }
  .df-message.assistant .df-message-avatar {
    background: linear-gradient(135deg, var(--accent) 0%, var(--accent-2) 100%);
    color: var(--accent-text);
  }
  .df-message-bubble { max-width: calc(100% - 90px); padding: 12px 16px;
    border-radius: var(--radius-lg); font-size: 14px; line-height: 1.6;
    word-wrap: break-word; white-space: pre-wrap;
  }
  .df-message.user .df-message-bubble { background: var(--user-bubble);
    color: var(--user-bubble-text); border-bottom-right-radius: var(--radius-sm);
    box-shadow: var(--shadow);
  }
  .df-message.assistant .df-message-bubble { background: var(--bot-bubble);
    color: var(--bot-bubble-text); border-bottom-left-radius: var(--radius-sm);
    border: 1px solid var(--border); box-shadow: var(--shadow);
  }
  [data-theme='flat-design'] .df-message.assistant .df-message-bubble { box-shadow: none; border: 2px solid var(--text-primary); }
  [data-theme='flat-design'] .df-message.user .df-message-bubble { box-shadow: none; }
  [data-theme='skeuomorphism'] .df-message.user .df-message-bubble {
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.25), inset 0 -2px 0 rgba(0,0,0,0.2), 0 4px 10px rgba(61,40,23,0.35);
  }
  [data-theme='skeuomorphism'] .df-message.assistant .df-message-bubble {
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.7), 0 3px 8px rgba(61,40,23,0.2);
  }
  .df-message-time { font-size: 10px; color: var(--text-muted); margin-top: 5px; }

  .df-typing-dots { display: inline-flex; gap: 4px; padding: 4px 0; }
  .df-typing-dots span { width: 6px; height: 6px; border-radius: 50%;
    background: var(--text-muted); animation: dfTyping 1.3s infinite;
  }
  .df-typing-dots span:nth-child(2) { animation-delay: 0.15s; }
  .df-typing-dots span:nth-child(3) { animation-delay: 0.3s; }
  @keyframes dfTyping {
    0%, 60%, 100% { transform: translateY(0); opacity: 0.4; }
    30% { transform: translateY(-5px); opacity: 1; }
  }

  .df-composer-wrap { padding: 14px 24px 20px;
    background: linear-gradient(180deg, transparent 0%, var(--bg) 30%); flex-shrink: 0;
  }
  [data-theme='royal-amethyst'] .df-composer-wrap {
    background: linear-gradient(180deg, transparent 0%, rgba(19,8,31,0.95) 40%);
  }
  .df-composer { max-width: 760px; margin: 0 auto; background: var(--surface-elevated);
    border: 1px solid var(--border); border-radius: var(--radius-lg);
    padding: 6px 6px 6px 16px; display: flex; align-items: flex-end; gap: 6px;
    box-shadow: var(--shadow); transition: all 0.18s ease;
  }
  .df-composer:focus-within { border-color: var(--accent); box-shadow: var(--shadow), 0 0 0 4px var(--accent-soft); }
  [data-theme='flat-design'] .df-composer { border: 2px solid var(--text-primary); box-shadow: none; }
  [data-theme='flat-design'] .df-composer:focus-within { border-color: var(--accent); box-shadow: none; }
  [data-theme='skeuomorphism'] .df-composer {
    box-shadow: inset 0 2px 4px rgba(61,40,23,0.18), inset 0 -1px 0 rgba(255,255,255,0.5);
  }

  .df-textarea { flex: 1; resize: none; font-size: 14px; line-height: 1.5;
    color: var(--text-primary); padding: 10px 0; max-height: 200px; min-height: 22px;
    font-family: var(--font-body); border: none; outline: none; background: none; width: 100%;
  }
  .df-textarea::placeholder { color: var(--text-muted); }

  .df-composer-tools { display: flex; align-items: center; gap: 3px; padding-bottom: 3px; }
  .df-tool-btn { width: 32px; height: 32px; border-radius: var(--radius-sm);
    display: grid; place-items: center; color: var(--text-muted);
    transition: all 0.15s ease; border: none; background: none; cursor: pointer;
  }
  .df-tool-btn:hover { background: var(--surface-hover); color: var(--text-primary); }

  .df-send-btn { width: 36px; height: 36px; border-radius: var(--radius);
    background: var(--accent); color: var(--accent-text); display: grid; place-items: center;
    transition: all 0.18s ease; flex-shrink: 0; box-shadow: var(--shadow);
    border: none; cursor: pointer;
  }
  .df-send-btn:hover:not(:disabled) { background: var(--accent-hover); transform: translateY(-1px); }
  .df-send-btn:disabled { opacity: 0.4; cursor: not-allowed; }
  [data-theme='skeuomorphism'] .df-send-btn {
    background: linear-gradient(180deg, #c4823d 0%, #a8632a 50%, #8b4d1f 100%);
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.4), inset 0 -2px 0 rgba(0,0,0,0.2), 0 3px 6px rgba(61,40,23,0.3);
  }
  [data-theme='flat-design'] .df-send-btn:hover:not(:disabled) { transform: none; }

  .df-composer-hint { max-width: 760px; margin: 6px auto 0; font-size: 10px;
    color: var(--text-muted); text-align: center;
  }

  .df-documents-grid { max-width: 1100px; margin: 0 auto; padding: 28px 26px;
    display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px;
  }
  .df-doc-card { padding: 20px; background: var(--surface-elevated);
    border: 1px solid var(--border); border-radius: var(--radius-lg);
    cursor: pointer; transition: all 0.2s ease; box-shadow: var(--shadow);
    display: flex; flex-direction: column; gap: 12px;
  }
  .df-doc-card:hover { transform: translateY(-3px); box-shadow: var(--shadow-lg); border-color: var(--accent); }
  [data-theme='flat-design'] .df-doc-card { border: 2px solid var(--text-primary); box-shadow: none; }
  [data-theme='flat-design'] .df-doc-card:hover { transform: none; background: var(--accent-soft); }
  .df-doc-icon { width: 42px; height: 42px; border-radius: var(--radius);
    display: grid; place-items: center; background: var(--accent-soft); color: var(--accent);
  }
  .df-doc-title { font-weight: 600; font-size: 15px; color: var(--text-primary); font-family: var(--font-display); }
  .df-doc-meta { display: flex; justify-content: space-between; align-items: center;
    font-size: 11px; color: var(--text-muted);
  }
  .df-doc-status { padding: 3px 8px; border-radius: 999px; font-size: 10px; font-weight: 600;
    text-transform: uppercase; letter-spacing: 0.04em;
  }
  [data-theme='flat-design'] .df-doc-status { border-radius: 0; }
  .df-doc-status.published { background: rgba(74, 124, 46, 0.15); color: var(--success); }
  .df-doc-status.draft { background: var(--surface-hover); color: var(--text-muted); }
  .df-doc-status.review { background: rgba(196, 130, 61, 0.18); color: var(--warning); }

  .df-view-header { padding: 24px 26px 16px; border-bottom: 1px solid var(--border);
    display: flex; justify-content: space-between; align-items: center;
  }
  .df-view-title { font-family: var(--font-display); font-size: 26px; font-weight: 600;
    letter-spacing: -0.02em; color: var(--text-primary);
  }
  .df-view-title .df-accent { color: var(--accent); font-style: italic; }
  [data-theme='flat-design'] .df-view-title .df-accent { font-style: normal; }
  .df-view-subtitle { font-size: 13px; color: var(--text-muted); margin-top: 3px; }

  .df-btn-primary { padding: 9px 15px; background: var(--accent); color: var(--accent-text);
    border-radius: var(--radius); font-weight: 600; font-size: 13px;
    display: inline-flex; align-items: center; gap: 7px; box-shadow: var(--shadow);
    transition: all 0.18s ease; border: none; cursor: pointer;
  }
  .df-btn-primary:hover { background: var(--accent-hover); transform: translateY(-1px); }
  [data-theme='flat-design'] .df-btn-primary:hover { transform: none; }

  ::-webkit-scrollbar { width: 8px; height: 8px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: var(--border-strong); border-radius: 8px; }
`;

// ─── Bot replies ───
function generateReply(text) {
  const t = text.toLowerCase();
  if (t.includes('hello') || t.includes('hi ') || t === 'hi') {
    return "Hi! I'm Techspecbot. Tell me what you'd like to forge — a spec, API contract, PRD, or architecture note — and I'll get you a first draft.";
  }
  if (t.includes('openapi') || t.includes('api spec')) {
    return "I'll outline an OpenAPI 3.0 structure: info, servers, paths (with operation IDs, parameters, request bodies, responses), components/schemas, and securitySchemes. For auth, I'd suggest documenting login, signup, refresh, and password-reset as separate paths under /auth. Want me to generate the full YAML?";
  }
  if (t.includes('prd') || t.includes('requirements')) {
    return "A solid PRD one-pager covers: Problem, Users & jobs-to-be-done, Goals (metrics), Non-goals, Proposed solution, Risks, and a Rollout sketch. Share the feature name and your top metric, and I'll draft it.";
  }
  if (t.includes('checklist')) {
    return "A great backend tech spec usually has:\n\n① Context & goals\n② Non-goals\n③ Current state\n④ Proposed design (data model, APIs, sequence flows)\n⑤ Alternatives considered\n⑥ Observability & SLOs\n⑦ Security & privacy\n⑧ Migration plan\n⑨ Open questions\n\nWant me to expand any section?";
  }
  if (t.includes('architecture') || t.includes('diagram')) {
    return "Here's a clean text sketch:\n\nClient → API Gateway → [Auth, Orders, Inventory] → Event Bus → [Notifications, Analytics, Search]\n\nEach service owns its own data store. The event bus (Kafka or similar) decouples write-side commands from read-side projections. Want me to elaborate on any layer?";
  }
  const fallbacks = [
    "Great question — here's a starting structure. I'd organize this around three sections: (1) the problem and constraints, (2) the proposed design with trade-offs called out explicitly, and (3) the rollout plan with measurable success criteria. Want me to draft each section?",
    "Got it. For a spec like this, I'd lead with the user-facing behavior, then drop into the data model and API contract. After that, cover failure modes, observability, and migration. I can generate a first draft if you share the feature name.",
    "Let me draft that for you. I'll use the standard sections — overview, goals, non-goals, design, alternatives considered, and open questions. Anything specific you want emphasized?",
  ];
  return fallbacks[Math.floor(Math.random() * fallbacks.length)];
}

const suggestions = [
  { icon: <FileCode size={17} />, title: 'API spec from description', desc: 'Generate an OpenAPI 3.0 spec', prompt: 'Generate an OpenAPI 3.0 spec for a user auth service.' },
  { icon: <Wand2 size={17} />, title: 'PRD template', desc: 'Draft a one-pager for a new feature', prompt: 'Draft a PRD one-pager for a collaborative whiteboard.' },
  { icon: <ListChecks size={17} />, title: 'Tech-spec checklist', desc: 'Review my spec for completeness', prompt: 'Give me a checklist of what a great backend tech spec should contain.' },
  { icon: <GitBranch size={17} />, title: 'Architecture diagram', desc: 'Describe a system cleanly', prompt: 'Describe a typical event-driven microservices architecture.' },
];

const sampleDocs = [
  { id: '1', title: 'Auth Service v2 — Tech Spec', type: 'spec', updatedAt: '2 hours ago', status: 'review' },
  { id: '2', title: 'Payments API Reference', type: 'api', updatedAt: 'Yesterday', status: 'published' },
  { id: '3', title: 'Onboarding Flow PRD', type: 'spec', updatedAt: '3 days ago', status: 'draft' },
  { id: '4', title: 'SDK Integration Guide', type: 'guide', updatedAt: '1 week ago', status: 'published' },
  { id: '5', title: 'Realtime Notifications Spec', type: 'spec', updatedAt: '2 weeks ago', status: 'published' },
  { id: '6', title: 'GraphQL Schema Notes', type: 'api', updatedAt: '3 weeks ago', status: 'draft' },
];

const docIcon = (type) => {
  if (type === 'api') return <FileCode size={20} />;
  if (type === 'guide') return <BookOpen size={20} />;
  if (type === 'readme') return <FileBadge size={20} />;
  return <FileText size={20} />;
};

function ThemeSwitcher() {
  const { theme, themeId, setThemeId, allThemes } = useTheme();
  const [open, setOpen] = useState(false);
  return (
    <div style={{ position: 'relative' }}>
      <button className="df-theme-btn" onClick={() => setOpen(v => !v)}>
        <Palette size={14} />
        <span>{theme.name}</span>
        <div className="df-swatches">
          {theme.swatch.slice(0, 3).map((c, i) => (
            <div key={i} className="df-swatch-dot" style={{ background: c }} />
          ))}
        </div>
        <ChevronDown size={13} />
      </button>
      {open && (
        <>
          <div className="df-menu-backdrop" onClick={() => setOpen(false)} />
          <div className="df-theme-menu">
            {allThemes.map(t => (
              <button key={t.id}
                className={`df-theme-option ${themeId === t.id ? 'active' : ''}`}
                onClick={() => { setThemeId(t.id); setOpen(false); }}>
                <div className="df-theme-option-swatches">
                  {t.swatch.map((c, i) => (
                    <div key={i} className="df-theme-option-swatch" style={{ background: c }} />
                  ))}
                </div>
                <div className="df-theme-option-info">
                  <div className="df-theme-option-name">{t.name}</div>
                  <div className="df-theme-option-desc">{t.description}</div>
                </div>
                <div className="df-theme-option-check"><Check size={15} /></div>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function Sidebar({ view, setView, conversations, activeConvId, onSelectConv, onNewChat }) {
  return (
    <aside className="df-sidebar">
      <div className="df-sidebar-header">
        <div className="df-logo-mark">D</div>
        <div className="df-logo-text">Doc<span className="df-accent-letter">Forge</span></div>
      </div>
      <button className="df-new-chat" onClick={onNewChat}>
        <Plus size={15} /> New conversation
      </button>
      <div className="df-sidebar-section">
        <div className="df-section-title">Workspace</div>
        <div>
          <button className={`df-nav-item ${view === 'chat' ? 'active' : ''}`} onClick={() => setView('chat')}>
            <Sparkles size={15} /> Techspecbot
          </button>
          <button className={`df-nav-item ${view === 'documents' ? 'active' : ''}`} onClick={() => setView('documents')}>
            <FileText size={15} /> Documents
          </button>
          <button className="df-nav-item"><LayoutGrid size={15} /> Templates</button>
          <button className="df-nav-item"><BookOpen size={15} /> Knowledge base</button>
        </div>
      </div>
      {view === 'chat' && (
        <>
          <div className="df-sidebar-section" style={{ paddingBottom: 2 }}>
            <div className="df-section-title">Recent chats</div>
          </div>
          <div className="df-conv-list">
            {conversations.map(c => (
              <button key={c.id}
                className={`df-conv-item ${activeConvId === c.id ? 'active' : ''}`}
                onClick={() => onSelectConv(c.id)}>
                <MessageSquare size={13} />
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.title}</span>
              </button>
            ))}
            {conversations.length === 0 && (
              <div style={{ padding: '10px 12px', fontSize: 12, opacity: 0.6, fontStyle: 'italic' }}>
                No conversations yet
              </div>
            )}
          </div>
        </>
      )}
      {view !== 'chat' && <div style={{ flex: 1 }} />}
      <div className="df-sidebar-footer">
        <div className="df-avatar">JM</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 600 }}>Jordan Mills</div>
          <div style={{ fontSize: 10, opacity: 0.7 }}>Pro plan</div>
        </div>
        <button className="df-icon-btn"><Settings size={14} /></button>
      </div>
    </aside>
  );
}

function ChatView({ conversation, onSendMessage, isTyping }) {
  const [input, setInput] = useState('');
  const textareaRef = useRef(null);
  const messagesEndRef = useRef(null);
  const messages = conversation?.messages || [];
  const isEmpty = messages.length === 0;

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 200) + 'px';
  }, [input]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, isTyping]);

  const handleSend = () => {
    const t = input.trim();
    if (!t) return;
    onSendMessage(t);
    setInput('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="df-chat">
      <div className="df-topbar">
        <div className="df-page-title">Techspec<span className="df-accent">bot</span></div>
        <div className="df-topbar-actions">
          <button className="df-icon-btn"><Share2 size={16} /></button>
          <button className="df-icon-btn"><MoreHorizontal size={16} /></button>
          <ThemeSwitcher />
        </div>
      </div>

      <div className="df-messages-area">
        {isEmpty ? (
          <div className="df-welcome">
            <div className="df-welcome-mark">D</div>
            <h1 className="df-welcome-title">Forge your <span className="df-accent">next spec</span></h1>
            <p className="df-welcome-subtitle">
              Techspecbot drafts product specs, API contracts, architecture notes, and engineering checklists — tuned to your team's voice.
            </p>
            <div className="df-suggestions">
              {suggestions.map((s, i) => (
                <button key={i} className="df-suggestion" onClick={() => onSendMessage(s.prompt)}>
                  <div style={{ color: 'var(--accent)', marginBottom: 4 }}>{s.icon}</div>
                  <div className="df-suggestion-title">{s.title}</div>
                  <div className="df-suggestion-desc">{s.desc}</div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="df-messages-container">
            {messages.map(m => {
              const time = new Date(m.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              return (
                <div key={m.id} className={`df-message ${m.role}`}>
                  <div className="df-message-avatar">
                    {m.role === 'user' ? 'You' : <Sparkles size={14} />}
                  </div>
                  <div>
                    <div className="df-message-bubble">{m.content}</div>
                    <div className="df-message-time" style={{ textAlign: m.role === 'user' ? 'right' : 'left' }}>{time}</div>
                  </div>
                </div>
              );
            })}
            {isTyping && (
              <div className="df-message assistant">
                <div className="df-message-avatar"><Sparkles size={14} /></div>
                <div className="df-message-bubble">
                  <div className="df-typing-dots"><span /><span /><span /></div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      <div className="df-composer-wrap">
        <div className="df-composer">
          <textarea
            ref={textareaRef}
            className="df-textarea"
            placeholder="Ask Techspecbot to forge a doc, spec, or diagram…"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            rows={1}
          />
          <div className="df-composer-tools">
            <button className="df-tool-btn"><Paperclip size={16} /></button>
            <button className="df-tool-btn"><Mic size={16} /></button>
            <button className="df-send-btn" onClick={handleSend} disabled={!input.trim()}>
              <Send size={15} />
            </button>
          </div>
        </div>
        <div className="df-composer-hint">
          Techspecbot can be wrong. Verify important details. Press Enter to send, Shift+Enter for newline.
        </div>
      </div>
    </div>
  );
}

function DocumentsView() {
  return (
    <div className="df-chat">
      <div className="df-topbar">
        <div className="df-page-title">Doc<span className="df-accent">uments</span></div>
        <div className="df-topbar-actions">
          <button className="df-btn-primary"><Plus size={15} /> New document</button>
          <ThemeSwitcher />
        </div>
      </div>
      <div className="df-view-header">
        <div>
          <div className="df-view-title">All <span className="df-accent">documents</span></div>
          <div className="df-view-subtitle">{sampleDocs.length} documents in your workspace</div>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div className="df-documents-grid">
          {sampleDocs.map(d => (
            <div key={d.id} className="df-doc-card">
              <div className="df-doc-icon">{docIcon(d.type)}</div>
              <div className="df-doc-title">{d.title}</div>
              <div className="df-doc-meta">
                <span>Updated {d.updatedAt}</span>
                <span className={`df-doc-status ${d.status}`}>{d.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const uid = () => Math.random().toString(36).slice(2, 10);

function AppShell() {
  useFonts();
  const [view, setView] = useState('chat');
  const [conversations, setConversations] = useState([
    { id: 'c1', title: 'Auth service redesign', messages: [], updatedAt: Date.now() - 1800000 },
    { id: 'c2', title: 'Webhook delivery spec', messages: [], updatedAt: Date.now() - 7200000 },
    { id: 'c3', title: 'Onboarding PRD draft', messages: [], updatedAt: Date.now() - 86400000 },
  ]);
  const [activeConvId, setActiveConvId] = useState(null);
  const [isTyping, setIsTyping] = useState(false);
  const activeConv = conversations.find(c => c.id === activeConvId) || null;

  const handleNewChat = () => setActiveConvId(null);
  const handleSelectConv = (id) => { setActiveConvId(id); setView('chat'); };

  const handleSendMessage = (text) => {
    let convId = activeConvId;
    if (!convId) {
      const newConv = {
        id: uid(),
        title: text.length > 40 ? text.slice(0, 40) + '…' : text,
        messages: [], updatedAt: Date.now(),
      };
      setConversations(prev => [newConv, ...prev]);
      convId = newConv.id;
      setActiveConvId(convId);
    }
    const userMsg = { id: uid(), role: 'user', content: text, timestamp: Date.now() };
    setConversations(prev => prev.map(c =>
      c.id === convId ? { ...c, messages: [...c.messages, userMsg], updatedAt: Date.now() } : c
    ));
    setIsTyping(true);
    const replyText = generateReply(text);
    const delay = 700 + Math.min(replyText.length * 6, 1400);
    setTimeout(() => {
      const botMsg = { id: uid(), role: 'assistant', content: replyText, timestamp: Date.now() };
      setConversations(prev => prev.map(c =>
        c.id === convId ? { ...c, messages: [...c.messages, botMsg], updatedAt: Date.now() } : c
      ));
      setIsTyping(false);
    }, delay);
  };

  return (
    <>
      <style>{styles}</style>
      <div className="df-app">
        <Sidebar
          view={view} setView={setView}
          conversations={conversations}
          activeConvId={activeConvId}
          onSelectConv={handleSelectConv}
          onNewChat={handleNewChat}
        />
        <main className="df-main">
          {view === 'chat' ? (
            <ChatView conversation={activeConv} onSendMessage={handleSendMessage} isTyping={isTyping} />
          ) : (
            <DocumentsView />
          )}
        </main>
      </div>
    </>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppShell />
    </ThemeProvider>
  );
}
