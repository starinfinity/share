import os
from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    AZURE_OPENAI_ENDPOINT: str = Field(default="https://your-resource.openai.azure.com/")
    AZURE_OPENAI_KEY: str = Field(default="your-key-here")
    AZURE_OPENAI_DEPLOYMENT: str = Field(default="gpt-4o")
    AZURE_OPENAI_API_VERSION: str = Field(default="2024-02-15-preview")
    
    GITHUB_TOKEN: str = Field(default="")
    
    UPLOAD_DIR: str = Field(default="./uploads")
    MAX_THREAD_RESTARTS: int = Field(default=5)
    THREAD_RESTART_BACKOFF_SECONDS: int = Field(default=3)

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()

# Ensure upload directory exists
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
