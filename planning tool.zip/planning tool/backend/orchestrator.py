import os
import json
import time
import queue
import logging
import threading
from typing import Dict, List, Any
from backend.config import settings
from backend.services.document_service import DocumentService
from backend.services.azure_openai_service import AzureOpenAIService
from backend.services.github_service import GithubService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ThreadOrchestrator")

class ThreadOrchestrator:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        with cls._lock:
            if not cls._instance:
                cls._instance = super(ThreadOrchestrator, cls).__new__(cls, *args, **kwargs)
                cls._instance._initialized = False
            return cls._instance

    def __init__(self):
        if self._initialized:
            return
        
        self.doc_service = DocumentService()
        self.openai_service = AzureOpenAIService()
        self.github_service = GithubService()

        # Job state tracking
        self.state = {
            "thread1": {"status": "IDLE", "restarts": 0, "error": None, "last_active": None},
            "thread2": {"status": "IDLE", "restarts": 0, "error": None, "last_active": None},
            "thread3": {"status": "IDLE", "restarts": 0, "error": None, "last_active": None},
            "planning_input": {"github_url": None},
            "plan_draft": None,  # Will store {achievable: [], unachievable: [], plan: ""}
            "plan_final": None   # Will store final plan markdown string
        }
        self.state_lock = threading.Lock()

        # Queues for work
        self.req_queue = queue.Queue()
        self.knowledge_queue = queue.Queue()
        self.planning_queue = queue.Queue()

        # Coordination Events
        self.req_done_event = threading.Event()
        self.knowledge_done_event = threading.Event()

        # Paths for files
        self.req_file_path = os.path.join(settings.UPLOAD_DIR, "requirement.txt")
        self.knowledge_file_path = os.path.join(settings.UPLOAD_DIR, "knowledge.txt")
        self.plan_draft_path = os.path.join(settings.UPLOAD_DIR, "plan_draft.json")
        self.plan_final_path = os.path.join(settings.UPLOAD_DIR, "plan_final.txt")

        # Load existing files if any (to resume state)
        if os.path.exists(self.req_file_path):
            self.req_done_event.set()
        if os.path.exists(self.knowledge_file_path):
            self.knowledge_done_event.set()
        if os.path.exists(self.plan_draft_path):
            try:
                with open(self.plan_draft_path, "r", encoding="utf-8") as f:
                    self.state["plan_draft"] = json.load(f)
            except Exception:
                pass
        if os.path.exists(self.plan_final_path):
            try:
                with open(self.plan_final_path, "r", encoding="utf-8") as f:
                    self.state["plan_final"] = f.read()
            except Exception:
                pass

        # Thread objects
        self.threads = {}
        self.should_run = True

        # Start supervisor thread
        self.supervisor_thread = threading.Thread(target=self._monitor_threads, name="SupervisorThread", daemon=True)
        self.supervisor_thread.start()

        self._initialized = True
        logger.info("ThreadOrchestrator initialized and supervisor started.")

    def update_thread_state(self, thread_name: str, **kwargs):
        with self.state_lock:
            for k, v in kwargs.items():
                self.state[thread_name][k] = v
            self.state[thread_name]["last_active"] = time.time()

    def get_status(self) -> Dict[str, Any]:
        with self.state_lock:
            # Return deep-ish copy of thread states and plan presence
            return {
                "threads": {
                    "thread1": self.state["thread1"].copy(),
                    "thread2": self.state["thread2"].copy(),
                    "thread3": self.state["thread3"].copy(),
                },
                "requirements_complete": self.req_done_event.is_set(),
                "knowledge_complete": self.knowledge_done_event.is_set(),
                "plan_draft_ready": self.state["plan_draft"] is not None,
                "plan_final_ready": self.state["plan_final"] is not None,
                "github_url": self.state["planning_input"]["github_url"]
            }

    # --- Job Submissions ---

    def submit_requirements_job(self, file_path: str):
        self.req_done_event.clear()
        self.update_thread_state("thread1", status="PENDING", error=None)
        self.req_queue.put(file_path)
        logger.info(f"Submitted requirements file to queue: {file_path}")

    def submit_knowledge_job(self, file_paths: List[str]):
        self.knowledge_done_event.clear()
        self.update_thread_state("thread2", status="PENDING", error=None)
        self.knowledge_queue.put(file_paths)
        logger.info(f"Submitted {len(file_paths)} knowledge files to queue.")

    def submit_planning_job(self, github_url: str):
        with self.state_lock:
            self.state["planning_input"]["github_url"] = github_url
            self.state["plan_draft"] = None
        self.update_thread_state("thread3", status="PENDING", error=None)
        self.planning_queue.put(github_url)
        logger.info(f"Submitted planning job for repository: {github_url}")

    # --- Thread Workers Loop ---

    def _requirements_worker(self):
        logger.info("Thread 1 (Requirements) started.")
        while self.should_run:
            try:
                # Polling queue with timeout to allow thread shutdown/interrupt check
                try:
                    file_path = self.req_queue.get(timeout=1.0)
                except queue.Empty:
                    continue

                self.update_thread_state("thread1", status="RUNNING")
                logger.info(f"Thread 1 processing file: {file_path}")
                
                # 1. Extract text from uploaded document
                text = self.doc_service.extract_text_from_file(file_path)
                if not text.strip():
                    raise ValueError("Document was empty or text extraction failed.")

                # 2. Call Azure OpenAI to generate requirements text
                logger.info("Thread 1 calling Azure OpenAI...")
                reqs_txt_content = self.openai_service.generate_requirements(text)
                
                # 3. Save requirement.txt
                with open(self.req_file_path, "w", encoding="utf-8") as f:
                    f.write(reqs_txt_content)
                
                # 4. Clean up uploaded temporary file
                try:
                    os.remove(file_path)
                except Exception:
                    pass

                self.req_done_event.set()
                self.update_thread_state("thread1", status="COMPLETE")
                self.req_queue.task_done()
                logger.info("Thread 1 completed successfully.")

            except Exception as e:
                logger.error(f"Error in Thread 1: {e}")
                self.update_thread_state("thread1", status="FAILED", error=str(e))
                # Propagate exception to trigger supervisor restart
                raise e

    def _knowledge_worker(self):
        logger.info("Thread 2 (Knowledge) started.")
        while self.should_run:
            try:
                try:
                    file_paths = self.knowledge_queue.get(timeout=1.0)
                except queue.Empty:
                    continue

                self.update_thread_state("thread2", status="RUNNING")
                logger.info(f"Thread 2 processing files: {file_paths}")

                # 1. Extract text from all files
                extracted_texts = []
                for fp in file_paths:
                    file_name = os.path.basename(fp)
                    extracted_texts.append(f"=== File: {file_name} ===")
                    text = self.doc_service.extract_text_from_file(fp)
                    extracted_texts.append(text)
                
                combined_text = "\n\n".join(extracted_texts)
                if not combined_text.strip():
                    raise ValueError("Knowledge files were empty or text extraction failed.")

                # 2. Call Azure OpenAI to synthesize knowledge
                logger.info("Thread 2 calling Azure OpenAI...")
                knowledge_txt_content = self.openai_service.generate_knowledge(combined_text)

                # 3. Save knowledge.txt
                with open(self.knowledge_file_path, "w", encoding="utf-8") as f:
                    f.write(knowledge_txt_content)

                # 4. Clean up temp files
                for fp in file_paths:
                    try:
                        os.remove(fp)
                    except Exception:
                        pass

                self.knowledge_done_event.set()
                self.update_thread_state("thread2", status="COMPLETE")
                self.knowledge_queue.task_done()
                logger.info("Thread 2 completed successfully.")

            except Exception as e:
                logger.error(f"Error in Thread 2: {e}")
                self.update_thread_state("thread2", status="FAILED", error=str(e))
                raise e

    def _planning_worker(self):
        logger.info("Thread 3 (Planning) started.")
        while self.should_run:
            try:
                try:
                    github_url = self.planning_queue.get(timeout=1.0)
                except queue.Empty:
                    continue

                self.update_thread_state("thread3", status="WAITING_FOR_DEPS")
                logger.info("Thread 3 waiting for Thread 1 and Thread 2 to complete...")

                # Wait for Thread 1 and Thread 2
                while not (self.req_done_event.is_set() and self.knowledge_done_event.is_set()):
                    # Double check if any dependency has failed, so we don't wait forever
                    t1_status = self.state["thread1"]["status"]
                    t2_status = self.state["thread2"]["status"]
                    if t1_status == "FAILED" or t2_status == "FAILED":
                        raise RuntimeError("Cannot start planning because requirements or knowledge thread failed.")
                    
                    time.sleep(1.0)
                    if not self.should_run:
                        return

                self.update_thread_state("thread3", status="RUNNING")
                logger.info("Thread 1 and 2 completed. Analyzing Github repository...")

                # 1. Fetch Github details
                repo_details = self.github_service.fetch_repo_details(github_url)

                # 2. Read requirements and knowledge content
                with open(self.req_file_path, "r", encoding="utf-8") as f:
                    req_content = f.read()
                with open(self.knowledge_file_path, "r", encoding="utf-8") as f:
                    know_content = f.read()

                # 3. Call Azure OpenAI to generate planning lists + draft plan
                logger.info("Thread 3 generating implementation plan via Azure OpenAI...")
                plan_draft = self.openai_service.generate_initial_plan(repo_details, req_content, know_content)

                # 4. Save plan draft
                with self.state_lock:
                    self.state["plan_draft"] = plan_draft
                
                import json
                with open(self.plan_draft_path, "w", encoding="utf-8") as f:
                    json.dump(plan_draft, f, indent=2)

                self.update_thread_state("thread3", status="COMPLETE")
                self.planning_queue.task_done()
                logger.info("Thread 3 completed successfully.")

            except Exception as e:
                logger.error(f"Error in Thread 3: {e}")
                self.update_thread_state("thread3", status="FAILED", error=str(e))
                raise e

    # --- User Plan Revision ---

    def submit_plan_revision(self, achievable: List[str], unachievable: List[str], special_requests: str) -> str:
        """
        Runs synchronously (or inside backend router thread context) to rework the plan based on review list and special requests.
        """
        logger.info("Re-generating final plan based on user edits and requests...")
        
        draft = self.state["plan_draft"]
        previous_plan = draft.get("plan", "") if draft else ""

        final_plan = self.openai_service.regenerate_final_plan(
            achievable=achievable,
            unachievable=unachievable,
            special_requests=special_requests,
            previous_plan=previous_plan
        )

        with self.state_lock:
            self.state["plan_final"] = final_plan
            # update draft as well to reflect final lists
            if self.state["plan_draft"]:
                self.state["plan_draft"]["achievable"] = achievable
                self.state["plan_draft"]["unachievable"] = unachievable

        # Save to file
        with open(self.plan_final_path, "w", encoding="utf-8") as f:
            f.write(final_plan)
        
        # update draft file with new lists
        if self.state["plan_draft"]:
            import json
            with open(self.plan_draft_path, "w", encoding="utf-8") as f:
                json.dump(self.state["plan_draft"], f, indent=2)

        logger.info("Final plan successfully generated and saved.")
        return final_plan

    # --- Supervisor & Monitoring ---

    def _monitor_threads(self):
        """
        Runs in a separate thread. Regularly checks if worker threads are alive.
        If any worker thread exits with an exception, starts a new thread.
        """
        logger.info("Supervisor Thread monitoring started.")
        
        thread_targets = {
            "thread1": (self._requirements_worker, "RequirementsWorker"),
            "thread2": (self._knowledge_worker, "KnowledgeWorker"),
            "thread3": (self._planning_worker, "PlanningWorker")
        }

        # First boot: spawn all three threads
        for t_id, (target, name) in thread_targets.items():
            t = threading.Thread(target=target, name=name, daemon=True)
            self.threads[t_id] = t
            t.start()

        while self.should_run:
            time.sleep(1.0)
            
            for t_id, (target, name) in thread_targets.items():
                t = self.threads.get(t_id)
                
                # If thread has stopped and we expect it to be running
                if t is None or not t.is_alive():
                    # Check restart count
                    restarts = self.state[t_id]["restarts"]
                    if restarts >= settings.MAX_THREAD_RESTARTS:
                        logger.critical(f"Thread {name} has failed {restarts} times. Manual intervention required!")
                        continue

                    # If status is failed or it died unexpectedly
                    current_status = self.state[t_id]["status"]
                    
                    logger.warning(f"Thread {name} is dead. Status: {current_status}. Restarting...")
                    
                    # Backoff
                    backoff = settings.THREAD_RESTART_BACKOFF_SECONDS * (restarts + 1)
                    time.sleep(backoff)

                    # Update state
                    self.update_thread_state(t_id, restarts=restarts + 1, error=f"Thread restarted (Failure #{restarts + 1})")
                    
                    # Spawn new thread
                    new_t = threading.Thread(target=target, name=name, daemon=True)
                    self.threads[t_id] = new_t
                    new_t.start()
                    logger.info(f"Thread {name} successfully restarted.")

    def shutdown(self):
        self.should_run = False
        logger.info("ThreadOrchestrator shutting down workers.")
