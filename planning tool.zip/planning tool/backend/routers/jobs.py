import os
import shutil
import uuid
from typing import List
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, BackgroundTasks
from pydantic import BaseModel
from backend.orchestrator import ThreadOrchestrator
from backend.config import settings

router = APIRouter(prefix="/api")
orchestrator = ThreadOrchestrator()

class GitRepoPayload(BaseModel):
    github_url: str

class PlanReviewPayload(BaseModel):
    achievable: List[str]
    unachievable: List[str]
    special_requests: str

@router.post("/jobs/requirements")
def upload_requirements(file: UploadFile = File(...)):
    """
    Endpoint for uploading a single requirements document. Starts Thread 1.
    """
    # Create unique temp name in upload folder
    file_id = str(uuid.uuid4())
    _, ext = os.path.splitext(file.filename)
    temp_path = os.path.join(settings.UPLOAD_DIR, f"req_input_{file_id}{ext}")
    
    try:
        with open(temp_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save uploaded file: {str(e)}")

    orchestrator.submit_requirements_job(temp_path)
    return {"message": "Requirements processing started (Thread 1)", "filename": file.filename}

@router.post("/jobs/knowledge")
def upload_knowledge(files: List[UploadFile] = File(...)):
    """
    Endpoint for uploading one or more Word/Excel/Txt documents for Thread 2.
    """
    temp_paths = []
    for file in files:
        file_id = str(uuid.uuid4())
        _, ext = os.path.splitext(file.filename)
        temp_path = os.path.join(settings.UPLOAD_DIR, f"know_input_{file_id}{ext}")
        try:
            with open(temp_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
            temp_paths.append(temp_path)
        except Exception as e:
            # Cleanup already written files
            for tp in temp_paths:
                try:
                    os.remove(tp)
                except Exception:
                    pass
            raise HTTPException(status_code=500, detail=f"Failed to save uploaded file {file.filename}: {str(e)}")

    orchestrator.submit_knowledge_job(temp_paths)
    return {"message": f"Knowledge processing started (Thread 2) with {len(files)} files"}

@router.post("/jobs/plan")
def start_planning(payload: GitRepoPayload):
    """
    Endpoint for triggering planning using Github URL. Starts Thread 3.
    """
    if not payload.github_url or "github.com" not in payload.github_url.lower():
        raise HTTPException(status_code=400, detail="Invalid GitHub repository URL.")
    
    orchestrator.submit_planning_job(payload.github_url)
    return {"message": "Planning process started (Thread 3)"}

@router.get("/jobs/status")
def get_jobs_status():
    """
    Polls the current status of all 3 threads and plan creation status.
    """
    return orchestrator.get_status()

@router.get("/plan/draft")
def get_plan_draft():
    """
    Retrieves the parsed draft plan containing achievable, unachievable, and detailed plan.
    """
    status = orchestrator.get_status()
    if not status["plan_draft_ready"]:
        raise HTTPException(status_code=404, detail="Plan draft not ready yet. Please wait for Thread 3 to complete.")
    return orchestrator.state["plan_draft"]

@router.post("/plan/review")
def submit_plan_review(payload: PlanReviewPayload):
    """
    Endpoint for submitting user-edited achievable/unachievable lists and special requests.
    Generates the final plan.
    """
    # Ensure draft is ready
    status = orchestrator.get_status()
    if not status["plan_draft_ready"]:
        raise HTTPException(status_code=400, detail="Plan draft is not ready. You cannot review yet.")

    try:
        final_plan = orchestrator.submit_plan_revision(
            achievable=payload.achievable,
            unachievable=payload.unachievable,
            special_requests=payload.special_requests
        )
        return {"message": "Final plan generated successfully", "final_plan": final_plan}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate final plan: {str(e)}")

@router.get("/plan/final")
def get_final_plan():
    """
    Retrieves the final regenerated plan.
    """
    status = orchestrator.get_status()
    if not status["plan_final_ready"]:
        raise HTTPException(status_code=404, detail="Final plan is not ready. Please complete reviews and submit.")
    return {"final_plan": orchestrator.state["plan_final"]}

@router.post("/jobs/reset")
def reset_jobs():
    """
    Utility endpoint to reset the system state and clean files.
    """
    orchestrator.req_done_event.clear()
    orchestrator.knowledge_done_event.clear()
    
    with orchestrator.state_lock:
        orchestrator.state["plan_draft"] = None
        orchestrator.state["plan_final"] = None
        orchestrator.state["planning_input"]["github_url"] = None
        
        # Clear errors
        for t_id in ["thread1", "thread2", "thread3"]:
            orchestrator.state[t_id]["error"] = None
            orchestrator.state[t_id]["status"] = "IDLE"

    # Remove files if they exist
    for filepath in [orchestrator.req_file_path, orchestrator.knowledge_file_path, 
                      orchestrator.plan_draft_path, orchestrator.plan_final_path]:
        if os.path.exists(filepath):
            try:
                os.remove(filepath)
            except Exception:
                pass
                
    return {"message": "State reset successful"}
