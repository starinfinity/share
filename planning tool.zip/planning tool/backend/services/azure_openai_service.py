import json
import logging
from openai import AzureOpenAI
from backend.config import settings
from tenacity import retry, stop_after_attempt, wait_exponential

logger = logging.getLogger(__name__)

class AzureOpenAIService:
    def __init__(self):
        self.client = AzureOpenAI(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_key=settings.AZURE_OPENAI_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION
        )
        self.model = settings.AZURE_OPENAI_DEPLOYMENT

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    def generate_requirements(self, doc_text: str) -> str:
        """
        Thread 1: Processes document to generate requirements.txt content/structure.
        """
        system_prompt = (
            "You are a Senior Systems Analyst. Analyze the following document text and "
            "extract the functional and technical requirements. "
            "Format the output clearly. Group them by category. "
            "Write the response exactly as a structured document description detailing all requirements, "
            "which will be saved in requirements.txt."
        )
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Document text:\n\n{doc_text}"}
            ],
            temperature=0.2
        )
        return response.choices[0].message.content

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    def generate_knowledge(self, docs_text: str) -> str:
        """
        Thread 2: Processes multiple word/excel documents to generate knowledge.txt.
        """
        system_prompt = (
            "You are a Knowledge Management specialist. Synthesize the provided information from "
            "various documents into a unified knowledge.txt format. "
            "Highlight domain rules, definitions, architecture notes, databases, "
            "and business workflows that are essential for implementation."
        )
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f"Synthesized documents text:\n\n{docs_text}"}
            ],
            temperature=0.2
        )
        return response.choices[0].message.content

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    def generate_initial_plan(self, code_structure: str, requirements: str, knowledge: str) -> dict:
        """
        Thread 3: Combines Github repository structure, requirements, and knowledge to generate a plan.
        It must output a JSON structure with achievable and unachievable tasks, plus a detailed description.
        """
        system_prompt = (
            "You are an AI Architect. You are given a code repository structure/details, "
            "a requirements file (requirements.txt), and a knowledge base (knowledge.txt).\n\n"
            "Your task is to analyze these materials and split the requirements into two lists:\n"
            "1. Achievable Tasks: Requirements that can be done given the current repository structure and knowledge.\n"
            "2. Unachievable Tasks: Requirements that are impossible, conflict with the knowledge base, or require "
            "missing systems/frameworks not present or planned.\n\n"
            "Then, write a detailed step-by-step implementation plan.\n\n"
            "You MUST respond ONLY with a valid JSON object matching this schema:\n"
            "{\n"
            '  "achievable": ["task 1 description", "task 2 description", ...],\n'
            '  "unachievable": ["task A description", ...],\n'
            '  "plan": "Detailed markdown formatted step-by-step implementation plan."\n'
            "}"
        )
        
        user_content = (
            f"--- GITHUB REPO DETAILS ---\n{code_structure}\n\n"
            f"--- REQUIREMENTS (requirements.txt) ---\n{requirements}\n\n"
            f"--- KNOWLEDGE BASE (knowledge.txt) ---\n{knowledge}"
        )

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content}
            ],
            response_format={"type": "json_object"},
            temperature=0.3
        )
        try:
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            logger.error(f"Failed to parse JSON response from OpenAI: {e}")
            # Fallback structure
            return {
                "achievable": ["Error parsing initial plan: Check Azure OpenAI output"],
                "unachievable": [],
                "plan": f"Raw output:\n\n{response.choices[0].message.content}"
            }

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=2, max=10))
    def regenerate_final_plan(self, 
                              achievable: list, 
                              unachievable: list, 
                              special_requests: str, 
                              previous_plan: str) -> str:
        """
        Final step: Reworks the plan based on user edits of achievable/unachievable lists and special requests.
        """
        system_prompt = (
            "You are a Lead AI Architect. The user has reviewed and updated the lists of "
            "Achievable and Unachievable tasks, and added some Special Requests.\n"
            "Rework the implementation plan to reflect these changes. Make it highly detailed, "
            "structured with markdown headers, lists, code block stubs where appropriate, and step-by-step instructions. "
            "Address all special requests explicitly."
        )

        user_content = (
            f"--- USER-EDITED ACHIEVABLE TASKS ---\n{json.dumps(achievable, indent=2)}\n\n"
            f"--- USER-EDITED UNACHIEVABLE TASKS ---\n{json.dumps(unachievable, indent=2)}\n\n"
            f"--- SPECIAL REQUESTS ---\n{special_requests}\n\n"
            f"--- PREVIOUS PLAN DRAFT ---\n{previous_plan}"
        )

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content}
            ],
            temperature=0.3
        )
        return response.choices[0].message.content
