import os
import docx
import pdfplumber
import openpyxl
from typing import List

class DocumentService:
    @staticmethod
    def extract_text_from_file(file_path: str) -> str:
        _, ext = os.path.splitext(file_path.lower())
        if ext == ".txt":
            return DocumentService.extract_txt(file_path)
        elif ext == ".docx":
            return DocumentService.extract_docx(file_path)
        elif ext == ".pdf":
            return DocumentService.extract_pdf(file_path)
        elif ext in [".xlsx", ".xls"]:
            return DocumentService.extract_excel(file_path)
        else:
            raise ValueError(f"Unsupported file format: {ext}")

    @staticmethod
    def extract_txt(file_path: str) -> str:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    @staticmethod
    def extract_docx(file_path: str) -> str:
        doc = docx.Document(file_path)
        full_text = []
        for para in doc.paragraphs:
            full_text.append(para.text)
        for table in doc.tables:
            for row in table.rows:
                row_text = [cell.text for cell in row.cells]
                full_text.append(" | ".join(row_text))
        return "\n".join(full_text)

    @staticmethod
    def extract_pdf(file_path: str) -> str:
        full_text = []
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    full_text.append(text)
        return "\n".join(full_text)

    @staticmethod
    def extract_excel(file_path: str) -> str:
        wb = openpyxl.load_workbook(file_path, data_only=True)
        full_text = []
        for sheet_name in wb.sheetnames:
            sheet = wb[sheet_name]
            full_text.append(f"--- Sheet: {sheet_name} ---")
            for row in sheet.iter_rows(values_only=True):
                if any(row):  # skip empty rows
                    row_str = " | ".join([str(val) if val is not None else "" for val in row])
                    full_text.append(row_str)
        return "\n".join(full_text)
