import re
import logging
from github import Github
from backend.config import settings

logger = logging.getLogger(__name__)

class GithubService:
    def __init__(self):
        token = settings.GITHUB_TOKEN if settings.GITHUB_TOKEN else None
        self.g = Github(login_or_token=token)

    def parse_repo_url(self, url: str) -> tuple:
        """
        Parses github URL into owner and repo name.
        Supports:
        - https://github.com/owner/repo
        - github.com/owner/repo
        - owner/repo
        """
        url = url.strip()
        pattern = r"(?:https?://)?(?:www\.)?github\.com/([^/]+)/([^/]+?)(?:\.git|/)?$"
        match = re.match(pattern, url)
        if match:
            return match.group(1), match.group(2)
        
        # If it's already in format owner/repo
        parts = url.split("/")
        if len(parts) == 2:
            return parts[0], parts[1]
        
        raise ValueError(f"Invalid GitHub URL or repo format: {url}")

    def fetch_repo_details(self, repo_url: str) -> str:
        """
        Fetches repository file tree structure and reads key project files
        (like README.md, package.json, requirements.txt, setup.py, go.mod, etc.)
        to provide context for the code analysis.
        """
        try:
            owner, repo_name = self.parse_repo_url(repo_url)
            repo = self.g.get_repo(f"{owner}/{repo_name}")
            
            # Recursively fetch repository tree structure
            tree = repo.get_git_tree(repo.default_branch, recursive=True)
            
            file_paths = []
            key_files_content = []
            
            # Key files to read content for context
            target_config_files = {
                "readme.md", "package.json", "requirements.txt", "pipfile", "pyproject.toml",
                "gemfile", "cargo.toml", "go.mod", "dockerfile", "docker-compose.yml",
                "webpack.config.js", "tsconfig.json", "vite.config.ts"
            }

            for element in tree.tree:
                path = element.path
                file_paths.append(path)
                
                # Check if it's a key configuration file (case-insensitive check)
                filename = path.split("/")[-1].lower()
                if filename in target_config_files and element.type == "blob":
                    try:
                        content_file = repo.get_contents(path)
                        decoded = content_file.decoded_content.decode("utf-8", errors="ignore")
                        # Truncate content if too large (e.g., max 4000 characters per config file)
                        if len(decoded) > 4000:
                            decoded = decoded[:4000] + "\n... (truncated)"
                        key_files_content.append(f"--- File: {path} ---\n{decoded}")
                    except Exception as e:
                        logger.warning(f"Failed to fetch content for {path}: {e}")

            # Combine everything
            repo_structure_str = "\n".join(file_paths[:150])  # limit file paths listing to first 150 files to prevent token blowup
            if len(file_paths) > 150:
                repo_structure_str += f"\n... and {len(file_paths) - 150} more files."

            key_contents_str = "\n\n".join(key_files_content)

            output = (
                f"Repository: {owner}/{repo_name}\n"
                f"Default Branch: {repo.default_branch}\n\n"
                f"--- Directory Tree Structure ---\n{repo_structure_str}\n\n"
                f"--- Key Project Config Files ---\n{key_contents_str}"
            )
            return output

        except Exception as e:
            logger.error(f"Error fetching Github details: {e}")
            raise Exception(f"Github API error: {str(e)}")
