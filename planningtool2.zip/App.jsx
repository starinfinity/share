import { useState, useEffect, useRef } from "react";

const DEFAULT_BASE = "http://localhost:8000";

const EFFORT_COLORS = { XS: "#639922", S: "#1D9E75", M: "#BA7517", L: "#D85A30", XL: "#A32D2D" };
const PRIORITY_COLORS = { Critical: "#A32D2D", High: "#BA7517", Medium: "#185FA5", Low: "#3B6D11" };
const STATUS_CONFIG = {
  idle:       { bg: "#F1EFE8", color: "#5F5E5A", label: "Idle" },
  running:    { bg: "#E6F1FB", color: "#185FA5", label: "Running…" },
  waiting:    { bg: "#E6F1FB", color: "#185FA5", label: "Waiting…" },
  completed:  { bg: "#EAF3DE", color: "#3B6D11", label: "Done" },
  failed:     { bg: "#FCEBEB", color: "#A32D2D", label: "Failed" },
  restarting: { bg: "#FAEEDA", color: "#854F0B", label: "Restarting" },
};

const steps = ["Upload", "Documents", "GitHub", "Monitor", "Review", "Final Plan"];

function Badge({ label, color, bg }) {
  return (
    <span style={{ background: bg, color, fontSize: 11, fontWeight: 500, padding: "2px 8px", borderRadius: 99, letterSpacing: "0.02em" }}>
      {label}
    </span>
  );
}

function ThreadCard({ name, label, desc, thread }) {
  const cfg = STATUS_CONFIG[thread?.status ?? "idle"] ?? STATUS_CONFIG.idle;
  const retries = thread?.retry_count ?? 0;
  return (
    <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-lg)", padding: "14px 18px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
        <span style={{ width: 28, height: 28, borderRadius: "50%", background: cfg.bg, color: cfg.color, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 500, fontSize: 12 }}>{name}</span>
        <div style={{ flex: 1 }}>
          <p style={{ margin: 0, fontWeight: 500, fontSize: 14 }}>{label}</p>
          <p style={{ margin: 0, fontSize: 12, color: "var(--color-text-secondary)" }}>{desc}</p>
        </div>
        <Badge label={cfg.label} color={cfg.color} bg={cfg.bg} />
      </div>
      {thread?.error && <p style={{ margin: "6px 0 0", fontSize: 12, color: "#A32D2D", background: "#FCEBEB", padding: "6px 10px", borderRadius: 6 }}>{thread.error}</p>}
      {retries > 0 && <p style={{ margin: "4px 0 0", fontSize: 11, color: "var(--color-text-secondary)" }}>Retry {retries}/{thread?.max_retries ?? 3}</p>}
    </div>
  );
}

function TaskCard({ task, type, onEdit, onRemove }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(task.title);
  const [notes, setNotes] = useState(task.technical_notes ?? task.reason ?? "");

  const save = () => { onEdit({ ...task, title: val, technical_notes: notes, reason: notes }); setEditing(false); };

  return (
    <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "12px 14px", marginBottom: 8 }}>
      {editing ? (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <input value={val} onChange={e => setVal(e.target.value)} style={{ width: "100%", boxSizing: "border-box" }} />
          <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3} style={{ width: "100%", boxSizing: "border-box", resize: "vertical" }} />
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={save}>Save</button>
            <button onClick={() => setEditing(false)}>Cancel</button>
          </div>
        </div>
      ) : (
        <div>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", marginBottom: 4 }}>
                <span style={{ fontSize: 11, fontWeight: 500, color: "var(--color-text-secondary)", fontFamily: "var(--font-mono)" }}>{task.id}</span>
                {type === "achievable" && task.priority && (
                  <Badge label={task.priority} color={PRIORITY_COLORS[task.priority] ?? "#185FA5"} bg={task.priority === "Critical" ? "#FCEBEB" : task.priority === "High" ? "#FAEEDA" : "#E6F1FB"} />
                )}
                {type === "achievable" && task.effort && (
                  <Badge label={task.effort} color={EFFORT_COLORS[task.effort] ?? "#5F5E5A"} bg="#F1EFE8" />
                )}
              </div>
              <p style={{ margin: "0 0 4px", fontWeight: 500, fontSize: 14 }}>{task.title}</p>
              <p style={{ margin: 0, fontSize: 13, color: "var(--color-text-secondary)", lineHeight: 1.5 }}>{task.description}</p>
              {type === "unachievable" && task.reason && (
                <p style={{ margin: "6px 0 0", fontSize: 12, color: "#A32D2D" }}><strong>Reason:</strong> {task.reason}</p>
              )}
              {type === "unachievable" && task.alternative && (
                <p style={{ margin: "4px 0 0", fontSize: 12, color: "#3B6D11" }}><strong>Alternative:</strong> {task.alternative}</p>
              )}
            </div>
            <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
              <button onClick={() => setEditing(true)} style={{ padding: "4px 8px", fontSize: 12 }} title="Edit"><i className="ti ti-edit" aria-hidden="true" /></button>
              <button onClick={() => onRemove(task.id)} style={{ padding: "4px 8px", fontSize: 12, color: "#A32D2D" }} title="Remove"><i className="ti ti-trash" aria-hidden="true" /></button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ProgressBar({ value }) {
  return (
    <div style={{ height: 4, background: "var(--color-background-secondary)", borderRadius: 99, overflow: "hidden", margin: "4px 0 0" }}>
      <div style={{ height: "100%", width: `${value}%`, background: "#1D9E75", borderRadius: 99, transition: "width 0.4s ease" }} />
    </div>
  );
}

export default function App() {
  const [base, setBase] = useState(DEFAULT_BASE);
  const [step, setStep] = useState(0);
  const [status, setStatus] = useState({ threads: {}, outputs: {} });
  const [plan, setPlan] = useState(null);
  const [finalPlan, setFinalPlan] = useState(null);
  const [achievable, setAchievable] = useState([]);
  const [unachievable, setUnachievable] = useState([]);
  const [specialReq, setSpecialReq] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [reqFile, setReqFile] = useState(null);
  const [docFiles, setDocFiles] = useState([]);
  const [githubUrl, setGithubUrl] = useState("");
  const [moveTarget, setMoveTarget] = useState({});
  const pollRef = useRef(null);

  const api = async (path, opts = {}) => {
    const r = await fetch(`${base}${path}`, opts);
    if (r.status === 202) return { _pending: true, ...(await r.json()) };
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.detail ?? r.statusText); }
    return r.json();
  };

  const fetchStatus = async () => {
    try {
      const s = await api("/status");
      setStatus(s);
    } catch { /* silent */ }
  };

  useEffect(() => {
    if (step === 3) {
      fetchStatus();
      pollRef.current = setInterval(fetchStatus, 2500);
    }
    return () => clearInterval(pollRef.current);
  }, [step]);

  useEffect(() => {
    if (step === 3 && status.outputs?.plan_ready && !plan) {
      api("/plan").then(p => {
        if (!p._pending) {
          setPlan(p);
          setAchievable(p.achievable_tasks ?? []);
          setUnachievable(p.unachievable_tasks ?? []);
          clearInterval(pollRef.current);
        }
      }).catch(() => {});
    }
  }, [status, step]);

  const startThread1 = async () => {
    if (!reqFile) return setError("Please select a file.");
    setLoading(true); setError("");
    try {
      const fd = new FormData();
      fd.append("file", reqFile);
      await api("/thread1/start", { method: "POST", body: fd });
      setStep(1);
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const startThread2 = async () => {
    if (!docFiles.length) return setError("Please select at least one file.");
    setLoading(true); setError("");
    try {
      const fd = new FormData();
      docFiles.forEach(f => fd.append("files", f));
      await api("/thread2/start", { method: "POST", body: fd });
      setStep(2);
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const startThread3 = async () => {
    if (!githubUrl.trim()) return setError("Please enter a GitHub repository URL.");
    setLoading(true); setError("");
    try {
      await api("/thread3/start", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ repo_url: githubUrl }) });
      setStep(3);
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const submitFinal = async () => {
    setLoading(true); setError("");
    try {
      const fp = await api("/plan/finalize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ achievable_tasks: achievable, unachievable_tasks: unachievable, special_requests: specialReq }),
      });
      setFinalPlan(fp);
      setStep(5);
    } catch (e) { setError(e.message); }
    setLoading(false);
  };

  const moveTask = (id, from, to) => {
    if (from === "achievable") {
      const task = achievable.find(t => t.id === id);
      if (task) { setAchievable(achievable.filter(t => t.id !== id)); setUnachievable([...unachievable, task]); }
    } else {
      const task = unachievable.find(t => t.id === id);
      if (task) { setUnachievable(unachievable.filter(t => t.id !== id)); setAchievable([...achievable, task]); }
    }
  };

  const allThreadsDone = () => {
    const t = status.threads;
    return t.thread1?.status === "completed" && t.thread2?.status === "completed";
  };

  const thread3Status = status.threads?.thread3?.status;

  const progressPct = () => {
    let n = 0;
    if (status.threads?.thread1?.status === "completed") n++;
    if (status.threads?.thread2?.status === "completed") n++;
    if (thread3Status === "completed") n++;
    return Math.round((n / 3) * 100);
  };

  return (
    <div style={{ padding: "1.5rem 0", maxWidth: 680, margin: "0 auto", fontFamily: "var(--font-sans)" }}>
      <h2 style={{ sr_only: true }} className="sr-only">AI Project Planner</h2>

      {/* Header */}
      <div style={{ marginBottom: "1.5rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
          <i className="ti ti-brain" style={{ fontSize: 22, color: "#534AB7" }} aria-hidden="true" />
          <h2 style={{ margin: 0, fontSize: 20, fontWeight: 500 }}>AI Project Planner</h2>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {steps.map((s, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 4 }}>
              <span style={{ fontSize: 12, padding: "3px 10px", borderRadius: 99, background: i === step ? "#EEEDFE" : i < step ? "#EAF3DE" : "var(--color-background-secondary)", color: i === step ? "#534AB7" : i < step ? "#3B6D11" : "var(--color-text-secondary)", fontWeight: i === step ? 500 : 400 }}>
                {i < step && <i className="ti ti-check" style={{ fontSize: 11, marginRight: 3 }} aria-hidden="true" />}{s}
              </span>
              {i < steps.length - 1 && <i className="ti ti-chevron-right" style={{ fontSize: 12, color: "var(--color-text-secondary)" }} aria-hidden="true" />}
            </div>
          ))}
        </div>
      </div>

      {/* Base URL config */}
      <div style={{ background: "var(--color-background-secondary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "10px 14px", marginBottom: "1.25rem", display: "flex", alignItems: "center", gap: 10 }}>
        <i className="ti ti-settings" style={{ fontSize: 16, color: "var(--color-text-secondary)" }} aria-hidden="true" />
        <span style={{ fontSize: 13, color: "var(--color-text-secondary)", flexShrink: 0 }}>API base:</span>
        <input value={base} onChange={e => setBase(e.target.value)} style={{ flex: 1, fontSize: 13 }} />
      </div>

      {error && (
        <div style={{ background: "#FCEBEB", color: "#A32D2D", fontSize: 13, padding: "10px 14px", borderRadius: "var(--border-radius-md)", marginBottom: "1rem", display: "flex", gap: 8 }}>
          <i className="ti ti-alert-circle" style={{ flexShrink: 0, marginTop: 1 }} aria-hidden="true" />
          {error}
        </div>
      )}

      {/* ─── Step 0: Upload requirement document ─────────────────────────── */}
      {step === 0 && (
        <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-lg)", padding: "1.5rem" }}>
          <div style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: "1.25rem" }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#EEEDFE", color: "#534AB7", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 500, flexShrink: 0 }}>1</div>
            <div>
              <p style={{ margin: 0, fontWeight: 500, fontSize: 15 }}>Upload requirement document</p>
              <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--color-text-secondary)" }}>Thread 1 will extract and structure all requirements using Azure OpenAI and save them to <code>requirement.txt</code>.</p>
            </div>
          </div>
          <label style={{ display: "block", border: "0.5px dashed var(--color-border-secondary)", borderRadius: "var(--border-radius-md)", padding: "1.5rem", textAlign: "center", cursor: "pointer", background: "var(--color-background-secondary)" }}>
            <i className="ti ti-upload" style={{ fontSize: 28, color: "var(--color-text-secondary)", display: "block", marginBottom: 8 }} aria-hidden="true" />
            <span style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>{reqFile ? reqFile.name : "Click to select a file (.docx, .pdf, .txt, .xlsx…)"}</span>
            <input type="file" style={{ display: "none" }} accept=".txt,.docx,.doc,.pdf,.xlsx,.xls,.md" onChange={e => setReqFile(e.target.files[0])} />
          </label>
          <button onClick={startThread1} disabled={loading || !reqFile} style={{ marginTop: "1rem", width: "100%" }}>
            {loading ? "Starting…" : "Start Thread 1 — Generate requirements.txt →"}
          </button>
        </div>
      )}

      {/* ─── Step 1: Upload knowledge documents ──────────────────────────── */}
      {step === 1 && (
        <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-lg)", padding: "1.5rem" }}>
          <div style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: "1.25rem" }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#E1F5EE", color: "#0F6E56", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 500, flexShrink: 0 }}>2</div>
            <div>
              <p style={{ margin: 0, fontWeight: 500, fontSize: 15 }}>Upload knowledge documents</p>
              <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--color-text-secondary)" }}>Thread 2 reads one or more Word/Excel documents and synthesises a <code>knowledge.txt</code> knowledge base. Thread 1 is already running in parallel.</p>
            </div>
          </div>
          <label style={{ display: "block", border: "0.5px dashed var(--color-border-secondary)", borderRadius: "var(--border-radius-md)", padding: "1.5rem", textAlign: "center", cursor: "pointer", background: "var(--color-background-secondary)" }}>
            <i className="ti ti-files" style={{ fontSize: 28, color: "var(--color-text-secondary)", display: "block", marginBottom: 8 }} aria-hidden="true" />
            <span style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>
              {docFiles.length ? `${docFiles.length} file(s) selected` : "Click to select files (.docx, .xlsx, .pdf…)"}
            </span>
            <input type="file" style={{ display: "none" }} accept=".txt,.docx,.doc,.pdf,.xlsx,.xls,.md" multiple onChange={e => setDocFiles(Array.from(e.target.files))} />
          </label>
          {docFiles.length > 0 && (
            <ul style={{ margin: "10px 0 0", padding: 0, listStyle: "none" }}>
              {docFiles.map((f, i) => (
                <li key={i} style={{ fontSize: 13, color: "var(--color-text-secondary)", display: "flex", alignItems: "center", gap: 6, padding: "3px 0" }}>
                  <i className="ti ti-file" style={{ fontSize: 14 }} aria-hidden="true" />{f.name}
                </li>
              ))}
            </ul>
          )}
          <button onClick={startThread2} disabled={loading || !docFiles.length} style={{ marginTop: "1rem", width: "100%" }}>
            {loading ? "Starting…" : "Start Thread 2 — Generate knowledge.txt →"}
          </button>
        </div>
      )}

      {/* ─── Step 2: GitHub repo ──────────────────────────────────────────── */}
      {step === 2 && (
        <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-lg)", padding: "1.5rem" }}>
          <div style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: "1.25rem" }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#FAEEDA", color: "#854F0B", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 500, flexShrink: 0 }}>3</div>
            <div>
              <p style={{ margin: 0, fontWeight: 500, fontSize: 15 }}>GitHub repository</p>
              <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--color-text-secondary)" }}>Thread 3 waits for threads 1 and 2, then analyses the GitHub repository alongside the generated files to produce the project plan.</p>
            </div>
          </div>
          <label style={{ fontSize: 13, color: "var(--color-text-secondary)", display: "block", marginBottom: 6 }}>Repository URL</label>
          <input value={githubUrl} onChange={e => setGithubUrl(e.target.value)} placeholder="https://github.com/owner/repo" style={{ width: "100%", boxSizing: "border-box" }} />
          <button onClick={startThread3} disabled={loading || !githubUrl.trim()} style={{ marginTop: "1rem", width: "100%" }}>
            {loading ? "Starting…" : "Start Thread 3 — Generate plan →"}
          </button>
        </div>
      )}

      {/* ─── Step 3: Monitor threads ──────────────────────────────────────── */}
      {step === 3 && (
        <div>
          <div style={{ marginBottom: "1rem" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontSize: 13, fontWeight: 500 }}>Overall progress</span>
              <span style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>{progressPct()}%</span>
            </div>
            <ProgressBar value={progressPct()} />
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: "1.25rem" }}>
            <ThreadCard name="T1" label="Requirements extraction" desc="Document → requirement.txt" thread={status.threads?.thread1} />
            <ThreadCard name="T2" label="Knowledge base synthesis" desc="Documents → knowledge.txt" thread={status.threads?.thread2} />
            <ThreadCard name="T3" label="Plan generation" desc="Waits for T1 & T2, then generates plan" thread={status.threads?.thread3} />
          </div>

          {thread3Status === "completed" && plan ? (
            <button onClick={() => setStep(4)} style={{ width: "100%" }}>
              Review plan <i className="ti ti-arrow-right" aria-hidden="true" />
            </button>
          ) : (
            <div style={{ background: "var(--color-background-secondary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "12px 16px", textAlign: "center" }}>
              <i className="ti ti-loader" style={{ fontSize: 18, color: "var(--color-text-secondary)", marginRight: 8 }} aria-hidden="true" />
              <span style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>Polling every 2.5s… Plan will appear when Thread 3 completes.</span>
            </div>
          )}
        </div>
      )}

      {/* ─── Step 4: Review plan ─────────────────────────────────────────── */}
      {step === 4 && plan && (
        <div>
          <div style={{ background: "var(--color-background-secondary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "12px 16px", marginBottom: "1.25rem" }}>
            <p style={{ margin: 0, fontSize: 14, lineHeight: 1.6 }}>{plan.summary}</p>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: "1.25rem" }}>
            {[{ label: "Achievable", val: achievable.length, color: "#3B6D11", bg: "#EAF3DE" },
              { label: "Unachievable", val: unachievable.length, color: "#A32D2D", bg: "#FCEBEB" },
              { label: "Est. days", val: plan.estimated_total_days ?? "—", color: "#185FA5", bg: "#E6F1FB" }
            ].map(m => (
              <div key={m.label} style={{ background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", padding: "10px 14px" }}>
                <p style={{ margin: "0 0 2px", fontSize: 12, color: "var(--color-text-secondary)" }}>{m.label}</p>
                <p style={{ margin: 0, fontSize: 22, fontWeight: 500, color: m.color }}>{m.val}</p>
              </div>
            ))}
          </div>

          {/* Achievable tasks */}
          <div style={{ marginBottom: "1.25rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <i className="ti ti-circle-check" style={{ fontSize: 18, color: "#3B6D11" }} aria-hidden="true" />
              <h3 style={{ margin: 0, fontSize: 15, fontWeight: 500 }}>Achievable tasks</h3>
              <Badge label={achievable.length} color="#3B6D11" bg="#EAF3DE" />
            </div>
            {achievable.length === 0 && <p style={{ color: "var(--color-text-secondary)", fontSize: 13 }}>No achievable tasks.</p>}
            {achievable.map(t => (
              <div key={t.id}>
                <TaskCard task={t} type="achievable"
                  onEdit={updated => setAchievable(achievable.map(x => x.id === updated.id ? updated : x))}
                  onRemove={id => setAchievable(achievable.filter(x => x.id !== id))}
                />
                <button onClick={() => moveTask(t.id, "achievable", "unachievable")} style={{ fontSize: 11, padding: "2px 8px", marginBottom: 8, color: "#A32D2D" }}>
                  <i className="ti ti-arrow-down" aria-hidden="true" /> Move to unachievable
                </button>
              </div>
            ))}
          </div>

          {/* Unachievable tasks */}
          <div style={{ marginBottom: "1.5rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <i className="ti ti-circle-x" style={{ fontSize: 18, color: "#A32D2D" }} aria-hidden="true" />
              <h3 style={{ margin: 0, fontSize: 15, fontWeight: 500 }}>Unachievable tasks</h3>
              <Badge label={unachievable.length} color="#A32D2D" bg="#FCEBEB" />
            </div>
            {unachievable.length === 0 && <p style={{ color: "var(--color-text-secondary)", fontSize: 13 }}>No unachievable tasks.</p>}
            {unachievable.map(t => (
              <div key={t.id}>
                <TaskCard task={t} type="unachievable"
                  onEdit={updated => setUnachievable(unachievable.map(x => x.id === updated.id ? updated : x))}
                  onRemove={id => setUnachievable(unachievable.filter(x => x.id !== id))}
                />
                <button onClick={() => moveTask(t.id, "unachievable", "achievable")} style={{ fontSize: 11, padding: "2px 8px", marginBottom: 8, color: "#3B6D11" }}>
                  <i className="ti ti-arrow-up" aria-hidden="true" /> Move to achievable
                </button>
              </div>
            ))}
          </div>

          {/* Special requests */}
          <div style={{ marginBottom: "1.25rem" }}>
            <label style={{ fontSize: 14, fontWeight: 500, display: "block", marginBottom: 8 }}>
              <i className="ti ti-sparkles" style={{ marginRight: 6 }} aria-hidden="true" />Special requests
            </label>
            <textarea value={specialReq} onChange={e => setSpecialReq(e.target.value)} rows={4} placeholder="Add any special instructions, additional context, or requests for the final plan…" style={{ width: "100%", boxSizing: "border-box" }} />
          </div>

          <button onClick={submitFinal} disabled={loading} style={{ width: "100%" }}>
            {loading ? "Generating final plan…" : "Submit for final plan →"}
          </button>
        </div>
      )}

      {/* ─── Step 5: Final plan ───────────────────────────────────────────── */}
      {step === 5 && finalPlan && (
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: "1.25rem" }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: "#EAF3DE", color: "#3B6D11", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <i className="ti ti-check" aria-hidden="true" />
            </div>
            <div>
              <p style={{ margin: 0, fontWeight: 500, fontSize: 15 }}>Final plan generated</p>
              <p style={{ margin: "2px 0 0", fontSize: 13, color: "var(--color-text-secondary)" }}>{finalPlan.summary}</p>
            </div>
          </div>

          {/* Success metrics */}
          {finalPlan.success_metrics?.length > 0 && (
            <div style={{ background: "var(--color-background-secondary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "12px 16px", marginBottom: "1.25rem" }}>
              <p style={{ margin: "0 0 8px", fontSize: 13, fontWeight: 500 }}>Success metrics</p>
              <ul style={{ margin: 0, paddingLeft: 18 }}>
                {finalPlan.success_metrics.map((m, i) => <li key={i} style={{ fontSize: 13, color: "var(--color-text-secondary)", marginBottom: 4 }}>{m}</li>)}
              </ul>
            </div>
          )}

          {/* Milestones */}
          {finalPlan.milestones?.length > 0 && (
            <div style={{ marginBottom: "1.25rem" }}>
              <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 10px" }}>
                <i className="ti ti-flag" style={{ marginRight: 6 }} aria-hidden="true" />Milestones
              </p>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 10 }}>
                {finalPlan.milestones.map((m, i) => (
                  <div key={i} style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "10px 14px" }}>
                    <p style={{ margin: "0 0 4px", fontWeight: 500, fontSize: 13 }}>{m.name}</p>
                    <p style={{ margin: "0 0 6px", fontSize: 12, color: "#185FA5" }}>Week {m.target_week}</p>
                    {m.deliverables?.map((d, j) => <p key={j} style={{ margin: "2px 0", fontSize: 11, color: "var(--color-text-secondary)" }}>{d}</p>)}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tasks */}
          <div style={{ marginBottom: "1.25rem" }}>
            <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 10px" }}>
              <i className="ti ti-circle-check" style={{ marginRight: 6, color: "#3B6D11" }} aria-hidden="true" />
              Achievable tasks ({finalPlan.achievable_tasks?.length ?? 0})
            </p>
            {finalPlan.achievable_tasks?.map(t => (
              <div key={t.id} style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "12px 14px", marginBottom: 8 }}>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 4 }}>
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--color-text-secondary)" }}>{t.id}</span>
                  {t.priority && <Badge label={t.priority} color={PRIORITY_COLORS[t.priority] ?? "#185FA5"} bg={t.priority === "Critical" ? "#FCEBEB" : t.priority === "High" ? "#FAEEDA" : "#E6F1FB"} />}
                  {t.effort && <Badge label={t.effort} color={EFFORT_COLORS[t.effort] ?? "#5F5E5A"} bg="#F1EFE8" />}
                  {t.estimated_days && <Badge label={`${t.estimated_days}d`} color="#5F5E5A" bg="#F1EFE8" />}
                </div>
                <p style={{ margin: "0 0 4px", fontWeight: 500, fontSize: 14 }}>{t.title}</p>
                <p style={{ margin: "0 0 8px", fontSize: 13, color: "var(--color-text-secondary)" }}>{t.description}</p>
                {t.implementation_steps?.length > 0 && (
                  <details>
                    <summary style={{ fontSize: 12, color: "#185FA5", cursor: "pointer" }}>Implementation steps</summary>
                    <ol style={{ margin: "6px 0 0", paddingLeft: 18 }}>
                      {t.implementation_steps.map((s, i) => <li key={i} style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 3 }}>{s}</li>)}
                    </ol>
                  </details>
                )}
                {t.acceptance_criteria?.length > 0 && (
                  <details>
                    <summary style={{ fontSize: 12, color: "#3B6D11", cursor: "pointer", marginTop: 4 }}>Acceptance criteria</summary>
                    <ul style={{ margin: "6px 0 0", paddingLeft: 18 }}>
                      {t.acceptance_criteria.map((c, i) => <li key={i} style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 3 }}>{c}</li>)}
                    </ul>
                  </details>
                )}
              </div>
            ))}
          </div>

          {/* Risks */}
          {finalPlan.risks?.length > 0 && (
            <div style={{ marginBottom: "1.25rem" }}>
              <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 10px" }}>
                <i className="ti ti-alert-triangle" style={{ marginRight: 6, color: "#BA7517" }} aria-hidden="true" />Risks
              </p>
              {finalPlan.risks.map((r, i) => (
                <div key={i} style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", padding: "10px 14px", marginBottom: 8 }}>
                  <div style={{ display: "flex", gap: 6, marginBottom: 4 }}>
                    <Badge label={`Likelihood: ${r.likelihood}`} color="#854F0B" bg="#FAEEDA" />
                    <Badge label={`Impact: ${r.impact}`} color="#854F0B" bg="#FAEEDA" />
                  </div>
                  <p style={{ margin: "0 0 4px", fontWeight: 500, fontSize: 13 }}>{r.risk}</p>
                  <p style={{ margin: 0, fontSize: 12, color: "#3B6D11" }}><strong>Mitigation:</strong> {r.mitigation}</p>
                </div>
              ))}
            </div>
          )}

          {/* Special request responses */}
          {finalPlan.special_request_responses?.length > 0 && (
            <div style={{ marginBottom: "1.25rem" }}>
              <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 10px" }}>
                <i className="ti ti-sparkles" style={{ marginRight: 6 }} aria-hidden="true" />Special request responses
              </p>
              {finalPlan.special_request_responses.map((r, i) => (
                <div key={i} style={{ background: "#EEEDFE", border: "0.5px solid #AFA9EC", borderRadius: "var(--border-radius-md)", padding: "10px 14px", marginBottom: 8 }}>
                  <p style={{ margin: "0 0 4px", fontSize: 13, color: "#3C3489" }}><strong>Request:</strong> {r.request}</p>
                  <p style={{ margin: 0, fontSize: 13, color: "#26215C" }}>{r.response}</p>
                </div>
              ))}
            </div>
          )}

          {/* Next steps */}
          {finalPlan.next_steps?.length > 0 && (
            <div style={{ background: "#EAF3DE", border: "0.5px solid #97C459", borderRadius: "var(--border-radius-md)", padding: "12px 16px", marginBottom: "1.25rem" }}>
              <p style={{ margin: "0 0 8px", fontSize: 13, fontWeight: 500, color: "#3B6D11" }}>Next steps</p>
              <ol style={{ margin: 0, paddingLeft: 18 }}>
                {finalPlan.next_steps.map((s, i) => <li key={i} style={{ fontSize: 13, color: "#27500A", marginBottom: 4 }}>{s}</li>)}
              </ol>
            </div>
          )}

          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => { setPlan(null); setFinalPlan(null); setStep(4); }} style={{ flex: 1 }}>
              <i className="ti ti-edit" aria-hidden="true" /> Revise plan
            </button>
            <button onClick={() => { const el = document.createElement("a"); el.href = `${base}/files/final_plan.json`; el.download = "final_plan.json"; el.click(); }} style={{ flex: 1 }}>
              <i className="ti ti-download" aria-hidden="true" /> Download JSON
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
