"""
main.py — FastAPI application for AI-powered project planning.

Exposes three threaded processors:
  Thread 1 → requirement.txt   (from one document)
  Thread 2 → knowledge.txt     (from one or more Word/Excel docs)
  Thread 3 → plan.json         (waits for 1 & 2, uses GitHub repo)

And a synchronous finalise endpoint that incorporates user edits into a
detailed final_plan.json.
"""

import os
import shutil
import logging
from pathlib import Path
from typing import List, Optional
from contextlib import asynccontextmanager

from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel

from thread_manager import ThreadManager, ThreadStatus
from processors import (
    process_document_to_requirements,
    process_docs_to_knowledge,
    generate_plan,
    generate_final_plan,
)

# ─── Logging ─────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

# ─── Directories ─────────────────────────────────────────────────────────────

UPLOAD_DIR = Path("uploads")
OUTPUT_DIR = Path("outputs")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

REQ_FILE = str(OUTPUT_DIR / "requirement.txt")
KNOW_FILE = str(OUTPUT_DIR / "knowledge.txt")
PLAN_FILE = str(OUTPUT_DIR / "plan.json")
FINAL_FILE = str(OUTPUT_DIR / "final_plan.json")

# ─── Global state ────────────────────────────────────────────────────────────

thread_manager = ThreadManager()

app_state: dict = {
    "github_repo": None,
    "requirement_file": None,
    "knowledge_file": None,
    "plan": None,
    "final_plan": None,
}


# ─── Lifespan ────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀  Project Planner API starting up.")
    yield
    logger.info("🛑  Project Planner API shutting down.")


# ─── App ─────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Project Planner API",
    description=(
        "AI-powered project planning using Azure OpenAI.\n\n"
        "**Workflow**:\n"
        "1. `POST /thread1/start` — upload requirement document\n"
        "2. `POST /thread2/start` — upload knowledge documents\n"
        "3. `POST /thread3/start` — provide GitHub repo URL; thread waits for 1 & 2\n"
        "4. `GET /plan` — retrieve the generated plan\n"
        "5. `POST /plan/finalize` — submit user edits → final plan\n"
        "6. `GET /plan/final` — retrieve the final plan"
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Pydantic models ─────────────────────────────────────────────────────────

class Thread3Config(BaseModel):
    repo_url: str


class FinalizePlanRequest(BaseModel):
    achievable_tasks: list
    unachievable_tasks: list
    special_requests: str = ""


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _save_upload(file: UploadFile) -> str:
    dest = UPLOAD_DIR / file.filename
    with open(dest, "wb") as fh:
        shutil.copyfileobj(file.file, fh)
    return str(dest)


# ─── Thread 1 ────────────────────────────────────────────────────────────────

@app.post(
    "/thread1/start",
    summary="Upload a document → generate requirement.txt",
    tags=["Threads"],
)
async def start_thread1(file: UploadFile = File(...)):
    """
    Upload **one** document (any format: .txt, .docx, .pdf, .xlsx …).
    Starts Thread 1, which processes it into `outputs/requirement.txt`
    using Azure OpenAI.
    """
    file_path = _save_upload(file)

    def _task():
        path = process_document_to_requirements(file_path, REQ_FILE)
        app_state["requirement_file"] = path
        return path

    t = thread_manager.register("thread1", _task, max_retries=3)
    t.start()

    return {
        "message": "Thread 1 started — requirement.txt generation in progress.",
        "uploaded_file": file.filename,
        "thread": t.to_dict(),
    }


# ─── Thread 2 ────────────────────────────────────────────────────────────────

@app.post(
    "/thread2/start",
    summary="Upload documents → generate knowledge.txt",
    tags=["Threads"],
)
async def start_thread2(files: List[UploadFile] = File(...)):
    """
    Upload **one or more** Word/Excel documents.
    Starts Thread 2, which synthesises them into `outputs/knowledge.txt`
    using Azure OpenAI.
    """
    file_paths = [_save_upload(f) for f in files]

    def _task():
        path = process_docs_to_knowledge(file_paths, KNOW_FILE)
        app_state["knowledge_file"] = path
        return path

    t = thread_manager.register("thread2", _task, max_retries=3)
    t.start()

    return {
        "message": "Thread 2 started — knowledge.txt generation in progress.",
        "uploaded_files": [f.filename for f in files],
        "thread": t.to_dict(),
    }


# ─── Thread 3 ────────────────────────────────────────────────────────────────

@app.post(
    "/thread3/start",
    summary="Start plan generation (waits for Threads 1 & 2)",
    tags=["Threads"],
)
async def start_thread3(config: Thread3Config):
    """
    Provide a GitHub repository URL.
    Thread 3 will **wait** for Threads 1 and 2 to complete, then call
    Azure OpenAI to generate a project plan split into achievable and
    unachievable tasks.
    """
    app_state["github_repo"] = config.repo_url

    def _task():
        t1 = thread_manager.get("thread1")
        t2 = thread_manager.get("thread2")

        if t1 is None:
            raise RuntimeError("Thread 1 has not been started. Call /thread1/start first.")
        if t2 is None:
            raise RuntimeError("Thread 2 has not been started. Call /thread2/start first.")

        logger.info("[Thread3] Waiting for Thread 1 …")
        t1.wait()
        logger.info("[Thread3] Waiting for Thread 2 …")
        t2.wait()

        if t1.status != ThreadStatus.COMPLETED:
            raise RuntimeError(
                f"Thread 1 did not complete successfully (status={t1.status.value}): {t1.error}"
            )
        if t2.status != ThreadStatus.COMPLETED:
            raise RuntimeError(
                f"Thread 2 did not complete successfully (status={t2.status.value}): {t2.error}"
            )

        logger.info("[Thread3] Dependencies satisfied. Generating plan …")
        plan = generate_plan(
            github_repo_url=app_state["github_repo"],
            requirements_path=app_state["requirement_file"],
            knowledge_path=app_state["knowledge_file"],
            output_path=PLAN_FILE,
        )
        app_state["plan"] = plan
        return plan

    t = thread_manager.register("thread3", _task, max_retries=3)
    t.start()

    return {
        "message": "Thread 3 started — waiting for Threads 1 & 2, then generating plan.",
        "github_repo": config.repo_url,
        "thread": t.to_dict(),
    }


# ─── Status ──────────────────────────────────────────────────────────────────

@app.get("/status", summary="Get status of all threads", tags=["Status"])
async def get_status():
    """
    Returns the current status of all three threads and a summary of
    available outputs.
    """
    return {
        "threads": thread_manager.status_all(),
        "outputs": {
            "requirement_file": app_state["requirement_file"],
            "knowledge_file": app_state["knowledge_file"],
            "github_repo": app_state["github_repo"],
            "plan_ready": app_state["plan"] is not None,
            "final_plan_ready": app_state["final_plan"] is not None,
        },
    }


# ─── Plan endpoints ──────────────────────────────────────────────────────────

@app.get("/plan", summary="Retrieve the generated plan", tags=["Plan"])
async def get_plan():
    """
    Returns the plan JSON once Thread 3 has completed.
    Responds with HTTP 202 while still generating.
    """
    t3 = thread_manager.get("thread3")

    if app_state["plan"] is not None:
        return app_state["plan"]

    if t3 is None:
        raise HTTPException(status_code=404, detail="Thread 3 has not been started.")

    if t3.status in (ThreadStatus.RUNNING, ThreadStatus.WAITING, ThreadStatus.RESTARTING):
        return JSONResponse(
            status_code=202,
            content={"detail": "Plan is still being generated.", "thread": t3.to_dict()},
        )

    if t3.status == ThreadStatus.FAILED:
        raise HTTPException(
            status_code=500,
            detail=f"Plan generation failed: {t3.error}",
        )

    raise HTTPException(status_code=404, detail="Plan not yet available.")


@app.post("/plan/finalize", summary="Submit user edits → generate final plan", tags=["Plan"])
async def finalize_plan(request: FinalizePlanRequest):
    """
    Accept the user's reviewed/edited achievable and unachievable task lists
    plus any special requests, then generate and return the final plan.
    """
    if app_state["plan"] is None:
        raise HTTPException(
            status_code=400,
            detail="No plan to finalise. Generate a plan first via Thread 3.",
        )

    final = generate_final_plan(
        original_plan=app_state["plan"],
        updated_achievable=request.achievable_tasks,
        updated_unachievable=request.unachievable_tasks,
        special_requests=request.special_requests,
        output_path=FINAL_FILE,
    )
    app_state["final_plan"] = final
    return final


@app.get("/plan/final", summary="Retrieve the final plan", tags=["Plan"])
async def get_final_plan():
    """Returns the final plan after `/plan/finalize` has been called."""
    if app_state["final_plan"] is None:
        raise HTTPException(
            status_code=404,
            detail="Final plan not generated yet. Call /plan/finalize first.",
        )
    return app_state["final_plan"]


# ─── File downloads ──────────────────────────────────────────────────────────

@app.get(
    "/files/{filename}",
    summary="Download a generated output file",
    tags=["Files"],
    response_class=PlainTextResponse,
)
async def download_file(filename: str):
    """Download `requirement.txt`, `knowledge.txt`, `plan.json`, or `final_plan.json`."""
    # Whitelist to prevent path traversal
    allowed = {"requirement.txt", "knowledge.txt", "plan.json", "final_plan.json"}
    if filename not in allowed:
        raise HTTPException(status_code=403, detail=f"File '{filename}' is not accessible.")

    file_path = OUTPUT_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail=f"File '{filename}' has not been generated yet.")

    return file_path.read_text(encoding="utf-8")


# ─── Reset ───────────────────────────────────────────────────────────────────

@app.delete("/reset", summary="Reset all state and clear outputs", tags=["Admin"])
async def reset():
    """
    Clears all thread state and generated output files.
    Useful for starting a fresh session.
    """
    app_state.update(
        github_repo=None,
        requirement_file=None,
        knowledge_file=None,
        plan=None,
        final_plan=None,
    )
    thread_manager.reset()

    for f in OUTPUT_DIR.glob("*"):
        f.unlink(missing_ok=True)

    return {"message": "State and outputs reset successfully."}


# ─── Entry point ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8000)),
        reload=os.getenv("RELOAD", "false").lower() == "true",
        log_level="info",
    )
