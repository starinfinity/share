"""
Processors — Azure OpenAI powered tasks for each thread.
"""

import os
import json
import logging
from pathlib import Path
from typing import List, Optional

from openai import AzureOpenAI

logger = logging.getLogger(__name__)


# ─── Azure Client Factory ────────────────────────────────────────────────────

def _get_client() -> AzureOpenAI:
    return AzureOpenAI(
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01"),
    )


def _deployment() -> str:
    return os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")


# ─── File Reading ────────────────────────────────────────────────────────────

def read_file_content(file_path: str) -> str:
    """
    Read text from .txt, .md, .docx, .doc, .xlsx, .xls, or .pdf.
    Falls back to UTF-8 text for unknown extensions.
    """
    path = Path(file_path)
    ext = path.suffix.lower()

    if ext in {".txt", ".md", ".rst", ".csv"}:
        return path.read_text(encoding="utf-8", errors="replace")

    elif ext in {".docx", ".doc"}:
        from docx import Document  # python-docx
        doc = Document(file_path)
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        # Also extract table cells
        for table in doc.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                if cells:
                    paragraphs.append(" | ".join(cells))
        return "\n".join(paragraphs)

    elif ext in {".xlsx", ".xls"}:
        import openpyxl
        wb = openpyxl.load_workbook(file_path, data_only=True)
        lines: List[str] = []
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            lines.append(f"=== Sheet: {sheet_name} ===")
            for row in ws.iter_rows(values_only=True):
                row_str = "\t".join(
                    str(cell) if cell is not None else "" for cell in row
                )
                if row_str.strip():
                    lines.append(row_str)
        return "\n".join(lines)

    elif ext == ".pdf":
        import fitz  # PyMuPDF
        doc = fitz.open(file_path)
        return "\n".join(page.get_text() for page in doc)

    else:
        return path.read_text(encoding="utf-8", errors="replace")


# ─── Thread 1: Requirements Generator ───────────────────────────────────────

def process_document_to_requirements(
    file_path: str,
    output_path: str = "outputs/requirement.txt",
) -> str:
    """
    Read a document and use Azure OpenAI to produce a structured
    requirement.txt file. Returns the output path.
    """
    logger.info(f"[Thread1] Reading document: {file_path}")
    content = read_file_content(file_path)

    if not content.strip():
        raise ValueError(f"Document at {file_path} appears to be empty.")

    client = _get_client()

    system_prompt = (
        "You are a senior business analyst and requirements engineer. "
        "Your job is to extract, clarify, and structure ALL requirements "
        "from a raw document into a clean, numbered requirements list. "
        "Use clear, unambiguous language suitable for a development team."
    )

    user_prompt = f"""Extract all requirements from the document below.
Format the output as follows:

FUNCTIONAL REQUIREMENTS
=======================
FR-001: <short title>
        Description: <full description>
        Acceptance Criteria: <how we know it's done>

FR-002: ...

NON-FUNCTIONAL REQUIREMENTS
============================
NFR-001: <short title>
         Description: <full description>

CONSTRAINTS & ASSUMPTIONS
==========================
C-001: <description>

Document content:
-----------------
{content}
"""

    logger.info("[Thread1] Calling Azure OpenAI...")
    response = client.chat.completions.create(
        model=_deployment(),
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        max_tokens=4096,
        temperature=0.2,
    )

    requirements_text = response.choices[0].message.content

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(requirements_text, encoding="utf-8")
    logger.info(f"[Thread1] Requirements written → {output_path}")
    return output_path


# ─── Thread 2: Knowledge Base Generator ─────────────────────────────────────

def process_docs_to_knowledge(
    file_paths: List[str],
    output_path: str = "outputs/knowledge.txt",
) -> str:
    """
    Read multiple Word/Excel documents and synthesize a Knowledge.txt file
    using Azure OpenAI. Returns the output path.
    """
    logger.info(f"[Thread2] Processing {len(file_paths)} document(s)...")

    doc_sections: List[str] = []
    for fp in file_paths:
        content = read_file_content(fp)
        doc_sections.append(
            f"╔══ FILE: {Path(fp).name} ══╗\n{content}\n╚{'═' * (len(Path(fp).name) + 12)}╝"
        )

    combined = "\n\n".join(doc_sections)

    if not combined.strip():
        raise ValueError("All provided documents appear to be empty.")

    client = _get_client()

    system_prompt = (
        "You are a knowledge management expert and technical writer. "
        "Your role is to synthesize information from multiple source documents "
        "into a structured, comprehensive knowledge base that a development team "
        "can reference during planning and implementation."
    )

    user_prompt = f"""Synthesize the content of the documents below into a Knowledge Base file.

Structure your output as follows:

DOMAIN OVERVIEW
===============
<High-level description of the domain and business context>

KEY CONCEPTS & TERMINOLOGY
===========================
<Defined terms and concepts important for understanding the project>

BUSINESS RULES
==============
<Rules, policies, constraints that govern the system behaviour>

TECHNICAL CONTEXT
=================
<Existing systems, integrations, technologies, infrastructure details>

DATA ENTITIES & RELATIONSHIPS
==============================
<Key data models, entities, and their relationships>

STAKEHOLDERS & ROLES
====================
<Who is involved and what they care about>

KNOWN RISKS & OPEN QUESTIONS
=============================
<Identified risks, unknowns, or areas needing clarification>

Documents:
{combined}
"""

    logger.info("[Thread2] Calling Azure OpenAI...")
    response = client.chat.completions.create(
        model=_deployment(),
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        max_tokens=4096,
        temperature=0.2,
    )

    knowledge_text = response.choices[0].message.content

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(knowledge_text, encoding="utf-8")
    logger.info(f"[Thread2] Knowledge base written → {output_path}")
    return output_path


# ─── GitHub Repo Inspector ───────────────────────────────────────────────────

def _get_repo_summary(repo_url: str) -> str:
    """
    Fetch basic repository metadata and directory structure using PyGithub.
    """
    try:
        from github import Github, GithubException

        token = os.getenv("GITHUB_TOKEN")
        g = Github(token) if token else Github()

        # Strip URL prefix to get owner/repo
        repo_name = (
            repo_url
            .replace("https://github.com/", "")
            .replace("http://github.com/", "")
            .rstrip("/")
        )
        repo = g.get_repo(repo_name)

        lines = [
            f"Repository  : {repo.full_name}",
            f"Description : {repo.description or 'N/A'}",
            f"Language    : {repo.language or 'N/A'}",
            f"Stars       : {repo.stargazers_count}",
            f"Default branch: {repo.default_branch}",
            "",
            "Top-level structure:",
        ]

        def _tree(path: str = "", depth: int = 0, max_depth: int = 3) -> None:
            if depth >= max_depth:
                return
            try:
                items = repo.get_contents(path)
                for item in (items[:25] if isinstance(items, list) else [items]):
                    indent = "  " * depth
                    lines.append(f"{indent}{'📁 ' if item.type == 'dir' else '📄 '}{item.name}")
                    if item.type == "dir":
                        _tree(item.path, depth + 1, max_depth)
            except Exception:
                pass

        _tree()

        # Grab README (first 1 500 chars)
        try:
            readme = repo.get_readme()
            import base64
            readme_text = base64.b64decode(readme.content).decode("utf-8", errors="replace")
            lines += ["", "README (excerpt):", readme_text[:1500]]
        except Exception:
            pass

        return "\n".join(lines)

    except Exception as exc:
        logger.warning(f"Could not fetch GitHub repo info: {exc}")
        return f"GitHub repo: {repo_url}\n(Details unavailable: {exc})"


# ─── Thread 3: Plan Generator ────────────────────────────────────────────────

def generate_plan(
    github_repo_url: str,
    requirements_path: str,
    knowledge_path: str,
    output_path: str = "outputs/plan.json",
) -> dict:
    """
    Combine GitHub info + requirements + knowledge to produce a structured plan
    with achievable and unachievable task lists.
    """
    logger.info("[Thread3] Gathering inputs for plan generation...")

    requirements = Path(requirements_path).read_text(encoding="utf-8")
    knowledge = Path(knowledge_path).read_text(encoding="utf-8")
    repo_summary = _get_repo_summary(github_repo_url)

    client = _get_client()

    system_prompt = (
        "You are a senior technical architect and project planner. "
        "You produce detailed, realistic project plans in JSON. "
        "Always respond with a single, valid JSON object and NOTHING else — "
        "no markdown fences, no preamble, no explanation."
    )

    user_prompt = f"""You are planning a software project. Analyse ALL requirements and classify each one.

━━━ GITHUB REPOSITORY ━━━
{repo_summary}

━━━ REQUIREMENTS ━━━
{requirements}

━━━ KNOWLEDGE BASE ━━━
{knowledge}

Produce a JSON plan with this exact schema:

{{
  "summary": "string — 2-3 sentence project overview",
  "achievable_tasks": [
    {{
      "id": "T001",
      "title": "string",
      "description": "string",
      "priority": "Critical | High | Medium | Low",
      "effort": "XS | S | M | L | XL",
      "estimated_days": 0,
      "dependencies": ["T002"],
      "technical_notes": "string",
      "implementation_steps": ["step 1", "step 2"]
    }}
  ],
  "unachievable_tasks": [
    {{
      "id": "U001",
      "title": "string",
      "description": "string",
      "reason": "string — why it cannot be done",
      "blockers": ["blocker 1"],
      "alternative": "string — what could be done instead"
    }}
  ],
  "estimated_total_days": 0,
  "timeline_overview": "string",
  "tech_stack_recommendations": ["string"],
  "risks": [
    {{ "risk": "string", "likelihood": "Low|Medium|High", "impact": "Low|Medium|High", "mitigation": "string" }}
  ],
  "milestones": [
    {{ "name": "string", "task_ids": ["T001"], "target_week": 0 }}
  ],
  "open_questions": ["string"]
}}
"""

    logger.info("[Thread3] Calling Azure OpenAI for plan generation...")
    response = client.chat.completions.create(
        model=_deployment(),
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        max_tokens=6000,
        temperature=0.2,
        response_format={"type": "json_object"},
    )

    raw = response.choices[0].message.content
    plan = json.loads(raw)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(json.dumps(plan, indent=2), encoding="utf-8")
    logger.info(f"[Thread3] Plan written → {output_path}")
    return plan


# ─── Final Plan Generator (synchronous, called directly) ────────────────────

def generate_final_plan(
    original_plan: dict,
    updated_achievable: list,
    updated_unachievable: list,
    special_requests: str,
    output_path: str = "outputs/final_plan.json",
) -> dict:
    """
    After the user reviews and edits the plan, generate a detailed final plan
    that incorporates all changes and special requests.
    """
    logger.info("[FinalPlan] Generating final plan with user edits...")

    client = _get_client()

    system_prompt = (
        "You are a senior technical architect delivering a final project plan. "
        "Incorporate the user's edits faithfully. "
        "Always respond with a single valid JSON object, nothing else."
    )

    user_prompt = f"""The user has reviewed the initial plan and made changes. Produce the FINAL, detailed plan.

━━━ ORIGINAL SUMMARY ━━━
{original_plan.get("summary", "")}

━━━ USER-REVISED ACHIEVABLE TASKS ━━━
{json.dumps(updated_achievable, indent=2)}

━━━ USER-REVISED UNACHIEVABLE TASKS ━━━
{json.dumps(updated_unachievable, indent=2)}

━━━ USER SPECIAL REQUESTS ━━━
{special_requests or "None"}

Produce a comprehensive final plan JSON:
{{
  "summary": "string",
  "achievable_tasks": [
    {{
      "id": "string",
      "title": "string",
      "description": "string",
      "priority": "Critical | High | Medium | Low",
      "effort": "XS | S | M | L | XL",
      "estimated_days": 0,
      "dependencies": ["string"],
      "technical_notes": "string",
      "implementation_steps": ["string"],
      "acceptance_criteria": ["string"]
    }}
  ],
  "unachievable_tasks": [
    {{
      "id": "string",
      "title": "string",
      "description": "string",
      "reason": "string",
      "alternative": "string"
    }}
  ],
  "special_request_responses": [
    {{ "request": "string", "response": "string" }}
  ],
  "timeline_overview": "string",
  "milestones": [
    {{ "name": "string", "task_ids": ["string"], "target_week": 0, "deliverables": ["string"] }}
  ],
  "risks": [
    {{ "risk": "string", "likelihood": "Low|Medium|High", "impact": "Low|Medium|High", "mitigation": "string" }}
  ],
  "tech_stack": ["string"],
  "success_metrics": ["string"],
  "next_steps": ["string"]
}}
"""

    response = client.chat.completions.create(
        model=_deployment(),
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        max_tokens=8000,
        temperature=0.2,
        response_format={"type": "json_object"},
    )

    final_plan = json.loads(response.choices[0].message.content)

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(json.dumps(final_plan, indent=2), encoding="utf-8")
    logger.info(f"[FinalPlan] Final plan written → {output_path}")
    return final_plan
