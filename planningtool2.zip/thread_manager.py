"""
Thread Manager — Managed threads with automatic restart on failure.
"""

import threading
import time
import logging
from enum import Enum
from typing import Callable, Optional, Dict, Any
from datetime import datetime

logger = logging.getLogger(__name__)


class ThreadStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    RESTARTING = "restarting"
    WAITING = "waiting"


class ManagedThread:
    """
    A thread wrapper that automatically restarts on failure up to max_retries.
    """

    def __init__(
        self,
        name: str,
        target: Callable,
        max_retries: int = 3,
        retry_delay: float = 5.0,
    ):
        self.name = name
        self.target = target
        self.max_retries = max_retries
        self.retry_delay = retry_delay

        self.status: ThreadStatus = ThreadStatus.IDLE
        self.error: Optional[str] = None
        self.result: Optional[Any] = None
        self.retry_count: int = 0
        self.started_at: Optional[datetime] = None
        self.completed_at: Optional[datetime] = None

        self._thread: Optional[threading.Thread] = None
        self._args: tuple = ()
        self._kwargs: dict = {}
        self._lock = threading.Lock()

    # ─── Internal runner ────────────────────────────────────────────────────

    def _run(self) -> None:
        while self.retry_count <= self.max_retries:
            try:
                with self._lock:
                    self.status = ThreadStatus.RUNNING
                    self.started_at = datetime.utcnow()
                    self.error = None

                logger.info(
                    f"[{self.name}] Starting attempt {self.retry_count + 1}/{self.max_retries + 1}"
                )
                result = self.target(*self._args, **self._kwargs)

                with self._lock:
                    self.result = result
                    self.status = ThreadStatus.COMPLETED
                    self.completed_at = datetime.utcnow()

                logger.info(f"[{self.name}] Completed successfully.")
                return

            except Exception as exc:
                self.retry_count += 1
                error_msg = str(exc)

                with self._lock:
                    self.error = error_msg

                logger.error(f"[{self.name}] Failed: {error_msg}")

                if self.retry_count <= self.max_retries:
                    with self._lock:
                        self.status = ThreadStatus.RESTARTING
                    logger.info(
                        f"[{self.name}] Restarting in {self.retry_delay}s "
                        f"(attempt {self.retry_count + 1}/{self.max_retries + 1})"
                    )
                    time.sleep(self.retry_delay)
                else:
                    with self._lock:
                        self.status = ThreadStatus.FAILED
                    logger.error(f"[{self.name}] Exceeded max retries. Giving up.")

    # ─── Public API ─────────────────────────────────────────────────────────

    def start(self, *args, **kwargs) -> None:
        """Start (or restart) the thread with the given arguments."""
        self._args = args
        self._kwargs = kwargs
        self.retry_count = 0
        self._thread = threading.Thread(
            target=self._run, daemon=True, name=self.name
        )
        self._thread.start()
        logger.info(f"[{self.name}] Thread dispatched.")

    def is_alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def wait(self, timeout: Optional[float] = None) -> None:
        """Block until this thread completes (or times out)."""
        if self._thread:
            self._thread.join(timeout=timeout)

    def to_dict(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "name": self.name,
                "status": self.status.value,
                "retry_count": self.retry_count,
                "max_retries": self.max_retries,
                "error": self.error,
                "started_at": self.started_at.isoformat() if self.started_at else None,
                "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            }


class ThreadManager:
    """Registry that owns and tracks all ManagedThread instances."""

    def __init__(self) -> None:
        self._threads: Dict[str, ManagedThread] = {}
        self._registry_lock = threading.Lock()

    def register(
        self,
        name: str,
        target: Callable,
        max_retries: int = 3,
        retry_delay: float = 5.0,
    ) -> ManagedThread:
        """Create (or replace) a managed thread by name."""
        thread = ManagedThread(
            name=name,
            target=target,
            max_retries=max_retries,
            retry_delay=retry_delay,
        )
        with self._registry_lock:
            self._threads[name] = thread
        return thread

    def get(self, name: str) -> Optional[ManagedThread]:
        return self._threads.get(name)

    def status_all(self) -> Dict[str, Dict]:
        with self._registry_lock:
            return {name: t.to_dict() for name, t in self._threads.items()}

    def reset(self) -> None:
        with self._registry_lock:
            self._threads.clear()
