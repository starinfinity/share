import React, { useState, useEffect } from 'react';
import { MessageCircle } from 'lucide-react';
import ChatInterface from './components/ChatInterface';
import { ThemeProvider, useTheme, themeConfig } from './contexts/ThemeContext';
import ThemeSelector from './components/ThemeSelector';
import { Message } from './types/chat';
import './App.css';

function AppContent() {
  const { theme } = useTheme();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'assistant',
      content: 'Hello! I\'m your SQL Assistant. I can help you query your Oracle database using natural language. Just describe what data you need and I\'ll generate the appropriate SQL query and execute it for you.',
      timestamp: new Date(),
    }
  ]);

  const handleSendMessage = async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: content }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: data.response,
        timestamp: new Date(),
        resultType: data.result_type,
        sqlQuery: data.sql_query,
        tableData: data.result_type === 'table' ? data.data : undefined,
        fileData: data.result_type === 'file' ? data.data : undefined,
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'Sorry, I encountered an error while processing your request. Please make sure the backend server is running and try again.',
        timestamp: new Date(),
      };
      
      setMessages(prev => [...prev, errorMessage]);
    }
  };

  const currentTheme = themeConfig[theme];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${currentTheme.bg}`}>
      <header className={`border-b transition-colors duration-300 ${currentTheme.header} backdrop-blur-sm`}>
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${currentTheme.headerIcon}`}>
              <MessageCircle size={24} />
            </div>
            <div>
              <h1 className={`text-xl font-bold ${currentTheme.text}`}>
                SQL Assistant
              </h1>
              <p className={`text-sm ${currentTheme.subtext}`}>
                AI-powered database query assistant
              </p>
            </div>
          </div>
          
          <ThemeSelector />
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        <ChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
        />
      </main>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;