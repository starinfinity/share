import React from 'react';
import { TableData, FileData } from '../types/chat';
import { useTheme, themeConfig } from '../contexts/ThemeContext';
import { Download, FileText } from 'lucide-react';

interface ResultDisplayProps {
  resultType: 'text' | 'table' | 'file';
  tableData?: TableData;
  fileData?: FileData;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ resultType, tableData, fileData }) => {
  const { theme } = useTheme();
  const currentTheme = themeConfig[theme];

  if (resultType === 'table' && tableData) {
    return (
      <div className={`rounded-lg overflow-hidden border ${currentTheme.resultBg}`}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className={currentTheme.tableHeader}>
              <tr>
                {tableData.columns.map((column, index) => (
                  <th key={index} className={`px-4 py-3 text-left text-sm font-semibold ${currentTheme.text}`}>
                    {column}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tableData.rows.map((row, rowIndex) => (
                <tr key={rowIndex} className={`border-t ${currentTheme.tableBorder}`}>
                  {row.map((cell, cellIndex) => (
                    <td key={cellIndex} className={`px-4 py-3 text-sm ${currentTheme.subtext}`}>
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  if (resultType === 'file' && fileData) {
    return (
      <div className={`rounded-lg border p-4 ${currentTheme.resultBg}`}>
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${currentTheme.headerIcon}`}>
            <FileText size={20} />
          </div>
          <div className="flex-1">
            <h4 className={`font-medium ${currentTheme.text}`}>
              {fileData.name}
            </h4>
            <p className={`text-sm ${currentTheme.subtext}`}>
              {fileData.type} • {fileData.size}
            </p>
          </div>
          <button className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${currentTheme.primaryBtn}`}>
            <Download size={16} />
            <span className="text-sm">Download</span>
          </button>
        </div>
      </div>
    );
  }

  return null;
};

export default ResultDisplay;