import React, { useState } from 'react';
import { Palette, Check } from 'lucide-react';
import { useTheme, Theme, themeConfig } from '../contexts/ThemeContext';

const ThemeSelector: React.FC = () => {
  const { theme, setTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);

  const themes: { key: Theme; color: string }[] = [
    { key: 'light', color: 'bg-gray-100' },
    { key: 'dark', color: 'bg-gray-800' },
    { key: 'navy', color: 'bg-navy-500' },
    { key: 'teal', color: 'bg-teal-main' },
    { key: 'pink', color: 'bg-rose-500' },
    { key: 'blue', color: 'bg-sky-500' },
  ];

  const currentTheme = themeConfig[theme];

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`p-2 rounded-lg transition-colors ${currentTheme.button} flex items-center space-x-2`}
        aria-label="Select theme"
      >
        <Palette size={20} />
        <span className="hidden sm:inline text-sm">{currentTheme.name}</span>
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => setIsOpen(false)}
          />
          <div className={`absolute right-0 top-12 z-20 rounded-lg shadow-lg border min-w-48 ${currentTheme.resultBg} ${currentTheme.codeBg}`}>
            <div className="p-2">
              <h3 className={`text-sm font-medium px-3 py-2 ${currentTheme.text}`}>
                Choose Theme
              </h3>
              <div className="space-y-1">
                {themes.map(({ key, color }) => (
                  <button
                    key={key}
                    onClick={() => {
                      setTheme(key);
                      setIsOpen(false);
                    }}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md transition-colors ${
                      theme === key 
                        ? currentTheme.primaryBtn.replace('hover:', '')
                        : currentTheme.codeBtn
                    }`}
                  >
                    <div className={`w-4 h-4 rounded-full ${color} border-2 border-white shadow-sm`} />
                    <span className="flex-1 text-left text-sm">
                      {themeConfig[key].name}
                    </span>
                    {theme === key && <Check size={16} />}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ThemeSelector;