import React, { createContext, useContext, useState, useEffect } from 'react';

export type Theme = 'light' | 'dark' | 'navy' | 'teal' | 'pink' | 'blue';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

interface ThemeProviderProps {
  children: React.ReactNode;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>('navy');

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as Theme;
    if (savedTheme) {
      setTheme(savedTheme);
    }
  }, []);

  const handleSetTheme = (newTheme: Theme) => {
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme: handleSetTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const themeConfig = {
  light: {
    name: 'Light',
    bg: 'bg-gradient-to-br from-gray-50 via-white to-gray-100',
    header: 'bg-white/80 border-gray-200',
    headerIcon: 'bg-gray-100 text-gray-600',
    text: 'text-gray-800',
    subtext: 'text-gray-600',
    button: 'hover:bg-gray-100 text-gray-600 hover:text-gray-800',
    chatBg: 'bg-white/80 border-gray-200',
    userBubble: 'bg-blue-500 text-white',
    assistantBubble: 'bg-white text-gray-800 border border-gray-200',
    input: 'bg-white text-gray-800 placeholder-gray-500 border-gray-200 focus:border-blue-500',
    primaryBtn: 'bg-blue-500 text-white hover:bg-blue-600',
    disabledBtn: 'bg-gray-200 text-gray-400',
    timestamp: 'text-gray-500',
    resultBg: 'bg-white border-gray-200',
    tableHeader: 'bg-gray-50',
    tableBorder: 'border-gray-200',
    codeBtn: 'hover:bg-gray-50 text-gray-700',
    codeBg: 'border-gray-200',
  },
  dark: {
    name: 'Dark',
    bg: 'bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900',
    header: 'bg-gray-800/80 border-gray-700',
    headerIcon: 'bg-gray-700 text-gray-300',
    text: 'text-white',
    subtext: 'text-gray-400',
    button: 'hover:bg-gray-700 text-gray-300 hover:text-white',
    chatBg: 'bg-gray-800/80 border-gray-700',
    userBubble: 'bg-blue-600 text-white',
    assistantBubble: 'bg-gray-700 text-gray-100',
    input: 'bg-gray-700 text-white placeholder-gray-400 border-gray-600 focus:border-blue-500',
    primaryBtn: 'bg-blue-600 text-white hover:bg-blue-700',
    disabledBtn: 'bg-gray-700 text-gray-500',
    timestamp: 'text-gray-400',
    resultBg: 'bg-gray-700 border-gray-600',
    tableHeader: 'bg-gray-800',
    tableBorder: 'border-gray-600',
    codeBtn: 'hover:bg-gray-800 text-gray-300',
    codeBg: 'border-gray-600',
  },
  navy: {
    name: 'Navy Blue',
    bg: 'bg-gradient-to-br from-navy-50 via-blue-100 to-navy-200',
    header: 'bg-white/80 border-navy-300',
    headerIcon: 'bg-navy-100 text-navy-600',
    text: 'text-slate-800',
    subtext: 'text-slate-600',
    button: 'hover:bg-navy-100 text-slate-600 hover:text-slate-800',
    chatBg: 'bg-white/80 border-navy-200',
    userBubble: 'bg-navy-500 text-white',
    assistantBubble: 'bg-white text-slate-800 border border-navy-200',
    input: 'bg-white text-slate-800 placeholder-slate-500 border-navy-200 focus:border-navy-500',
    primaryBtn: 'bg-navy-500 text-white hover:bg-navy-600',
    disabledBtn: 'bg-navy-200 text-navy-400',
    timestamp: 'text-slate-500',
    resultBg: 'bg-white border-navy-200',
    tableHeader: 'bg-navy-50',
    tableBorder: 'border-navy-200',
    codeBtn: 'hover:bg-navy-50 text-slate-700',
    codeBg: 'border-navy-200',
  },
  teal: {
    name: 'Teal Dark',
    bg: 'bg-gradient-to-br from-teal-royal via-teal-green to-teal-royal',
    header: 'bg-teal-green/50 border-teal-main',
    headerIcon: 'bg-teal-main/30 text-teal-seafoam',
    text: 'text-white',
    subtext: 'text-slate-400',
    button: 'hover:bg-teal-main text-teal-seafoam hover:text-white',
    chatBg: 'bg-teal-green/50 border-teal-main',
    userBubble: 'bg-teal-main text-white',
    assistantBubble: 'bg-teal-green text-teal-seafoam',
    input: 'bg-teal-main text-white placeholder-teal-seafoam border-teal-green focus:border-teal-seafoam',
    primaryBtn: 'bg-teal-main text-white hover:bg-teal-green',
    disabledBtn: 'bg-teal-green text-teal-seafoam/50',
    timestamp: 'text-teal-seafoam/70',
    resultBg: 'bg-teal-green border-teal-main',
    tableHeader: 'bg-teal-royal',
    tableBorder: 'border-teal-main',
    codeBtn: 'hover:bg-teal-royal text-teal-seafoam',
    codeBg: 'border-teal-main',
  },
  pink: {
    name: 'Pink Rose',
    bg: 'bg-gradient-to-br from-rose-50 via-pink-50 to-rose-100',
    header: 'bg-white/80 border-rose-200',
    headerIcon: 'bg-rose-100 text-rose-600',
    text: 'text-rose-900',
    subtext: 'text-rose-700',
    button: 'hover:bg-rose-100 text-rose-600 hover:text-rose-800',
    chatBg: 'bg-white/80 border-rose-200',
    userBubble: 'bg-rose-500 text-white',
    assistantBubble: 'bg-white text-rose-900 border border-rose-200',
    input: 'bg-white text-rose-900 placeholder-rose-500 border-rose-200 focus:border-rose-500',
    primaryBtn: 'bg-rose-500 text-white hover:bg-rose-600',
    disabledBtn: 'bg-rose-200 text-rose-400',
    timestamp: 'text-rose-500',
    resultBg: 'bg-white border-rose-200',
    tableHeader: 'bg-rose-50',
    tableBorder: 'border-rose-200',
    codeBtn: 'hover:bg-rose-50 text-rose-700',
    codeBg: 'border-rose-200',
  },
  blue: {
    name: 'Sky Blue',
    bg: 'bg-gradient-to-br from-sky-50 via-blue-50 to-cyan-50',
    header: 'bg-white/80 border-sky-200',
    headerIcon: 'bg-sky-100 text-sky-600',
    text: 'text-sky-900',
    subtext: 'text-sky-700',
    button: 'hover:bg-sky-100 text-sky-600 hover:text-sky-800',
    chatBg: 'bg-white/80 border-sky-200',
    userBubble: 'bg-sky-500 text-white',
    assistantBubble: 'bg-white text-sky-900 border border-sky-200',
    input: 'bg-white text-sky-900 placeholder-sky-500 border-sky-200 focus:border-sky-500',
    primaryBtn: 'bg-sky-500 text-white hover:bg-sky-600',
    disabledBtn: 'bg-sky-200 text-sky-400',
    timestamp: 'text-sky-500',
    resultBg: 'bg-white border-sky-200',
    tableHeader: 'bg-sky-50',
    tableBorder: 'border-sky-200',
    codeBtn: 'hover:bg-sky-50 text-sky-700',
    codeBg: 'border-sky-200',
  },
};