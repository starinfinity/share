export interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  resultType?: 'text' | 'table' | 'file';
  sqlQuery?: string | null;
  tableData?: TableData;
  fileData?: FileData;
}

export interface TableData {
  columns: string[];
  rows: string[][];
}

export interface FileData {
  name: string;
  size: string;
  type: string;
  downloadUrl: string;
}