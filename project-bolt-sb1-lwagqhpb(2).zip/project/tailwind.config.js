/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#d4f1f4',
          100: '#b8e9ed',
          200: '#9ce1e6',
          300: '#75e6da',
          400: '#4dd4c7',
          500: '#189ab4',
          600: '#158a9f',
          700: '#127a8a',
          800: '#0f6a75',
          900: '#05445e',
        },
        blue: {
          50: '#d4f1f4',
          100: '#b8e9ed',
          200: '#9ce1e6',
          300: '#75e6da',
          400: '#4dd4c7',
          500: '#189ab4',
          600: '#158a9f',
          700: '#127a8a',
          800: '#0f6a75',
          900: '#05445e',
        }
      },
      teal: {
        50: '#f0fdfa',
        100: '#ccfbf1',
        200: '#99f6e4',
        300: '#5eead4',
        400: '#2dd4bf',
        500: '#14b8a6',
        600: '#0d9488',
        700: '#0f766e',
        800: '#115e59',
        900: '#134e4a',
        'green': '#175873',
        'main': '#2b7c85',
        'seafoam': '#87aca3',
        'royal': '#0c1446',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
};