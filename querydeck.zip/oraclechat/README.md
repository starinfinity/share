# QueryDeck — Chat with your Oracle databases

Plain-English questions in → Azure OpenAI writes Oracle SQL → query runs read-only →
results, execution stats, and an auto-generated chart come back in a chat UI.

```
┌────────────┐  question   ┌──────────────┐  schema + prompt  ┌──────────────┐
│  React TS  │ ──────────▶ │   FastAPI    │ ────────────────▶ │ Azure OpenAI │
│  frontend  │ ◀────────── │   backend    │ ◀──────────────── │  deployment  │
└────────────┘  results +  └──────┬───────┘     SQL (JSON)    └──────────────┘
                stats             │ validated read-only SQL
                                  ▼
                        ┌──────────────────┐
                        │ Oracle DBs (1..n)│  python-oracledb thin mode
                        └──────────────────┘
```

## Features

- **Database dropdown** — every Oracle connection configured in `.env` appears in the picker.
- **NL → SQL** — Azure OpenAI gets a cached schema summary of the chosen database and returns
  strict-JSON `{sql, explanation}`. Follow-up questions reuse recent conversation history.
- **Read-only guard** — `sqlparse`-based validation; only single `SELECT`/`WITH` statements
  ever reach Oracle. DML/DDL/PLSQL is rejected before execution.
- **Results table** — shows the **first 10 columns by default**, with a column picker to add
  more / show all, sticky headers, NULL styling, and numeric alignment.
- **Exports** — download the *currently filtered columns* as **Excel (.xlsx), CSV, or TXT**
  (fixed-width text), generated server-side.
- **Query stats** — circular progress meters break the round trip into SQL generation,
  DB execution, and row fetch, plus a rows-vs-cap meter.
- **Auto visualization** — bar chart for categorical results, line chart for time series,
  up to 4 numeric series (Recharts).
- **Two themes** — `Neon` (dark glassmorphism with neon accents and glowing meters) and
  `Minimal` (off-white, deep navy, one electric ultraviolet accent). Persisted per browser.

## Backend setup

```bash
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # then edit .env
uvicorn app.main:app --reload --port 8000
```

`.env` essentials:

| Variable | Meaning |
|---|---|
| `AZURE_OPENAI_ENDPOINT` / `AZURE_OPENAI_API_KEY` | Your Azure OpenAI resource |
| `AZURE_OPENAI_DEPLOYMENT` | Deployment name (e.g. `gpt-4o`) |
| `ORACLE_DATABASES` | JSON map: `{"NAME": {"user", "password", "dsn", "description"}}` |
| `MAX_RESULT_ROWS` | Hard cap on rows returned to the UI (default 500) |

`python-oracledb` runs in **thin mode** — no Oracle Instant Client install required.
Use a **read-only DB account** per database for defense in depth; the SQL guard is a
second layer, not the only one.

API docs are auto-generated at `http://localhost:8000/docs`.

## Frontend setup

```bash
cd frontend
npm install
npm run dev          # http://localhost:5173  (proxies /api → :8000)
```

## API surface

| Endpoint | Purpose |
|---|---|
| `GET /api/databases?check=true` | Dropdown contents (+optional reachability ping) |
| `POST /api/chat` | `{database, question, history}` → SQL + rows + stats |
| `POST /api/export` | Filtered columns → streamed `csv` / `xlsx` / `txt` file |
| `GET /health` | Liveness probe |

## Production notes

- Put the backend behind auth (e.g. Azure AD / OAuth proxy) before exposing it.
- `npm run build` produces static files; serve them from any web server and point it at the API,
  or mount them in FastAPI with `StaticFiles`.
- Increase `min/max` pool sizes in `app/services/oracle_db.py` for heavier concurrency.
- The schema summary is cached 10 minutes per database; restart or wait to pick up DDL changes.
