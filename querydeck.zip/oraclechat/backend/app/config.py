"""Application settings loaded from environment / .env file."""
from functools import lru_cache
from typing import Dict, List

from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict


class OracleDatabaseConfig(BaseModel):
    user: str
    password: str
    dsn: str                       # EZConnect: host:port/service_name
    description: str = ""


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    # Azure OpenAI
    azure_openai_endpoint: str
    azure_openai_api_key: str
    azure_openai_deployment: str = "gpt-4o"
    azure_openai_api_version: str = "2024-06-01"

    # Oracle databases keyed by display name
    oracle_databases: Dict[str, OracleDatabaseConfig] = {}

    # App behaviour
    max_result_rows: int = 500
    query_timeout_seconds: int = 60
    cors_origins: List[str] = ["http://localhost:5173"]


@lru_cache
def get_settings() -> Settings:
    return Settings()
