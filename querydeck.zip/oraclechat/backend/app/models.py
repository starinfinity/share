"""API request / response schemas."""
from typing import Any, List, Optional

from pydantic import BaseModel, Field


class DatabaseInfo(BaseModel):
    name: str
    description: str = ""
    reachable: Optional[bool] = None


class ChatRequest(BaseModel):
    database: str = Field(..., description="Database name from /databases")
    question: str = Field(..., min_length=1, description="Plain-English question")
    history: List[dict] = Field(default_factory=list,
                                description="Prior turns [{role, content}] for follow-up questions")


class QueryStats(BaseModel):
    generation_ms: float          # time spent in Azure OpenAI
    execution_ms: float           # time spent executing SQL in Oracle
    fetch_ms: float               # time spent fetching rows
    total_ms: float
    rows_returned: int
    row_cap: int                  # MAX_RESULT_ROWS
    truncated: bool               # True if the cap was hit
    columns: int
    database: str


class ChatResponse(BaseModel):
    sql: str
    explanation: str              # model's one-line summary of what the SQL does
    columns: List[str]
    column_types: List[str]
    rows: List[List[Any]]
    stats: QueryStats


class ExportRequest(BaseModel):
    columns: List[str]
    rows: List[List[Any]]
    selected_columns: List[str]   # the user's filtered column subset
    format: str = Field(..., pattern="^(csv|xlsx|txt)$")
    filename: str = "query_result"


class ErrorResponse(BaseModel):
    detail: str
    sql: Optional[str] = None     # include generated SQL so the user can debug
