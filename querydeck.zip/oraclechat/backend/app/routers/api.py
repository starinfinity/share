"""All API routes."""
import csv
import io
import time

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse

from ..config import get_settings
from ..models import ChatRequest, ChatResponse, DatabaseInfo, ExportRequest, QueryStats
from ..services import azure_llm, oracle_db
from ..services.sql_guard import UnsafeSQLError, validate_readonly

router = APIRouter(prefix="/api")


@router.get("/databases", response_model=list[DatabaseInfo])
def list_databases(check: bool = False):
    """Databases for the dropdown. Pass ?check=true to ping each one."""
    out = []
    for name, cfg in get_settings().oracle_databases.items():
        out.append(DatabaseInfo(
            name=name,
            description=cfg.description,
            reachable=oracle_db.ping(name) if check else None,
        ))
    return out


@router.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    settings = get_settings()
    if req.database not in settings.oracle_databases:
        raise HTTPException(404, f"Unknown database '{req.database}'")

    t_start = time.perf_counter()

    # 1. Schema context for the LLM
    try:
        schema = oracle_db.get_schema_summary(req.database)
    except Exception as exc:
        raise HTTPException(502, f"Could not read schema from {req.database}: {exc}")

    # 2. NL -> SQL
    try:
        sql, explanation, generation_ms = azure_llm.generate_sql(req.question, schema, req.history)
    except Exception as exc:
        raise HTTPException(502, f"Azure OpenAI error: {exc}")

    if not sql:
        raise HTTPException(422, explanation or "The model could not produce SQL for this question.")

    # 3. Safety gate
    try:
        sql = validate_readonly(sql)
    except UnsafeSQLError as exc:
        raise HTTPException(400, f"Generated SQL was rejected: {exc}")

    # 4. Execute
    try:
        columns, col_types, rows, exec_stats = oracle_db.execute_readonly(req.database, sql)
    except Exception as exc:
        # Surface the SQL so the user can see what failed
        raise HTTPException(400, f"Oracle error: {exc} -- SQL: {sql}")

    total_ms = round((time.perf_counter() - t_start) * 1000, 1)
    stats = QueryStats(
        generation_ms=generation_ms,
        execution_ms=exec_stats["execution_ms"],
        fetch_ms=exec_stats["fetch_ms"],
        total_ms=total_ms,
        rows_returned=exec_stats["rows_returned"],
        row_cap=exec_stats["row_cap"],
        truncated=exec_stats["truncated"],
        columns=len(columns),
        database=req.database,
    )
    return ChatResponse(sql=sql, explanation=explanation, columns=columns,
                        column_types=col_types, rows=rows, stats=stats)


@router.post("/export")
def export(req: ExportRequest):
    """Server-side export of the user's filtered columns to csv / xlsx / txt."""
    idx = [req.columns.index(c) for c in req.selected_columns if c in req.columns]
    if not idx:
        raise HTTPException(400, "No valid columns selected.")
    header = [req.columns[i] for i in idx]
    data = [[row[i] for i in idx] for row in req.rows]

    if req.format == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(header)
        writer.writerows(data)
        media, ext = "text/csv", "csv"
        body = io.BytesIO(buf.getvalue().encode("utf-8-sig"))

    elif req.format == "txt":
        buf = io.StringIO()
        widths = [max(len(str(h)), *(len(str(r[i_])) for r in data)) if data else len(str(h))
                  for i_, h in enumerate(header)]
        buf.write("  ".join(str(h).ljust(w) for h, w in zip(header, widths)) + "\n")
        buf.write("  ".join("-" * w for w in widths) + "\n")
        for r in data:
            buf.write("  ".join(str(v if v is not None else "").ljust(w)
                                for v, w in zip(r, widths)) + "\n")
        media, ext = "text/plain", "txt"
        body = io.BytesIO(buf.getvalue().encode("utf-8"))

    else:  # xlsx
        from openpyxl import Workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Query result"
        ws.append(header)
        for r in data:
            ws.append([v if v is not None else "" for v in r])
        ws.freeze_panes = "A2"
        body = io.BytesIO()
        wb.save(body)
        body.seek(0)
        media = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ext = "xlsx"

    return StreamingResponse(
        body, media_type=media,
        headers={"Content-Disposition": f'attachment; filename="{req.filename}.{ext}"'},
    )
