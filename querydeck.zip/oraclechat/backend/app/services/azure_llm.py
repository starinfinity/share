"""Natural language -> Oracle SQL via Azure OpenAI."""
import json
import time
from typing import List, Tuple

from openai import AzureOpenAI

from ..config import get_settings

_client: AzureOpenAI | None = None


def _client_instance() -> AzureOpenAI:
    global _client
    if _client is None:
        s = get_settings()
        _client = AzureOpenAI(
            azure_endpoint=s.azure_openai_endpoint,
            api_key=s.azure_openai_api_key,
            api_version=s.azure_openai_api_version,
        )
    return _client


SYSTEM_PROMPT = """You are an expert Oracle SQL writer. Convert the user's question into ONE
read-only Oracle SQL query against the schema below.

Rules:
- Output STRICT JSON: {"sql": "...", "explanation": "..."} and nothing else.
- SELECT or WITH statements only. Never modify data. No DDL/DML/PLSQL.
- Use Oracle syntax (FETCH FIRST n ROWS ONLY, NVL, TO_CHAR, SYSDATE, etc.).
- Unless the user asks otherwise, cap results with FETCH FIRST 500 ROWS ONLY.
- Prefer readable column aliases in UPPER_SNAKE_CASE.
- If the question is ambiguous, make the most reasonable assumption and note it
  in "explanation" (one short sentence describing what the query returns).
- If the question cannot be answered from the schema, return
  {"sql": "", "explanation": "<why it cannot be answered>"}.

SCHEMA:
{schema}
"""


def generate_sql(question: str, schema: str, history: List[dict]) -> Tuple[str, str, float]:
    """Returns (sql, explanation, generation_ms)."""
    s = get_settings()
    messages = [{"role": "system", "content": SYSTEM_PROMPT.replace("{schema}", schema)}]
    # Include a short window of prior turns so follow-ups like "now by region" work
    for turn in history[-6:]:
        if turn.get("role") in ("user", "assistant") and turn.get("content"):
            messages.append({"role": turn["role"], "content": str(turn["content"])[:2000]})
    messages.append({"role": "user", "content": question})

    t0 = time.perf_counter()
    resp = _client_instance().chat.completions.create(
        model=s.azure_openai_deployment,
        messages=messages,
        temperature=0,
        response_format={"type": "json_object"},
    )
    generation_ms = round((time.perf_counter() - t0) * 1000, 1)

    payload = json.loads(resp.choices[0].message.content)
    return payload.get("sql", ""), payload.get("explanation", ""), generation_ms
