"""Oracle access layer: pooled connections, schema cache, timed execution."""
import time
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, List, Tuple

import oracledb

from ..config import OracleDatabaseConfig, get_settings

_pools: Dict[str, oracledb.ConnectionPool] = {}
_schema_cache: Dict[str, str] = {}
_SCHEMA_TTL_SECONDS = 600
_schema_cached_at: Dict[str, float] = {}


def _get_pool(name: str, cfg: OracleDatabaseConfig) -> oracledb.ConnectionPool:
    if name not in _pools:
        _pools[name] = oracledb.create_pool(
            user=cfg.user, password=cfg.password, dsn=cfg.dsn,
            min=1, max=4, increment=1, getmode=oracledb.POOL_GETMODE_WAIT,
        )
    return _pools[name]


def _jsonable(value: Any) -> Any:
    """Convert Oracle column values to JSON-friendly types."""
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, oracledb.LOB):
        return value.read()
    if isinstance(value, bytes):
        return value.hex()
    return value


def ping(name: str) -> bool:
    cfg = get_settings().oracle_databases[name]
    try:
        with _get_pool(name, cfg).acquire() as conn:
            conn.ping()
        return True
    except Exception:
        return False


def get_schema_summary(name: str) -> str:
    """Compact schema description used as LLM context (cached)."""
    now = time.time()
    if name in _schema_cache and now - _schema_cached_at.get(name, 0) < _SCHEMA_TTL_SECONDS:
        return _schema_cache[name]

    cfg = get_settings().oracle_databases[name]
    with _get_pool(name, cfg).acquire() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT table_name, column_name, data_type
            FROM   user_tab_columns
            ORDER  BY table_name, column_id
        """)
        tables: Dict[str, List[str]] = {}
        for table, column, dtype in cur:
            tables.setdefault(table, []).append(f"{column} {dtype}")

    lines = [f"TABLE {t}: " + ", ".join(cols) for t, cols in tables.items()]
    summary = "\n".join(lines) or "(no tables visible to this user)"
    # Keep the prompt bounded for very large schemas
    if len(summary) > 24000:
        summary = summary[:24000] + "\n...(schema truncated)"
    _schema_cache[name] = summary
    _schema_cached_at[name] = now
    return summary


def execute_readonly(name: str, sql: str) -> Tuple[List[str], List[str], List[List[Any]], dict]:
    """Run a validated read-only query. Returns columns, types, rows, timing stats."""
    settings = get_settings()
    cfg = settings.oracle_databases[name]
    pool = _get_pool(name, cfg)

    with pool.acquire() as conn:
        conn.call_timeout = settings.query_timeout_seconds * 1000  # ms
        cur = conn.cursor()
        cur.arraysize = 200

        t0 = time.perf_counter()
        cur.execute(sql)
        t1 = time.perf_counter()

        columns = [d.name for d in cur.description]
        col_types = [d.type.name if d.type else "UNKNOWN" for d in cur.description]
        raw = cur.fetchmany(settings.max_result_rows + 1)
        t2 = time.perf_counter()

    truncated = len(raw) > settings.max_result_rows
    raw = raw[: settings.max_result_rows]
    rows = [[_jsonable(v) for v in row] for row in raw]

    stats = {
        "execution_ms": round((t1 - t0) * 1000, 1),
        "fetch_ms": round((t2 - t1) * 1000, 1),
        "rows_returned": len(rows),
        "row_cap": settings.max_result_rows,
        "truncated": truncated,
    }
    return columns, col_types, rows, stats
