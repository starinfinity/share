"""Guard rails: only read-only SQL is ever sent to Oracle."""
import re

import sqlparse

# Statements that are never allowed, even inside CTEs or comments tricks
FORBIDDEN = re.compile(
    r"\b(insert|update|delete|merge|drop|truncate|alter|create|grant|revoke|"
    r"comment|lock|call|begin|declare|execute)\b",
    re.IGNORECASE,
)


class UnsafeSQLError(ValueError):
    pass


def strip_code_fences(text: str) -> str:
    """LLMs love wrapping SQL in ```sql fences; remove them."""
    text = text.strip()
    text = re.sub(r"^```(?:sql)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip().rstrip(";")


def validate_readonly(sql: str) -> str:
    """Raise UnsafeSQLError unless `sql` is a single read-only statement."""
    sql = strip_code_fences(sql)
    statements = [s for s in sqlparse.parse(sql) if s.token_first(skip_cm=True)]
    if len(statements) != 1:
        raise UnsafeSQLError("Exactly one SQL statement is allowed.")

    stmt = statements[0]
    first = stmt.token_first(skip_cm=True)
    if first is None or first.normalized.upper() not in ("SELECT", "WITH"):
        raise UnsafeSQLError("Only SELECT / WITH queries are permitted.")

    # Belt-and-braces keyword scan on the comment-stripped text
    cleaned = sqlparse.format(sql, strip_comments=True)
    if FORBIDDEN.search(cleaned):
        raise UnsafeSQLError("Query contains a forbidden keyword; only read-only queries are permitted.")

    return sql
