import { FormEvent, KeyboardEvent, useEffect, useRef, useState } from "react";
import { fetchDatabases, sendChat } from "./api";
import MessageBubble from "./components/MessageBubble";
import type { ChatMessage, DatabaseInfo, ThemeName } from "./types";
import "./themes.css";

const SUGGESTIONS: { icon: string; text: string }[] = [
  { icon: "ti-trending-up", text: "Top 10 customers by total order value this year" },
  { icon: "ti-calendar-stats", text: "Monthly revenue trend for the last 12 months" },
  { icon: "ti-alert-circle", text: "Which products are out of stock?" },
];

let nextId = 0;
const uid = () => `m${++nextId}`;

export default function App() {
  const [theme, setTheme] = useState<ThemeName>(
    () => (localStorage.getItem("qd-theme-v4") as ThemeName) || "light",
  );
  const [databases, setDatabases] = useState<DatabaseInfo[]>([]);
  const [db, setDb] = useState<string>("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("qd-theme-v4", theme);
  }, [theme]);

  useEffect(() => {
    fetchDatabases()
      .then((dbs) => {
        setDatabases(dbs);
        if (dbs.length) setDb(dbs[0].name);
      })
      .catch(() =>
        setMessages([{
          id: uid(), role: "assistant",
          content: "", error: "Could not reach the backend. Is the FastAPI server running on port 8000?",
        }]),
      );
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const ask = async (question: string) => {
    if (!question.trim() || !db || busy) return;
    setBusy(true);
    setInput("");
    const pendingId = uid();
    const history = messages
      .filter((m) => !m.error && !m.pending)
      .map((m) => ({
        role: m.role,
        content: m.role === "user" ? m.content : m.result?.sql ?? m.content,
      }));

    setMessages((prev) => [
      ...prev,
      { id: uid(), role: "user", content: question },
      { id: pendingId, role: "assistant", content: "", pending: true },
    ]);

    try {
      const result = await sendChat(db, question, history);
      setMessages((prev) =>
        prev.map((m) => (m.id === pendingId ? { ...m, pending: false, result } : m)),
      );
    } catch (err) {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === pendingId
            ? { ...m, pending: false, error: err instanceof Error ? err.message : "Unexpected error" }
            : m,
        ),
      );
    } finally {
      setBusy(false);
    }
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    ask(input);
  };
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      ask(input);
    }
  };

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">QueryDeck</div>
        <div className="brand-sub">Oracle · NL → SQL</div>

        <button className="nav-item active"><i className="ti ti-message-circle" /> Chat</button>
        <button className="nav-item" onClick={() => setMessages([])}><i className="ti ti-plus" /> New</button>
        <button className="nav-item" disabled><i className="ti ti-history" /> History</button>
        <button className="nav-item" disabled><i className="ti ti-bookmark" /> Saved</button>

        <div className="nav-section-label">Workspace</div>
        <button className="nav-item" disabled><i className="ti ti-database" /> Databases</button>
        <button className="nav-item" disabled><i className="ti ti-settings" /> Settings</button>

        <div className="sidebar-footer">
          <div className="theme-switch" role="group" aria-label="Theme">
            <button className={theme === "light" ? "on" : ""} onClick={() => setTheme("light")}>
              <i className="ti ti-sun" /> Light
            </button>
            <button className={theme === "dark" ? "on" : ""} onClick={() => setTheme("dark")}>
              <i className="ti ti-moon" /> Dark
            </button>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <h1>Chat with your Oracle data</h1>
          <div className="db-select">
            <label htmlFor="db">Database</label>
            <select id="db" value={db} onChange={(e) => setDb(e.target.value)}>
              {databases.map((d) => (
                <option key={d.name} value={d.name} title={d.description}>{d.name}</option>
              ))}
            </select>
          </div>
        </header>

        <div className="chat-scroll" ref={scrollRef}>
          <div className="chat-inner">
            {messages.length === 0 ? (
              <div className="empty-state">
                <div className="eyebrow">Plain English · in</div>
                <h2>Ask your database <em>anything.</em></h2>
                <p>Pick a database, type a question, and read the answer as a chart, a table, or the SQL behind it.</p>
                <div className="suggestions">
                  {SUGGESTIONS.map((s) => (
                    <button key={s.text} onClick={() => ask(s.text)}>
                      <i className={`ti ${s.icon}`} />
                      {s.text}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((m) => <MessageBubble key={m.id} msg={m} />)
            )}
          </div>
        </div>

        <form className="composer" onSubmit={onSubmit}>
          <div className="composer-inner">
            <textarea
              rows={1}
              placeholder={db ? `Ask ${db} a question…` : "Waiting for databases…"}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKey}
              disabled={busy || !db}
              aria-label="Your question"
            />
            <button className="send-btn" type="submit" disabled={busy || !input.trim() || !db}>
              {busy ? <><i className="ti ti-loader" /> Running</> : <>Run <i className="ti ti-arrow-right" /></>}
            </button>
          </div>
        </form>
      </main>
    </div>
  );
}
