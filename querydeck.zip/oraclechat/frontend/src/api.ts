import type { ChatResult, DatabaseInfo, ExportFormat } from "./types";

const BASE = "/api";

async function handle<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let detail = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body.detail) detail = body.detail;
    } catch {
      /* keep default message */
    }
    throw new Error(detail);
  }
  return res.json() as Promise<T>;
}

export async function fetchDatabases(check = false): Promise<DatabaseInfo[]> {
  return handle(await fetch(`${BASE}/databases?check=${check}`));
}

export async function sendChat(
  database: string,
  question: string,
  history: { role: string; content: string }[],
): Promise<ChatResult> {
  return handle(
    await fetch(`${BASE}/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ database, question, history }),
    }),
  );
}

export async function downloadExport(
  columns: string[],
  rows: unknown[][],
  selectedColumns: string[],
  format: ExportFormat,
  filename = "query_result",
): Promise<void> {
  const res = await fetch(`${BASE}/export`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ columns, rows, selected_columns: selectedColumns, format, filename }),
  });
  if (!res.ok) throw new Error(`Export failed (${res.status})`);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${filename}.${format}`;
  a.click();
  URL.revokeObjectURL(url);
}
