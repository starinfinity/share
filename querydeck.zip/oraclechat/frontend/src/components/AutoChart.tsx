import { useMemo } from "react";
import {
  Bar, BarChart, CartesianGrid, Legend, Line, LineChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";

const SERIES_COLORS = ["var(--data-1)", "var(--data-2)", "var(--data-3)", "var(--data-4)"];
const MAX_POINTS = 40;

interface Props {
  columns: string[];
  columnTypes: string[];
  rows: unknown[][];
}

function isNumericType(t: string) {
  return /NUMBER|FLOAT|BINARY|INT|DECIMAL/i.test(t);
}
function isDateType(t: string) {
  return /DATE|TIMESTAMP/i.test(t);
}

/** Heuristic chart: first non-numeric column = x-axis, up to 4 numeric columns
 *  = series, date x-axis -> line, categorical -> bar. */
export default function AutoChart({ columns, columnTypes, rows }: Props) {
  const config = useMemo(() => {
    if (rows.length < 2) return null;
    const numericIdx = columns
      .map((_, i) => i)
      .filter((i) => isNumericType(columnTypes[i] ?? "") ||
        rows.every((r) => r[i] === null || typeof r[i] === "number"));
    const labelIdx = columns.map((_, i) => i).find((i) => !numericIdx.includes(i));
    const seriesIdx = numericIdx.filter((i) => i !== labelIdx).slice(0, 4);
    if (labelIdx === undefined || seriesIdx.length === 0) return null;
    const timeline = isDateType(columnTypes[labelIdx] ?? "");
    const data = rows.slice(0, MAX_POINTS).map((r) => {
      const point: Record<string, unknown> = { __x: String(r[labelIdx] ?? "—") };
      for (const i of seriesIdx) point[columns[i]] = r[i];
      return point;
    });
    return { labelIdx, seriesIdx, timeline, data };
  }, [columns, columnTypes, rows]);

  if (!config) {
    return (
      <div className="chart-stage" style={{ textAlign: "center", padding: "40px 18px", color: "var(--text-dim)", fontSize: 13 }}>
        <i className="ti ti-chart-bar-off" style={{ fontSize: 24, color: "var(--text-faint)", display: "block", marginBottom: 8 }} />
        This result doesn't have a chartable shape — view it in the <b>Data</b> tab.
      </div>
    );
  }

  const { labelIdx, seriesIdx, timeline, data } = config;
  const ChartTag = timeline ? LineChart : BarChart;

  return (
    <div className="chart-stage">
      <div className="chart-meta">
        <span className="lhs">{columns[labelIdx]} <em style={{ color: "var(--text-faint)", fontStyle: "normal" }}>·</em> {seriesIdx.map((i) => columns[i]).join(", ")}</span>
        <span className="rhs">{rows.length > MAX_POINTS ? `First ${MAX_POINTS} of ${rows.length}` : `${rows.length} points`}</span>
      </div>
      <ResponsiveContainer width="100%" height={280}>
        <ChartTag data={data} margin={{ top: 4, right: 12, bottom: 4, left: 0 }}>
          <CartesianGrid stroke="var(--chart-grid)" vertical={false} />
          <XAxis dataKey="__x" tick={{ fontSize: 10.5, fill: "var(--text-dim)" }}
            tickLine={false} axisLine={{ stroke: "var(--border)" }} />
          <YAxis tick={{ fontSize: 10.5, fill: "var(--text-dim)" }}
            tickLine={false} axisLine={false} width={56} />
          <Tooltip
            cursor={{ fill: "var(--accent-soft)" }}
            contentStyle={{
              background: "var(--surface)", border: "1px solid var(--border)",
              borderRadius: 6, color: "var(--text)", fontSize: 12,
              fontFamily: "var(--font-mono)",
            }}
          />
          {seriesIdx.length > 1 && <Legend wrapperStyle={{ fontSize: 11, color: "var(--text-dim)" }} iconType="circle" iconSize={8} />}
          {seriesIdx.map((i, k) =>
            timeline ? (
              <Line key={columns[i]} type="monotone" dataKey={columns[i]}
                stroke={SERIES_COLORS[k]} strokeWidth={2} dot={{ r: 2.5 }}
                activeDot={{ r: 4 }} />
            ) : (
              <Bar key={columns[i]} dataKey={columns[i]}
                fill={SERIES_COLORS[k]} radius={[3, 3, 0, 0]} maxBarSize={32} />
            ),
          )}
        </ChartTag>
      </ResponsiveContainer>
    </div>
  );
}
