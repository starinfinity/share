import type { ChatMessage } from "../types";
import ResultsPanel from "./ResultsPanel";

/** Render one chat turn. The assistant has three shapes:
 *  - pending (typing dots)
 *  - error (red-bordered card)
 *  - success (full result card with tabs) */
export default function MessageBubble({ msg }: { msg: ChatMessage }) {
  if (msg.role === "user") {
    return <div className="bubble user">{msg.content}</div>;
  }
  if (msg.pending) {
    return (
      <div className="bubble assistant-text" aria-live="polite">
        <span className="typing"><span /><span /><span /></span>
      </div>
    );
  }
  if (msg.error) {
    return (
      <div className="bubble error">
        <strong style={{ fontWeight: 500, display: "block", marginBottom: 4 }}>That didn't work</strong>
        {msg.error}
      </div>
    );
  }
  if (msg.result) {
    return <ResultsPanel result={msg.result} />;
  }
  return null;
}
