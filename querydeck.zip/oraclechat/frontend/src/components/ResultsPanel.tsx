import { useEffect, useMemo, useRef, useState } from "react";
import { downloadExport } from "../api";
import type { ChatResult, ExportFormat } from "../types";
import AutoChart from "./AutoChart";
import StatsStrip from "./StatsMeters";

const DEFAULT_VISIBLE_COLUMNS = 10;
type Tab = "viz" | "data" | "sql";

/** Tiny client-side SQL syntax highlighter. Keywords + numbers + strings.
 *  Good enough for the visual texture; keeps the dependency footprint
 *  small (no monaco/highlight.js). */
function highlightSQL(sql: string): { html: string } {
  const KEYWORDS =
    /\b(SELECT|FROM|WHERE|GROUP BY|ORDER BY|HAVING|JOIN|LEFT JOIN|RIGHT JOIN|INNER JOIN|OUTER JOIN|ON|AS|AND|OR|NOT|IN|NULL|IS|LIKE|BETWEEN|CASE|WHEN|THEN|ELSE|END|FETCH FIRST|ROWS ONLY|WITH|UNION|ALL|DISTINCT|COUNT|SUM|AVG|MIN|MAX|ROUND|NVL|COALESCE|TO_CHAR|TO_DATE|TRUNC|SYSDATE|DESC|ASC|LIMIT|OFFSET)\b/gi;
  let html = sql.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  html = html.replace(/('[^']*')/g, '<span class="str">$1</span>');
  html = html.replace(/\b(\d+(?:\.\d+)?)\b/g, '<span class="num">$1</span>');
  html = html.replace(KEYWORDS, '<span class="kw">$&</span>');
  return { html };
}

export default function ResultsPanel({ result }: { result: ChatResult }) {
  const { columns, column_types, rows, stats, sql, explanation } = result;

  // Pick a default tab: chart if it's chart-shaped, otherwise data
  const defaultTab: Tab = useMemo(() => {
    const hasNumeric = column_types.some((t) => /NUMBER|FLOAT|BINARY|INT/i.test(t));
    return rows.length >= 2 && hasNumeric ? "viz" : "data";
  }, [column_types, rows]);

  const [tab, setTab] = useState<Tab>(defaultTab);
  const [visible, setVisible] = useState<Set<string>>(
    () => new Set(columns.slice(0, DEFAULT_VISIBLE_COLUMNS)),
  );
  const [colsOpen, setColsOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [exporting, setExporting] = useState<ExportFormat | null>(null);
  const [copied, setCopied] = useState(false);
  const popRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (popRef.current && !popRef.current.contains(e.target as Node)) {
        setColsOpen(false);
        setExportOpen(false);
      }
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const visibleIdx = useMemo(
    () => columns.map((c, i) => [c, i] as const).filter(([c]) => visible.has(c)).map(([, i]) => i),
    [columns, visible],
  );

  const toggle = (col: string) =>
    setVisible((prev) => {
      const next = new Set(prev);
      if (next.has(col)) next.delete(col);
      else next.add(col);
      return next;
    });

  const handleExport = async (format: ExportFormat) => {
    setExporting(format);
    setExportOpen(false);
    try {
      await downloadExport(columns, rows, columns.filter((c) => visible.has(c)), format);
    } finally {
      setExporting(null);
    }
  };

  const copySql = async () => {
    await navigator.clipboard.writeText(sql);
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };

  const isNum = (i: number) => /NUMBER|FLOAT|BINARY|INT/i.test(column_types[i] ?? "");
  const hl = useMemo(() => highlightSQL(sql), [sql]);

  return (
    <div className="result-card" ref={popRef}>
      <header className="result-header">
        <p className="explanation">{explanation || "Query result"}</p>
        <StatsStrip stats={stats} />
      </header>

      <nav className="tab-bar" role="tablist">
        <button role="tab" aria-selected={tab === "viz"}
          className={`tab-btn ${tab === "viz" ? "active" : ""}`} onClick={() => setTab("viz")}>
          <i className="ti ti-chart-bar" /> Visualization
        </button>
        <button role="tab" aria-selected={tab === "data"}
          className={`tab-btn ${tab === "data" ? "active" : ""}`} onClick={() => setTab("data")}>
          <i className="ti ti-table" /> Data
          <span className="count">{rows.length.toLocaleString()}</span>
        </button>
        <button role="tab" aria-selected={tab === "sql"}
          className={`tab-btn ${tab === "sql" ? "active" : ""}`} onClick={() => setTab("sql")}>
          <i className="ti ti-code" /> SQL
        </button>
      </nav>

      <div className="tab-panel" role="tabpanel">
        {tab === "viz" && (
          <AutoChart columns={columns} columnTypes={column_types} rows={rows} />
        )}

        {tab === "data" && (
          <>
            <div className="result-toolbar">
              <span className="col-note">
                Showing {visibleIdx.length} of {columns.length} columns · {rows.length.toLocaleString()} rows
                {stats.truncated ? ` (capped at ${stats.row_cap})` : ""}
              </span>

              <div className="popover-anchor">
                <button className="icon-btn" onClick={() => { setColsOpen((o) => !o); setExportOpen(false); }}
                  aria-expanded={colsOpen}>
                  <i className="ti ti-columns-3" /> Columns
                </button>
                {colsOpen && (
                  <div className="popover cols">
                    <div className="popover-actions">
                      <button onClick={() => setVisible(new Set(columns))}>Show all</button>
                      <button onClick={() => setVisible(new Set(columns.slice(0, DEFAULT_VISIBLE_COLUMNS)))}>
                        First {DEFAULT_VISIBLE_COLUMNS}
                      </button>
                    </div>
                    {columns.map((c) => (
                      <label key={c} className="col-check">
                        <input type="checkbox" checked={visible.has(c)} onChange={() => toggle(c)} />
                        {c}
                      </label>
                    ))}
                  </div>
                )}
              </div>

              <div className="popover-anchor">
                <button className="icon-btn" onClick={() => { setExportOpen((o) => !o); setColsOpen(false); }}
                  aria-expanded={exportOpen} disabled={exporting !== null}>
                  <i className="ti ti-download" />
                  {exporting ? "Exporting…" : "Export"}
                  <i className="ti ti-chevron-down" style={{ fontSize: 12, marginLeft: 2 }} />
                </button>
                {exportOpen && (
                  <div className="popover">
                    <button className="menu-item" onClick={() => handleExport("xlsx")}>
                      <i className="ti ti-file-spreadsheet" /> Excel <span className="ext">.xlsx</span>
                    </button>
                    <button className="menu-item" onClick={() => handleExport("csv")}>
                      <i className="ti ti-file-text" /> CSV <span className="ext">.csv</span>
                    </button>
                    <button className="menu-item" onClick={() => handleExport("txt")}>
                      <i className="ti ti-file-description" /> Text <span className="ext">.txt</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div className="table-wrap" tabIndex={0}>
              <table className="results">
                <thead>
                  <tr>{visibleIdx.map((i) => <th key={columns[i]}>{columns[i]}</th>)}</tr>
                </thead>
                <tbody>
                  {rows.map((row, r) => (
                    <tr key={r}>
                      {visibleIdx.map((i) => {
                        const v = row[i];
                        return (
                          <td key={i} className={v === null ? "null" : isNum(i) ? "num" : ""}>
                            {v === null ? "NULL" : typeof v === "number" ? v.toLocaleString() : String(v)}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {tab === "sql" && (
          <pre className="sql-block">
            <button className="sql-copy" onClick={copySql}>
              <i className={`ti ti-${copied ? "check" : "copy"}`} /> {copied ? "Copied" : "Copy"}
            </button>
            <code dangerouslySetInnerHTML={{ __html: hl.html }} />
          </pre>
        )}
      </div>
    </div>
  );
}
