import { useState } from "react";
import type { QueryStats } from "../types";

/** Quiet meta line: one row showing only what you glance at —
 *  total time + row count + DB name. The full timing breakdown
 *  (SQL / run / fetch) is hidden behind a "details" toggle since
 *  you only look at it when something feels slow. */
export default function MetaLine({ stats }: { stats: QueryStats }) {
  const [open, setOpen] = useState(false);
  const fmt = (ms: number) => (ms >= 1000 ? `${(ms / 1000).toFixed(2)}s` : `${Math.round(ms)}ms`);

  return (
    <>
      <div className="meta-line">
        <span className="meta-item">
          <i className="ti ti-clock" /> {fmt(stats.total_ms)}
        </span>
        <span className="meta-sep">·</span>
        <span className="meta-item">
          <i className="ti ti-table" /> {stats.rows_returned.toLocaleString()} rows
          {stats.truncated && (
            <span style={{ color: "var(--accent-marker)", marginLeft: 4 }}>(capped)</span>
          )}
        </span>
        <span className="meta-sep">·</span>
        <span className="meta-item">
          <i className="ti ti-database" /> {stats.database}
        </span>
        <span className="meta-sep">·</span>
        <button
          className="meta-toggle"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          {open ? "Hide" : "Details"} <i className="ti ti-chevron-down" />
        </button>
      </div>
      {open && (
        <div className="meta-details">
          <span className="item"><span className="k">SQL generation</span> <span className="v">{fmt(stats.generation_ms)}</span></span>
          <span className="item"><span className="k">DB execution</span> <span className="v">{fmt(stats.execution_ms)}</span></span>
          <span className="item"><span className="k">Row fetch</span> <span className="v">{fmt(stats.fetch_ms)}</span></span>
          <span className="item"><span className="k">Columns</span> <span className="v">{stats.columns}</span></span>
          {stats.truncated && (
            <span className="item"><span className="k">Row cap</span> <span className="v">{stats.row_cap}</span></span>
          )}
        </div>
      )}
    </>
  );
}
