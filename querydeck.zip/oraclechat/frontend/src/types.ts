export interface DatabaseInfo {
  name: string;
  description: string;
  reachable: boolean | null;
}

export interface QueryStats {
  generation_ms: number;
  execution_ms: number;
  fetch_ms: number;
  total_ms: number;
  rows_returned: number;
  row_cap: number;
  truncated: boolean;
  columns: number;
  database: string;
}

export interface ChatResult {
  sql: string;
  explanation: string;
  columns: string[];
  column_types: string[];
  rows: unknown[][];
  stats: QueryStats;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;          // user question, or assistant explanation
  result?: ChatResult;      // present on successful assistant turns
  error?: string;           // present on failed assistant turns
  pending?: boolean;
}

export type ThemeName = "light" | "dark";
export type ExportFormat = "csv" | "xlsx" | "txt";
