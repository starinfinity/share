from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import sqlite3
import threading
import uuid
from datetime import datetime
import time
import re

app = Flask(__name__)
CORS(app)

# Initialize database
def init_db():
    conn = sqlite3.connect('scraper.db')
    cursor = conn.cursor()
    
    # Create links table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL,
            text TEXT,
            status TEXT DEFAULT 'pending',
            status_code INTEGER,
            scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            parent_url TEXT
        )
    ''')
    
    # Create scrape_jobs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS scrape_jobs (
            id TEXT PRIMARY KEY,
            url TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            progress INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

# Web scraper class
class WebScraper:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
    
    def is_valid_url(self, url):
        try:
            result = urlparse(url)
            return all([result.scheme, result.netloc])
        except:
            return False
    
    def extract_links(self, url):
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            links = []
            
            # Find all anchor tags with href attributes
            for a_tag in soup.find_all('a', href=True):
                href = a_tag['href']
                text = a_tag.get_text(strip=True)
                
                # Convert relative URLs to absolute
                full_url = urljoin(url, href)
                
                # Filter out unwanted links
                if self.is_valid_url(full_url) and not href.startswith('#'):
                    links.append({
                        'url': full_url,
                        'text': text[:200] if text else '',  # Limit text length
                        'parent_url': url
                    })
            
            return links
        except Exception as e:
            print(f"Error extracting links from {url}: {str(e)}")
            return []
    
    def check_link_status(self, url):
        try:
            response = self.session.head(url, timeout=10, allow_redirects=True)
            return response.status_code
        except:
            try:
                response = self.session.get(url, timeout=10)
                return response.status_code
            except:
                return None
    
    def scrape_website(self, job_id, url):
        conn = sqlite3.connect('scraper.db')
        cursor = conn.cursor()
        
        try:
            # Update job status
            cursor.execute('UPDATE scrape_jobs SET status = ? WHERE id = ?', ('running', job_id))
            conn.commit()
            
            # Extract links
            links = self.extract_links(url)
            total_links = len(links)
            
            if total_links == 0:
                cursor.execute('UPDATE scrape_jobs SET status = ?, progress = ? WHERE id = ?', 
                             ('completed', 100, job_id))
                conn.commit()
                return
            
            # Clear previous links for this URL
            cursor.execute('DELETE FROM links WHERE parent_url = ?', (url,))
            
            # Process each link
            for i, link in enumerate(links):
                # Check link status
                status_code = self.check_link_status(link['url'])
                status = 'active' if status_code and 200 <= status_code < 400 else 'expired'
                
                # Insert link into database
                cursor.execute('''
                    INSERT INTO links (url, text, status, status_code, parent_url)
                    VALUES (?, ?, ?, ?, ?)
                ''', (link['url'], link['text'], status, status_code, link['parent_url']))
                
                # Update progress
                progress = int((i + 1) / total_links * 100)
                cursor.execute('UPDATE scrape_jobs SET progress = ? WHERE id = ?', (progress, job_id))
                conn.commit()
                
                # Small delay to avoid overwhelming servers
                time.sleep(0.1)
            
            # Mark job as completed
            cursor.execute('UPDATE scrape_jobs SET status = ? WHERE id = ?', ('completed', job_id))
            conn.commit()
            
        except Exception as e:
            print(f"Error during scraping: {str(e)}")
            cursor.execute('UPDATE scrape_jobs SET status = ? WHERE id = ?', ('error', job_id))
            conn.commit()
        finally:
            conn.close()

# Initialize scraper
scraper = WebScraper()

@app.route('/api/scrape', methods=['POST'])
def start_scrape():
    data = request.json
    url = data.get('url')
    
    if not url:
        return jsonify({'error': 'URL is required'}), 400
    
    if not scraper.is_valid_url(url):
        return jsonify({'error': 'Invalid URL'}), 400
    
    # Create job
    job_id = str(uuid.uuid4())
    
    conn = sqlite3.connect('scraper.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO scrape_jobs (id, url) VALUES (?, ?)', (job_id, url))
    conn.commit()
    conn.close()
    
    # Start scraping in background thread
    thread = threading.Thread(target=scraper.scrape_website, args=(job_id, url))
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'message': 'Scraping started successfully',
        'job_id': job_id
    })

@app.route('/api/scrape-status/<job_id>')
def get_scrape_status(job_id):
    conn = sqlite3.connect('scraper.db')
    cursor = conn.cursor()
    cursor.execute('SELECT status, progress FROM scrape_jobs WHERE id = ?', (job_id,))
    result = cursor.fetchone()
    conn.close()
    
    if not result:
        return jsonify({'error': 'Job not found'}), 404
    
    return jsonify({
        'status': result[0],
        'progress': result[1]
    })

@app.route('/api/links')
def get_links():
    conn = sqlite3.connect('scraper.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, url, text, status, status_code, scraped_at
        FROM links
        ORDER BY scraped_at DESC
    ''')
    
    rows = cursor.fetchall()
    conn.close()
    
    links = []
    for row in rows:
        links.append({
            'id': row[0],
            'url': row[1],
            'text': row[2],
            'status': row[3],
            'status_code': row[4],
            'scraped_at': row[5]
        })
    
    return jsonify(links)

@app.route('/api/expired-links')
def get_expired_links():
    conn = sqlite3.connect('scraper.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT id, url, text, status, status_code, scraped_at
        FROM links
        WHERE status = 'expired'
        ORDER BY scraped_at DESC
    ''')
    
    rows = cursor.fetchall()
    conn.close()
    
    links = []
    for row in rows:
        links.append({
            'id': row[0],
            'url': row[1],
            'text': row[2],
            'status': row[3],
            'status_code': row[4],
            'scraped_at': row[5]
        })
    
    return jsonify(links)

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    message = data.get('message', '')
    
    # Simple chatbot responses based on keywords
    message_lower = message.lower()
    
    if 'hello' in message_lower or 'hi' in message_lower:
        response = "Hello! I'm here to help you with web scraping and link analysis. What would you like to know?"
    elif 'scrape' in message_lower or 'crawl' in message_lower:
        # Get recent scraping stats
        conn = sqlite3.connect('scraper.db')
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM links')
        total_links = cursor.fetchone()[0]
        cursor.execute('SELECT COUNT(*) FROM links WHERE status = "expired"')
        expired_links = cursor.fetchone()[0]
        conn.close()
        
        response = f"I can help you understand your scraping results. You currently have {total_links} total links discovered, with {expired_links} expired links. Would you like me to analyze any specific aspect?"
    elif 'expired' in message_lower or 'broken' in message_lower:
        conn = sqlite3.connect('scraper.db')
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM links WHERE status = "expired"')
        expired_count = cursor.fetchone()[0]
        cursor.execute('SELECT COUNT(*) FROM links WHERE status_code >= 400 AND status_code < 500')
        client_errors = cursor.fetchone()[0]
        cursor.execute('SELECT COUNT(*) FROM links WHERE status_code >= 500')
        server_errors = cursor.fetchone()[0]
        conn.close()
        
        response = f"You have {expired_count} expired links. Breaking it down: {client_errors} client errors (4xx) and {server_errors} server errors (5xx). Client errors are usually broken or moved pages, while server errors indicate issues with the target server."
    elif 'help' in message_lower:
        response = "I can help you with:\n• Understanding your scraping results\n• Analyzing link status and errors\n• Explaining HTTP status codes\n• Providing insights about your crawled data\n\nJust ask me about any aspect of your web scraping results!"
    elif 'status' in message_lower and 'code' in message_lower:
        response = "HTTP status codes help identify link issues:\n• 200-299: Success\n• 300-399: Redirects\n• 400-499: Client errors (broken links, not found)\n• 500-599: Server errors (server issues)\n\nWould you like me to analyze your specific status codes?"
    else:
        response = "I understand you're asking about web scraping or link analysis. Could you be more specific? I can help with scraping results, link status, error analysis, or general web crawling questions."
    
    return jsonify({
        'message': message,
        'response': response
    })

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5000)