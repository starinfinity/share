import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout';
import UrlScraper from './pages/UrlScraper';
import Chatbot from './pages/Chatbot';
import AllLinks from './pages/AllLinks';
import ExpiredLinks from './pages/ExpiredLinks';

function App() {
  return (
    <ThemeProvider>
      <Router>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
          <Routes>
            <Route path="/" element={<Layout />}>
              <Route index element={<UrlScraper />} />
              <Route path="chat" element={<Chatbot />} />
              <Route path="links" element={<AllLinks />} />
              <Route path="expired" element={<ExpiredLinks />} />
            </Route>
          </Routes>
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;