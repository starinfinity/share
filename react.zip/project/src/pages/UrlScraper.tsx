import React, { useState } from 'react';
import { Search, Globe, Loader, CheckCircle, AlertCircle } from 'lucide-react';
import { api } from '../services/api';

const UrlScraper: React.FC = () => {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;

    setIsLoading(true);
    setStatus('loading');
    setMessage('');

    try {
      const response = await api.scrapeUrl(url);
      setStatus('success');
      setMessage(response.message);
      setUrl('');
    } catch (error) {
      setStatus('error');
      setMessage('Failed to start scraping. Please check the URL and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const validateUrl = (url: string): boolean => {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };

  const isValidUrl = url ? validateUrl(url) : true;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-full mx-auto mb-4">
          <Globe className="w-8 h-8 text-blue-600 dark:text-blue-400" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          Web Scraper
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          Enter a URL to start crawling and analyzing web content
        </p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 mb-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="url" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Website URL
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Globe className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="url"
                id="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com"
                className={`block w-full pl-10 pr-4 py-3 border rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors duration-200 ${
                  !isValidUrl
                    ? 'border-red-300 dark:border-red-600'
                    : 'border-gray-300 dark:border-gray-600'
                }`}
                disabled={isLoading}
              />
            </div>
            {!isValidUrl && (
              <p className="mt-2 text-sm text-red-600 dark:text-red-400">
                Please enter a valid URL (e.g., https://example.com)
              </p>
            )}
          </div>

          <button
            type="submit"
            disabled={!url.trim() || !isValidUrl || isLoading}
            className="w-full flex items-center justify-center px-6 py-3 border border-transparent rounded-lg shadow-sm text-base font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
          >
            {isLoading ? (
              <>
                <Loader className="w-5 h-5 mr-2 animate-spin" />
                Starting Scrape...
              </>
            ) : (
              <>
                <Search className="w-5 h-5 mr-2" />
                Start Scraping
              </>
            )}
          </button>
        </form>
      </div>

      {/* Status Messages */}
      {status !== 'idle' && (
        <div className={`rounded-lg p-4 ${
          status === 'success'
            ? 'bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-800'
            : status === 'error'
            ? 'bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800'
            : 'bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800'
        }`}>
          <div className="flex items-center">
            {status === 'success' && <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400 mr-2" />}
            {status === 'error' && <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400 mr-2" />}
            {status === 'loading' && <Loader className="w-5 h-5 text-blue-600 dark:text-blue-400 mr-2 animate-spin" />}
            <p className={`text-sm font-medium ${
              status === 'success'
                ? 'text-green-800 dark:text-green-200'
                : status === 'error'
                ? 'text-red-800 dark:text-red-200'
                : 'text-blue-800 dark:text-blue-200'
            }`}>
              {message}
            </p>
          </div>
        </div>
      )}

      {/* Instructions */}
      <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">How it works</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-6 h-6 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400">1</span>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Enter a valid website URL to begin crawling</p>
            </div>
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-6 h-6 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400">2</span>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Our crawler analyzes the website structure</p>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-6 h-6 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400">3</span>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300">All links are extracted and categorized</p>
            </div>
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-6 h-6 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center">
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400">4</span>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300">View results in the Links and Expired tabs</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UrlScraper;