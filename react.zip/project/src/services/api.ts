const API_BASE_URL = '/api';

interface ScrapeResponse {
  message: string;
  job_id: string;
}

interface LinkData {
  id: number;
  url: string;
  text: string;
  status: 'active' | 'expired';
  status_code?: number;
  scraped_at: string;
}

interface ChatResponse {
  message: string;
  response: string;
}

class ApiService {
  async scrapeUrl(url: string): Promise<ScrapeResponse> {
    const response = await fetch(`${API_BASE_URL}/scrape`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url }),
    });

    if (!response.ok) {
      throw new Error('Failed to start scraping');
    }

    return response.json();
  }

  async getLinks(): Promise<LinkData[]> {
    const response = await fetch(`${API_BASE_URL}/links`);
    
    if (!response.ok) {
      throw new Error('Failed to fetch links');
    }

    return response.json();
  }

  async getExpiredLinks(): Promise<LinkData[]> {
    const response = await fetch(`${API_BASE_URL}/expired-links`);
    
    if (!response.ok) {
      throw new Error('Failed to fetch expired links');
    }

    return response.json();
  }

  async sendChatMessage(message: string): Promise<ChatResponse> {
    const response = await fetch(`${API_BASE_URL}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      throw new Error('Failed to send chat message');
    }

    return response.json();
  }

  async getScrapeStatus(jobId: string): Promise<{ status: string; progress: number }> {
    const response = await fetch(`${API_BASE_URL}/scrape-status/${jobId}`);
    
    if (!response.ok) {
      throw new Error('Failed to get scrape status');
    }

    return response.json();
  }
}

export const api = new ApiService();
export type { LinkData, ChatResponse };