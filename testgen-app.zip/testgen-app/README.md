# Test Member Generator

Chatbot that generates **synthetic** test members from JSON templates using
Azure OpenAI, with per-environment routing and a strict PHI/PII boundary.

## Architecture

```
Navbar env dropdown (dev/qa/staging/prod) selects a registry key.
Every call routes through it.

Path A — GENERATION (no PHI, no tools)
  query + template(s) + counts  ->  /api/generate  ->  single Azure OpenAI call
  ->  synthetic members returned to UI for review

Path B — LOAD (deterministic, user-triggered, env-routed)
  reviewed members + env  ->  /api/load  ->  env loader_url
  (prod is role-gated + requires confirmation)

Path C — LOOKUP (PHI/PII, isolated, display-only)
  member_id + env  ->  /api/data/cob|pcp  ->  env-routed fetch
  ->  returned to UI only; NEVER re-enters Path A
```

### PHI/PII boundary
- `services/generator.py` is the ONLY module that talks to Azure OpenAI.
- `services/downstream.py` (COB/PCP) and `services/loader.py` handle PHI.
- They never share a call path. `tools/check_isolation.py` fails CI if
  `generator.py` ever imports the PHI modules — the boundary is structural,
  not just conventional.
- Templates are **schemas only**. Never put real member values in a template;
  that is the one way PHI could reach the model.

## Backend
```bash
cd backend
cp .env.example .env    # fill in Azure OpenAI + tenant/client IDs
./run.sh                # installs deps, runs isolation guard, starts uvicorn
```
Runs on http://localhost:8000. Swap the in-memory history/prompt stores and the
env registry for a real DB/secret store before production.

## Frontend
```bash
cd frontend
cp .env.example .env    # fill in MSAL SPA client/tenant/scope (optional for local)
npm install
npm run dev             # http://localhost:5173, proxies /api to :8000
```
Without MSAL env vars, the frontend uses a `dev` token that the backend accepts
as a stub user. With them, it does real Entra ID SSO.

## Auth notes
- Backend `core/auth.py` is a validation **stub**. Replace the TODO with real
  JWT signature/aud/iss/exp validation against your tenant JWKS before exposing.
- Prod loads require the `loader.prod` role.

## Agent reference tools (added)

During generation the model may call **reference/config lookups** to make
synthetic members valid — group, subgroup, and class/plan lookups, with more
addable. These return config data only (no member PHI), so their results are
safe to enter the model context.

Registry: `backend/app/services/tools.py`. To add a tool:
1. Write an async fetch function returning reference data (no PHI).
2. Wrap it in `Tool(name, description, parameters=<json schema>, handler, phi_safe=True)`.
3. `registry.register(...)` it.

`ToolRegistry.register()` **refuses** any tool without `phi_safe=True`, so a
PHI-returning function can never be exposed to the model. Real member COB/PCP
lookups stay in `downstream.py` (display-only Path C) and are deliberately not
agent tools. The CI guard `tools/check_isolation.py` fails the build if either
`generator.py` or `tools.py` imports the PHI modules — verified to catch both
`import downstream` and `from app.services import downstream` forms.

## Review table & Save to Facets (added)

After generation, members render in an **editable review table** in the chat,
before anything is sent to the load API. The user can edit any cell, then click
**Save to Facets** at the top of the table. That calls `POST /api/load` with the
*edited* data and posts the load API's JSON response back into the chat.

### Editable columns — single source of truth
Columns are defined once in `backend/app/core/columns.py` and served via
`GET /api/columns`; the frontend fetches them at startup and builds the grid
from them. **Update columns in that one file** and both sides follow. Each
column has `key`, `label`, `type` (text/date/number/select), optional `options`
(for selects) and `editable`. In the frontend the matching type is
`Column` in `src/types/index.ts`.

Prod is still gated: saving into the production environment triggers the
confirmation modal before the load API is called.

## UI refresh — JET Agent (light theme)

The app is now branded **JET Agent** with a light theme, dark-blue action
buttons, a search bar, sidebar with a gradient logo, and a centered greeting
with an animated orb on the empty state.

### Data display
Generated members are no longer shown as JSON. They render as a **table** in the
chat output showing: Index, Database, GroupID, SubscriberId, FirstName,
LastName, MedicaidId, MedicareId, EffectiveDate, and an **Edit** button as the
last column. Clicking Edit opens a **popup form** with every field (including
fields not shown in the table, via `in_table: false`), with **Save** and
**Cancel** at the bottom. After Save to Facets the rows lock and the button
becomes **View** (read-only form).

The load-API response is also shown in readable label/value rows, not JSON.

### Columns (still one source of truth)
`backend/app/core/columns.py` — each column now also has `in_table` (show in the
table row) vs form-only. Update that file and both the table and the popup form
follow. Frontend type: `Column` in `src/types/index.ts`.

## Save prompt moved into chat; History now reopens full exchanges

**Save prompt** is no longer a button under the input box. Each message you
send shows a small "Save prompt" button under your own bubble; click it to
save that exact query, and it flips to "Saved as prompt" (locked).

**History** now actually reopens past conversations. Each generation snapshots
the full exchange (your message + the assistant's response, including the
review table and its state) into `HistoryItem.turns`, sent to
`POST /api/history` and stored alongside the existing summary fields.
Clicking a history entry replaces the current chat view with that full
snapshot instead of just refilling the input box. Older/incomplete history
entries (no `turns`) still fall back to prefilling the query.
