"""
Azure Entra ID (SSO) auth dependency.

This is a validation stub wired for the real flow: the frontend acquires an
access token via MSAL and sends it as `Authorization: Bearer <jwt>`. Here we
decode/validate it. For production, verify the signature against the tenant's
JWKS and check `aud`/`iss`/`exp`. The TODO marks where to plug in real
verification (e.g. via `python-jose` + cached JWKS from
https://login.microsoftonline.com/<tenant>/discovery/v2.0/keys).
"""

from fastapi import Depends, Header, HTTPException
from pydantic import BaseModel

from app.core.config import settings


class User(BaseModel):
    oid: str
    name: str
    email: str
    roles: list[str] = []


async def get_current_user(authorization: str = Header(default="")) -> User:
    if not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    token = authorization.split(" ", 1)[1]

    # TODO: replace with real Entra ID JWT validation (signature, aud, iss, exp).
    # For local dev without SSO, a token of "dev" yields a stub user.
    if token == "dev":
        return User(oid="dev-oid", name="Dev User", email="dev@example.com", roles=["loader.prod"])

    raise HTTPException(status_code=401, detail="Invalid token (SSO validation not configured)")


def require_prod_loader(user: User = Depends(get_current_user)) -> User:
    if "loader.prod" not in user.roles:
        raise HTTPException(status_code=403, detail="Not authorized to load into production")
    return user
