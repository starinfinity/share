"""
Column definitions for the member review table (single source of truth).

The frontend fetches these via GET /api/columns and renders the table + edit
form from them, so you update columns HERE and both sides follow.

Each column:
  key       -> matches the member field key produced by generation
  label     -> header shown to the user
  type      -> "text" | "date" | "number" | "select"
  editable  -> whether the field can be edited in the popup form (default True)
  options   -> allowed values when type == "select"
  in_table  -> show this column in the table row (default True). Fields with
               in_table=False still appear in the edit/view popup form.
"""

from typing import Any

COLUMNS: list[dict[str, Any]] = [
    {"key": "index",         "label": "Index",          "type": "number", "editable": False, "in_table": True},
    {"key": "database",      "label": "Database",       "type": "text",   "editable": True,  "in_table": True},
    {"key": "groupId",       "label": "GroupID",        "type": "text",   "editable": True,  "in_table": True},
    {"key": "subscriberId",  "label": "SubscriberId",   "type": "text",   "editable": True,  "in_table": True},
    {"key": "firstName",     "label": "FirstName",      "type": "text",   "editable": True,  "in_table": True},
    {"key": "lastName",      "label": "LastName",       "type": "text",   "editable": True,  "in_table": True},
    {"key": "medicaidId",    "label": "MedicaidId",     "type": "text",   "editable": True,  "in_table": True},
    {"key": "medicareId",    "label": "MedicareId",     "type": "text",   "editable": True,  "in_table": True},
    {"key": "effectiveDate", "label": "EffectiveDate",  "type": "date",   "editable": True,  "in_table": True},
    # Extra fields below live in the popup form only (in_table=False). Add more freely.
    {"key": "subgroupId",    "label": "SubgroupID",     "type": "text",   "editable": True,  "in_table": False},
    {"key": "classPlan",     "label": "Class/Plan",     "type": "text",   "editable": True,  "in_table": False},
    {
        "key": "planType", "label": "Plan Type", "type": "select", "editable": True, "in_table": False,
        "options": ["PPO", "HMO", "EPO", "POS", "HDHP"],
    },
]


def column_keys() -> list[str]:
    return [c["key"] for c in COLUMNS]
