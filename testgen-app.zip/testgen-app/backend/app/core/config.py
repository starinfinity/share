from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Azure OpenAI
    azure_openai_endpoint: str = "https://YOUR-RESOURCE.openai.azure.com/"
    azure_openai_api_key: str = "REPLACE_ME"
    azure_openai_api_version: str = "2024-10-21"
    azure_openai_deployment: str = "gpt-5.5"  # your Azure deployment name

    # Azure AD / Entra SSO (token validation)
    azure_tenant_id: str = "REPLACE_ME"
    azure_client_id: str = "REPLACE_ME"
    # Comma-separated env keys a user may load into prod (role-gated). Demo stub.
    prod_load_allowed: str = ""

    cors_origins: str = "http://localhost:5173"


settings = Settings()
