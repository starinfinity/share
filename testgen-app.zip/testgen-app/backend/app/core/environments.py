"""
Environment registry.

The navbar dropdown selects one of these keys. Every generation (deployment),
lookup (cob/pcp), and load (loader_url) call routes through the selected env.

In production, load this from config/secret store or a DB rather than hardcoding.
"""

from pydantic import BaseModel


class EnvConfig(BaseModel):
    key: str
    label: str
    cob_url: str
    pcp_url: str
    loader_url: str
    reference_url: str
    downstream_api_key: str
    azure_deployment: str  # allows per-env model deployment if needed
    is_prod: bool = False


_REGISTRY: dict[str, EnvConfig] = {
    "dev": EnvConfig(
        key="dev", label="Development",
        cob_url="https://dev.internal.example.com/cob",
        pcp_url="https://dev.internal.example.com/pcp",
        loader_url="https://dev.internal.example.com/load",
        reference_url="https://dev.internal.example.com/ref",
        downstream_api_key="REPLACE_ME_DEV",
        azure_deployment="gpt-5.5",
    ),
    "qa": EnvConfig(
        key="qa", label="QA",
        cob_url="https://qa.internal.example.com/cob",
        pcp_url="https://qa.internal.example.com/pcp",
        loader_url="https://qa.internal.example.com/load",
        reference_url="https://qa.internal.example.com/ref",
        downstream_api_key="REPLACE_ME_QA",
        azure_deployment="gpt-5.5",
    ),
    "staging": EnvConfig(
        key="staging", label="Staging",
        cob_url="https://staging.internal.example.com/cob",
        pcp_url="https://staging.internal.example.com/pcp",
        loader_url="https://staging.internal.example.com/load",
        reference_url="https://staging.internal.example.com/ref",
        downstream_api_key="REPLACE_ME_STG",
        azure_deployment="gpt-5.5",
    ),
    "prod": EnvConfig(
        key="prod", label="Production",
        cob_url="https://prod.internal.example.com/cob",
        pcp_url="https://prod.internal.example.com/pcp",
        loader_url="https://prod.internal.example.com/load",
        reference_url="https://prod.internal.example.com/ref",
        downstream_api_key="REPLACE_ME_PROD",
        azure_deployment="gpt-5.5",
        is_prod=True,
    ),
}


def get_env(key: str) -> EnvConfig:
    if key not in _REGISTRY:
        raise KeyError(f"Unknown environment: {key}")
    return _REGISTRY[key]


def list_envs() -> list[dict]:
    return [{"key": e.key, "label": e.label, "is_prod": e.is_prod} for e in _REGISTRY.values()]
