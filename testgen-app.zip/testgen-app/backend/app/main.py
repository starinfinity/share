from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.columns import COLUMNS
from app.core.environments import list_envs
from app.routers import data, generate, load, workspace

app = FastAPI(title="Test Member Generator")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",")],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(generate.router)
app.include_router(data.router)
app.include_router(load.router)
app.include_router(workspace.router)


@app.get("/api/environments")
def environments():
    return list_envs()


@app.get("/api/columns")
def columns():
    return COLUMNS


@app.get("/health")
def health():
    return {"status": "ok"}
