from typing import Any
from pydantic import BaseModel, Field


class TemplateSpec(BaseModel):
    """One member type within a request: a template + how many of it."""
    type: str = Field(..., description="Label for this member type, e.g. 'COB-primary'")
    template: dict[str, Any] = Field(..., description="JSON shape to follow")
    count: int = Field(1, ge=1, le=100)


class GenerateRequest(BaseModel):
    query: str = Field(..., description="Natural-language description of the scenario")
    specs: list[TemplateSpec] = Field(..., min_length=1)
    environment: str = Field("dev")


class GeneratedGroup(BaseModel):
    type: str
    members: list[dict[str, Any]]


class GenerateResponse(BaseModel):
    groups: list[GeneratedGroup]
    environment: str
    tools_used: list[str] = []


class LoadRequest(BaseModel):
    environment: str
    members: list[dict[str, Any]] = Field(..., min_length=1)


class LoadResponse(BaseModel):
    environment: str
    loaded: int
    loader_response: dict[str, Any]


class SavedPrompt(BaseModel):
    id: str = ""
    title: str
    body: str


class HistoryItem(BaseModel):
    id: str = ""
    query: str
    environment: str
    created_at: str = ""
    member_count: int
    turns: list[dict[str, Any]] = Field(default_factory=list)  # full exchange snapshot
