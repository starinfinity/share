from fastapi import APIRouter, Depends, HTTPException

from app.core.auth import User, get_current_user
from app.services import downstream

router = APIRouter(prefix="/api/data", tags=["data"])


@router.get("/cob/{environment}/{member_id}")
async def get_cob(environment: str, member_id: str, user: User = Depends(get_current_user)):
    try:
        return await downstream.fetch_cob(environment, member_id)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"COB fetch failed: {e}")


@router.get("/pcp/{environment}/{member_id}")
async def get_pcp(environment: str, member_id: str, user: User = Depends(get_current_user)):
    try:
        return await downstream.fetch_pcp(environment, member_id)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"PCP fetch failed: {e}")
