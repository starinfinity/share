from fastapi import APIRouter, Depends, HTTPException

from app.core.auth import User, get_current_user
from app.models.schemas import GenerateRequest, GenerateResponse
from app.services.generator import generate as run_generate

router = APIRouter(prefix="/api", tags=["generate"])


@router.post("/generate", response_model=GenerateResponse)
async def generate(req: GenerateRequest, user: User = Depends(get_current_user)):
    try:
        groups, tools_used = await run_generate(req.query, req.specs, req.environment)
    except KeyError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Generation failed: {e}")
    return GenerateResponse(groups=groups, environment=req.environment, tools_used=tools_used)
