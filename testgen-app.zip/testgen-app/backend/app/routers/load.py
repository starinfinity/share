from fastapi import APIRouter, Depends, HTTPException

from app.core.auth import User, get_current_user, require_prod_loader
from app.core.environments import get_env
from app.models.schemas import LoadRequest, LoadResponse
from app.services import loader

router = APIRouter(prefix="/api", tags=["load"])


@router.post("/load", response_model=LoadResponse)
async def load(req: LoadRequest, user: User = Depends(get_current_user)):
    try:
        env = get_env(req.environment)
    except KeyError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # Highest-risk action: prod loads are role-gated.
    if env.is_prod and "loader.prod" not in user.roles:
        raise HTTPException(status_code=403, detail="Not authorized to load into production")

    try:
        result = await loader.load_members(req.environment, req.members)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Load failed: {e}")
    return LoadResponse(environment=req.environment, loaded=len(req.members), loader_response=result)
