import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends

from app.core.auth import User, get_current_user
from app.models.schemas import HistoryItem, SavedPrompt

router = APIRouter(prefix="/api", tags=["workspace"])

# In-memory demo stores keyed by user oid. Swap for Postgres in production.
_history: dict[str, list[HistoryItem]] = {}
_prompts: dict[str, list[SavedPrompt]] = {}

_DEFAULT_PROMPTS = [
    SavedPrompt(id="1", title="COB primary/secondary pair",
                body="Generate 2 members that are spouses sharing a COB relationship, one primary one secondary."),
    SavedPrompt(id="2", title="Members with assigned PCP",
                body="Generate 5 members each with an assigned in-network PCP and a recent effective date."),
]


@router.get("/history", response_model=list[HistoryItem])
def get_history(user: User = Depends(get_current_user)):
    return list(reversed(_history.get(user.oid, [])))


@router.post("/history", response_model=HistoryItem)
def add_history(item: HistoryItem, user: User = Depends(get_current_user)):
    item.id = str(uuid.uuid4())
    item.created_at = datetime.now(timezone.utc).isoformat()
    _history.setdefault(user.oid, []).append(item)
    return item


@router.get("/prompts", response_model=list[SavedPrompt])
def get_prompts(user: User = Depends(get_current_user)):
    return _prompts.setdefault(user.oid, [p.model_copy() for p in _DEFAULT_PROMPTS])


@router.post("/prompts", response_model=SavedPrompt)
def add_prompt(p: SavedPrompt, user: User = Depends(get_current_user)):
    p.id = str(uuid.uuid4())
    _prompts.setdefault(user.oid, []).append(p)
    return p


@router.delete("/prompts/{prompt_id}")
def delete_prompt(prompt_id: str, user: User = Depends(get_current_user)):
    lst = _prompts.setdefault(user.oid, [])
    _prompts[user.oid] = [p for p in lst if p.id != prompt_id]
    return {"ok": True}
