"""
Downstream COB / PCP client (PHI/PII).

PHI/PII SAFETY BOUNDARY
-----------------------
Responses here contain PHI/PII and are returned to the authorized frontend for
display ONLY. They must NEVER be passed into `generator.py` or the LLM.
Routed per selected environment.
"""

import httpx

from app.core.environments import get_env


async def fetch_cob(environment: str, member_id: str) -> dict:
    env = get_env(environment)
    headers = {"Authorization": f"Bearer {env.downstream_api_key}"}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(f"{env.cob_url}/{member_id}", headers=headers)
        r.raise_for_status()
        return r.json()


async def fetch_pcp(environment: str, member_id: str) -> dict:
    env = get_env(environment)
    headers = {"Authorization": f"Bearer {env.downstream_api_key}"}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(f"{env.pcp_url}/{member_id}", headers=headers)
        r.raise_for_status()
        return r.json()
