"""
Test-member generation service (agentic, reference-tools only).

PHI/PII SAFETY BOUNDARY
-----------------------
This module is the ONLY code path that talks to Azure OpenAI. It may offer the
model REFERENCE tools (group/subgroup/class-plan lookups) so it can generate
VALID synthetic members. Those tools return config data only.

It must NEVER import or call `downstream.py` (member PHI COB/PCP) or `loader.py`.
The CI guard tools/check_isolation.py enforces this. Only tools registered in
`tools.registry` (all phi_safe=True by construction) are exposed to the model.
"""

import json
from typing import Any

from openai import AzureOpenAI

from app.core.config import settings
from app.core.environments import get_env
from app.models.schemas import GeneratedGroup, TemplateSpec
from app.services.tools import registry

_client = AzureOpenAI(
    azure_endpoint=settings.azure_openai_endpoint,
    api_key=settings.azure_openai_api_key,
    api_version=settings.azure_openai_api_version,
)

MAX_TOOL_ROUNDS = 5

SYSTEM_PROMPT = """You generate SYNTHETIC test member records for a healthcare QA environment.

Hard rules:
- Output ONLY data conforming exactly to each provided JSON template's keys and value types.
- All values must be FICTIONAL and clearly synthetic. Never use real people or identifiers.
- Do not invent extra top-level fields not present in a template.
- Make IDs/names obviously test data (e.g. member IDs prefixed "TST").

Reference tools:
- You may call the provided reference lookups (group / subgroup / class-plan) to
  obtain VALID group, subgroup, and plan/class codes so the synthetic members are
  realistic and internally consistent. Use them only when the scenario needs a
  valid real code you don't already have. These return configuration data only.

When done, return JSON of the form:
{"groups": [{"type": "<type>", "members": [ ... ]}, ...]} and nothing else."""


async def _run_tool(name: str, args: dict, environment: str) -> dict:
    tool = registry.get(name)
    # environment is injected server-side; the model never chooses it.
    return await tool.handler(environment=environment, **args)


async def generate(query: str, specs: list[TemplateSpec], environment: str) -> tuple[list[GeneratedGroup], list[str]]:
    env = get_env(environment)

    spec_blob = [{"type": s.type, "count": s.count, "template": s.template} for s in specs]
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {
            "role": "user",
            "content": (
                "Groups to generate (follow each template shape exactly):\n"
                f"{json.dumps(spec_blob, indent=2)}\n\n"
                f"Scenario request: {query}"
            ),
        },
    ]

    tools = registry.openai_schema()
    tools_used: list[str] = []

    for _ in range(MAX_TOOL_ROUNDS):
        resp = _client.chat.completions.create(
            model=env.azure_deployment,
            messages=messages,
            tools=tools,
            tool_choice="auto",
        )
        msg = resp.choices[0].message

        if msg.tool_calls:
            messages.append({
                "role": "assistant",
                "content": msg.content or "",
                "tool_calls": [tc.model_dump() for tc in msg.tool_calls],
            })
            for tc in msg.tool_calls:
                tools_used.append(tc.function.name)
                args = json.loads(tc.function.arguments or "{}")
                try:
                    result = await _run_tool(tc.function.name, args, environment)
                except Exception as e:
                    result = {"error": str(e)}
                messages.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": json.dumps(result),
                })
            continue  # let the model use the tool results

        # No tool calls -> final answer. Force JSON parse.
        content = msg.content or "{}"
        break
    else:
        # Ran out of rounds; ask once more for the final JSON.
        messages.append({"role": "user", "content": "Return the final JSON now."})
        content = (_client.chat.completions.create(
            model=env.azure_deployment,
            messages=messages,
            response_format={"type": "json_object"},
        ).choices[0].message.content) or "{}"

    # Some models wrap JSON in prose when tools were used; extract the object.
    content = content.strip()
    if not content.startswith("{"):
        start, end = content.find("{"), content.rfind("}")
        content = content[start:end + 1] if start != -1 and end != -1 else "{}"

    data = json.loads(content)
    groups: list[GeneratedGroup] = []
    for g in data.get("groups", []):
        members = g.get("members", [])
        if not isinstance(members, list):
            members = [members]
        groups.append(GeneratedGroup(type=g.get("type", "unknown"), members=members))
    return groups, tools_used
