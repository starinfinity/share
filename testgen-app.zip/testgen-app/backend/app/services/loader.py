"""
Loader client: pushes already-generated, already-reviewed members into the
final per-environment load API.

Deterministic, user-triggered. Does NOT involve the LLM. Routed per env.
"""

import httpx

from app.core.environments import get_env


async def load_members(environment: str, members: list[dict]) -> dict:
    env = get_env(environment)
    headers = {"Authorization": f"Bearer {env.downstream_api_key}"}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(env.loader_url, json={"members": members}, headers=headers)
        r.raise_for_status()
        return r.json()
