"""
Reference-lookup tool registry (agent tools).

DESIGN + PHI/PII BOUNDARY
-------------------------
These are the functions the Azure OpenAI model may call during generation to
make synthetic test members VALID (real group / subgroup / class-plan codes,
etc.). Their results DO enter the model context, so every tool registered here
MUST return reference/config data only — never member PHI/PII.

Each tool declares `phi_safe`. `register()` REFUSES to register a tool whose
`phi_safe` is not True, so a PHI-returning function can never be wired into the
agent loop. Member-PHI lookups (real COB/PCP for a person) live in
`downstream.py` and are intentionally NOT tools here.

ADD A NEW TOOL
--------------
1. Write an async fetch function that returns reference data (no PHI).
2. Wrap it in a Tool(...) with a JSON-schema `parameters`.
3. Add it to TOOLS below. That's it — it's now available to the agent.
"""

from typing import Any, Awaitable, Callable

import httpx
from pydantic import BaseModel

from app.core.environments import get_env


class Tool(BaseModel):
    name: str
    description: str
    parameters: dict[str, Any]          # JSON schema for the function args
    handler: Callable[..., Awaitable[dict]]
    phi_safe: bool = False

    model_config = {"arbitrary_types_allowed": True}


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        if tool.phi_safe is not True:
            raise ValueError(
                f"Refusing to register '{tool.name}': only phi_safe reference "
                f"tools may be exposed to the model."
            )
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool:
        return self._tools[name]

    def openai_schema(self) -> list[dict]:
        """Tool definitions in the shape Azure OpenAI expects."""
        return [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.parameters,
                },
            }
            for t in self._tools.values()
        ]

    def names(self) -> list[str]:
        return list(self._tools)


# ---------------------------------------------------------------------------
# Reference fetchers (config data only — safe for the model)
# Replace the endpoint paths with your real reference APIs. Routed per env.
# ---------------------------------------------------------------------------

async def _ref_get(environment: str, path: str, params: dict) -> dict:
    env = get_env(environment)
    headers = {"Authorization": f"Bearer {env.downstream_api_key}"}
    # NOTE: reference base assumed at <cob_url host>/ref — adjust to your infra.
    base = env.reference_url
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.get(f"{base}/{path}", params=params, headers=headers)
        r.raise_for_status()
        return r.json()


async def group_lookup(environment: str, group_id: str) -> dict:
    return await _ref_get(environment, "group", {"groupId": group_id})


async def subgroup_lookup(environment: str, group_id: str, subgroup_id: str = "") -> dict:
    return await _ref_get(environment, "subgroup", {"groupId": group_id, "subgroupId": subgroup_id})


async def class_plan_lookup(environment: str, group_id: str, subgroup_id: str = "") -> dict:
    return await _ref_get(environment, "classplan", {"groupId": group_id, "subgroupId": subgroup_id})


# ---------------------------------------------------------------------------
# Registry: add new reference tools here.
# ---------------------------------------------------------------------------

registry = ToolRegistry()

registry.register(Tool(
    name="group_lookup",
    description="Look up a group by its ID to get valid group-level attributes "
                "for generating realistic test members. Returns config/reference "
                "data only (no member PHI).",
    parameters={
        "type": "object",
        "properties": {
            "group_id": {"type": "string", "description": "The group identifier"},
        },
        "required": ["group_id"],
    },
    handler=group_lookup,
    phi_safe=True,
))

registry.register(Tool(
    name="subgroup_lookup",
    description="List/validate subgroups under a group. Reference data only.",
    parameters={
        "type": "object",
        "properties": {
            "group_id": {"type": "string"},
            "subgroup_id": {"type": "string", "description": "Optional specific subgroup"},
        },
        "required": ["group_id"],
    },
    handler=subgroup_lookup,
    phi_safe=True,
))

registry.register(Tool(
    name="class_plan_lookup",
    description="Get valid class/plan codes for a group (and optional subgroup) "
                "so generated members carry a real, valid plan. Reference data only.",
    parameters={
        "type": "object",
        "properties": {
            "group_id": {"type": "string"},
            "subgroup_id": {"type": "string"},
        },
        "required": ["group_id"],
    },
    handler=class_plan_lookup,
    phi_safe=True,
))
