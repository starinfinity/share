#!/usr/bin/env bash
set -e
python -m venv .venv 2>/dev/null || true
source .venv/bin/activate
pip install -q -r requirements.txt
python tools/check_isolation.py
uvicorn app.main:app --reload --port 8000
