"""
CI guard: fail the build if the LLM-facing code can reach PHI/PII modules.

Neither the generator nor the agent tool registry may import the downstream
(member COB/PCP PHI) or loader modules. Run in CI:
    python tools/check_isolation.py
"""

import ast
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent / "app" / "services"
LLM_FACING = ["generator.py", "tools.py"]
FORBIDDEN = ("downstream", "loader")


def imported_names(path: Path) -> set[str]:
    tree = ast.parse(path.read_text())
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.module:
                names.add(node.module)
            # also capture `from pkg import <name>` targets
            names.update(a.name for a in node.names)
        elif isinstance(node, ast.Import):
            names.update(a.name for a in node.names)
    return names


def main() -> int:
    failed = False
    for fname in LLM_FACING:
        names = imported_names(BASE / fname)
        hits = [n for n in names for f in FORBIDDEN if f in n]
        if hits:
            print(f"PHI ISOLATION VIOLATION: {fname} imports {hits}", file=sys.stderr)
            failed = True
    if failed:
        return 1
    print("OK: LLM-facing code is isolated from PHI/PII modules.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
