import { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import Composer from "./components/Composer";
import Transcript from "./components/Transcript";
import * as api from "./api/client";
import type {
  ChatTurn,
  Column,
  EnvOption,
  HistoryItem,
  SavedPrompt,
  TemplateSpec,
} from "./types";
import "./styles/app.css";

interface PendingSave {
  turnIndex: number;
  members: Record<string, unknown>[];
}

export default function App() {
  const [envs, setEnvs] = useState<EnvOption[]>([]);
  const [env, setEnv] = useState("dev");
  const [columns, setColumns] = useState<Column[]>([]);
  const [turns, setTurns] = useState<ChatTurn[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [prompts, setPrompts] = useState<SavedPrompt[]>([]);
  const [busy, setBusy] = useState(false);
  const [savingIndex, setSavingIndex] = useState<number | null>(null);
  const [presetQuery, setPresetQuery] = useState<string>();
  const [pendingSave, setPendingSave] = useState<PendingSave | null>(null);

  const currentEnv = envs.find((e) => e.key === env);

  useEffect(() => {
    api.getEnvironments().then((e) => {
      setEnvs(e);
      if (e.length) setEnv(e[0].key);
    });
    api.getColumns().then(setColumns).catch(() => {});
    api.getHistory().then(setHistory).catch(() => {});
    api.getPrompts().then(setPrompts).catch(() => {});
  }, []);

  async function handleGenerate(query: string, specs: TemplateSpec[]) {
    setBusy(true);
    const userTurn: ChatTurn = { role: "user", content: query };
    setTurns((t) => [...t, userTurn]);
    try {
      const res = await api.generate(query, specs, env);
      const flat = res.groups.flatMap((g) => g.members);
      const assistantTurn: ChatTurn = {
        role: "assistant",
        content: `Generated ${flat.length} synthetic member(s) across ${res.groups.length} type(s). Review and edit below, then Save to Facets.`,
        groups: res.groups,
        toolsUsed: res.tools_used,
        reviewMembers: flat,
        saved: false,
      };
      setTurns((t) => [...t, assistantTurn]);
      // Snapshot the full exchange (not just the query) so History can reopen it later.
      const h = await api.addHistory({
        query,
        environment: env,
        member_count: flat.length,
        turns: [userTurn, assistantTurn],
      });
      setHistory((prev) => [h, ...prev]);
    } catch (e) {
      setTurns((t) => [
        ...t,
        { role: "assistant", content: `Generation failed: ${(e as Error).message}` },
      ]);
    } finally {
      setBusy(false);
    }
  }

  function requestSave(turnIndex: number, members: Record<string, unknown>[]) {
    if (currentEnv?.is_prod) {
      setPendingSave({ turnIndex, members });
    } else {
      doSave(turnIndex, members);
    }
  }

  async function doSave(turnIndex: number, members: Record<string, unknown>[]) {
    setPendingSave(null);
    setSavingIndex(turnIndex);
    try {
      const res = await api.loadMembers(env, members);
      // mark the reviewed turn as saved (locks the table) and post API result to chat
      setTurns((t) =>
        t.map((turn, i) => (i === turnIndex ? { ...turn, saved: true } : turn))
      );
      setTurns((t) => [
        ...t,
        {
          role: "assistant",
          content: `Saved ${res.loaded} member(s) into Facets (${env}). Response from the load API:`,
          result: res.loader_response,
        },
      ]);
    } catch (e) {
      setTurns((t) => [
        ...t,
        { role: "assistant", content: `Save to Facets failed: ${(e as Error).message}` },
      ]);
    } finally {
      setSavingIndex(null);
    }
  }

  async function savePromptFromMessage(turnIndex: number, title: string, body: string) {
    const p = await api.addPrompt(title, body);
    setPrompts((prev) => [...prev, p]);
    setTurns((t) =>
      t.map((turn, i) => (i === turnIndex ? { ...turn, promptSaved: true } : turn))
    );
  }

  async function removePrompt(id: string) {
    await api.deletePrompt(id);
    setPrompts((prev) => prev.filter((p) => p.id !== id));
  }

  function openHistory(h: HistoryItem) {
    // Reopen the full past exchange if we have a snapshot; otherwise fall back
    // to just prefilling the query (older/incomplete history entries).
    if (h.turns && h.turns.length > 0) {
      setTurns(h.turns);
    } else {
      setPresetQuery(h.query);
    }
  }

  return (
    <div className="app">
      <Navbar envs={envs} selected={env} onSelect={setEnv} userInitial="T" />
      <div className="body">
        <Sidebar
          history={history}
          prompts={prompts}
          onNewChat={() => setTurns([])}
          onPickPrompt={(p) => setPresetQuery(p.body)}
          onDeletePrompt={removePrompt}
          onPickHistory={openHistory}
        />
        <div className="chat">
          <Transcript
            turns={turns}
            columns={columns}
            env={currentEnv}
            onSave={requestSave}
            savingIndex={savingIndex}
            userName="Toby"
            onSavePrompt={savePromptFromMessage}
          />
          <Composer
            key={presetQuery}
            onSubmit={handleGenerate}
            busy={busy}
            presetQuery={presetQuery}
          />
        </div>
      </div>

      {pendingSave && (
        <div className="overlay" onClick={() => setPendingSave(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>Save to Facets — Production</h3>
            <p>
              You are about to save {pendingSave.members.length} member(s) into
              the <strong>production</strong> Facets environment. This is the
              highest-risk action. Confirm only if these synthetic records are
              meant for prod.
            </p>
            <div className="row">
              <button className="btn ghost" onClick={() => setPendingSave(null)}>
                Cancel
              </button>
              <button
                className="btn prod"
                onClick={() => doSave(pendingSave.turnIndex, pendingSave.members)}
              >
                Confirm save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
