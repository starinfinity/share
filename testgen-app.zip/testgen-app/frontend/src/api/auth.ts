/**
 * Azure Entra ID (SSO) via MSAL.
 *
 * Fill in tenant/client IDs from your app registration, then call
 * `initAuth()` once at startup. `client.ts` will pull real tokens through
 * setTokenProvider. Until configured, the app falls back to the "dev" token
 * which the backend accepts as a local stub user.
 */
import { PublicClientApplication, InteractionRequiredAuthError } from "@azure/msal-browser";
import { setTokenProvider } from "./client";

const msalConfig = {
  auth: {
    clientId: import.meta.env.VITE_AZURE_CLIENT_ID ?? "",
    authority: `https://login.microsoftonline.com/${import.meta.env.VITE_AZURE_TENANT_ID ?? "common"}`,
    redirectUri: window.location.origin,
  },
};

// The API's exposed scope, e.g. "api://<api-client-id>/access_as_user"
const SCOPES = [import.meta.env.VITE_API_SCOPE ?? ""];

const pca = new PublicClientApplication(msalConfig);

export async function initAuth(): Promise<boolean> {
  if (!msalConfig.auth.clientId) return false; // not configured -> dev stub
  await pca.initialize();
  const accounts = pca.getAllAccounts();
  if (accounts.length === 0) {
    await pca.loginRedirect({ scopes: SCOPES });
    return false;
  }
  pca.setActiveAccount(accounts[0]);

  setTokenProvider(async () => {
    try {
      const res = await pca.acquireTokenSilent({ scopes: SCOPES });
      return res.accessToken;
    } catch (e) {
      if (e instanceof InteractionRequiredAuthError) {
        await pca.acquireTokenRedirect({ scopes: SCOPES });
      }
      throw e;
    }
  });
  return true;
}
