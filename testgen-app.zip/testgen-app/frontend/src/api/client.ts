import type {
  Column,
  EnvOption,
  GenerateResponse,
  HistoryItem,
  SavedPrompt,
  TemplateSpec,
} from "../types";

// Swap this for the real MSAL-acquired token. "dev" hits the backend dev stub.
let tokenProvider: () => Promise<string> = async () => "dev";

export function setTokenProvider(fn: () => Promise<string>) {
  tokenProvider = fn;
}

async function authHeaders(): Promise<Record<string, string>> {
  const token = await tokenProvider();
  return { "Content-Type": "application/json", Authorization: `Bearer ${token}` };
}

async function handle<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const detail = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(detail.detail ?? `Request failed (${res.status})`);
  }
  return res.json() as Promise<T>;
}

export async function getEnvironments(): Promise<EnvOption[]> {
  return handle(await fetch("/api/environments"));
}

export async function getColumns(): Promise<Column[]> {
  return handle(await fetch("/api/columns"));
}

export async function generate(
  query: string,
  specs: TemplateSpec[],
  environment: string
): Promise<GenerateResponse> {
  return handle(
    await fetch("/api/generate", {
      method: "POST",
      headers: await authHeaders(),
      body: JSON.stringify({ query, specs, environment }),
    })
  );
}

export async function loadMembers(
  environment: string,
  members: Record<string, unknown>[]
) {
  return handle(
    await fetch("/api/load", {
      method: "POST",
      headers: await authHeaders(),
      body: JSON.stringify({ environment, members }),
    })
  );
}

export async function getHistory(): Promise<HistoryItem[]> {
  return handle(await fetch("/api/history", { headers: await authHeaders() }));
}

export async function addHistory(item: Omit<HistoryItem, "id" | "created_at">) {
  return handle<HistoryItem>(
    await fetch("/api/history", {
      method: "POST",
      headers: await authHeaders(),
      body: JSON.stringify({ ...item, id: "", created_at: "" }),
    })
  );
}

export async function getPrompts(): Promise<SavedPrompt[]> {
  return handle(await fetch("/api/prompts", { headers: await authHeaders() }));
}

export async function addPrompt(title: string, body: string) {
  return handle<SavedPrompt>(
    await fetch("/api/prompts", {
      method: "POST",
      headers: await authHeaders(),
      body: JSON.stringify({ id: "", title, body }),
    })
  );
}

export async function deletePrompt(id: string) {
  return handle(
    await fetch(`/api/prompts/${id}`, {
      method: "DELETE",
      headers: await authHeaders(),
    })
  );
}
