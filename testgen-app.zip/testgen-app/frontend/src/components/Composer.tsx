import { useState, useEffect } from "react";
import type { TemplateSpec } from "../types";

interface Props {
  onSubmit: (query: string, specs: TemplateSpec[]) => void;
  busy: boolean;
  presetQuery?: string;
}

// Hidden default template — the per-request template/type builder UI was
// removed; generation always uses this shape. Update to match your real
// Facets fields (mirrors backend/app/core/columns.py).
const DEFAULT_TEMPLATE = {
  database: "string",
  groupId: "string",
  subscriberId: "string",
  firstName: "string",
  lastName: "string",
  medicaidId: "string",
  medicareId: "string",
  effectiveDate: "YYYY-MM-DD",
};

function parseCount(query: string): number {
  const m = query.match(/\b(\d{1,3})\b/);
  const n = m ? parseInt(m[1], 10) : 1;
  return Math.min(Math.max(n, 1), 100);
}

export default function Composer({ onSubmit, busy, presetQuery }: Props) {
  const [query, setQuery] = useState(presetQuery ?? "");
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (presetQuery !== undefined) setQuery(presetQuery);
  }, [presetQuery]);

  function submit() {
    setErr(null);
    if (!query.trim()) return setErr("Describe the scenario before generating.");
    const specs: TemplateSpec[] = [
      { type: "member", template: DEFAULT_TEMPLATE, count: parseCount(query) },
    ];
    onSubmit(query.trim(), specs);
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
    // Shift+Enter: let the default behavior insert a newline.
  }

  return (
    <div className="composer">
      <div className="composer-inner">
        <div className="composer-card">
          <div className="query-row">
            <textarea
              value={query}
              placeholder="Ask me anything… e.g. 'Generate 3 members in group 4471 on a PPO plan'"
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={onKeyDown}
            />
            <button className="btn" onClick={submit} disabled={busy}>
              {busy ? "Generating…" : "Generate"}
            </button>
          </div>

          <div className="save-prompt-row">
            <span className="hint">Enter to send · Shift+Enter for a new line</span>
          </div>

          {err && <div className="err">{err}</div>}
        </div>
      </div>
    </div>
  );
}
