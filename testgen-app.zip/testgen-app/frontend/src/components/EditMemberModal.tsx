import { useState } from "react";
import type { Column } from "../types";

interface Props {
  columns: Column[];
  member: Record<string, unknown>;
  readOnly: boolean;
  onSave: (updated: Record<string, unknown>) => void;
  onCancel: () => void;
}

export default function EditMemberModal({
  columns,
  member,
  readOnly,
  onSave,
  onCancel,
}: Props) {
  const [form, setForm] = useState<Record<string, unknown>>({ ...member });

  function set(key: string, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  return (
    <div className="overlay" onClick={onCancel}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h3>{readOnly ? "View member" : "Edit member"}</h3>
          <button className="x" onClick={onCancel}>
            ×
          </button>
        </div>

        <div className="modal-body">
          <div className="form-grid">
            {columns.map((c) => {
              const val = form[c.key] ?? "";
              const disabled = readOnly || c.editable === false;
              return (
                <div className="field" key={c.key}>
                  <label htmlFor={`f-${c.key}`}>{c.label}</label>
                  {c.type === "select" ? (
                    <select
                      id={`f-${c.key}`}
                      value={String(val)}
                      disabled={disabled}
                      onChange={(e) => set(c.key, e.target.value)}
                    >
                      <option value=""></option>
                      {(c.options ?? []).map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      id={`f-${c.key}`}
                      type={c.type === "number" ? "number" : c.type === "date" ? "date" : "text"}
                      value={String(val)}
                      disabled={disabled}
                      onChange={(e) => set(c.key, e.target.value)}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="modal-foot">
          <button className="btn ghost" onClick={onCancel}>
            Cancel
          </button>
          {!readOnly && (
            <button className="btn" onClick={() => onSave(form)}>
              Save
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
