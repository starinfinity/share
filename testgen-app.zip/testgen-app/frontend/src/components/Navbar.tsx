import type { EnvOption } from "../types";

interface Props {
  envs: EnvOption[];
  selected: string;
  onSelect: (key: string) => void;
  userInitial: string;
}

export default function Navbar({ envs, selected, onSelect, userInitial }: Props) {
  const current = envs.find((e) => e.key === selected);
  const isProd = current?.is_prod ?? false;

  return (
    <div className="navbar">
      <div className="brand">
        <span className="logo">JET</span>
        <span className="name">
          <b>JET</b> Agent
        </span>
      </div>

      <div className="nav-spacer" />

      <div className={`env-select ${isProd ? "is-prod" : ""}`}>
        <label htmlFor="env">Environment</label>
        <select id="env" value={selected} onChange={(e) => onSelect(e.target.value)}>
          {envs.map((e) => (
            <option key={e.key} value={e.key}>
              {e.label}
            </option>
          ))}
        </select>
      </div>

      <div className="user-chip">{userInitial}</div>
    </div>
  );
}
