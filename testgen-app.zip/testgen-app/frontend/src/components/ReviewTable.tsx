import { useState } from "react";
import type { Column, EnvOption } from "../types";
import EditMemberModal from "./EditMemberModal";

interface Props {
  columns: Column[];
  initialMembers: Record<string, unknown>[];
  env: EnvOption | undefined;
  onSave: (members: Record<string, unknown>[]) => void;
  saving: boolean;
  saved: boolean;
}

export default function ReviewTable({
  columns,
  initialMembers,
  env,
  onSave,
  saving,
  saved,
}: Props) {
  const [rows, setRows] = useState<Record<string, unknown>[]>(
    initialMembers.map((m, i) => ({ index: i + 1, ...m }))
  );
  const [editIdx, setEditIdx] = useState<number | null>(null);

  const tableCols = columns.filter((c) => c.in_table !== false);

  function saveRow(updated: Record<string, unknown>) {
    if (editIdx === null) return;
    setRows((r) => r.map((row, i) => (i === editIdx ? updated : row)));
    setEditIdx(null);
  }

  return (
    <div className="review">
      <div className="review-bar">
        <div className="review-title">
          Generated {rows.length} member{rows.length === 1 ? "" : "s"}
          <span className="review-sub">
            {saved
              ? "Saved to Facets."
              : `Review, edit any row, then save into ${env?.label ?? "the environment"}.`}
          </span>
        </div>
        <button
          className={`btn ${env?.is_prod ? "prod" : ""}`}
          disabled={saving || saved}
          onClick={() => onSave(rows)}
        >
          {saved ? "Saved" : saving ? "Saving…" : "Save to Facets"}
        </button>
      </div>

      <div className="review-scroll">
        <table className="grid">
          <thead>
            <tr>
              {tableCols.map((c) => (
                <th key={c.key}>{c.label}</th>
              ))}
              <th>Edit</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, ri) => (
              <tr key={ri}>
                {tableCols.map((c) => (
                  <td key={c.key}>{String(row[c.key] ?? "")}</td>
                ))}
                <td>
                  <button className="edit-btn" onClick={() => setEditIdx(ri)}>
                    {saved ? "View" : "Edit"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editIdx !== null && (
        <EditMemberModal
          columns={columns}
          member={rows[editIdx]}
          readOnly={saved}
          onSave={saveRow}
          onCancel={() => setEditIdx(null)}
        />
      )}
    </div>
  );
}
