import { useState } from "react";
import type { HistoryItem, SavedPrompt } from "../types";

type Tab = "history" | "prompts";

interface Props {
  history: HistoryItem[];
  prompts: SavedPrompt[];
  onNewChat: () => void;
  onPickPrompt: (p: SavedPrompt) => void;
  onDeletePrompt: (id: string) => void;
  onPickHistory: (h: HistoryItem) => void;
}

export default function Sidebar({
  history,
  prompts,
  onNewChat,
  onPickPrompt,
  onDeletePrompt,
  onPickHistory,
}: Props) {
  const [tab, setTab] = useState<Tab>("history");

  return (
    <aside className="sidebar">
      <div className="side-tabs">
        <button className={tab === "history" ? "active" : ""} onClick={() => setTab("history")}>
          History
        </button>
        <button className={tab === "prompts" ? "active" : ""} onClick={() => setTab("prompts")}>
          Saved Prompts
        </button>
      </div>

      <div className="side-content">
        {tab === "history" &&
          (history.length === 0 ? (
            <div className="side-empty">No generations yet.</div>
          ) : (
            <>
              <div className="side-group-label">Recent</div>
              {history.map((h) => (
                <div key={h.id} className="side-item" onClick={() => onPickHistory(h)}>
                  <div className="t">{h.query || "(untitled)"}</div>
                  <div className="s">
                    {h.environment} · {h.member_count} members
                  </div>
                </div>
              ))}
            </>
          ))}

        {tab === "prompts" &&
          (prompts.length === 0 ? (
            <div className="side-empty">No saved prompts.</div>
          ) : (
            prompts.map((p) => (
              <div key={p.id} className="side-item" onClick={() => onPickPrompt(p)}>
                <button
                  className="del"
                  title="Delete"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeletePrompt(p.id);
                  }}
                >
                  ×
                </button>
                <div className="t">{p.title}</div>
                <div className="s">{p.body}</div>
              </div>
            ))
          ))}
      </div>

      <div className="side-foot">
        <button className="new-chat" onClick={onNewChat}>
          + New Chat
        </button>
      </div>
    </aside>
  );
}
