import type { ChatTurn, Column, EnvOption } from "../types";
import ReviewTable from "./ReviewTable";

interface Props {
  turns: ChatTurn[];
  columns: Column[];
  env: EnvOption | undefined;
  onSave: (turnIndex: number, members: Record<string, unknown>[]) => void;
  savingIndex: number | null;
  userName: string;
  onSavePrompt: (turnIndex: number, title: string, body: string) => void;
}

function ResultView({ result }: { result: Record<string, unknown> }) {
  // Render the load-API response as readable label/value pairs (no JSON).
  const entries = Object.entries(result);
  return (
    <div className="result-view">
      {entries.map(([k, v]) => (
        <div className="result-row" key={k}>
          <span className="result-k">{k}</span>
          <span className="result-v">
            {typeof v === "object" ? JSON.stringify(v) : String(v)}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function Transcript({
  turns,
  columns,
  env,
  onSave,
  savingIndex,
  userName,
  onSavePrompt,
}: Props) {
  if (turns.length === 0) {
    const hour = new Date().getHours();
    const part = hour < 12 ? "Morning" : hour < 18 ? "Afternoon" : "Evening";
    return (
      <div className="transcript">
        <div className="greeting">
          <div className="orb" />
          <h1>
            Good {part}, {userName}
          </h1>
          <h1>
            How Can I <span className="accent">Assist You Today?</span>
          </h1>
          <p>Describe a member scenario below and I'll generate synthetic test members.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="transcript">
      {turns.map((t, i) => (
        <div className={`turn ${t.role}`} key={i}>
          <div className="who">{t.role === "user" ? userName : "JET Agent"}</div>
          <div className="bubble">
            <div>{t.content}</div>

            {t.role === "user" && (
              <div className="msg-actions">
                <button
                  className={`save-msg-btn ${t.promptSaved ? "saved" : ""}`}
                  disabled={t.promptSaved}
                  onClick={() => onSavePrompt(i, t.content.slice(0, 40), t.content)}
                >
                  {t.promptSaved ? "Saved as prompt" : "Save prompt"}
                </button>
              </div>
            )}

            {t.toolsUsed && t.toolsUsed.length > 0 && (
              <div className="tools-used">
                <span className="tu-label">reference lookups</span>
                {t.toolsUsed.map((name, ti) => (
                  <span className="tu-badge" key={ti}>
                    {name}
                  </span>
                ))}
              </div>
            )}

            {t.groups && (
              <div className="group-summary">
                {t.groups.map((g, gi) => (
                  <span className="group-head" key={gi}>
                    <span className="badge">{g.type}</span>
                    <span>{g.members.length}</span>
                  </span>
                ))}
              </div>
            )}

            {t.result && <ResultView result={t.result} />}

            {t.reviewMembers && (
              <ReviewTable
                columns={columns}
                initialMembers={t.reviewMembers}
                env={env}
                saving={savingIndex === i}
                saved={t.saved ?? false}
                onSave={(members) => onSave(i, members)}
              />
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
