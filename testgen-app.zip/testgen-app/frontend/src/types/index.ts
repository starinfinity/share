export interface Column {
  key: string;
  label: string;
  type: "text" | "date" | "number" | "select";
  editable?: boolean;
  options?: string[];
  in_table?: boolean;
  width?: number;
}

export interface EnvOption {
  key: string;
  label: string;
  is_prod: boolean;
}

export interface TemplateSpec {
  type: string;
  template: Record<string, unknown>;
  count: number;
}

export interface GeneratedGroup {
  type: string;
  members: Record<string, unknown>[];
}

export interface GenerateResponse {
  groups: GeneratedGroup[];
  environment: string;
  tools_used: string[];
}

export interface SavedPrompt {
  id: string;
  title: string;
  body: string;
}

export interface HistoryItem {
  id: string;
  query: string;
  environment: string;
  created_at: string;
  member_count: number;
  turns?: ChatTurn[]; // full snapshot of the exchange, restored when clicked
}

export interface ChatTurn {
  role: "user" | "assistant";
  content: string;
  groups?: GeneratedGroup[];
  toolsUsed?: string[];
  reviewMembers?: Record<string, unknown>[]; // flat list shown in editable table
  saved?: boolean;                            // becomes true after Save to Facets
  result?: Record<string, unknown>;           // load-API response, shown as label/value
  promptSaved?: boolean;                      // becomes true after "Save prompt" on this message
}
