# Text-to-SQL Backend (PHI-safe, agentic, forecasting)

Three-stage pipeline that turns plain-English requests into validated, executed
SQL — without sending any user PHI or result rows to Azure OpenAI.

## Learning from history (persistent, few-shot from past queries)
`app/feedback_store.py` stores every query in a **persistent, file-based vector
database** and retrieves similar **successful** ones to inject as few-shot
examples into future generation prompts. **Data survives app restarts.**

Backends (auto-selected, both file-based, no server process):
- **ChromaDB persistent** (preferred) -> `data/feedback/vectorstore/`. Real
  ANN search with cosine distance. Used when `chromadb` is installed.
- **File fallback** -> `data/feedback/feedback_vectors.pkl`. Atomic writes,
  brute-force cosine. Fully persistent; used when Chroma isn't available.

Both expose the same interface, so swapping is transparent. To force the file
backend, set `PREFER_CHROMA = False` in settings.

Privacy model (two separate fields per record):
- `raw_message` — original user text, for YOUR analytics only. **Never**
  retrieved into a model prompt.
- `sanitized_message` — post-gatekeeper text (PHI removed). Embedded locally
  and the only message form ever surfaced into a prompt.
- Result **rows are never stored** — only column names + row count.

Retrieval embeds the new sanitized message with a **local** model, finds the
top-K similar past successes (cosine >= `FEWSHOT_MIN_SCORE`), and the agent
injects their `(sanitized question -> SQL)` pairs as guidance.

> The store holds `raw_message`, which may contain PHI. The `data/feedback/`
> directory MUST be encrypted at rest and access-controlled. The
> `/analytics/recent` endpoint exposes raw messages — protect it.

## Pipeline

1. **Gatekeeper (local)** — `app/gatekeeper.py`
   Redacts PHI/PII with Presidio (names, addresses) + regex (SSN, email, etc.).
   Fails closed if it can't safely sanitize.

2. **Pruner (local)** — `app/pruner.py`
   - Keyword-matches the request against `data/schema_catalog.json` (all tables).
   - Semantic search over **cold** tables using a **local** embedding model.
   - Builds an FK relationship graph and adds **bridge tables** so joins resolve.

3. **Agentic loop** — `app/agent.py` + `app/guardrails.py`
   Generate SQL → guardrail (read-only, row cap, table whitelist) →
   column validation → execute → on error, feed the error back and retry.

4. **Prediction (local, multi-model)** — `app/prediction.py`,
   `app/model_selector.py`, `app/forecast_models.py`
   - Profiles the result columns into METADATA (name, type, distinct count,
     monotonicity, row count) — no values.
   - The agent (`ModelSelector`) picks a model from a registry and maps
     result columns to roles (`target`, `time`, `category`), returning a JSON
     plan. It sees only column metadata + the model registry, never values.
   - The chosen model runs LOCALLY on the real numbers.
   - A name-aware heuristic fallback runs if no LLM/invalid plan.

   Models available (each self-describes when to use it):
   - `linear_trend` — steady trend, few points
   - `moving_average` — noisy/flat series
   - `seasonal_naive` — strong repeating cycle, little trend
   - `holt_winters` — trend + seasonality, >=2 cycles (e.g. enrollment counts)
   - `categorical_growth` — per-group forecast (e.g. count by state)

   To add a model: implement a runner in `forecast_models.py`, register it in
   `MODEL_RUNNERS`, and add a `ModelSpec` to `MODEL_SPECS`. The agent picks it
   up automatically via `registry_for_prompt()`.

## What reaches Azure OpenAI
Schema metadata, sanitized intent, join paths, and (for narration) aggregate
forecast numbers. **Never** raw user input with PHI, and **never** result rows.

## Run
```bash
pip install -r requirements.txt
export AZURE_OPENAI_ENDPOINT=... AZURE_OPENAI_KEY=... AZURE_OPENAI_DEPLOYMENT=gpt-5.5
export DB_CONNECTION_STRING="Driver={ODBC Driver 18 for SQL Server};..."  # SELECT-only user
uvicorn app.main:app --reload
# Offline demo (no DB / no Azure needed for pipeline shape):
USE_MOCK_DB=1 uvicorn app.main:app
```

## Production checklist
- DB login must be **db_datareader only** — the app-layer guardrails are a
  second line of defense, not the boundary.
- Replace the linear forecast with Prophet/ARIMA (`statsmodels`) as needed.
- Populate `data/schema_catalog.json` for all ~2000 tables; mark the 20–50
  hot tables with `"is_hot": true`. Description/keyword quality drives accuracy.
- Use a local embedding model (default `bge-small-en-v1.5`) so even sanitized
  intent text stays in your environment.
