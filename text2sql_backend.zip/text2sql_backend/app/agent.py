"""
app/agent.py
Stage 2: Agentic RAG loop with mid-loop schema lookup.

generate -> (maybe LOOKUP more tables) -> guardrail -> validate -> execute
-> on error, feed error back. Repeats up to MAX_SQL_RETRIES.

The agent can DISCOVER tables it wasn't given in two ways:
  1. Model-requested: it replies `LOOKUP: <term>` instead of SQL when it
     believes a needed table/join is missing. The agent searches the catalog,
     adds the matches (plus any bridge tables to connect them), and retries
     WITHOUT consuming a hard retry.
  2. Error-driven: if the guardrail rejects an unknown table, the agent auto-
     searches the catalog for it before the next attempt (safety net).

Only schema metadata, sanitized intent, and error strings reach the LLM.
Never result rows, never PHI.
"""
import re
from dataclasses import dataclass, field
from typing import List, Optional, Set

from app.guardrails import Guardrails, validate_columns
from app.llm_client import LLMClient
from config.settings import settings


SYSTEM_PROMPT = """You are an expert T-SQL query writer for Azure SQL Server.
Rules:
- Generate exactly ONE read-only SELECT statement. Never write INSERT/UPDATE/DELETE/DDL.
- Use ONLY the tables and columns provided in the schema. Do not invent columns.
- Use the provided JOIN RELATIONSHIPS for all joins.
- If you believe a table needed for the answer (or to bridge a join) is MISSING
  from the schema above, do NOT guess. Instead reply with exactly one line:
      LOOKUP: <table name or keyword>
  You will be given that table's schema and can then write the query.
- Otherwise return ONLY the SQL. No markdown, no explanation, no code fences.
"""

GEN_TEMPLATE = """-- SCHEMA --
{schema}

-- JOIN RELATIONSHIPS --
{joins}
{examples_block}
-- REQUEST --
{intent}
{error_block}
Write the T-SQL SELECT query (or a single LOOKUP: line if a table is missing):"""

LOOKUP_RE = re.compile(r"^\s*LOOKUP:\s*(.+?)\s*$", re.IGNORECASE | re.MULTILINE)


@dataclass
class AgentResult:
    success: bool
    sql: str = ""
    rows: list = field(default_factory=list)
    columns: List[str] = field(default_factory=list)
    attempts: int = 0
    error: str = ""
    tables_used: List[str] = field(default_factory=list)
    lookups: List[str] = field(default_factory=list)
    trace: List[str] = field(default_factory=list)


def _strip_fences(text: str) -> str:
    text = re.sub(r"^```(?:sql)?", "", text.strip(), flags=re.IGNORECASE)
    text = re.sub(r"```$", "", text.strip())
    return text.strip()


class SQLAgent:
    def __init__(self, llm: LLMClient, guardrails: Guardrails,
                 catalog: dict, db_executor, pruner=None,
                 max_lookups: int = 4):
        self.llm = llm
        self.guardrails = guardrails
        self.catalog = catalog
        self.execute = db_executor          # callable(sql) -> (columns, rows)
        self.pruner = pruner                # provides lookup_tables / connect_tables
        self.max_lookups = max_lookups

    # --- helpers -------------------------------------------------------
    def _expand(self, tables: Set[str], new_tables: List[str],
                joins: Set[str], trace: List[str]) -> None:
        """Add new tables + connect them into the working set (mutates args)."""
        for nt in new_tables:
            if nt in tables:
                continue
            if self.pruner is not None:
                connected, new_joins = self.pruner.connect_tables(tables, nt)
                tables |= connected
                joins |= set(new_joins)
            else:
                tables.add(nt)
        trace.append(f"           schema expanded -> {sorted(tables)}")

    def _render(self, tables: Set[str]) -> str:
        if self.pruner is not None:
            return self.pruner.render_schema(tables)
        # Minimal fallback renderer if no pruner is wired in.
        blocks = []
        for t in sorted(tables):
            meta = self.catalog.get(t)
            if not meta:
                continue
            cols = "\n".join(f"  {c}" for c in meta["columns"])
            blocks.append(f"TABLE {t} (\n{cols}\n)")
        return "\n\n".join(blocks)

    @staticmethod
    def _render_examples(examples) -> str:
        """Render retrieved past (question -> SQL) pairs as few-shot guidance.
        Examples are PROMPT-SAFE: sanitized question + working SQL only."""
        if not examples:
            return ""
        lines = ["\n-- SIMILAR PAST QUERIES THAT SUCCEEDED (use as guidance, "
                 "adapt to the current request; do not copy blindly) --"]
        for ex in examples:
            lines.append(f"Q: {ex.sanitized_message}\nSQL: {ex.sql}")
        return "\n".join(lines) + "\n"

    # --- main loop -----------------------------------------------------
    def run(self, sanitized_intent: str, schema_ddl: str,
            join_paths: List[str], tables: Optional[Set[str]] = None,
            examples: Optional[list] = None) -> AgentResult:
        working_tables: Set[str] = set(tables) if tables else set(self.guardrails.allowed_tables_original)
        working_joins: Set[str] = set(join_paths)
        examples_block = self._render_examples(examples)
        prior_error: Optional[str] = None
        trace: List[str] = []
        lookups_done: List[str] = []
        lookup_budget = self.max_lookups

        attempt = 0
        while attempt < settings.MAX_SQL_RETRIES:
            attempt += 1
            schema_text = self._render(working_tables) if self.pruner else schema_ddl
            joins_text = "\n".join(sorted(working_joins)) if working_joins else "(none)"

            error_block = ""
            if prior_error:
                error_block = (
                    f"\n-- PREVIOUS ATTEMPT FAILED --\n"
                    f"Error: {prior_error}\nFix the query.\n"
                )

            prompt = GEN_TEMPLATE.format(
                schema=schema_text, joins=joins_text, examples_block=examples_block,
                intent=sanitized_intent, error_block=error_block,
            )
            raw = self.llm.complete(SYSTEM_PROMPT, prompt)

            # --- model-requested lookup? ---
            m = LOOKUP_RE.match(raw.strip()) or LOOKUP_RE.search(raw.strip())
            if m and self.pruner is not None and lookup_budget > 0:
                term = m.group(1).strip()
                lookup_budget -= 1
                found = self.pruner.lookup_tables(term, limit=3)
                lookups_done.append(term)
                trace.append(f"[attempt {attempt}] model requested LOOKUP '{term}' -> {found}")
                if found:
                    self._expand(working_tables, found, working_joins, trace)
                    # refresh guardrail whitelist with the new tables
                    self.guardrails.update_allowed(working_tables)
                    prior_error = None
                else:
                    prior_error = f"No tables found matching '{term}'. Use existing schema."
                attempt -= 1  # a lookup turn doesn't burn a real retry
                continue

            sql = _strip_fences(raw)
            trace.append(f"[attempt {attempt}] generated: {sql}")

            # --- guardrail ---
            guard = self.guardrails.check(sql)
            if not guard.ok:
                prior_error = f"Guardrail: {guard.reason}"
                trace.append(f"[attempt {attempt}] guardrail rejected: {guard.reason}")
                # Error-driven discovery: unknown table -> try to find it.
                unknown = self._unknown_table_from_reason(guard.reason)
                if unknown and self.pruner is not None and lookup_budget > 0:
                    lookup_budget -= 1
                    found = self.pruner.lookup_tables(unknown, limit=3)
                    trace.append(f"           auto-lookup '{unknown}' -> {found}")
                    if found:
                        self._expand(working_tables, found, working_joins, trace)
                        self.guardrails.update_allowed(working_tables)
                continue

            sql = guard.fixed_sql

            # --- column validation ---
            col_check = validate_columns(sql, self.catalog, settings.DB_DIALECT)
            if not col_check.ok:
                prior_error = f"Validation: {col_check.reason}"
                trace.append(f"[attempt {attempt}] validation failed: {col_check.reason}")
                continue

            # --- execute ---
            try:
                columns, rows = self.execute(sql)
                trace.append(f"[attempt {attempt}] executed OK, {len(rows)} rows")
                return AgentResult(
                    success=True, sql=sql, rows=rows, columns=columns,
                    attempts=attempt, tables_used=sorted(working_tables),
                    lookups=lookups_done, trace=trace,
                )
            except Exception as e:
                prior_error = str(e)
                trace.append(f"[attempt {attempt}] execution error: {e}")

        return AgentResult(
            success=False, attempts=attempt, error=prior_error or "unknown",
            tables_used=sorted(working_tables), lookups=lookups_done, trace=trace,
        )

    @staticmethod
    def _unknown_table_from_reason(reason: str) -> Optional[str]:
        m = re.search(r"Table not permitted:\s*(\w+)", reason or "")
        return m.group(1) if m else None
