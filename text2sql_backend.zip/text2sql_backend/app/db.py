"""
app/db.py
Database execution layer.

Uses pyodbc against Azure SQL with a SELECT-only login. Includes a mock
executor so the pipeline can be tested without a live DB.
"""
from typing import List, Tuple

try:
    import pyodbc
    _PYODBC_AVAILABLE = True
except ImportError:
    _PYODBC_AVAILABLE = False


class DBExecutor:
    """Real executor. Requires a least-privilege (db_datareader) connection."""
    def __init__(self, connection_string: str, timeout: int = 30):
        if not _PYODBC_AVAILABLE:
            raise RuntimeError("pyodbc not installed")
        self.connection_string = connection_string
        self.timeout = timeout

    def __call__(self, sql: str) -> Tuple[List[str], list]:
        conn = pyodbc.connect(self.connection_string, timeout=self.timeout)
        try:
            conn.autocommit = False
            cur = conn.cursor()
            cur.execute(sql)
            columns = [d[0] for d in cur.description] if cur.description else []
            rows = [list(r) for r in cur.fetchall()]
            conn.rollback()  # never persist anything; read-only by intent
            return columns, rows
        finally:
            conn.close()


class MockExecutor:
    """Deterministic mock for local testing of the full pipeline."""
    def __call__(self, sql: str) -> Tuple[List[str], list]:
        s = sql.lower()
        # Simulate a syntax error to exercise the self-fix loop.
        if "membr" in s or "actv" in s:
            raise RuntimeError("Invalid column name (simulated)")

        if "count" in s and "enrollmentperiod" in s.replace(" ", ""):
            # Member count per enrollment period (time series for forecasting)
            return (["PeriodName", "StartDate", "MemberCount"], [
                ["2021 Open", "2021-11-01", 1200],
                ["2022 Open", "2022-11-01", 1450],
                ["2023 Open", "2023-11-01", 1610],
                ["2024 Open", "2024-11-01", 1875],
                ["2025 Open", "2025-11-01", 2050],
            ])

        if "count" in s:
            return (["ActiveMemberCount"], [[842]])

        # Default: a few active Florida members
        return (["MemberID", "FirstName", "StatusName", "StateName"], [
            [101, "REDACTED", "Active", "Florida"],
            [102, "REDACTED", "Active", "Florida"],
        ])
