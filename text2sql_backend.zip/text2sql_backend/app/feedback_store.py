"""
app/feedback_store.py
Persistent vector-backed store for query history + few-shot retrieval.

Data survives app restarts: everything is written to disk.

BACKENDS (auto-selected, all file-based / no server):
  1. ChromaDB persistent  -> data/vectorstore/ (preferred; real ANN search)
  2. File fallback        -> data/feedback_vectors.pkl (brute-force cosine,
                             still fully persistent across restarts)

PRIVACY MODEL (unchanged):
  - raw_message       : original text, analytics only, NEVER sent to a model.
  - sanitized_message : PHI-removed; embedded + the only form put in prompts.
  - result ROWS are never stored (only column names + row count).
Embeddings are computed with a LOCAL model, so nothing leaves the environment.
"""
import json
import math
import os
import pickle
import time
import uuid
from dataclasses import dataclass, field
from typing import List, Optional

try:
    from sentence_transformers import SentenceTransformer
    _ST_AVAILABLE = True
except ImportError:
    _ST_AVAILABLE = False

try:
    import chromadb
    _CHROMA_AVAILABLE = True
except ImportError:
    _CHROMA_AVAILABLE = False


@dataclass
class SimilarExample:
    sanitized_message: str
    sql: str
    tables_used: List[str]
    score: float


def _cosine(a, b) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


# ---------------------------------------------------------------------------
# Backend 2: persistent file store (no external deps). Brute-force cosine.
# ---------------------------------------------------------------------------
class _FilePersistentBackend:
    def __init__(self, path: str):
        self.path = path
        self.records: List[dict] = []
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            try:
                with open(self.path, "rb") as f:
                    self.records = pickle.load(f)
            except Exception:
                self.records = []

    def _flush(self):
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "wb") as f:
            pickle.dump(self.records, f)
        os.replace(tmp, self.path)   # atomic write -> survives crash mid-write

    def add(self, rec: dict):
        self.records.append(rec)
        self._flush()

    def query_successful(self, q_emb, k, min_score):
        out = []
        for r in self.records:
            if not r["success"] or r.get("embedding") is None:
                continue
            score = _cosine(q_emb, r["embedding"])
            if score >= min_score:
                out.append((score, r))
        out.sort(key=lambda x: x[0], reverse=True)
        return out[:k]

    def recent(self, limit):
        return list(reversed(self.records[-limit:]))

    def count(self):
        return len(self.records)


# ---------------------------------------------------------------------------
# Backend 1: ChromaDB persistent
# ---------------------------------------------------------------------------
class _ChromaBackend:
    def __init__(self, persist_dir: str):
        os.makedirs(persist_dir, exist_ok=True)
        self.client = chromadb.PersistentClient(path=persist_dir)
        # We pass our own (local) embeddings, so no embedding_function here.
        self.col = self.client.get_or_create_collection(
            name="query_history", metadata={"hnsw:space": "cosine"}
        )

    def add(self, rec: dict):
        # Chroma stores vector + metadata + the doc text. Vectors required.
        emb = rec.get("embedding")
        if emb is None:
            # No vector -> can't store in Chroma meaningfully for search.
            # Store with a zero vector so it's still persisted/auditable.
            emb = [0.0]
        self.col.add(
            ids=[rec["id"]],
            embeddings=[emb],
            documents=[rec["sanitized_message"]],
            metadatas=[{
                "raw_message": rec["raw_message"],
                "sql": rec["sql"],
                "success": rec["success"],
                "error": rec["error"],
                "result_columns": json.dumps(rec["result_columns"]),
                "row_count": rec["row_count"],
                "tables_used": json.dumps(rec["tables_used"]),
                "created_at": rec["created_at"],
            }],
        )

    def query_successful(self, q_emb, k, min_score):
        # Over-fetch then filter to success + threshold (Chroma where-filter
        # also works, but we keep it simple + backend-agnostic).
        res = self.col.query(
            query_embeddings=[q_emb],
            n_results=max(k * 5, k),
            where={"success": True},
        )
        out = []
        ids = res.get("ids", [[]])[0]
        metas = res.get("metadatas", [[]])[0]
        docs = res.get("documents", [[]])[0]
        dists = res.get("distances", [[]])[0]
        for meta, doc, dist in zip(metas, docs, dists):
            score = 1.0 - dist          # cosine distance -> similarity
            if score >= min_score:
                rec = dict(meta)
                rec["sanitized_message"] = doc
                out.append((score, rec))
        out.sort(key=lambda x: x[0], reverse=True)
        return out[:k]

    def recent(self, limit):
        got = self.col.get(include=["metadatas", "documents"], limit=limit)
        recs = []
        for meta, doc in zip(got.get("metadatas", []), got.get("documents", [])):
            r = dict(meta)
            r["sanitized_message"] = doc
            recs.append(r)
        recs.sort(key=lambda r: r.get("created_at", 0), reverse=True)
        return recs[:limit]

    def count(self):
        return self.col.count()


# ---------------------------------------------------------------------------
# Public store
# ---------------------------------------------------------------------------
class FeedbackStore:
    def __init__(self, persist_dir: str, embedding_model_name: str,
                 prefer_chroma: bool = True):
        self._model = SentenceTransformer(embedding_model_name) if _ST_AVAILABLE else None

        self.backend_name = "file"
        if prefer_chroma and _CHROMA_AVAILABLE:
            try:
                self.backend = _ChromaBackend(os.path.join(persist_dir, "vectorstore"))
                self.backend_name = "chroma"
            except Exception:
                self.backend = _FilePersistentBackend(
                    os.path.join(persist_dir, "feedback_vectors.pkl"))
        else:
            self.backend = _FilePersistentBackend(
                os.path.join(persist_dir, "feedback_vectors.pkl"))

    def _embed(self, text: str) -> Optional[List[float]]:
        if not self._model:
            return None
        return self._model.encode(text, normalize_embeddings=True).tolist()

    # ---------------- write ----------------
    def add(self, raw_message: str, sanitized_message: str, sql: str,
            success: bool, error: str, result_columns: List[str],
            row_count: int, tables_used: List[str]) -> None:
        rec = {
            "id": str(uuid.uuid4()),
            "raw_message": raw_message,
            "sanitized_message": sanitized_message,
            "sql": sql,
            "success": bool(success),
            "error": error,
            "result_columns": result_columns,
            "row_count": row_count,
            "tables_used": tables_used,
            "embedding": self._embed(sanitized_message),
            "created_at": time.time(),
        }
        self.backend.add(rec)

    # ---------------- read (prompt-safe) ----------------
    def find_similar_successful(self, sanitized_message: str, k: int = 3,
                                min_score: float = 0.55) -> List[SimilarExample]:
        q_emb = self._embed(sanitized_message)
        if q_emb is None:
            return []   # no local embedder -> skip retrieval rather than guess
        hits = self.backend.query_successful(q_emb, k, min_score)
        out = []
        for score, rec in hits:
            tables = rec.get("tables_used", [])
            if isinstance(tables, str):
                tables = json.loads(tables)
            out.append(SimilarExample(
                sanitized_message=rec["sanitized_message"],
                sql=rec["sql"], tables_used=tables, score=round(score, 3),
            ))
        return out

    # ---------------- analytics (raw data stays here) ----------------
    def recent(self, limit: int = 50) -> List[dict]:
        recs = self.backend.recent(limit)
        norm = []
        for r in recs:
            tables = r.get("tables_used", [])
            if isinstance(tables, str):
                tables = json.loads(tables)
            cols = r.get("result_columns", [])
            if isinstance(cols, str):
                cols = json.loads(cols)
            norm.append({
                "raw_message": r.get("raw_message", ""),
                "sanitized_message": r.get("sanitized_message", ""),
                "sql": r.get("sql", ""),
                "success": bool(r.get("success")),
                "error": r.get("error", ""),
                "row_count": r.get("row_count", 0),
                "tables_used": tables,
                "created_at": r.get("created_at", 0),
            })
        return norm

    def count(self) -> int:
        return self.backend.count()
