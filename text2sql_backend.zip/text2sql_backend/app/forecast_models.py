"""
app/forecast_models.py
A registry of forecasting models, each with a common interface and a
self-describing spec so the agent can choose the right one.

All models run LOCALLY on real numbers. The agent only ever sees each model's
metadata (name, description, when_to_use, required column ROLES) — never data.

Column roles a model may request:
  - "time"     : the ordering/time axis (date or sequential label)
  - "target"   : the numeric value to forecast
  - "category" : a grouping dimension (e.g. state) for per-group forecasts
"""
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

import numpy as np


@dataclass
class ModelSpec:
    name: str
    description: str
    when_to_use: str
    required_roles: List[str]            # roles this model needs mapped
    optional_roles: List[str] = field(default_factory=list)
    min_points: int = 3


@dataclass
class ForecastOutput:
    model: str
    horizon: int
    # For single-series models:
    history: List[float] = field(default_factory=list)
    forecast: List[float] = field(default_factory=list)
    # For grouped (categorical) models: {category: {"history":[], "forecast":[]}}
    by_category: Dict[str, Dict[str, List[float]]] = field(default_factory=dict)
    notes: str = ""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _ols_forecast(series: List[float], periods: int) -> List[float]:
    x = np.arange(len(series))
    slope, intercept = np.polyfit(x, np.array(series), 1)
    fx = np.arange(len(series), len(series) + periods)
    return [round(float(slope * i + intercept), 2) for i in fx]


def _moving_average(series: List[float], periods: int, window: int = 3) -> List[float]:
    s = list(series)
    out = []
    for _ in range(periods):
        w = s[-window:] if len(s) >= window else s
        nxt = round(float(np.mean(w)), 2)
        out.append(nxt)
        s.append(nxt)
    return out


def _seasonal_naive(series: List[float], periods: int, season: int) -> List[float]:
    if len(series) < season:
        return _moving_average(series, periods)
    out = []
    for i in range(periods):
        out.append(round(float(series[-season + (i % season)]), 2))
    return out


def _holt_winters(series: List[float], periods: int, season: int) -> List[float]:
    """Triple exponential smoothing (additive). Falls back to OLS if statsmodels
    is unavailable or the series is too short for the season."""
    try:
        from statsmodels.tsa.holtwinters import ExponentialSmoothing
        if len(series) < 2 * season:
            raise ValueError("not enough cycles")
        model = ExponentialSmoothing(
            series, trend="add", seasonal="add", seasonal_periods=season
        ).fit()
        fc = model.forecast(periods)
        return [round(float(v), 2) for v in fc]
    except Exception:
        return _ols_forecast(series, periods)


# ---------------------------------------------------------------------------
# Model implementations: each takes (mapped_data, horizon, params) -> Output
# mapped_data holds resolved columns: {"time":[...], "target":[...], "category":[...]}
# ---------------------------------------------------------------------------
def run_linear_trend(data, horizon, params):
    series = data["target"]
    return ForecastOutput(
        model="linear_trend", horizon=horizon, history=series,
        forecast=_ols_forecast(series, horizon),
        notes="OLS linear trend.",
    )


def run_moving_average(data, horizon, params):
    series = data["target"]
    w = int(params.get("window", 3))
    return ForecastOutput(
        model="moving_average", horizon=horizon, history=series,
        forecast=_moving_average(series, horizon, w),
        notes=f"Moving average (window={w}).",
    )


def run_seasonal_naive(data, horizon, params):
    series = data["target"]
    season = int(params.get("season", 4))
    return ForecastOutput(
        model="seasonal_naive", horizon=horizon, history=series,
        forecast=_seasonal_naive(series, horizon, season),
        notes=f"Seasonal naive (season={season}).",
    )


def run_holt_winters(data, horizon, params):
    series = data["target"]
    season = int(params.get("season", 4))
    return ForecastOutput(
        model="holt_winters", horizon=horizon, history=series,
        forecast=_holt_winters(series, horizon, season),
        notes=f"Holt-Winters additive (season={season}).",
    )


def run_categorical_growth(data, horizon, params):
    """Forecast each category's target series independently with OLS."""
    cats = data.get("category")
    target = data["target"]
    if not cats:
        # No category provided: behave like linear trend on the whole series.
        return run_linear_trend(data, horizon, params)

    groups: Dict[str, List[float]] = {}
    for c, v in zip(cats, target):
        groups.setdefault(str(c), []).append(float(v))

    by_cat = {}
    for c, series in groups.items():
        if len(series) >= 2:
            fc = _ols_forecast(series, horizon)
        else:
            fc = [round(float(series[-1]), 2)] * horizon
        by_cat[c] = {"history": series, "forecast": fc}

    return ForecastOutput(
        model="categorical_growth", horizon=horizon, by_category=by_cat,
        notes=f"Per-category OLS over {len(by_cat)} groups.",
    )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------
MODEL_RUNNERS: Dict[str, Callable] = {
    "linear_trend": run_linear_trend,
    "moving_average": run_moving_average,
    "seasonal_naive": run_seasonal_naive,
    "holt_winters": run_holt_winters,
    "categorical_growth": run_categorical_growth,
}

MODEL_SPECS: Dict[str, ModelSpec] = {
    "linear_trend": ModelSpec(
        name="linear_trend",
        description="Fits a straight line (OLS) and extrapolates.",
        when_to_use="Steady upward/downward trend, no seasonality, few points.",
        required_roles=["target"], optional_roles=["time"], min_points=3,
    ),
    "moving_average": ModelSpec(
        name="moving_average",
        description="Averages the most recent N points and projects forward.",
        when_to_use="Noisy/flat series with no clear trend; short horizon.",
        required_roles=["target"], optional_roles=["time"], min_points=3,
    ),
    "seasonal_naive": ModelSpec(
        name="seasonal_naive",
        description="Repeats the values from the last full season/cycle.",
        when_to_use="Strong repeating cycle and little trend (e.g. same enrollment "
                    "pattern each year). Set params.season to the cycle length.",
        required_roles=["target", "time"], min_points=4,
    ),
    "holt_winters": ModelSpec(
        name="holt_winters",
        description="Triple exponential smoothing: level + trend + seasonality.",
        when_to_use="Series with BOTH trend and seasonality and >=2 full cycles "
                    "of history. Best for enrollment counts across many periods. "
                    "Set params.season to the cycle length.",
        required_roles=["target", "time"], min_points=8,
    ),
    "categorical_growth": ModelSpec(
        name="categorical_growth",
        description="Forecasts each category's series separately (OLS per group).",
        when_to_use="Result has a grouping dimension (e.g. count by state, by plan) "
                    "and you want a forecast PER category. Map 'category' to the "
                    "grouping column.",
        required_roles=["target", "category"], optional_roles=["time"], min_points=2,
    ),
}


def registry_for_prompt() -> str:
    """Compact catalog of models for the agent to choose from (no data)."""
    lines = []
    for spec in MODEL_SPECS.values():
        roles = ", ".join(spec.required_roles)
        opt = f" (optional: {', '.join(spec.optional_roles)})" if spec.optional_roles else ""
        lines.append(
            f"- {spec.name}: {spec.description}\n"
            f"    use when: {spec.when_to_use}\n"
            f"    required columns(roles): {roles}{opt}; needs >= {spec.min_points} points."
        )
    return "\n".join(lines)
