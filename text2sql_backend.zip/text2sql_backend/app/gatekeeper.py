"""
app/gatekeeper.py
Stage 1a: PHI / PII detection and redaction.

Runs FULLY LOCALLY. Nothing here calls Azure OpenAI.
Uses Microsoft Presidio when available (catches names, addresses, etc.)
and falls back to regex for structured identifiers.

Policy: FAIL CLOSED. If we detect PHI we cannot safely strip, we reject
the request rather than risk leaking it downstream.
"""
import re
from dataclasses import dataclass, field
from typing import List

# Presidio is optional at import time so the module loads even without it.
try:
    from presidio_analyzer import AnalyzerEngine
    from presidio_anonymizer import AnonymizerEngine
    _PRESIDIO_AVAILABLE = True
except ImportError:
    _PRESIDIO_AVAILABLE = False


# Structured-identifier patterns (regex catches what NER may miss)
PHI_PATTERNS = {
    "SSN": r"\b\d{3}-\d{2}-\d{4}\b",
    "MRN": r"\bMRN[:\s]*\d+\b",
    "EMAIL": r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b",
    "PHONE": r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b",
    "DOB": r"\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b",
    "CREDIT_CARD": r"\b(?:\d[ -]*?){13,16}\b",
}

# Presidio entity types we treat as PHI/PII to redact.
PRESIDIO_ENTITIES = [
    "PERSON", "EMAIL_ADDRESS", "PHONE_NUMBER", "US_SSN",
    "CREDIT_CARD", "MEDICAL_LICENSE", "US_DRIVER_LICENSE",
    "LOCATION", "DATE_TIME", "US_BANK_NUMBER", "IP_ADDRESS",
]

# Locations that are legitimate query targets (states) — don't redact these.
# Member-level addresses are still caught by Presidio LOCATION otherwise.
STATE_ALLOWLIST = {
    "alabama", "alaska", "arizona", "arkansas", "california", "colorado",
    "connecticut", "delaware", "florida", "georgia", "hawaii", "idaho",
    "illinois", "indiana", "iowa", "kansas", "kentucky", "louisiana",
    "maine", "maryland", "massachusetts", "michigan", "minnesota",
    "mississippi", "missouri", "montana", "nebraska", "nevada",
    "new hampshire", "new jersey", "new mexico", "new york",
    "north carolina", "north dakota", "ohio", "oklahoma", "oregon",
    "pennsylvania", "rhode island", "south carolina", "south dakota",
    "tennessee", "texas", "utah", "vermont", "virginia", "washington",
    "west virginia", "wisconsin", "wyoming",
}


@dataclass
class GatekeeperResult:
    sanitized_text: str
    phi_found: List[str] = field(default_factory=list)
    blocked: bool = False
    block_reason: str = ""


class Gatekeeper:
    def __init__(self, fail_closed: bool = True):
        self.fail_closed = fail_closed
        self._analyzer = None
        self._anonymizer = None
        if _PRESIDIO_AVAILABLE:
            self._analyzer = AnalyzerEngine()
            self._anonymizer = AnonymizerEngine()

    def _regex_redact(self, text: str):
        found = []
        redacted = text
        for label, pattern in PHI_PATTERNS.items():
            if re.search(pattern, redacted):
                found.append(label)
                redacted = re.sub(pattern, f"[{label}_REDACTED]", redacted)
        return redacted, found

    def _presidio_redact(self, text: str):
        results = self._analyzer.analyze(
            text=text, entities=PRESIDIO_ENTITIES, language="en"
        )
        # Drop LOCATION hits that are just state names (valid query targets).
        filtered = []
        for r in results:
            span = text[r.start:r.end].lower().strip()
            if r.entity_type == "LOCATION" and span in STATE_ALLOWLIST:
                continue
            filtered.append(r)

        if not filtered:
            return text, []

        anonymized = self._anonymizer.anonymize(text=text, analyzer_results=filtered)
        found = sorted({r.entity_type for r in filtered})
        return anonymized.text, found

    def process(self, text: str) -> GatekeeperResult:
        """Redact PHI from the user instruction. Returns sanitized text."""
        # Layer 1: regex for structured identifiers
        redacted, regex_found = self._regex_redact(text)

        # Layer 2: Presidio NER for names/locations/etc.
        presidio_found = []
        if _PRESIDIO_AVAILABLE:
            redacted, presidio_found = self._presidio_redact(redacted)
        elif self.fail_closed:
            # No NER available — only structured PHI was checked.
            # If the text looks like it might contain a person name, fail closed.
            if self._looks_like_unhandled_phi(redacted):
                return GatekeeperResult(
                    sanitized_text="",
                    phi_found=regex_found,
                    blocked=True,
                    block_reason="PHI detector (Presidio) unavailable and possible "
                                 "unstructured PHI detected. Failing closed.",
                )

        all_found = sorted(set(regex_found) | set(presidio_found))

        # Final guard: if redaction markers remain mixed with high PHI density,
        # and fail_closed is on, block when too much was redacted to be useful.
        if self.fail_closed and self._over_redacted(redacted):
            return GatekeeperResult(
                sanitized_text="",
                phi_found=all_found,
                blocked=True,
                block_reason="Too much PHI detected to safely process the request.",
            )

        return GatekeeperResult(sanitized_text=redacted, phi_found=all_found)

    @staticmethod
    def _looks_like_unhandled_phi(text: str) -> bool:
        # Heuristic: 'named X', 'patient X', capitalized name after a keyword.
        return bool(re.search(r"\b(named|patient|member|mr|mrs|ms|dr)\.?\s+[A-Z][a-z]+", text))

    @staticmethod
    def _over_redacted(text: str) -> bool:
        markers = text.count("_REDACTED]") + text.count("<")
        words = max(len(text.split()), 1)
        return markers / words > 0.5
