"""
app/guardrails.py
Stage 2: SQL guardrails and static validation.

These are APP-LAYER guards. They must be backed by a least-privilege,
SELECT-only database user as the real enforcement boundary.
"""
from dataclasses import dataclass
from typing import Set

import sqlglot
from sqlglot import exp


@dataclass
class GuardResult:
    ok: bool
    reason: str = ""
    fixed_sql: str = ""


FORBIDDEN = (
    exp.Insert, exp.Update, exp.Delete, exp.Drop, exp.Create,
    exp.Alter, exp.TruncateTable, exp.Merge, exp.Command,
)


class Guardrails:
    def __init__(self, allowed_tables: Set[str], dialect: str = "tsql",
                 row_limit: int = 1000):
        self.allowed_tables_original = set(allowed_tables)
        self.allowed_tables = {t.lower() for t in allowed_tables}
        self.dialect = dialect
        self.row_limit = row_limit

    def update_allowed(self, tables: Set[str]) -> None:
        """Expand the whitelist when the agent discovers new tables mid-loop."""
        self.allowed_tables_original |= set(tables)
        self.allowed_tables |= {t.lower() for t in tables}

    def check(self, sql: str) -> GuardResult:
        # 1. Parse
        try:
            parsed = sqlglot.parse_one(sql, dialect=self.dialect)
        except Exception as e:
            return GuardResult(ok=False, reason=f"Unparseable SQL: {e}")

        if parsed is None:
            return GuardResult(ok=False, reason="Empty SQL")

        # 2. Must be a SELECT (or CTE wrapping a SELECT)
        if not isinstance(parsed, (exp.Select, exp.With, exp.Subquery)):
            return GuardResult(ok=False, reason="Only SELECT statements are allowed")

        # 3. No forbidden write/DDL operations anywhere
        for forbidden in FORBIDDEN:
            if parsed.find(forbidden):
                return GuardResult(
                    ok=False,
                    reason=f"Forbidden operation detected: {forbidden.__name__}",
                )

        # 4. All referenced tables must be whitelisted
        for tbl in parsed.find_all(exp.Table):
            name = tbl.name.lower()
            if name and name not in self.allowed_tables:
                return GuardResult(ok=False, reason=f"Table not permitted: {tbl.name}")

        # 5. Enforce a row cap (inject TOP for T-SQL if missing)
        fixed = self._enforce_row_cap(parsed)

        return GuardResult(ok=True, fixed_sql=fixed)

    def _enforce_row_cap(self, parsed: exp.Expression) -> str:
        select = parsed if isinstance(parsed, exp.Select) else parsed.find(exp.Select)

        if self.dialect == "tsql":
            has_top = bool(select and select.args.get("limit")) or "TOP" in parsed.sql(dialect="tsql").upper()
            if select is not None and not has_top:
                select.set("limit", exp.Limit(expression=exp.Literal.number(self.row_limit)))
            sql = parsed.sql(dialect="tsql")
            # sqlglot renders LIMIT as TOP for tsql automatically on Select.
            return sql

        # Other dialects: ensure LIMIT exists
        if select is not None and not select.args.get("limit"):
            select.set("limit", exp.Limit(expression=exp.Literal.number(self.row_limit)))
        return parsed.sql(dialect=self.dialect)


def validate_columns(sql: str, catalog: dict, dialect: str = "tsql") -> GuardResult:
    """Verify every referenced column exists in the catalog (best-effort)."""
    try:
        parsed = sqlglot.parse_one(sql, dialect=dialect)
    except Exception as e:
        return GuardResult(ok=False, reason=f"Unparseable: {e}")

    # Build a map of known columns per table.
    known = {t.lower(): {c.lower() for c in m["columns"]} for t, m in catalog.items()}

    # Collect table aliases -> real table.
    alias_map = {}
    for tbl in parsed.find_all(exp.Table):
        real = tbl.name.lower()
        alias = (tbl.alias or tbl.name).lower()
        alias_map[alias] = real

    for col in parsed.find_all(exp.Column):
        tbl_ref = (col.table or "").lower()
        col_name = col.name.lower()
        if not tbl_ref:
            continue  # unqualified column - skip (can't resolve reliably)
        real = alias_map.get(tbl_ref, tbl_ref)
        if real in known and col_name not in known[real] and col_name != "*":
            return GuardResult(
                ok=False, reason=f"Unknown column '{col.name}' on table '{real}'"
            )
    return GuardResult(ok=True, fixed_sql=sql)
