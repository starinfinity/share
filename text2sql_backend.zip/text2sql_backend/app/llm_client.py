"""
app/llm_client.py
Thin wrapper around Azure OpenAI.

IMPORTANT: Callers must only ever pass schema metadata + sanitized intent +
aggregate numbers here. No raw user PHI, no query result rows.
"""
from config.settings import settings


class LLMClient:
    def __init__(self):
        from openai import AzureOpenAI  # lazy: only needed when actually calling

        self.client = AzureOpenAI(
            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
            api_key=settings.AZURE_OPENAI_KEY,
            api_version=settings.AZURE_OPENAI_API_VERSION,
        )
        self.deployment = settings.AZURE_OPENAI_DEPLOYMENT

    def complete(self, system: str, user: str, temperature: float = 0.0) -> str:
        resp = self.client.chat.completions.create(
            model=self.deployment,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=temperature,
        )
        return resp.choices[0].message.content.strip()
