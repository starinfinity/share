"""
app/main.py
FastAPI entrypoint.

Run: uvicorn app.main:app --reload
Set USE_MOCK_DB=1 to run without a live database.
"""
import os

from fastapi import FastAPI
from pydantic import BaseModel

from app.db import DBExecutor, MockExecutor
from app.orchestrator import Orchestrator
from config.settings import settings

app = FastAPI(title="Text-to-SQL Backend")


def _build_executor():
    if os.getenv("USE_MOCK_DB") == "1" or not settings.DB_CONNECTION_STRING:
        return MockExecutor()
    return DBExecutor(settings.DB_CONNECTION_STRING)


orchestrator = Orchestrator(db_executor=_build_executor())


class QueryRequest(BaseModel):
    text: str


@app.post("/query")
def query(req: QueryRequest):
    resp = orchestrator.handle(req.text)
    return {
        "status": resp.status,
        "message": resp.message,
        "sql": resp.sql,
        "columns": resp.columns,
        "rows": resp.rows,
        "phi_found": resp.phi_found,
        "tables_used": resp.tables_used,
        "examples_used": resp.examples_used,
        "prediction": None if resp.prediction is None else {
            "model": resp.prediction.model,
            "mapping": resp.prediction.mapping,
            "params": resp.prediction.params,
            "reason": resp.prediction.reason,
            "narrative": resp.prediction.narrative,
            "output": None if resp.prediction.output is None else {
                "history": resp.prediction.output.history,
                "forecast": resp.prediction.output.forecast,
                "by_category": resp.prediction.output.by_category,
                "horizon": resp.prediction.output.horizon,
                "notes": resp.prediction.output.notes,
            },
        },
        "trace": resp.trace,
    }


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.get("/analytics/recent")
def analytics_recent(limit: int = 50):
    """For internal dashboards. Includes raw messages - protect this endpoint."""
    return {"records": orchestrator.feedback.recent(limit)}
