"""
app/model_selector.py
Lets the agent choose a forecasting model and a column->role mapping.

The agent is shown ONLY:
  - the sanitized intent
  - the result COLUMN SCHEMA (name + inferred type + a couple of non-PHI
    descriptors like distinct-count / is-monotonic), and row count
  - the model registry (names + when_to_use + required roles)

It returns a JSON plan. Actual values are never sent.
"""
import json
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Dict, List, Optional

from app.forecast_models import MODEL_SPECS, registry_for_prompt
from app.llm_client import LLMClient


@dataclass
class ColumnProfile:
    name: str
    dtype: str          # "numeric" | "date" | "categorical" | "text"
    distinct: int
    monotonic: bool     # for numeric: largely increasing/decreasing
    n_rows: int


@dataclass
class ForecastPlan:
    use_forecast: bool
    model: str = ""
    mapping: Dict[str, str] = field(default_factory=dict)  # role -> column name
    params: Dict[str, object] = field(default_factory=dict)
    horizon: int = 1
    reason: str = ""


def _infer_dtype(values: list) -> str:
    non_null = [v for v in values if v is not None]
    if not non_null:
        return "text"
    if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in non_null):
        return "numeric"
    if all(isinstance(v, (date, datetime)) for v in non_null):
        return "date"
    # date-like strings?
    if all(isinstance(v, str) for v in non_null):
        if all(re.match(r"\d{4}-\d{2}-\d{2}", v) for v in non_null):
            return "date"
        # low cardinality strings -> categorical
        if len(set(non_null)) <= max(2, len(non_null) // 2):
            return "categorical"
        return "text"
    return "text"


def profile_columns(columns: List[str], rows: list) -> List[ColumnProfile]:
    """Build per-column metadata WITHOUT exposing values."""
    profiles = []
    n = len(rows)
    for i, name in enumerate(columns):
        col = [r[i] for r in rows]
        dtype = _infer_dtype(col)
        distinct = len({str(v) for v in col if v is not None})
        monotonic = False
        if dtype == "numeric":
            nums = [float(v) for v in col if isinstance(v, (int, float))]
            if len(nums) >= 2:
                inc = all(b >= a for a, b in zip(nums, nums[1:]))
                dec = all(b <= a for a, b in zip(nums, nums[1:]))
                monotonic = inc or dec
        profiles.append(ColumnProfile(name, dtype, distinct, monotonic, n))
    return profiles


SELECT_SYSTEM = """You choose a forecasting model and map result columns to the
roles the model needs. You are given column METADATA only, never the data.
Roles: time (ordering axis), target (numeric value to forecast),
category (grouping dimension for per-group forecasts).
Return ONLY JSON, no prose, with this shape:
{"use_forecast": bool, "model": str, "mapping": {"target": "Col", "time": "Col", "category": "Col"},
 "params": {"season": int}, "horizon": int, "reason": str}
If forecasting doesn't apply, return {"use_forecast": false, "reason": "..."}.
Only include roles in "mapping" that the chosen model needs. Only include
"season" when the model uses it; infer it from the time column if possible."""

SELECT_TEMPLATE = """-- USER REQUEST --
{intent}

-- RESULT COLUMNS (metadata only) --
{columns}
Row count: {n_rows}

-- AVAILABLE MODELS --
{registry}

Pick the best model and column mapping. Return JSON only."""


class ModelSelector:
    def __init__(self, llm: Optional[LLMClient] = None):
        self.llm = llm

    def _format_columns(self, profiles: List[ColumnProfile]) -> str:
        out = []
        for p in profiles:
            extra = ", monotonic" if p.monotonic else ""
            out.append(f"- {p.name}: {p.dtype} (distinct={p.distinct}{extra})")
        return "\n".join(out)

    def select(self, intent: str, profiles: List[ColumnProfile]) -> ForecastPlan:
        n_rows = profiles[0].n_rows if profiles else 0
        # If no LLM available, fall back to a heuristic chooser.
        if self.llm is None:
            return self._heuristic(intent, profiles)

        prompt = SELECT_TEMPLATE.format(
            intent=intent,
            columns=self._format_columns(profiles),
            n_rows=n_rows,
            registry=registry_for_prompt(),
        )
        try:
            raw = self.llm.complete(SELECT_SYSTEM, prompt)
            plan = self._parse(raw)
            if plan and self._validate(plan, profiles):
                return plan
        except Exception:
            pass
        return self._heuristic(intent, profiles)

    def _parse(self, raw: str) -> Optional[ForecastPlan]:
        txt = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.IGNORECASE).strip()
        try:
            d = json.loads(txt)
        except Exception:
            m = re.search(r"\{.*\}", txt, re.DOTALL)
            if not m:
                return None
            d = json.loads(m.group(0))
        if not d.get("use_forecast"):
            return ForecastPlan(use_forecast=False, reason=d.get("reason", ""))
        return ForecastPlan(
            use_forecast=True, model=d.get("model", ""),
            mapping=d.get("mapping", {}), params=d.get("params", {}),
            horizon=int(d.get("horizon", 1)), reason=d.get("reason", ""),
        )

    def _validate(self, plan: ForecastPlan, profiles: List[ColumnProfile]) -> bool:
        spec = MODEL_SPECS.get(plan.model)
        if not spec:
            return False
        colnames = {p.name for p in profiles}
        for role in spec.required_roles:
            col = plan.mapping.get(role)
            if not col or col not in colnames:
                return False
        if (profiles[0].n_rows if profiles else 0) < spec.min_points:
            return False
        return True

    # ----- heuristic fallback (no LLM / invalid plan) -----
    def _heuristic(self, intent: str, profiles: List[ColumnProfile]) -> ForecastPlan:
        numeric = [p for p in profiles if p.dtype == "numeric"]
        time_cols = [p for p in profiles if p.dtype == "date"]
        cat_cols = [p for p in profiles if p.dtype == "categorical"]
        n = profiles[0].n_rows if profiles else 0
        if not numeric:
            return ForecastPlan(use_forecast=False, reason="no numeric target column")

        # Pick the target by NAME signal, not just position.
        target_kw = ("count", "total", "sum", "amount", "enrolled", "members",
                     "signups", "volume", "qty", "quantity", "num")
        scored_targets = []
        for p in numeric:
            score = sum(k in p.name.lower() for k in target_kw)
            # prefer non-id-looking, higher-variance-ish columns
            if p.name.lower().endswith("id") or p.name.lower() == "id":
                score -= 5
            scored_targets.append((score, p))
        scored_targets.sort(key=lambda x: x[0], reverse=True)
        target = scored_targets[0][1].name

        # Only use a category if it has few distinct values AND repeats across
        # a time axis (i.e. n_rows is a multiple-ish of distinct count).
        good_cat = None
        if cat_cols and time_cols and n >= 4:
            for c in cat_cols:
                if 2 <= c.distinct <= max(2, n // 2):
                    good_cat = c
                    break

        if good_cat:
            mapping = {"target": target, "category": good_cat.name,
                       "time": time_cols[0].name}
            return ForecastPlan(True, "categorical_growth", mapping, {}, 1,
                                f"grouping column '{good_cat.name}' repeats over time")

        if time_cols and n >= 8:
            return ForecastPlan(True, "holt_winters",
                                {"target": target, "time": time_cols[0].name},
                                {"season": 4}, 1, "time series with enough cycles")
        if time_cols and n >= 4:
            return ForecastPlan(True, "seasonal_naive",
                                {"target": target, "time": time_cols[0].name},
                                {"season": 4}, 1, "short seasonal series")
        return ForecastPlan(True, "linear_trend", {"target": target}, {}, 1,
                            "default trend")
