"""
app/orchestrator.py
Top-level pipeline. Chains the three stages and enforces the core invariant:
nothing that touches Azure OpenAI carries PHI or result rows.
"""
from dataclasses import dataclass, field
from typing import List, Optional

from app.agent import SQLAgent
from app.feedback_store import FeedbackStore
from app.gatekeeper import Gatekeeper
from app.guardrails import Guardrails
from app.llm_client import LLMClient
from app.prediction import Predictor, PredictionResult
from app.pruner import SchemaPruner
from config.settings import settings


@dataclass
class PipelineResponse:
    status: str                      # "ok" | "blocked" | "no_match" | "failed"
    message: str = ""
    sql: str = ""
    columns: List[str] = field(default_factory=list)
    rows: list = field(default_factory=list)
    phi_found: List[str] = field(default_factory=list)
    tables_used: List[str] = field(default_factory=list)
    prediction: Optional[PredictionResult] = None
    examples_used: int = 0
    trace: List[str] = field(default_factory=list)


class Orchestrator:
    def __init__(self, db_executor):
        self.gatekeeper = Gatekeeper(fail_closed=settings.PHI_FAIL_CLOSED)
        self.pruner = SchemaPruner(
            settings.SCHEMA_CATALOG_PATH, settings.LOCAL_EMBEDDING_MODEL
        )
        self.feedback = FeedbackStore(
            settings.FEEDBACK_DIR, settings.LOCAL_EMBEDDING_MODEL,
            prefer_chroma=settings.PREFER_CHROMA,
        )
        # LLM client is constructed lazily so the pipeline can run offline
        # (e.g. tests) up to the point of generation.
        self._llm: Optional[LLMClient] = None
        self.db_executor = db_executor

    @property
    def llm(self) -> LLMClient:
        if self._llm is None:
            self._llm = LLMClient()
        return self._llm

    def handle(self, user_text: str) -> PipelineResponse:
        # ---- STAGE 1a: PHI gatekeeper (local) ----
        gate = self.gatekeeper.process(user_text)
        if gate.blocked:
            return PipelineResponse(
                status="blocked", message=gate.block_reason, phi_found=gate.phi_found
            )
        sanitized = gate.sanitized_text

        # ---- STAGE 1b: prune schema + relationship graph (local) ----
        pruned = self.pruner.prune(sanitized, top_k=settings.SEMANTIC_TOP_K)
        if not pruned.tables:
            return PipelineResponse(
                status="no_match",
                message="No tables matched the request.",
                phi_found=gate.phi_found,
            )
        schema_ddl = self.pruner.render_schema(pruned.tables)

        # ---- STAGE 2: agentic generate -> guard -> validate -> execute ----
        guardrails = Guardrails(
            allowed_tables=pruned.tables,
            dialect=settings.DB_DIALECT,
            row_limit=settings.DEFAULT_ROW_LIMIT,
        )
        # ---- Retrieve similar PAST SUCCESSFUL queries (local, prompt-safe) ----
        examples = self.feedback.find_similar_successful(
            sanitized, k=settings.FEWSHOT_K
        )

        agent = SQLAgent(
            llm=self.llm, guardrails=guardrails,
            catalog=self.pruner.catalog, db_executor=self.db_executor,
            pruner=self.pruner,
        )
        agent_res = agent.run(
            sanitized, schema_ddl, pruned.join_paths, tables=pruned.tables,
            examples=examples,
        )

        if not agent_res.success:
            # Record the failure too - useful analytics, and avoids re-suggesting.
            self.feedback.add(
                raw_message=user_text, sanitized_message=sanitized,
                sql="", success=False, error=agent_res.error,
                result_columns=[], row_count=0,
                tables_used=agent_res.tables_used,
            )
            return PipelineResponse(
                status="failed", message=agent_res.error,
                phi_found=gate.phi_found,
                tables_used=sorted(pruned.tables), trace=agent_res.trace,
                examples_used=len(examples),
            )

        # ---- STAGE 3: multi-model forecast (local; narration on aggregates) ----
        predictor = Predictor(llm=self.llm)
        prediction = predictor.predict(
            sanitized, agent_res.columns, agent_res.rows
        )

        # ---- Record the SUCCESSFUL query for future few-shot retrieval ----
        # Stores raw_message for YOUR analytics; only sanitized + SQL are ever
        # surfaced back into prompts. Result ROWS are never stored.
        self.feedback.add(
            raw_message=user_text, sanitized_message=sanitized,
            sql=agent_res.sql, success=True, error="",
            result_columns=agent_res.columns, row_count=len(agent_res.rows),
            tables_used=agent_res.tables_used,
        )

        return PipelineResponse(
            status="ok",
            sql=agent_res.sql,
            columns=agent_res.columns,
            rows=agent_res.rows,
            phi_found=gate.phi_found,
            tables_used=sorted(pruned.tables),
            prediction=prediction if prediction.forecastable else None,
            examples_used=len(examples),
            trace=agent_res.trace,
        )
