"""
app/prediction.py
Stage 3: Multi-model forecast layer.

Flow:
  1. Profile result columns (metadata only -> safe to share).
  2. ModelSelector (agent) picks a model + column->role mapping + params.
  3. Resolve the mapped columns from the REAL rows (local) and run the model.
  4. Narrate using aggregates only.

Row values never go to the LLM; only column metadata and aggregate outputs do.
"""
import re
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import List, Optional

from app.forecast_models import MODEL_RUNNERS, MODEL_SPECS, ForecastOutput
from app.llm_client import LLMClient
from app.model_selector import ModelSelector, ForecastPlan, profile_columns


FUTURE_KEYWORDS = [
    "predict", "forecast", "future", "next", "projection", "expected",
    "will be", "upcoming", "estimate", "trend",
]


@dataclass
class PredictionResult:
    forecastable: bool
    model: str = ""
    mapping: dict = field(default_factory=dict)
    params: dict = field(default_factory=dict)
    reason: str = ""
    output: Optional[ForecastOutput] = None
    narrative: str = ""


def _has_future_intent(intent: str) -> bool:
    t = intent.lower()
    return any(k in t for k in FUTURE_KEYWORDS)


def _col_index(columns: List[str], name: str) -> int:
    return columns.index(name) if name in columns else -1


def _resolve_mapping(columns, rows, plan: ForecastPlan):
    """Pull the real column values for each mapped role. Sorts by time if given."""
    idx = {role: _col_index(columns, col) for role, col in plan.mapping.items()}

    # Order rows by the time column when present (so the series is chronological).
    order = list(range(len(rows)))
    if "time" in idx and idx["time"] >= 0:
        ti = idx["time"]
        def _key(r):
            v = rows[r][ti]
            if isinstance(v, (date, datetime)):
                return v.isoformat()
            return str(v)
        order = sorted(order, key=_key)

    data = {}
    if "target" in idx and idx["target"] >= 0:
        data["target"] = [float(rows[r][idx["target"]]) for r in order]
    if "time" in idx and idx["time"] >= 0:
        data["time"] = [rows[r][idx["time"]] for r in order]
    if "category" in idx and idx["category"] >= 0:
        data["category"] = [rows[r][idx["category"]] for r in order]
    return data


class Predictor:
    def __init__(self, llm: Optional[LLMClient] = None):
        self.llm = llm
        self.selector = ModelSelector(llm=llm)

    def predict(self, intent: str, columns: List[str], rows: list) -> PredictionResult:
        if len(rows) < 2 or not columns:
            return PredictionResult(forecastable=False, reason="not enough rows")

        # 1. Profile (metadata only)
        profiles = profile_columns(columns, rows)

        # Skip if clearly not a forecasting context and the data isn't obviously
        # a time series. (A single aggregate count, etc.)
        numeric = [p for p in profiles if p.dtype == "numeric"]
        if not numeric:
            return PredictionResult(forecastable=False, reason="no numeric column")
        if not _has_future_intent(intent) and len(rows) < 4:
            return PredictionResult(forecastable=False, reason="no forecast intent")

        # 2. Agent picks model + mapping (sees metadata only)
        plan = self.selector.select(intent, profiles)
        if not plan.use_forecast:
            return PredictionResult(forecastable=False, reason=plan.reason)

        runner = MODEL_RUNNERS.get(plan.model)
        if runner is None:
            return PredictionResult(forecastable=False,
                                    reason=f"unknown model '{plan.model}'")

        # 3. Resolve real columns + run locally
        data = _resolve_mapping(columns, rows, plan)
        if "target" not in data or len(data["target"]) < MODEL_SPECS[plan.model].min_points:
            return PredictionResult(forecastable=False,
                                    reason="target series too short for chosen model")
        output = runner(data, plan.horizon, plan.params)

        result = PredictionResult(
            forecastable=True, model=plan.model, mapping=plan.mapping,
            params=plan.params, reason=plan.reason, output=output,
        )

        # 4. Narrate on aggregates only
        if self.llm:
            result.narrative = self._narrate(intent, output)
        return result

    def _narrate(self, intent: str, output: ForecastOutput) -> str:
        system = ("Explain a forecast in 2-3 plain sentences using only the "
                  "aggregate numbers given. Do not invent data.")
        safe_intent = re.sub(r"\[[A-Z_]+_REDACTED\]", "the requested metric", intent)
        if output.by_category:
            summary = {c: {"last": v["history"][-1], "next": v["forecast"][0]}
                       for c, v in list(output.by_category.items())[:10]}
            payload = f"Per-category last vs next: {summary}"
        else:
            payload = (f"History (oldest->newest): {output.history}\n"
                       f"Forecast: {output.forecast}")
        user = (f"Request: {safe_intent}\nModel: {output.model}\n{payload}\n"
                f"{output.notes}\nWrite a short explanation.")
        try:
            return self.llm.complete(system, user)
        except Exception:
            if output.by_category:
                return (f"Forecast generated per category using {output.model}.")
            trend = ("increasing" if output.forecast and output.history and
                     output.forecast[0] > output.history[-1] else "changing")
            return (f"Using {output.model}, the metric is {trend}. "
                    f"Next: {output.forecast[0] if output.forecast else 'n/a'}.")
