"""
app/pruner.py
Stage 1b: Schema pruning + relationship graph.

1. Keyword match across ALL tables (hot + cold) using the metadata file.
2. Semantic search over NON-HOT (cold) tables only, using a LOCAL embedding
   model so the sanitized intent text never leaves the environment.
3. Build a relationship graph and add bridge tables so joins resolve.

Output: the set of tables (matched + bridges) and the join paths.
"""
import json
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple

import networkx as nx
import numpy as np

# Local embedding model (no cloud call). Optional import.
try:
    from sentence_transformers import SentenceTransformer
    _ST_AVAILABLE = True
except ImportError:
    _ST_AVAILABLE = False


@dataclass
class PrunerResult:
    tables: Set[str] = field(default_factory=set)
    join_paths: List[str] = field(default_factory=list)
    graph: nx.Graph = None
    keyword_hits: Set[str] = field(default_factory=set)
    semantic_hits: Set[str] = field(default_factory=set)
    bridge_tables: Set[str] = field(default_factory=set)


class SchemaPruner:
    def __init__(self, catalog_path: str, embedding_model_name: str):
        with open(catalog_path) as f:
            self.catalog: Dict = json.load(f)

        self.hot_tables = {t for t, m in self.catalog.items() if m.get("is_hot")}
        self.cold_tables = {t for t, m in self.catalog.items() if not m.get("is_hot")}

        # Build local embedding index over cold tables only.
        self._model = None
        self._cold_index: List[Tuple[str, np.ndarray]] = []
        if _ST_AVAILABLE:
            self._model = SentenceTransformer(embedding_model_name)
            self._build_cold_index()

    def _table_text(self, table: str) -> str:
        meta = self.catalog[table]
        cols = "; ".join(
            f"{c}: {', '.join(cm.get('keywords', []))}"
            for c, cm in meta["columns"].items()
        )
        return f"{table}. {meta['description']} Columns: {cols}"

    def _build_cold_index(self):
        for table in self.cold_tables:
            emb = self._model.encode(self._table_text(table), normalize_embeddings=True)
            self._cold_index.append((table, emb))

    # ---------- Stage 1b.1: keyword match ----------
    def keyword_match(self, sanitized_query: str) -> Set[str]:
        q = sanitized_query.lower()
        matched = set()
        for table, meta in self.catalog.items():
            if any(kw in q for kw in meta.get("table_keywords", [])):
                matched.add(table)
            for col, cmeta in meta["columns"].items():
                if any(kw in q for kw in cmeta.get("keywords", [])):
                    matched.add(table)
        return matched

    # ---------- Stage 1b.2: semantic search (cold tables, local) ----------
    def semantic_match(self, sanitized_query: str, top_k: int = 5) -> Set[str]:
        if not self._model or not self._cold_index:
            return set()
        q_emb = self._model.encode(sanitized_query, normalize_embeddings=True)
        scored = [(t, float(np.dot(q_emb, emb))) for t, emb in self._cold_index]
        scored.sort(key=lambda x: x[1], reverse=True)
        # Keep only meaningful matches (cosine > 0.3) up to top_k.
        return {t for t, s in scored[:top_k] if s > 0.3}

    # ---------- Stage 1b.3: relationship graph + bridges ----------
    def build_graph(self, tables: Set[str]) -> Tuple[nx.Graph, List[str], Set[str]]:
        """Build FK graph over the full catalog, then connect matched tables."""
        full = nx.Graph()
        for table, meta in self.catalog.items():
            full.add_node(table)
            for col, cmeta in meta["columns"].items():
                if "fk" in cmeta:
                    target_table = cmeta["fk"].split(".")[0]
                    full.add_edge(
                        table, target_table,
                        on=f"{table}.{col} = {cmeta['fk']}",
                    )

        # Find bridge tables needed to connect matched tables together.
        bridges: Set[str] = set()
        matched_list = list(tables)
        for i in range(len(matched_list)):
            for j in range(i + 1, len(matched_list)):
                a, b = matched_list[i], matched_list[j]
                if a in full and b in full and nx.has_path(full, a, b):
                    path = nx.shortest_path(full, a, b)
                    for node in path:
                        if node not in tables:
                            bridges.add(node)

        final_tables = tables | bridges
        subgraph = full.subgraph(final_tables).copy()

        join_paths = [
            data["on"] for _, _, data in subgraph.edges(data=True) if "on" in data
        ]
        return subgraph, sorted(set(join_paths)), bridges

    # ---------- Mid-loop lookup (used by the agent) ----------
    def lookup_tables(self, term: str, limit: int = 5) -> List[str]:
        """Search the WHOLE catalog for tables matching a name/keyword term.
        Used when the agent realizes a needed table wasn't pre-selected.
        Combines exact/substring name match, keyword match, and (if available)
        local semantic similarity. Returns ranked table names.
        """
        t = term.lower().strip()
        scored: Dict[str, float] = {}

        for table, meta in self.catalog.items():
            score = 0.0
            tl = table.lower()
            # name match
            if t == tl:
                score += 5.0
            elif t in tl or tl in t:
                score += 3.0
            # table-level keyword match
            for kw in meta.get("table_keywords", []):
                if t == kw or t in kw or kw in t:
                    score += 2.0
                    break
            # column-level keyword match
            for col, cmeta in meta["columns"].items():
                if t in col.lower():
                    score += 1.0
                for kw in cmeta.get("keywords", []):
                    if t in kw or kw in t:
                        score += 0.5
                        break
            if score > 0:
                scored[table] = score

        # Semantic backstop over all tables if local model is available.
        if self._model:
            q_emb = self._model.encode(term, normalize_embeddings=True)
            for table in self.catalog:
                emb = self._model.encode(self._table_text(table), normalize_embeddings=True)
                sim = float(np.dot(q_emb, emb))
                if sim > 0.35:
                    scored[table] = scored.get(table, 0.0) + sim

        ranked = sorted(scored, key=lambda x: scored[x], reverse=True)
        return ranked[:limit]

    def connect_tables(self, known: Set[str], new_table: str):
        """Find the join path(s) connecting `new_table` to the known set,
        pulling in any intermediate bridge tables. Returns
        (all_tables, join_paths)."""
        if new_table not in self.catalog:
            return known, []

        full = nx.Graph()
        for table, meta in self.catalog.items():
            full.add_node(table)
            for col, cmeta in meta["columns"].items():
                if "fk" in cmeta:
                    target = cmeta["fk"].split(".")[0]
                    full.add_edge(table, target, on=f"{table}.{col} = {cmeta['fk']}")

        tables = set(known) | {new_table}
        bridges: Set[str] = set()
        for anchor in known:
            if anchor in full and new_table in full and nx.has_path(full, anchor, new_table):
                for node in nx.shortest_path(full, anchor, new_table):
                    if node not in tables:
                        bridges.add(node)

        tables |= bridges
        sub = full.subgraph(tables).copy()
        joins = sorted({d["on"] for _, _, d in sub.edges(data=True) if "on" in d})
        return tables, joins

    # ---------- Orchestration ----------
    def prune(self, sanitized_query: str, top_k: int = 5) -> PrunerResult:
        keyword_hits = self.keyword_match(sanitized_query)
        semantic_hits = self.semantic_match(sanitized_query, top_k=top_k)
        matched = keyword_hits | semantic_hits

        if not matched:
            return PrunerResult()  # nothing matched

        graph, join_paths, bridges = self.build_graph(matched)
        return PrunerResult(
            tables=matched | bridges,
            join_paths=join_paths,
            graph=graph,
            keyword_hits=keyword_hits,
            semantic_hits=semantic_hits,
            bridge_tables=bridges,
        )

    def render_schema(self, tables: Set[str]) -> str:
        """Render selected tables as DDL-like text for the SQL generator."""
        blocks = []
        for table in sorted(tables):
            meta = self.catalog.get(table)
            if not meta:
                continue
            lines = []
            for col, cmeta in meta["columns"].items():
                tags = []
                if cmeta.get("pk"):
                    tags.append("PK")
                if cmeta.get("fk"):
                    tags.append(f"FK->{cmeta['fk']}")
                tag_str = f" [{', '.join(tags)}]" if tags else ""
                lines.append(f"  {col} {cmeta.get('type','')}{tag_str}")
            blocks.append(f"TABLE {table} (\n" + "\n".join(lines) + "\n)")
        return "\n\n".join(blocks)
