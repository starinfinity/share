"""
config/settings.py
Central configuration. All secrets come from environment variables.
"""
import os


class Settings:
    # --- Azure OpenAI ---
    AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_KEY", "")
    AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
    AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-5.5")

    # --- Database (Azure SQL) ---
    # Use a LEAST-PRIVILEGE, SELECT-only DB user here.
    DB_CONNECTION_STRING = os.getenv("DB_CONNECTION_STRING", "")
    DB_DIALECT = "tsql"

    # --- Local embedding model (keeps intent text out of the cloud) ---
    LOCAL_EMBEDDING_MODEL = os.getenv("LOCAL_EMBEDDING_MODEL", "BAAI/bge-small-en-v1.5")

    # --- Agentic loop ---
    MAX_SQL_RETRIES = 3
    DEFAULT_ROW_LIMIT = 1000

    # --- Paths ---
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    SCHEMA_CATALOG_PATH = os.path.join(BASE_DIR, "data", "schema_catalog.json")

    # --- Feedback / learning store (PERSISTENT, file-based vector DB) ---
    # Survives app restarts. Uses ChromaDB persistent if installed, else a
    # persistent pickle file. The raw_message field may contain PHI -> this
    # directory MUST be encrypted at rest and access-controlled. Only
    # sanitized_message + SQL are ever surfaced into prompts.
    FEEDBACK_DIR = os.path.join(BASE_DIR, "data", "feedback")
    PREFER_CHROMA = True
    FEWSHOT_K = 3                 # how many past examples to inject
    FEWSHOT_MIN_SCORE = 0.55      # similarity threshold

    # --- PHI gatekeeper ---
    # If PHI detector confidence is below this, fail CLOSED (reject request).
    PHI_FAIL_CLOSED = True
    SEMANTIC_TOP_K = 5


settings = Settings()
