import React from 'react';
import { Message } from '../types/chat';
import { useTheme } from '../contexts/ThemeContext';
import ResultDisplay from './ResultDisplay';
import SqlQueryDisplay from './SqlQueryDisplay';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const { theme } = useTheme();
  const isUser = message.type === 'user';

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-[80%] ${isUser ? 'order-2' : 'order-1'}`}>
        <div className={`rounded-2xl px-4 py-3 ${
          isUser
            ? theme === 'dark'
              ? 'bg-rose-600 text-white'
              : 'bg-rose-500 text-white'
            : theme === 'dark'
              ? 'bg-slate-700 text-slate-100'
              : 'bg-white text-slate-800 border border-rose-200'
        }`}>
          <p className="whitespace-pre-wrap">{message.content}</p>
        </div>
        
        {/* Result Display */}
        {message.resultType && (
          <div className="mt-3">
            <ResultDisplay
              resultType={message.resultType}
              tableData={message.tableData}
              fileData={message.fileData}
            />
          </div>
        )}
        
        {/* SQL Query Display */}
        {message.sqlQuery && (
          <div className="mt-3">
            <SqlQueryDisplay query={message.sqlQuery} />
          </div>
        )}
        
        <div className={`text-xs mt-2 ${
          theme === 'dark' ? 'text-slate-400' : 'text-slate-500'
        } ${isUser ? 'text-right' : 'text-left'}`}>
          {message.timestamp.toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;