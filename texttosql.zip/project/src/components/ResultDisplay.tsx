import React from 'react';
import { TableData, FileData } from '../types/chat';
import { useTheme } from '../contexts/ThemeContext';
import { Download, FileText } from 'lucide-react';

interface ResultDisplayProps {
  resultType: 'text' | 'table' | 'file';
  tableData?: TableData;
  fileData?: FileData;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ resultType, tableData, fileData }) => {
  const { theme } = useTheme();

  if (resultType === 'table' && tableData) {
    return (
      <div className={`rounded-lg overflow-hidden border ${
        theme === 'dark' 
          ? 'bg-slate-800 border-slate-600' 
          : 'bg-white border-rose-200'
      }`}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className={`${
              theme === 'dark' ? 'bg-slate-700' : 'bg-rose-50'
            }`}>
              <tr>
                {tableData.columns.map((column, index) => (
                  <th key={index} className={`px-4 py-3 text-left text-sm font-semibold ${
                    theme === 'dark' ? 'text-slate-200' : 'text-slate-700'
                  }`}>
                    {column}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tableData.rows.map((row, rowIndex) => (
                <tr key={rowIndex} className={`border-t ${
                  theme === 'dark' ? 'border-slate-600' : 'border-rose-200'
                }`}>
                  {row.map((cell, cellIndex) => (
                    <td key={cellIndex} className={`px-4 py-3 text-sm ${
                      theme === 'dark' ? 'text-slate-300' : 'text-slate-600'
                    }`}>
                      {cell}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  if (resultType === 'file' && fileData) {
    return (
      <div className={`rounded-lg border p-4 ${
        theme === 'dark' 
          ? 'bg-slate-800 border-slate-600' 
          : 'bg-white border-rose-200'
      }`}>
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${
            theme === 'dark' ? 'bg-slate-700' : 'bg-rose-100'
          }`}>
            <FileText size={20} className={
              theme === 'dark' ? 'text-slate-300' : 'text-rose-600'
            } />
          </div>
          <div className="flex-1">
            <h4 className={`font-medium ${
              theme === 'dark' ? 'text-slate-200' : 'text-slate-800'
            }`}>
              {fileData.name}
            </h4>
            <p className={`text-sm ${
              theme === 'dark' ? 'text-slate-400' : 'text-slate-600'
            }`}>
              {fileData.type} • {fileData.size}
            </p>
          </div>
          <button className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
            theme === 'dark'
              ? 'bg-rose-600 text-white hover:bg-rose-700'
              : 'bg-rose-500 text-white hover:bg-rose-600'
          }`}>
            <Download size={16} />
            <span className="text-sm">Download</span>
          </button>
        </div>
      </div>
    );
  }

  return null;
};

export default ResultDisplay;