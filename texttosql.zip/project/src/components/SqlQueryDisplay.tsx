import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Code } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

interface SqlQueryDisplayProps {
  query: string;
}

const SqlQueryDisplay: React.FC<SqlQueryDisplayProps> = ({ query }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const { theme } = useTheme();

  return (
    <div className={`rounded-lg border ${
      theme === 'dark' 
        ? 'bg-slate-800 border-slate-600' 
        : 'bg-white border-rose-200'
    }`}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className={`w-full flex items-center justify-between p-3 text-left transition-colors ${
          theme === 'dark' 
            ? 'hover:bg-slate-700 text-slate-300' 
            : 'hover:bg-rose-50 text-slate-700'
        }`}
      >
        <div className="flex items-center space-x-2">
          <Code size={16} />
          <span className="text-sm font-medium">SQL Query</span>
        </div>
        {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
      </button>
      
      {isExpanded && (
        <div className={`border-t p-4 ${
          theme === 'dark' ? 'border-slate-600' : 'border-rose-200'
        }`}>
          <pre className={`text-sm overflow-x-auto ${
            theme === 'dark' ? 'text-slate-300' : 'text-slate-700'
          }`}>
            <code className="language-sql">{query}</code>
          </pre>
        </div>
      )}
    </div>
  );
};

export default SqlQueryDisplay;